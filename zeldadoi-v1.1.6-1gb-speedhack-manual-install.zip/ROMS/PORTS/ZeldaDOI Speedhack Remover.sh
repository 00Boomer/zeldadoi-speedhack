#!/bin/bash
set +u
set -o pipefail
umask 077
D=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd -P) || exit 2
K=""
for P in "$D" "$D/../ports" "$D/../../ports"; do
  if [ -f "$P/zeldadoi-speedhack-v6-lease-tools-15fd1403/v6-candidate-portmaster-manifest.json" ] && [ ! -L "$P/zeldadoi-speedhack-v6-lease-tools-15fd1403" ]; then
    K="$P/zeldadoi-speedhack-v6-lease-tools-15fd1403"; break
  fi
done
[ -n "$K" ] || { printf 'Private V6 package not found\n'; exit 2; }
K=$(CDPATH='' cd -- "$K" && pwd -P) || exit 2
PORTS=$(dirname -- "$K")
if [ "$(basename -- "$PORTS")" != ports ]; then
  LOWER="$(dirname -- "$PORTS")/ports"
  if [ -d "$LOWER" ] && [ ! -L "$LOWER" ] && [ "$PORTS" -ef "$LOWER" ]; then
    PORTS="$LOWER"
    K="$PORTS/${K##*/}"
  fi
fi
[ "$(basename -- "$PORTS")" = ports ] || { printf 'Lowercase ports root required\n'; exit 2; }
[ -d "$K/LICENSES" ] && [ ! -L "$K/LICENSES" ] || exit 2
[ -d "$K/artifacts" ] && [ ! -L "$K/artifacts" ] || exit 2
[ -d "$K/config" ] && [ ! -L "$K/config" ] || exit 2
[ -d "$K/device" ] && [ ! -L "$K/device" ] || exit 2
[ -d "$K/manifests" ] && [ ! -L "$K/manifests" ] || exit 2
[ -d "$K/scripts" ] && [ ! -L "$K/scripts" ] || exit 2
[ -d "$K/third_party" ] && [ ! -L "$K/third_party" ] || exit 2
[ -d "$K/device/tools" ] && [ ! -L "$K/device/tools" ] || exit 2
[ -d "$K/third_party/jeod-rhh-speedhack" ] && [ ! -L "$K/third_party/jeod-rhh-speedhack" ] || exit 2
[ -f "$K/v6-candidate-portmaster-manifest.json" ] && [ ! -L "$K/v6-candidate-portmaster-manifest.json" ] || exit 2
printf '%s  %s\n' '0645e1a565e5c27e6a06945e368efa48c13e5fcec46c4cd4311f413b2a9a4dd2' "$K/v6-candidate-portmaster-manifest.json" | sha256sum -c - || exit 2
[ -f "$K/LICENSE" ] && [ ! -L "$K/LICENSE" ] || exit 2
printf '%s  %s\n' 'd768a13e9bb1ef595fb8e4186f47cdcd6bcf4ed4bf51ca608238d1589d5575c8' "$K/LICENSE" | sha256sum -c - || exit 2
[ -f "$K/LICENSES/GMLoader-Next-upstream-LICENSE.md" ] && [ ! -L "$K/LICENSES/GMLoader-Next-upstream-LICENSE.md" ] || exit 2
printf '%s  %s\n' '5d05a329bdd65bc1212fda57942ea90a2a810ff7ce192dc38d7042a55caa4a28' "$K/LICENSES/GMLoader-Next-upstream-LICENSE.md" | sha256sum -c - || exit 2
[ -f "$K/README.md" ] && [ ! -L "$K/README.md" ] || exit 2
printf '%s  %s\n' 'd98be2a64d8f01e38d72e37300c79ceec24d4a086c8de9ed3187a98022840fbc' "$K/README.md" | sha256sum -c - || exit 2
[ -f "$K/THIRD_PARTY_NOTICES.md" ] && [ ! -L "$K/THIRD_PARTY_NOTICES.md" ] || exit 2
printf '%s  %s\n' '749670bc52ae1e285c9e9b1529a4b13d2dd7177ee355e766532dbb75b336868d' "$K/THIRD_PARTY_NOTICES.md" | sha256sum -c - || exit 2
[ -f "$K/artifacts/authority.json" ] && [ ! -L "$K/artifacts/authority.json" ] || exit 2
printf '%s  %s\n' 'fc96a3da110cc3c0dada79e1303210dae93a319121aae0e021ee0d86c30d2b02' "$K/artifacts/authority.json" | sha256sum -c - || exit 2
[ -f "$K/artifacts/game.xdelta" ] && [ ! -L "$K/artifacts/game.xdelta" ] || exit 2
printf '%s  %s\n' 'e53d6572ef97947cc17e992973632c8c3cd49d9869a2d37b4728bd2a2bc9ee99' "$K/artifacts/game.xdelta" | sha256sum -c - || exit 2
[ -f "$K/artifacts/generated-cache-contract.json" ] && [ ! -L "$K/artifacts/generated-cache-contract.json" ] || exit 2
printf '%s  %s\n' 'bd1a040b745d82a5970b663bbd5c82fa7549e357fbbe6148c25a33c17fd3a5f9' "$K/artifacts/generated-cache-contract.json" | sha256sum -c - || exit 2
[ -f "$K/artifacts/gmloader-e9a7992-d2a1ec8b-source-core.zip" ] && [ ! -L "$K/artifacts/gmloader-e9a7992-d2a1ec8b-source-core.zip" ] || exit 2
printf '%s  %s\n' 'b46de696c5b762124dda09a769a7be908db5dbb0ffe6f865b5b8f179aa771bd6' "$K/artifacts/gmloader-e9a7992-d2a1ec8b-source-core.zip" | sha256sum -c - || exit 2
[ -f "$K/artifacts/gmloader-e9a7992-d2a1ec8b-source-docs.zip" ] && [ ! -L "$K/artifacts/gmloader-e9a7992-d2a1ec8b-source-docs.zip" ] || exit 2
printf '%s  %s\n' '7ca5ab73309000b6eecec08ef3d21a5271fb3f48644f193379113573e32f8ef5' "$K/artifacts/gmloader-e9a7992-d2a1ec8b-source-docs.zip" | sha256sum -c - || exit 2
[ -f "$K/artifacts/gmloader-seeded.json" ] && [ ! -L "$K/artifacts/gmloader-seeded.json" ] || exit 2
printf '%s  %s\n' '730d21e17a0e1ccd66894c5e8a805b24cc1accdf3ba930e1a1ed14eff75a7aac' "$K/artifacts/gmloader-seeded.json" | sha256sum -c - || exit 2
[ -f "$K/artifacts/gmloadernext.aarch64" ] && [ ! -L "$K/artifacts/gmloadernext.aarch64" ] || exit 2
printf '%s  %s\n' 'd2a1ec8b284b2fe2e99732e0d5396daa745c0f2992eb19cd4d661c73793f4bf0' "$K/artifacts/gmloadernext.aarch64" | sha256sum -c - || exit 2
[ -f "$K/artifacts/options_override.default.ini" ] && [ ! -L "$K/artifacts/options_override.default.ini" ] || exit 2
printf '%s  %s\n' 'f4a7824c82551eb5d61208b3cedd5d80d7615faa8776029954b3a34d1821cfa6' "$K/artifacts/options_override.default.ini" | sha256sum -c - || exit 2
[ -f "$K/artifacts/runtime-authority.json" ] && [ ! -L "$K/artifacts/runtime-authority.json" ] || exit 2
printf '%s  %s\n' '533d4bc8745d35f6a2b3b35a26a3aa49572bd55e29db4c0647311d82b1b129cf' "$K/artifacts/runtime-authority.json" | sha256sum -c - || exit 2
[ -f "$K/artifacts/xdelta3-aarch64" ] && [ ! -L "$K/artifacts/xdelta3-aarch64" ] || exit 2
printf '%s  %s\n' '74a6cb55ed600b2315d37c8273d7aae4041915bddfad47a6a834387f50283148' "$K/artifacts/xdelta3-aarch64" | sha256sum -c - || exit 2
[ -f "$K/config/options-override-schema.json" ] && [ ! -L "$K/config/options-override-schema.json" ] || exit 2
printf '%s  %s\n' '613ee717877c82b462740e7c617768aab51ce9a0cf9d3aac4faacdd6555c52f7' "$K/config/options-override-schema.json" | sha256sum -c - || exit 2
[ -f "$K/config/options_override.release-crt-v1.default.ini" ] && [ ! -L "$K/config/options_override.release-crt-v1.default.ini" ] || exit 2
printf '%s  %s\n' 'f4a7824c82551eb5d61208b3cedd5d80d7615faa8776029954b3a34d1821cfa6' "$K/config/options_override.release-crt-v1.default.ini" | sha256sum -c - || exit 2
[ -f "$K/config/owned-v6-native-candidate-binding-v1.json" ] && [ ! -L "$K/config/owned-v6-native-candidate-binding-v1.json" ] || exit 2
printf '%s  %s\n' '434e159dbd34316676fa745db8a091087229b82a87cf7a8ed1e9c52258867081' "$K/config/owned-v6-native-candidate-binding-v1.json" | sha256sum -c - || exit 2
[ -f "$K/config/owned-v6-qualification-native-enrollment-v1.json" ] && [ ! -L "$K/config/owned-v6-qualification-native-enrollment-v1.json" ] || exit 2
printf '%s  %s\n' 'fc96a3da110cc3c0dada79e1303210dae93a319121aae0e021ee0d86c30d2b02' "$K/config/owned-v6-qualification-native-enrollment-v1.json" | sha256sum -c - || exit 2
[ -f "$K/config/owned-v6-qualification-runtime-authority-v1.json" ] && [ ! -L "$K/config/owned-v6-qualification-runtime-authority-v1.json" ] || exit 2
printf '%s  %s\n' '533d4bc8745d35f6a2b3b35a26a3aa49572bd55e29db4c0647311d82b1b129cf' "$K/config/owned-v6-qualification-runtime-authority-v1.json" | sha256sum -c - || exit 2
[ -f "$K/config/runtime-authority-schema.json" ] && [ ! -L "$K/config/runtime-authority-schema.json" ] || exit 2
printf '%s  %s\n' '0349f35f403d5d61b70253c111160b285a88f2ff66a0125e54135d5ea57e7b71' "$K/config/runtime-authority-schema.json" | sha256sum -c - || exit 2
[ -f "$K/config/runtime-authority-shared-schema-v2.json" ] && [ ! -L "$K/config/runtime-authority-shared-schema-v2.json" ] || exit 2
printf '%s  %s\n' '445228b6091da3a4753c6d0fac8191d956a50bec273a4a51b910f66534aa1050' "$K/config/runtime-authority-shared-schema-v2.json" | sha256sum -c - || exit 2
[ -f "$K/config/runtime-pair-capacity-schema.json" ] && [ ! -L "$K/config/runtime-pair-capacity-schema.json" ] || exit 2
printf '%s  %s\n' '119151d01e04b2edab009df9cbc49400f0f4fba5a919336204fc276a732a3b50' "$K/config/runtime-pair-capacity-schema.json" | sha256sum -c - || exit 2
[ -f "$K/config/v6-release-candidate-selection-v1.json" ] && [ ! -L "$K/config/v6-release-candidate-selection-v1.json" ] || exit 2
printf '%s  %s\n' 'dfa36129ee2ac70fd8fa746d1c6e2a46dbff56a2e49c6dca93f0626aa87cc016' "$K/config/v6-release-candidate-selection-v1.json" | sha256sum -c - || exit 2
[ -f "$K/device/tools/beta_bounded_log_capture_v1.py" ] && [ ! -L "$K/device/tools/beta_bounded_log_capture_v1.py" ] || exit 2
printf '%s  %s\n' 'ff3689c1521d1df79674137f6026dd79824274f6307c63cc3629d5fa7c9bf476' "$K/device/tools/beta_bounded_log_capture_v1.py" | sha256sum -c - || exit 2
[ -f "$K/device/tools/launch_speedhack_beta_v1.py" ] && [ ! -L "$K/device/tools/launch_speedhack_beta_v1.py" ] || exit 2
printf '%s  %s\n' 'fd756b975686968a4ad23785939d650561aab84ea982f9d44ad7200246b914b7' "$K/device/tools/launch_speedhack_beta_v1.py" | sha256sum -c - || exit 2
[ -f "$K/device/tools/materialize_current371_private_payload_v1.py" ] && [ ! -L "$K/device/tools/materialize_current371_private_payload_v1.py" ] || exit 2
printf '%s  %s\n' '50ef5e968842329eba47d0cacb45f27e49f2e12260f554f5fe8d50939e3ad59f' "$K/device/tools/materialize_current371_private_payload_v1.py" | sha256sum -c - || exit 2
[ -f "$K/device/tools/snapshot_ordinary_save_carrier.py" ] && [ ! -L "$K/device/tools/snapshot_ordinary_save_carrier.py" ] || exit 2
printf '%s  %s\n' 'cbf6b79b919283a46872abdabc5d5eef65a64b92d649cdbd5b2da00eb0e0c31c' "$K/device/tools/snapshot_ordinary_save_carrier.py" | sha256sum -c - || exit 2
[ -f "$K/device/tools/speedhack_beta_device_v1.py" ] && [ ! -L "$K/device/tools/speedhack_beta_device_v1.py" ] || exit 2
printf '%s  %s\n' 'e0b266b30e7e690bb9444ebb4dbe071e84a0cca33794eb3038940b0944510389' "$K/device/tools/speedhack_beta_device_v1.py" | sha256sum -c - || exit 2
[ -f "$K/manifests/generated-cache-contract.json" ] && [ ! -L "$K/manifests/generated-cache-contract.json" ] || exit 2
printf '%s  %s\n' 'bd1a040b745d82a5970b663bbd5c82fa7549e357fbbe6148c25a33c17fd3a5f9' "$K/manifests/generated-cache-contract.json" | sha256sum -c - || exit 2
[ -f "$K/scripts/_common.py" ] && [ ! -L "$K/scripts/_common.py" ] || exit 2
printf '%s  %s\n' '63a6abcf72edf2bb94007796562f1ab72c878c2764fdaaf95d670cc041981126' "$K/scripts/_common.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/assemble_bounded_cache_port.py" ] && [ ! -L "$K/scripts/assemble_bounded_cache_port.py" ] || exit 2
printf '%s  %s\n' 'f2539ab2667dd6a94b8bfa639723e5b9e4b3fc5be0dd0cd56ea52c6941968253' "$K/scripts/assemble_bounded_cache_port.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_installer_journal.py" ] && [ ! -L "$K/scripts/bounded_installer_journal.py" ] || exit 2
printf '%s  %s\n' '8c7be94cac1529617af5bfa19c60c86cd208ffe37ea26f4b3f887934bdab015b' "$K/scripts/bounded_installer_journal.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_installer_orchestrator.py" ] && [ ! -L "$K/scripts/bounded_installer_orchestrator.py" ] || exit 2
printf '%s  %s\n' '8eb711aca96afe3535066f22e88450d33f8af29b0e953ead26d19f90b5720b08' "$K/scripts/bounded_installer_orchestrator.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_installer_stage.py" ] && [ ! -L "$K/scripts/bounded_installer_stage.py" ] || exit 2
printf '%s  %s\n' 'f35ea2d9a968f626858e57510bd777ba382e6781f2c95443fcd8f074e8b87c16' "$K/scripts/bounded_installer_stage.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_runtime_lock.py" ] && [ ! -L "$K/scripts/bounded_runtime_lock.py" ] || exit 2
printf '%s  %s\n' '26ff4ea4fe7752a5a7a0df642ecfa86a3196e2bb8d2fcfed47374152610533a3' "$K/scripts/bounded_runtime_lock.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_runtime_pair_activation.py" ] && [ ! -L "$K/scripts/bounded_runtime_pair_activation.py" ] || exit 2
printf '%s  %s\n' '9acba0f4942ef8333f6b189e47529f2dad03d7d420eba2e00cafb76f06497ff3' "$K/scripts/bounded_runtime_pair_activation.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_runtime_pair_install.py" ] && [ ! -L "$K/scripts/bounded_runtime_pair_install.py" ] || exit 2
printf '%s  %s\n' '832e1e2001349fae6c77c40381b4372011219f92e32415732ceade248e7854d5' "$K/scripts/bounded_runtime_pair_install.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_runtime_pair_migrate.py" ] && [ ! -L "$K/scripts/bounded_runtime_pair_migrate.py" ] || exit 2
printf '%s  %s\n' 'ff58a5dcfd5ca9f4ba7a4e8c552e297309b021b045e0f7fa8a81fc45052ebc0c' "$K/scripts/bounded_runtime_pair_migrate.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_runtime_pair_restore.py" ] && [ ! -L "$K/scripts/bounded_runtime_pair_restore.py" ] || exit 2
printf '%s  %s\n' '301d924d146fd92ddadc306bf597020569c1bb95ed0c751d8eae621440eab02e' "$K/scripts/bounded_runtime_pair_restore.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_runtime_pair_stage.py" ] && [ ! -L "$K/scripts/bounded_runtime_pair_stage.py" ] || exit 2
printf '%s  %s\n' 'ec439d56860003f8a0c3777cc64e3fc8de336ae2ee9adee1da49716d2d30ae8c' "$K/scripts/bounded_runtime_pair_stage.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/bounded_runtime_pair_verify.py" ] && [ ! -L "$K/scripts/bounded_runtime_pair_verify.py" ] || exit 2
printf '%s  %s\n' 'fe2bafdacdab9472c71890e2392c9f612db5b9734f22780b64e8e3cc769a1f59' "$K/scripts/bounded_runtime_pair_verify.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/build_runtime_authority.py" ] && [ ! -L "$K/scripts/build_runtime_authority.py" ] || exit 2
printf '%s  %s\n' '90a4f64ea7c22b157200e2e6046f0cc4aaecc1f6418d77bea2479273464cd195' "$K/scripts/build_runtime_authority.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/convert_official_cache_bounded.py" ] && [ ! -L "$K/scripts/convert_official_cache_bounded.py" ] || exit 2
printf '%s  %s\n' 'cb934ee3a8d07cbfe7b80f1239b008d0418ae79fd39d679dcd37822cd8c00302' "$K/scripts/convert_official_cache_bounded.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/install_options_override_default.py" ] && [ ! -L "$K/scripts/install_options_override_default.py" ] || exit 2
printf '%s  %s\n' '653b5054f451a71086e70a0c00013850ce31a6575b67304982fe8f8697d6ec70' "$K/scripts/install_options_override_default.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/install_options_override_default_crt_v1.py" ] && [ ! -L "$K/scripts/install_options_override_default_crt_v1.py" ] || exit 2
printf '%s  %s\n' '4236dbfe59ad2a21a8f39274729ff69c9a8097dd67a9b90a782929fcbd7deb6c' "$K/scripts/install_options_override_default_crt_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_options_override.py" ] && [ ! -L "$K/scripts/launch_with_options_override.py" ] || exit 2
printf '%s  %s\n' '9874819fcb15bbaf16b54559ac459e5e4a897b03e2e1779de0e7bb5cbe1e8cee' "$K/scripts/launch_with_options_override.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_options_override_v2.py" ] && [ ! -L "$K/scripts/launch_with_options_override_v2.py" ] || exit 2
printf '%s  %s\n' 'dfc74f237d1cd6222527a96ff15eaaf8140664a9d693084328d144f61ad4d272' "$K/scripts/launch_with_options_override_v2.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_options_override_v3.py" ] && [ ! -L "$K/scripts/launch_with_options_override_v3.py" ] || exit 2
printf '%s  %s\n' '7d51795f3f7f9129cb59556464eb04aac70d224c946f3ea5b8470fe8521f5f21' "$K/scripts/launch_with_options_override_v3.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_options_override_v4.py" ] && [ ! -L "$K/scripts/launch_with_options_override_v4.py" ] || exit 2
printf '%s  %s\n' 'e7f687326fa99fa15f0ae4a04dc941cd160341d73558c4643fcbd9723aa8868c' "$K/scripts/launch_with_options_override_v4.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_options_override_v5.py" ] && [ ! -L "$K/scripts/launch_with_options_override_v5.py" ] || exit 2
printf '%s  %s\n' '3e47812111d918330ba57e5ad1cc251a4f1375fc504ef2069fbbd1cc322f96a8' "$K/scripts/launch_with_options_override_v5.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_owned_v6_native_v1.py" ] && [ ! -L "$K/scripts/launch_with_owned_v6_native_v1.py" ] || exit 2
printf '%s  %s\n' '10fc25db1dec9fe4c3a7f4dcba5603a2b498a762a16c4fc48ef59c31c7cd54f6' "$K/scripts/launch_with_owned_v6_native_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_shared_runtime_authority_v3.py" ] && [ ! -L "$K/scripts/launch_with_shared_runtime_authority_v3.py" ] || exit 2
printf '%s  %s\n' 'a2eb54886fb05b472fceed6d4b857fec85af624cebb92fcb0d6dcecd0e83fe14' "$K/scripts/launch_with_shared_runtime_authority_v3.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_shared_runtime_authority_v4.py" ] && [ ! -L "$K/scripts/launch_with_shared_runtime_authority_v4.py" ] || exit 2
printf '%s  %s\n' '824ccfdc5bbcd2db1e88f97dcbe1f9a393ce01255a33d5278e9a90f41368d74d' "$K/scripts/launch_with_shared_runtime_authority_v4.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_shared_runtime_authority_v5.py" ] && [ ! -L "$K/scripts/launch_with_shared_runtime_authority_v5.py" ] || exit 2
printf '%s  %s\n' '2d0129e37ece8cb4ea611f75cdda76d9dbab4c63a16ad3ce3cbe698f6a029f54' "$K/scripts/launch_with_shared_runtime_authority_v5.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/launch_with_shared_runtime_authority_v6.py" ] && [ ! -L "$K/scripts/launch_with_shared_runtime_authority_v6.py" ] || exit 2
printf '%s  %s\n' '64a0ce611ac5a4146e9592e7f94b8e9e5b171805a71d491192cc90c1bedb8ac6' "$K/scripts/launch_with_shared_runtime_authority_v6.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/lossless_data_format.py" ] && [ ! -L "$K/scripts/lossless_data_format.py" ] || exit 2
printf '%s  %s\n' '2e48f53a5f22fcbda1e7efaacf5cfbbe1cd096b3199e65b9f4706c91a6ab4f9a' "$K/scripts/lossless_data_format.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/options_override.py" ] && [ ! -L "$K/scripts/options_override.py" ] || exit 2
printf '%s  %s\n' 'ab1f69c2db340d1f5403c0c9923c930b927300ef027ac526cdae95ef9842ea20' "$K/scripts/options_override.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/options_override_aspect_v2.py" ] && [ ! -L "$K/scripts/options_override_aspect_v2.py" ] || exit 2
printf '%s  %s\n' 'a29072b39971356d6af4091050a2a8f9b02b98d16bb57a1773d92530390dc5b6' "$K/scripts/options_override_aspect_v2.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/options_override_crt_v1.py" ] && [ ! -L "$K/scripts/options_override_crt_v1.py" ] || exit 2
printf '%s  %s\n' '4b87a461eb5f6c90355408e2d60217aa0150cc4b1fb447c3d8baae0ec7565aff' "$K/scripts/options_override_crt_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/options_override_dungeon_seed_v1.py" ] && [ ! -L "$K/scripts/options_override_dungeon_seed_v1.py" ] || exit 2
printf '%s  %s\n' '0cab10365a9a53e00603f4a6f8eefcb1082ae43e7ed6425aa63b2eeaf88c65a2' "$K/scripts/options_override_dungeon_seed_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/options_override_dungeon_seed_v2.py" ] && [ ! -L "$K/scripts/options_override_dungeon_seed_v2.py" ] || exit 2
printf '%s  %s\n' '2f5df6da44917f4dc3acf28f0b51c6c219d1d8af05ec6fabda8f61194ab091e3' "$K/scripts/options_override_dungeon_seed_v2.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/options_override_filter_v1.py" ] && [ ! -L "$K/scripts/options_override_filter_v1.py" ] || exit 2
printf '%s  %s\n' 'efee3e2103b1ca27e4bd71ba5c477aaa1eba7b140befca8bd015902c444134e8' "$K/scripts/options_override_filter_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/owned_v6_native_authority_v1.py" ] && [ ! -L "$K/scripts/owned_v6_native_authority_v1.py" ] || exit 2
printf '%s  %s\n' '1d5cee85bb7337e4ace469ad60b437c4e8a256d6ce07be2a8af5cdee13e42820' "$K/scripts/owned_v6_native_authority_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/owned_v6_native_component_v1.py" ] && [ ! -L "$K/scripts/owned_v6_native_component_v1.py" ] || exit 2
printf '%s  %s\n' 'f5e8fb4ccf5a39b2f69013a684669cd28a1aa6581e9a4f0cd1a27f8807da535b' "$K/scripts/owned_v6_native_component_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/prepare_owned_v6_root_v1.py" ] && [ ! -L "$K/scripts/prepare_owned_v6_root_v1.py" ] || exit 2
printf '%s  %s\n' '7d35c16a1f25dc11ecf9daf25b64e76cfebcbe0f1aaf767d87689389217a962d' "$K/scripts/prepare_owned_v6_root_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/prepare_portmaster_runtime_log.py" ] && [ ! -L "$K/scripts/prepare_portmaster_runtime_log.py" ] || exit 2
printf '%s  %s\n' '62761704238bff713a6c085ebfe11ac76fb714156741e0e89de68922073aa406' "$K/scripts/prepare_portmaster_runtime_log.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/private_v6_archive_bootstrap_v1.py" ] && [ ! -L "$K/scripts/private_v6_archive_bootstrap_v1.py" ] || exit 2
printf '%s  %s\n' '61892121153af41ed716a6e855d12eb9597c8e0f84c0e5b11a0214baaf9d590b' "$K/scripts/private_v6_archive_bootstrap_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/private_v6_qualification_v1.py" ] && [ ! -L "$K/scripts/private_v6_qualification_v1.py" ] || exit 2
printf '%s  %s\n' '93f53f0a308d1733d2cd3c1a2bf3e82ff4eacd826fecfd3f816126120bcd32da' "$K/scripts/private_v6_qualification_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/render_owned_v6_portmaster_v1.py" ] && [ ! -L "$K/scripts/render_owned_v6_portmaster_v1.py" ] || exit 2
printf '%s  %s\n' 'ab295a0cf6820de5113676a204454bc2841167a46185516632717e2fe6a4e9de' "$K/scripts/render_owned_v6_portmaster_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/runseed_profile_identity.py" ] && [ ! -L "$K/scripts/runseed_profile_identity.py" ] || exit 2
printf '%s  %s\n' '07eb8369f953b2ca7c18cde72cbffc760ad2a97ea839df75a7194835607dca5d' "$K/scripts/runseed_profile_identity.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/runseed_profile_launch_environment_v1.py" ] && [ ! -L "$K/scripts/runseed_profile_launch_environment_v1.py" ] || exit 2
printf '%s  %s\n' '37dc55f2029792bb8bcd9fc57b3162a1ed1e2512330caaae67bd0ec7be1e4afe' "$K/scripts/runseed_profile_launch_environment_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/runtime_authority.py" ] && [ ! -L "$K/scripts/runtime_authority.py" ] || exit 2
printf '%s  %s\n' 'ae2079a9e94549cebcff261c4ce5b7f66ef98a26deaada79777e6d139a6083f0' "$K/scripts/runtime_authority.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/runtime_authority_shared_v2.py" ] && [ ! -L "$K/scripts/runtime_authority_shared_v2.py" ] || exit 2
printf '%s  %s\n' 'ee231a83369e6e088637bf999e86bf240fa172d24c6ce9b2a05f321454aa3ee3' "$K/scripts/runtime_authority_shared_v2.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/runtime_pair_capacity.py" ] && [ ! -L "$K/scripts/runtime_pair_capacity.py" ] || exit 2
printf '%s  %s\n' '68b8f9d2b1223582c99ed5a4c4d228ec0d5620b2fb5fa9d6297444f4c851785a' "$K/scripts/runtime_pair_capacity.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/runtime_pair_shared_adapter_v2.py" ] && [ ! -L "$K/scripts/runtime_pair_shared_adapter_v2.py" ] || exit 2
printf '%s  %s\n' '4bbd1d7fb5f41d59a509e313cb85b44373da5ccbecb3e42967f08224291e9c18' "$K/scripts/runtime_pair_shared_adapter_v2.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/select_shared_runtime_command_v2.py" ] && [ ! -L "$K/scripts/select_shared_runtime_command_v2.py" ] || exit 2
printf '%s  %s\n' '68002c692bf7922218d3179e4067a1dc2eadf1fdd33239c85bab5b03214a98a6' "$K/scripts/select_shared_runtime_command_v2.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/stream_encode_zdlf.py" ] && [ ! -L "$K/scripts/stream_encode_zdlf.py" ] || exit 2
printf '%s  %s\n' 'cb77acd43882291d09d6f34e0ff97b69ecae956cdff0f1f8f23cd3872acc4369' "$K/scripts/stream_encode_zdlf.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/stream_partition_zdlf.py" ] && [ ! -L "$K/scripts/stream_partition_zdlf.py" ] || exit 2
printf '%s  %s\n' '0a51c91cc63ca89f7df3e4b8805fde97a132cfd9345ae600eb2e011ddb74c405' "$K/scripts/stream_partition_zdlf.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/v6_release_candidate_v1.py" ] && [ ! -L "$K/scripts/v6_release_candidate_v1.py" ] || exit 2
printf '%s  %s\n' '893672ef3e3901d50530f19909623e03d583987d7d4d34590691d10d9cf9aaab' "$K/scripts/v6_release_candidate_v1.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/validate_bounded_patch_manifest.py" ] && [ ! -L "$K/scripts/validate_bounded_patch_manifest.py" ] || exit 2
printf '%s  %s\n' '693e61bfac3809ac0ce82cef581122d09e3cdefccac6137e3d45ab0ccdea6228' "$K/scripts/validate_bounded_patch_manifest.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/verify_shared_runtime_pair_v2.py" ] && [ ! -L "$K/scripts/verify_shared_runtime_pair_v2.py" ] || exit 2
printf '%s  %s\n' 'e0e0cc890975b0da3afe45d49ecfcb14c23837ee567da22f96d3d621af07629c' "$K/scripts/verify_shared_runtime_pair_v2.py" | sha256sum -c - || exit 2
[ -f "$K/scripts/zeldadoi_temporary_workspace_v1.py" ] && [ ! -L "$K/scripts/zeldadoi_temporary_workspace_v1.py" ] || exit 2
printf '%s  %s\n' 'd0f9ca2f25a449956b6124dcd1e3504806bb74ff68d6d608fbd1126c4f89d0d5' "$K/scripts/zeldadoi_temporary_workspace_v1.py" | sha256sum -c - || exit 2
[ -f "$K/third_party/jeod-rhh-speedhack/LICENSE" ] && [ ! -L "$K/third_party/jeod-rhh-speedhack/LICENSE" ] || exit 2
printf '%s  %s\n' 'd309ff7f1e5b44bd9a5de9615e277ac3ee49fe06db9023ea2dd939b39af59dd4' "$K/third_party/jeod-rhh-speedhack/LICENSE" | sha256sum -c - || exit 2
find "$K/scripts" "$K/device/tools" -mindepth 1 -print | while IFS= read -r component; do
  case "$component" in
    "$K/device/tools"|"$K/device/tools/beta_bounded_log_capture_v1.py"|"$K/device/tools/launch_speedhack_beta_v1.py"|"$K/device/tools/materialize_current371_private_payload_v1.py"|"$K/device/tools/snapshot_ordinary_save_carrier.py"|"$K/device/tools/speedhack_beta_device_v1.py"|"$K/scripts"|"$K/scripts/_common.py"|"$K/scripts/assemble_bounded_cache_port.py"|"$K/scripts/bounded_installer_journal.py"|"$K/scripts/bounded_installer_orchestrator.py"|"$K/scripts/bounded_installer_stage.py"|"$K/scripts/bounded_runtime_lock.py"|"$K/scripts/bounded_runtime_pair_activation.py"|"$K/scripts/bounded_runtime_pair_install.py"|"$K/scripts/bounded_runtime_pair_migrate.py"|"$K/scripts/bounded_runtime_pair_restore.py"|"$K/scripts/bounded_runtime_pair_stage.py"|"$K/scripts/bounded_runtime_pair_verify.py"|"$K/scripts/build_runtime_authority.py"|"$K/scripts/convert_official_cache_bounded.py"|"$K/scripts/install_options_override_default.py"|"$K/scripts/install_options_override_default_crt_v1.py"|"$K/scripts/launch_with_options_override.py"|"$K/scripts/launch_with_options_override_v2.py"|"$K/scripts/launch_with_options_override_v3.py"|"$K/scripts/launch_with_options_override_v4.py"|"$K/scripts/launch_with_options_override_v5.py"|"$K/scripts/launch_with_owned_v6_native_v1.py"|"$K/scripts/launch_with_shared_runtime_authority_v3.py"|"$K/scripts/launch_with_shared_runtime_authority_v4.py"|"$K/scripts/launch_with_shared_runtime_authority_v5.py"|"$K/scripts/launch_with_shared_runtime_authority_v6.py"|"$K/scripts/lossless_data_format.py"|"$K/scripts/options_override.py"|"$K/scripts/options_override_aspect_v2.py"|"$K/scripts/options_override_crt_v1.py"|"$K/scripts/options_override_dungeon_seed_v1.py"|"$K/scripts/options_override_dungeon_seed_v2.py"|"$K/scripts/options_override_filter_v1.py"|"$K/scripts/owned_v6_native_authority_v1.py"|"$K/scripts/owned_v6_native_component_v1.py"|"$K/scripts/prepare_owned_v6_root_v1.py"|"$K/scripts/prepare_portmaster_runtime_log.py"|"$K/scripts/private_v6_archive_bootstrap_v1.py"|"$K/scripts/private_v6_qualification_v1.py"|"$K/scripts/render_owned_v6_portmaster_v1.py"|"$K/scripts/runseed_profile_identity.py"|"$K/scripts/runseed_profile_launch_environment_v1.py"|"$K/scripts/runtime_authority.py"|"$K/scripts/runtime_authority_shared_v2.py"|"$K/scripts/runtime_pair_capacity.py"|"$K/scripts/runtime_pair_shared_adapter_v2.py"|"$K/scripts/select_shared_runtime_command_v2.py"|"$K/scripts/stream_encode_zdlf.py"|"$K/scripts/stream_partition_zdlf.py"|"$K/scripts/v6_release_candidate_v1.py"|"$K/scripts/validate_bounded_patch_manifest.py"|"$K/scripts/verify_shared_runtime_pair_v2.py"|"$K/scripts/zeldadoi_temporary_workspace_v1.py") ;;
    *) printf 'Unexpected source component: %s\n' "$component"; exit 2 ;;
  esac
done || exit 2
XDG_DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
if [ -f /mnt/mmc/MUOS/PortMaster/control.txt ]; then C=/mnt/mmc/MUOS/PortMaster
elif [ -f /mnt/sdcard/MUOS/PortMaster/control.txt ]; then C=/mnt/sdcard/MUOS/PortMaster
elif [ -f /opt/system/Tools/PortMaster/control.txt ]; then C=/opt/system/Tools/PortMaster
elif [ -f /opt/tools/PortMaster/control.txt ]; then C=/opt/tools/PortMaster
elif [ -f "$XDG_DATA_HOME/PortMaster/control.txt" ]; then C="$XDG_DATA_HOME/PortMaster"
elif [ -f /roms/ports/PortMaster/control.txt ]; then C=/roms/ports/PortMaster
elif [ -f /ROMS/PORTS/PortMaster/control.txt ]; then C=/ROMS/PORTS/PortMaster
else printf 'PortMaster controls not found\n'; exit 2; fi
source "$C/control.txt" || exit 2
[ -n "$CFW_NAME" ] && [ -f "$C/mod_$CFW_NAME.txt" ] && source "$C/mod_$CFW_NAME.txt"
declare -F get_controls >/dev/null || exit 2
get_controls || exit 2
export sdl_controllerconfig GPTOKEYB DEVICE_ARCH
export SDL_GAMECONTROLLERCONFIG="${sdl_controllerconfig:-${SDL_GAMECONTROLLERCONFIG:-}}"
/usr/bin/python3 -I -B "$K/scripts/v6_release_candidate_v1.py" restore \
    --game-dir "$PORTS/zeldadoi-speedhack-v6-lease-15fd1403" --artifacts "$K/artifacts"
status=$?
if declare -F pm_finish >/dev/null; then pm_finish; fi
exit "$status"
