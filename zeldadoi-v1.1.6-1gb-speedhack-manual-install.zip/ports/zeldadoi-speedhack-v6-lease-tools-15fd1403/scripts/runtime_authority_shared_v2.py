"""Strict shared-payload successor;legacy dual-runtime rules stay unchanged.

The existing two installation roles/paths remain transaction-owned aliases of
one exact archive/VM,not separately compiled Random/DungeonSeed/RunSeed games.
Equality of payload bytes is necessary,not proof of in-game mode capability.
"""
import inspect
from pathlib import Path
import runtime_authority as legacy

DEFAULT_SCHEMA = Path(__file__).resolve().parents[1] / 'config/runtime-authority-shared-schema-v2.json'
ARCHITECTURE = 'shared-in-process-seed-modes-v1'
RuntimeAuthorityError = legacy.RuntimeAuthorityError
POLICY = {
    'manifest_requires_exact_key_coverage': True,
    'manifest_may_embed_payload': False,
    'manifest_may_delegate_to_user_configuration': False,
    'default_runtime_may_differ_from_official_source': True,
    'seeded_runtime_must_differ_from_default_runtime': False,
    'logical_roles_must_share_exact_archive_and_game_droid': True,
}


def validate_schema(schema):
    document = legacy._exact_object(schema, legacy.SCHEMA_KEYS | {'runtime_architecture'},
        'shared runtime authority schema')
    if (type(document['schema_version']) is not int or document['schema_version'] != 2 or
        type(document['authority_manifest_schema_version']) is not int or
        document['authority_manifest_schema_version'] != 2 or
        document['runtime_architecture'] != ARCHITECTURE):
        legacy.reject('unsupported shared runtime architecture/version')
    policy = legacy._exact_object(document['policy'], set(POLICY), 'shared runtime policy')
    if policy != POLICY or any(type(value) is not bool for value in policy.values()):
        legacy.reject('shared runtime exact-payload policy changed')
    # Reuse every common path/source/size/algorithm/schema check. This internal
    # validation view is not a changed authority,receipt or observed payload.
    common = dict(document)
    del common['runtime_architecture']
    common.update(schema_version=1, authority_manifest_schema_version=1,
        policy={key: (True if key == 'seeded_runtime_must_differ_from_default_runtime'
                      else value) for key, value in POLICY.items() if key in legacy.POLICY_KEYS})
    legacy._validate_schema(common)
    return document


def load_schema(path=DEFAULT_SCHEMA):
    return validate_schema(legacy._read_regular_utf8_json(Path(path), 65536))


def validation_source():
    body = inspect.getsource(legacy.validate_document)
    for old, new in (
        ('if _same_identity(identities["default"], identities["seeded"]):',
         'if not _same_identity(identities["default"], identities["seeded"]):'),
        ('reject("seeded runtime archive must be distinct from the default archive")',
         'reject("shared logical roles must have identical archive bytes")'),
        ('if identities["default"]["game_droid"] == identities["seeded"]["game_droid"]:',
         'if identities["default"]["game_droid"] != identities["seeded"]["game_droid"]:'),
        ('reject("seeded runtime game.droid must be distinct from the default member")',
         'reject("shared logical roles must have identical game.droid bytes")'),
    ):
        if body.count(old) != 1:
            legacy.reject('shared authority inherited validation seam changed:' + old)
        body = body.replace(old, new, 1)
    return body


def validate_document(document, schema):
    schema = validate_schema(schema)
    authority = legacy._exact_object(document,
        legacy.AUTHORITY_KEYS | {'runtime_architecture'}, 'shared runtime authority')
    if (type(authority['schema_version']) is not int or authority['schema_version'] != 2 or
        authority['runtime_architecture'] != schema['runtime_architecture']):
        legacy.reject('shared runtime authority architecture/version mismatch')
    scope = dict(vars(legacy), _validate_schema=validate_schema,
        AUTHORITY_KEYS=legacy.AUTHORITY_KEYS | {'runtime_architecture'})
    exec(compile(validation_source(), '<strict shared-payload identity successor>', 'exec'), scope)
    return scope['validate_document'](authority, schema)


def load_authority(path, schema_path=DEFAULT_SCHEMA, expected_sha256=None):
    schema = load_schema(schema_path)
    document = legacy._read_regular_utf8_json(Path(path), schema['maximum_authority_bytes'], expected_sha256)
    return validate_document(document, schema)


authority_sha256 = legacy.authority_sha256
