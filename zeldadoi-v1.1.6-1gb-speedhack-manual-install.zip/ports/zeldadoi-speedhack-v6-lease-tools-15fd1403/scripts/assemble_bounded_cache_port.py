#!/usr/bin/env python3
"""Stream an official port, patched VM, and verified cache into a new port."""

from __future__ import annotations

import argparse
import copy
import json
import os
import resource
import re
import sys
import time
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, BinaryIO

from _common import load_json, project_root, sha256_file
from convert_official_cache_bounded import (
    CONTRACT_PATH,
    OWNERSHIP_MANIFEST,
    atomic_activate_no_replace,
    validate_contract,
)

DROID_MEMBER = "assets/game.droid"
DUNGEON_MEMBER = "assets/data/data_d"
ROOM_MEMBER = "assets/data/data_r"
HEX64 = re.compile(r"[0-9a-f]{64}")
CHUNK_BYTES = 1024 * 1024


def copy_stream(source: BinaryIO, destination: BinaryIO) -> int:
    total = 0
    while chunk := source.read(CHUNK_BYTES):
        destination.write(chunk)
        total += len(chunk)
    return total


def verify_file(path: Path, size: int, digest: str, label: str) -> None:
    if (
        type(size) is not int
        or size <= 0
        or HEX64.fullmatch(digest) is None
        or path.is_symlink()
        or not path.is_file()
        or path.stat().st_size != size
        or sha256_file(path) != digest
    ):
        raise ValueError(f"{label} identity mismatch")


def validate_cache_manifest(
    root: Path,
    cache_directory: Path,
    contract_path: Path,
    contract: dict[str, Any],
) -> dict[str, Path]:
    if cache_directory.is_symlink() or not cache_directory.is_dir():
        raise ValueError("cache directory must be a real directory")
    manifest_path = cache_directory / OWNERSHIP_MANIFEST
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError("generated-cache ownership manifest is missing or unsafe")
    manifest = load_json(manifest_path)
    converter_path = root / "scripts/convert_official_cache_bounded.py"
    if (
        manifest.get("schema_version") != 1
        or manifest.get("status") != "contract_verified_generated_cache"
        or manifest.get("profile") != contract["profile"]
        or manifest.get("source") != contract["source"]
        or manifest.get("format") != contract["format"]
        or manifest.get("ownership") != contract["ownership"]
        or manifest.get("generated_files") != contract["generated_files"]
        or manifest.get("generated_file_count") != contract["generated_file_count"]
        or manifest.get("generated_total_bytes") != contract["generated_total_bytes"]
        or manifest.get("generated_content_set_sha256")
        != contract["generated_content_set_sha256"]
        or manifest.get("generator", {}).get("sha256")
        != contract["generator"]["sha256"]
        or manifest.get("converter", {}).get("path")
        != "scripts/convert_official_cache_bounded.py"
        or manifest.get("converter", {}).get("sha256")
        != sha256_file(converter_path)
        or manifest.get("contract", {}).get("sha256") != sha256_file(contract_path)
        or manifest.get("activation", {}).get(
            "all_payload_files_verified_before_activation"
        ) is not True
        or manifest.get("activation", {}).get(
            "existing_output_adopted_or_overwritten"
        ) is not False
    ):
        raise ValueError("generated-cache ownership manifest mismatch")

    expected: dict[str, Path] = {}
    for record in contract["generated_files"]:
        relative = record["relative_path"]
        path = cache_directory.joinpath(*PurePosixPath(relative).parts)
        verify_file(path, record["size"], record["sha256"], relative)
        expected[relative] = path

    allowed_files = set(expected) | {OWNERSHIP_MANIFEST}
    allowed_directories = {"assets", "assets/data"}
    for path in cache_directory.rglob("*"):
        relative = path.relative_to(cache_directory).as_posix()
        if path.is_symlink():
            raise ValueError(f"cache contains symlink: {relative}")
        if path.is_file() and relative not in allowed_files:
            raise ValueError(f"cache contains unexpected file: {relative}")
        if path.is_dir() and relative not in allowed_directories:
            raise ValueError(f"cache contains unexpected directory: {relative}")
    return expected


def partition_order(
    contract: dict[str, Any], member: str
) -> list[dict[str, Any]]:
    records = [
        record
        for record in contract["generated_files"]
        if record["source_member"] == member
    ]
    records.sort(key=lambda record: tuple(record["source_coordinates"]))
    if not records:
        raise ValueError(f"generated-cache contract has no records for {member}")
    return records


def validate_destination(output: Path) -> Path:
    if output.exists() or output.is_symlink():
        raise ValueError("output path already exists")
    if not output.parent.is_dir() or output.parent.is_symlink():
        raise ValueError("output parent must be an existing non-symlink directory")
    stage = output.parent / f"{output.name}.stage-{os.getpid()}"
    if stage.exists() or stage.is_symlink():
        raise ValueError(f"output staging path already exists: {stage}")
    return stage


def assemble(
    official: Path,
    game_droid: Path,
    cache_directory: Path,
    output: Path,
    contract_path: Path,
    *,
    game_droid_size: int,
    game_droid_sha256: str,
    output_size: int,
    output_sha256: str,
    root: Path | None = None,
) -> dict[str, Any]:
    root = (root or project_root()).resolve()
    official = official.absolute()
    game_droid = game_droid.absolute()
    cache_directory = cache_directory.absolute()
    output = output.absolute()
    contract_path = contract_path.absolute()
    if contract_path.is_symlink() or not contract_path.is_file():
        raise ValueError("contract must be a regular non-symlink file")
    contract = load_json(contract_path)
    validate_contract(contract)
    if (
        contract["generator"]["path"] != "scripts/stream_partition_zdlf.py"
        or sha256_file(root / contract["generator"]["path"])
        != contract["generator"]["sha256"]
    ):
        raise ValueError("generated-cache generator identity mismatch")
    source = contract["source"]["official_port"]
    verify_file(official, source["size"], source["sha256"], "official port")
    verify_file(
        game_droid, game_droid_size, game_droid_sha256, "patched game.droid"
    )
    cache_files = validate_cache_manifest(
        root, cache_directory, contract_path, contract
    )
    stage = validate_destination(output)

    started = time.perf_counter()
    copied_source_bytes = 0
    copied_cache_bytes = 0
    written_members = 0
    with zipfile.ZipFile(official, "r") as source_archive, zipfile.ZipFile(
        stage, "w", allowZip64=True
    ) as target_archive:
        source_infos = source_archive.infolist()
        source_names = [info.filename for info in source_infos]
        if len(source_names) != len(set(source_names)):
            raise ValueError("official archive contains duplicate members")
        for name in source_names:
            normalized = PurePosixPath(name.replace("\\", "/"))
            if normalized.is_absolute() or ".." in normalized.parts:
                raise ValueError(f"official archive member path is unsafe: {name!r}")
        for required in (DROID_MEMBER, DUNGEON_MEMBER, ROOM_MEMBER):
            if source_names.count(required) != 1:
                raise ValueError(f"official archive member coverage mismatch: {required}")

        target_archive.comment = source_archive.comment
        for source_info in source_infos:
            replacements = None
            if source_info.filename == DUNGEON_MEMBER:
                replacements = partition_order(contract, DUNGEON_MEMBER)
            elif source_info.filename == ROOM_MEMBER:
                replacements = partition_order(contract, ROOM_MEMBER)
            if replacements is not None:
                for record in replacements:
                    info = copy.copy(source_info)
                    info.filename = record["relative_path"]
                    info.orig_filename = info.filename
                    with target_archive.open(info, "w", force_zip64=True) as destination:
                        with cache_files[info.filename].open("rb") as generated:
                            copied_cache_bytes += copy_stream(generated, destination)
                    written_members += 1
                continue

            info = copy.copy(source_info)
            with target_archive.open(info, "w", force_zip64=True) as destination:
                if source_info.filename == DROID_MEMBER:
                    with game_droid.open("rb") as patched:
                        copy_stream(patched, destination)
                elif not source_info.is_dir():
                    with source_archive.open(source_info, "r") as original:
                        copied_source_bytes += copy_stream(original, destination)
            written_members += 1

    verify_file(stage, output_size, output_sha256, "assembled port")
    atomic_activate_no_replace(stage, output)
    return {
        "status": "bounded_port_assembly_verified",
        "elapsed_seconds": time.perf_counter() - started,
        "peak_rss_kib": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
        "source_archive_bytes_materialized": False,
        "source_member_streaming": True,
        "copy_chunk_bytes": CHUNK_BYTES,
        "copied_unchanged_source_bytes": copied_source_bytes,
        "copied_generated_cache_bytes": copied_cache_bytes,
        "generated_cache_files": len(cache_files),
        "output_members": written_members,
        "output_size": output_size,
        "output_sha256": output_sha256,
        "atomic_activation": True,
        "staging_retained": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--official", type=Path, required=True)
    parser.add_argument("--game-droid", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--contract", type=Path, default=project_root() / CONTRACT_PATH)
    parser.add_argument("--game-droid-size", type=int, required=True)
    parser.add_argument("--game-droid-sha256", required=True)
    parser.add_argument("--output-size", type=int, required=True)
    parser.add_argument("--output-sha256", required=True)
    args = parser.parse_args()
    try:
        result = assemble(
            args.official,
            args.game_droid,
            args.cache_dir,
            args.output,
            args.contract,
            game_droid_size=args.game_droid_size,
            game_droid_sha256=args.game_droid_sha256,
            output_size=args.output_size,
            output_sha256=args.output_sha256,
        )
    except (
        OSError,
        ValueError,
        TypeError,
        KeyError,
        json.JSONDecodeError,
        zipfile.BadZipFile,
    ) as exc:
        print(f"bounded port assembly failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
