#!/usr/bin/env python3
"""Locked schema-2 archive-contained installer transaction orchestrator."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

import bounded_installer_journal as journal
import validate_bounded_patch_manifest as manifest_authority
from bounded_installer_stage import (
    OFFICIAL_DROID_NAME,
    PATCHED_DROID_NAME,
    PRESERVED_SOURCE_NAME,
    cleanup_after_recovery_decision,
    create_owned_stage,
    sha256_file,
)
from bounded_runtime_lock import (
    LOCK_NAME,
    recover_stale_lock as recover_shared_stale_lock,
    runtime_lock,
)
from convert_official_cache_bounded import atomic_activate_no_replace


ACTIVE_NAME = "zeldadoi.port"
PRESERVED_NAME = "zeldadoi.official-v1.1.6.port"
STATE_NAME = ".zeldadoi-speedhack"
CURRENT_NAME = "current"
CURRENT_NEXT_NAME = "current.next"
STATE_INIT_PREFIX = ".zeldadoi-speedhack-init-"
CHUNK_BYTES = 1024 * 1024
INJECTION_POINTS = journal.PHASES + ("after-active-replace",)
CURRENT_FIELDS = (
    "OWNER",
    "SCHEMA_VERSION",
    "PROFILE",
    "PATCH_ID",
    "MANIFEST_SHA256",
    "SOURCE_SHA256",
    "ACTIVE_SHA256",
)


class InjectedInterruption(RuntimeError):
    pass


def is_regular_single_link(path: Path) -> bool:
    """Accept only one-name regular files for transaction authority."""
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1


def is_complete_owned_state_init(path: Path) -> bool:
    if path.is_symlink() or not path.is_dir() or not path.name.startswith(
        STATE_INIT_PREFIX
    ):
        return False
    with os.scandir(path) as iterator:
        entries = list(iterator)
    owner = path / "owner"
    return (
        len(entries) == 1
        and entries[0].name == "owner"
        and is_regular_single_link(owner)
        and owner.read_text(encoding="utf-8") == journal.OWNER + "\n"
    )


def remove_complete_owned_state_init(game_directory: Path, path: Path) -> None:
    if not is_complete_owned_state_init(path):
        raise ValueError("refusing unsafe or incomplete bounded state-init cleanup")
    (path / "owner").unlink()
    path.rmdir()
    journal.fsync_directory(game_directory)


def initialize_owned_state_directory(game_directory: Path) -> tuple[Path, bool]:
    """Create or recover the owner-marked state directory without recursive cleanup."""
    if game_directory.is_symlink() or not game_directory.is_dir():
        raise ValueError("game directory must be a real directory")
    state_directory = game_directory / STATE_NAME
    if state_directory.exists() or state_directory.is_symlink():
        journal.verify_owned_state_directory(state_directory)
        for path in sorted(game_directory.glob(STATE_INIT_PREFIX + "*")):
            if is_complete_owned_state_init(path):
                remove_complete_owned_state_init(game_directory, path)
        return state_directory, False

    complete_stages = [
        path
        for path in sorted(game_directory.glob(STATE_INIT_PREFIX + "*"))
        if is_complete_owned_state_init(path)
    ]
    if complete_stages:
        stage = complete_stages[0]
    else:
        stage = Path(tempfile.mkdtemp(prefix=STATE_INIT_PREFIX, dir=game_directory))
        owner = stage / "owner"
        descriptor = os.open(owner, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            handle.write(journal.OWNER + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        journal.fsync_directory(stage)
        journal.fsync_directory(game_directory)

    try:
        atomic_activate_no_replace(stage, state_directory)
    except FileExistsError:
        journal.verify_owned_state_directory(state_directory)
        remove_complete_owned_state_init(game_directory, stage)
        return state_directory, False
    journal.fsync_directory(game_directory)
    journal.verify_owned_state_directory(state_directory)
    for path in complete_stages[1:]:
        remove_complete_owned_state_init(game_directory, path)
    return state_directory, True


def verify_file(path: Path, size: int, digest: str, label: str) -> None:
    if (
        not is_regular_single_link(path)
        or path.stat().st_size != size
        or sha256_file(path) != digest
    ):
        raise ValueError(f"{label} identity mismatch")


def fsync_file(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def copy_file_durable(source: Path, destination: Path) -> None:
    if destination.exists() or destination.is_symlink():
        raise ValueError("durable copy destination already exists")
    descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with source.open("rb") as input_handle, os.fdopen(
            descriptor, "wb", closefd=True
        ) as output_handle:
            while chunk := input_handle.read(CHUNK_BYTES):
                output_handle.write(chunk)
            output_handle.flush()
            os.fsync(output_handle.fileno())
    except BaseException:
        raise


def current_state_text(record: dict[str, str]) -> str:
    record = journal.validate_record(record)
    return (
        f"OWNER={journal.OWNER}\n"
        "SCHEMA_VERSION=2\n"
        "PROFILE=safe\n"
        f"PATCH_ID={record['PATCH_ID']}\n"
        f"MANIFEST_SHA256={record['MANIFEST_SHA256']}\n"
        f"SOURCE_SHA256={record['SOURCE_SHA256']}\n"
        f"ACTIVE_SHA256={record['OUTPUT_SHA256']}\n"
    )


def parse_current_state_text(value: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for line_number, raw in enumerate(value.splitlines(), 1):
        if not raw or "=" not in raw:
            raise ValueError(f"malformed bounded current-state line {line_number}")
        key, field_value = raw.split("=", 1)
        if (
            key not in CURRENT_FIELDS
            or not field_value
            or any(character.isspace() for character in field_value)
            or key in fields
        ):
            raise ValueError(f"invalid bounded current-state line {line_number}")
        fields[key] = field_value
    if tuple(fields) != CURRENT_FIELDS:
        raise ValueError("bounded current-state field coverage or order mismatch")
    if (
        fields["OWNER"] != journal.OWNER
        or fields["SCHEMA_VERSION"] != "2"
        or fields["PROFILE"] != "safe"
        or journal.TOKEN.fullmatch(fields["PATCH_ID"]) is None
        or fields["SOURCE_SHA256"] != journal.OFFICIAL_PORT_SHA256
        or any(
            journal.HEX64.fullmatch(fields[key]) is None
            for key in ("MANIFEST_SHA256", "SOURCE_SHA256", "ACTIVE_SHA256")
        )
    ):
        raise ValueError("bounded current-state authority mismatch")
    return fields


def read_current_state(state_directory: Path) -> dict[str, str] | None:
    path = state_directory / CURRENT_NAME
    if not path.exists() and not path.is_symlink():
        return None
    if not is_regular_single_link(path):
        raise ValueError("bounded current-state path is unsafe")
    try:
        return parse_current_state_text(path.read_text(encoding="utf-8"))
    except UnicodeDecodeError as exc:
        raise ValueError("bounded current-state must be UTF-8") from exc


def current_state_matches(state_directory: Path, record: dict[str, str]) -> bool:
    current = read_current_state(state_directory)
    return current is not None and current == parse_current_state_text(
        current_state_text(record)
    )


def write_current_state(state_directory: Path, record: dict[str, str]) -> None:
    journal.verify_owned_state_directory(state_directory)
    current = state_directory / CURRENT_NAME
    pending = state_directory / CURRENT_NEXT_NAME
    if current.exists() and not is_regular_single_link(current):
        raise ValueError("bounded current-state path is unsafe")
    expected = current_state_text(record)
    if pending.exists() or pending.is_symlink():
        if (
            not is_regular_single_link(pending)
            or pending.read_text(encoding="utf-8") != expected
        ):
            raise ValueError("bounded pending current-state path is unsafe or mismatched")
    else:
        descriptor = os.open(pending, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            handle.write(expected)
            handle.flush()
            os.fsync(handle.fileno())
    os.replace(pending, current)
    journal.fsync_directory(state_directory)


@contextmanager
def transaction_lock(state_directory: Path) -> Iterator[None]:
    """Use the same identity-checked lock as launch and runtime-pair tools."""
    with runtime_lock(state_directory):
        yield


def recover_stale_lock(state_directory: Path) -> bool:
    """Compatibility wrapper around the shared installer/runtime recovery rule."""
    return recover_shared_stale_lock(state_directory)


def reconcile_pending_journal(
    state_directory: Path,
    *,
    fields: dict[str, str],
    expected_manifest_sha256: str,
) -> dict[str, str] | None:
    """Adopt only an exact initial or immediately-next durable journal record."""
    journal.verify_owned_state_directory(state_directory)
    transaction = state_directory / journal.TRANSACTION_NAME
    pending = state_directory / journal.TRANSACTION_NEXT_NAME
    if not pending.exists() and not pending.is_symlink():
        return None
    pending_record = journal.read_record(pending)
    validate_release_record(pending_record, fields, expected_manifest_sha256)
    if transaction.exists() or transaction.is_symlink():
        current_record = journal.read_record(transaction)
        validate_release_record(current_record, fields, expected_manifest_sha256)
        current_index = journal.PHASES.index(current_record["PHASE"])
        if (
            current_index + 1 >= len(journal.PHASES)
            or pending_record["PHASE"] != journal.PHASES[current_index + 1]
            or any(
                pending_record[key] != current_record[key]
                for key in journal.FIELDS
                if key != "PHASE"
            )
        ):
            raise ValueError("pending bounded transaction is not an exact next phase")
    elif pending_record["PHASE"] != journal.PHASES[0]:
        raise ValueError("pending bounded transaction lacks its required predecessor")
    os.replace(pending, transaction)
    journal.fsync_directory(state_directory)
    return pending_record


def validate_release_record(
    record: dict[str, str],
    fields: dict[str, str],
    expected_manifest_sha256: str,
) -> dict[str, str]:
    checked = journal.validate_record(record)
    if (
        checked["PATCH_ID"] != fields["PATCH_ID"]
        or checked["MANIFEST_SHA256"] != expected_manifest_sha256
        or checked["SOURCE_SHA256"] != fields["SOURCE_SHA256"]
        or checked["OUTPUT_SHA256"] != fields["OUTPUT_SHA256"]
    ):
        raise ValueError("bounded transaction release authority mismatch")
    return checked


def checkpoint(name: str, fail_after: str | None) -> None:
    if fail_after == name:
        raise InjectedInterruption(f"injected interruption after {name}")


def run_checked(command: list[str], label: str) -> dict[str, Any] | None:
    result = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        raise ValueError(
            f"{label} failed with status {result.returncode}: {result.stderr.strip()}"
        )
    output = result.stdout.strip()
    if not output:
        return None
    try:
        parsed = json.loads(output)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{label} did not emit JSON") from exc
    if not isinstance(parsed, dict):
        raise ValueError(f"{label} JSON result must be an object")
    return parsed


def validate_preconditions(
    game_directory: Path,
    manifest_path: Path,
    artifacts_directory: Path,
    expected_manifest_sha256: str,
) -> dict[str, Any]:
    manifest_authority.validate(
        manifest_path, artifacts_directory, expected_manifest_sha256
    )
    fields = manifest_authority.parse_manifest(manifest_path)
    if game_directory.is_symlink() or not game_directory.is_dir():
        raise ValueError("game directory must be a real directory")
    state_directory = game_directory / STATE_NAME
    state_missing = not state_directory.exists() and not state_directory.is_symlink()
    if not state_missing:
        journal.verify_owned_state_directory(state_directory)
    active = game_directory / ACTIVE_NAME
    if not is_regular_single_link(active):
        raise ValueError("active port must be a regular non-symlink file")
    active_sha256 = sha256_file(active)
    preserved = game_directory / PRESERVED_NAME
    if preserved.exists() or preserved.is_symlink():
        verify_file(
            preserved,
            int(fields["SOURCE_SIZE"]),
            fields["SOURCE_SHA256"],
            "preserved official source",
        )
    current_state = None if state_missing else read_current_state(state_directory)
    transaction_paths_present = False
    if not state_missing:
        for name in (journal.TRANSACTION_NAME, journal.TRANSACTION_NEXT_NAME):
            path = state_directory / name
            if path.exists() or path.is_symlink():
                if not is_regular_single_link(path):
                    raise ValueError("bounded transaction path is unsafe")
                transaction_paths_present = True
    if active_sha256 == fields["SOURCE_SHA256"]:
        pass
    elif active_sha256 == fields["OUTPUT_SHA256"]:
        if not transaction_paths_present and (
            current_state is None
            or current_state["ACTIVE_SHA256"] != active_sha256
            or not is_regular_single_link(preserved)
        ):
            raise ValueError("exact output lacks matching bounded transaction state")
    else:
        raise ValueError("refusing unknown active payload")

    stats = os.statvfs(game_directory)
    available_bytes = stats.f_bavail * stats.f_frsize
    available_inodes = stats.f_favail
    required_bytes = int(
        fields[
            "REINSTALL_REQUIRED_FREE_BYTES"
            if preserved.exists()
            else "FIRST_INSTALL_REQUIRED_FREE_BYTES"
        ]
    )
    required_inodes = int(fields["REQUIRED_FREE_INODES"])
    if available_bytes < required_bytes:
        raise ValueError("insufficient free bytes for bounded installer transaction")
    if available_inodes < required_inodes:
        raise ValueError("insufficient free inodes for bounded installer transaction")
    if shutil.which("xdelta3") is None:
        raise ValueError("xdelta3 is required for bounded installer transaction")
    if sys.version_info < (3, 10):
        raise ValueError("Python 3.10 or newer is required")
    state_directory, state_initialized = initialize_owned_state_directory(
        game_directory
    )
    return {
        "fields": fields,
        "state_directory": state_directory,
        "active": active,
        "active_sha256": active_sha256,
        "preserved": preserved,
        "current_state": current_state,
        "state_initialized": state_initialized,
        "contract": artifacts_directory / fields["CACHE_CONTRACT_FILE"],
        "contract_sha256": fields["CACHE_CONTRACT_SHA256"],
    }


def remove_journal(state_directory: Path) -> None:
    path = state_directory / journal.TRANSACTION_NAME
    pending = state_directory / journal.TRANSACTION_NEXT_NAME
    if pending.exists() or pending.is_symlink():
        raise ValueError("cannot finish while a pending journal exists")
    if not is_regular_single_link(path):
        raise ValueError("durable journal is missing or unsafe")
    path.unlink()
    journal.fsync_directory(state_directory)


def recover_existing_transaction(
    context: dict[str, Any],
    expected_manifest_sha256: str,
) -> str | None:
    state_directory: Path = context["state_directory"]
    transaction = state_directory / journal.TRANSACTION_NAME
    if not transaction.exists() and not transaction.is_symlink():
        return None
    record = journal.read_record(transaction)
    validate_release_record(record, context["fields"], expected_manifest_sha256)
    active_sha256 = sha256_file(context["active"])
    preserved_sha256 = (
        sha256_file(context["preserved"])
        if is_regular_single_link(context["preserved"])
        else None
    )
    state_matches = current_state_matches(state_directory, record)
    decision = journal.recovery_decision(
        record,
        expected_manifest_sha256=expected_manifest_sha256,
        active_sha256=active_sha256,
        preserved_sha256=preserved_sha256,
        state_record_matches=state_matches,
    )
    action = decision["action"]
    if action == "discard-owned-stages-and-retry":
        cleanup_after_recovery_decision(
            state_directory,
            context["contract"],
            record,
            expected_manifest_sha256=expected_manifest_sha256,
            expected_contract_sha256=context["contract_sha256"],
            active_sha256=active_sha256,
            preserved_sha256=preserved_sha256,
            state_record_matches=False,
        )
        remove_journal(state_directory)
        return "retry"
    if action == "adopt-exact-output-then-cleanup":
        write_current_state(state_directory, record)
        while record["PHASE"] != "state-committed":
            next_phase = journal.PHASES[journal.PHASES.index(record["PHASE"]) + 1]
            record = journal.advance_record(
                state_directory,
                next_phase,
                expected_manifest_sha256=expected_manifest_sha256,
            )
        cleanup_after_recovery_decision(
            state_directory,
            context["contract"],
            record,
            expected_manifest_sha256=expected_manifest_sha256,
            expected_contract_sha256=context["contract_sha256"],
            active_sha256=active_sha256,
            preserved_sha256=preserved_sha256,
            state_record_matches=True,
        )
        remove_journal(state_directory)
        return "current"
    if action == "cleanup-owned-stages-only":
        cleanup_after_recovery_decision(
            state_directory,
            context["contract"],
            record,
            expected_manifest_sha256=expected_manifest_sha256,
            expected_contract_sha256=context["contract_sha256"],
            active_sha256=active_sha256,
            preserved_sha256=preserved_sha256,
            state_record_matches=True,
        )
        remove_journal(state_directory)
        return "current"
    raise ValueError(f"interrupted bounded transaction cannot be recovered: {action}")


def extract_official_droid(
    preserved: Path, destination: Path, fields: dict[str, str]
) -> None:
    if destination.exists() or destination.is_symlink():
        raise ValueError("official game.droid stage already exists")
    with zipfile.ZipFile(preserved, "r") as archive:
        matches = [
            info
            for info in archive.infolist()
            if info.filename == fields["SOURCE_GAME_DROID_MEMBER"] and not info.is_dir()
        ]
        if len(matches) != 1:
            raise ValueError("official archive game.droid member coverage mismatch")
        descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with archive.open(matches[0], "r") as source, os.fdopen(
            descriptor, "wb", closefd=True
        ) as output:
            while chunk := source.read(CHUNK_BYTES):
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
    verify_file(
        destination,
        int(fields["SOURCE_GAME_DROID_SIZE"]),
        fields["SOURCE_GAME_DROID_SHA256"],
        "staged official game.droid",
    )


def install_transaction(
    game_directory: Path,
    manifest_path: Path,
    artifacts_directory: Path,
    expected_manifest_sha256: str,
    generation_timestamp: str,
    *,
    fail_after: str | None = None,
) -> dict[str, Any]:
    if fail_after is not None and fail_after not in INJECTION_POINTS:
        raise ValueError("unknown bounded installer failure-injection point")
    context = validate_preconditions(
        game_directory,
        manifest_path,
        artifacts_directory,
        expected_manifest_sha256,
    )
    fields: dict[str, str] = context["fields"]
    state_directory: Path = context["state_directory"]
    active: Path = context["active"]
    preserved: Path = context["preserved"]

    with transaction_lock(state_directory):
        reconcile_pending_journal(
            state_directory,
            fields=fields,
            expected_manifest_sha256=expected_manifest_sha256,
        )
        recovered = recover_existing_transaction(context, expected_manifest_sha256)
        if recovered == "current":
            return {"status": "bounded_installer_recovered_current", "recovered": True}

        active_sha256 = sha256_file(active)
        source_sha256 = fields["SOURCE_SHA256"]
        output_sha256 = fields["OUTPUT_SHA256"]
        if active_sha256 == output_sha256:
            record = journal.make_record(
                patch_id=fields["PATCH_ID"],
                manifest_sha256=expected_manifest_sha256,
                previous_active_sha256=source_sha256,
                output_sha256=output_sha256,
                phase="state-committed",
            )
            if preserved.is_file() and current_state_matches(state_directory, record):
                return {"status": "bounded_installer_already_current", "recovered": False}
            raise ValueError("exact output is active without matching bounded state")
        if active_sha256 != source_sha256:
            current = read_current_state(state_directory)
            if current is None or current["ACTIVE_SHA256"] != active_sha256:
                raise ValueError("refusing unknown active payload")

        record = journal.make_record(
            patch_id=fields["PATCH_ID"],
            manifest_sha256=expected_manifest_sha256,
            previous_active_sha256=active_sha256,
            output_sha256=output_sha256,
        )
        journal.write_record_atomic(state_directory, record)
        stage_directory = create_owned_stage(
            state_directory,
            record,
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("validated", fail_after)

        if not preserved.exists():
            source_stage = stage_directory / PRESERVED_SOURCE_NAME
            copy_file_durable(active, source_stage)
            verify_file(
                source_stage,
                int(fields["SOURCE_SIZE"]),
                source_sha256,
                "staged preserved source",
            )
            atomic_activate_no_replace(source_stage, preserved)
            journal.fsync_directory(game_directory)
        verify_file(
            preserved,
            int(fields["SOURCE_SIZE"]),
            source_sha256,
            "preserved official source",
        )
        record = journal.advance_record(
            state_directory,
            "source-preserved",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("source-preserved", fail_after)

        official_droid = stage_directory / OFFICIAL_DROID_NAME
        extract_official_droid(preserved, official_droid, fields)
        record = journal.advance_record(
            state_directory,
            "droid-extracted",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("droid-extracted", fail_after)

        patched_droid = stage_directory / PATCHED_DROID_NAME
        run_checked(
            [
                "xdelta3",
                "-d",
                "-s",
                str(official_droid),
                str(artifacts_directory / fields["DROID_PATCH_FILE"]),
                str(patched_droid),
            ],
            "game.droid VCDIFF application",
        )
        fsync_file(patched_droid)
        verify_file(
            patched_droid,
            int(fields["PATCHED_GAME_DROID_SIZE"]),
            fields["PATCHED_GAME_DROID_SHA256"],
            "patched game.droid",
        )
        record = journal.advance_record(
            state_directory,
            "droid-patched",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("droid-patched", fail_after)

        cache_directory = stage_directory / "cache"
        run_checked(
            [
                sys.executable,
                str(artifacts_directory / fields["CONVERTER_FILE"]),
                "--official",
                str(preserved),
                "--output-dir",
                str(cache_directory),
                "--contract",
                str(context["contract"]),
                "--generation-timestamp",
                generation_timestamp,
            ],
            "bounded cache converter",
        )
        record = journal.advance_record(
            state_directory,
            "cache-generated",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("cache-generated", fail_after)

        candidate = state_directory / record["CANDIDATE_BASENAME"]
        run_checked(
            [
                sys.executable,
                str(artifacts_directory / fields["ASSEMBLER_FILE"]),
                "--official",
                str(preserved),
                "--game-droid",
                str(patched_droid),
                "--cache-dir",
                str(cache_directory),
                "--output",
                str(candidate),
                "--contract",
                str(context["contract"]),
                "--game-droid-size",
                fields["PATCHED_GAME_DROID_SIZE"],
                "--game-droid-sha256",
                fields["PATCHED_GAME_DROID_SHA256"],
                "--output-size",
                fields["OUTPUT_SIZE"],
                "--output-sha256",
                output_sha256,
            ],
            "bounded port assembler",
        )
        verify_file(
            candidate,
            int(fields["OUTPUT_SIZE"]),
            output_sha256,
            "assembled candidate archive",
        )
        record = journal.advance_record(
            state_directory,
            "archive-assembled",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("archive-assembled", fail_after)

        if sha256_file(active) != active_sha256:
            raise ValueError("active payload changed before bounded activation")
        verify_file(
            candidate,
            int(fields["OUTPUT_SIZE"]),
            output_sha256,
            "activation candidate archive",
        )
        os.chmod(candidate, 0o644)
        fsync_file(candidate)
        record = journal.advance_record(
            state_directory,
            "activation-prepared",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("activation-prepared", fail_after)
        os.replace(candidate, active)
        fsync_file(active)
        journal.fsync_directory(game_directory)
        checkpoint("after-active-replace", fail_after)
        record = journal.advance_record(
            state_directory,
            "archive-activated",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("archive-activated", fail_after)

        write_current_state(state_directory, record)
        record = journal.advance_record(
            state_directory,
            "state-committed",
            expected_manifest_sha256=expected_manifest_sha256,
        )
        checkpoint("state-committed", fail_after)
        cleanup_after_recovery_decision(
            state_directory,
            context["contract"],
            record,
            expected_manifest_sha256=expected_manifest_sha256,
            expected_contract_sha256=context["contract_sha256"],
            active_sha256=output_sha256,
            preserved_sha256=source_sha256,
            state_record_matches=True,
        )
        remove_journal(state_directory)
        return {
            "status": "bounded_installer_transaction_complete",
            "recovered": recovered == "retry",
            "active_sha256": output_sha256,
            "patch_id": fields["PATCH_ID"],
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--game-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--artifacts-dir", type=Path, required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--generation-timestamp", required=True)
    args = parser.parse_args()
    try:
        result = install_transaction(
            args.game_dir,
            args.manifest,
            args.artifacts_dir,
            args.expected_manifest_sha256,
            args.generation_timestamp,
        )
    except (OSError, ValueError, InjectedInterruption, zipfile.BadZipFile) as exc:
        print(f"bounded installer transaction failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
