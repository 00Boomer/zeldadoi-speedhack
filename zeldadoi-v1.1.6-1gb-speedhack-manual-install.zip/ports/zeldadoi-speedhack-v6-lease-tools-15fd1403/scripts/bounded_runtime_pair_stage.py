#!/usr/bin/env python3
"""Build one exact, bounded dual-runtime stage without activating gameplay.

The stage is consumed by ``bounded_runtime_pair_activation.py``.  This module
never replaces the active archive and never installs the seeded runtime.  It
requires an exact official active/preserved pair, one independently hash-bound
runtime authority, two independently hash-bound VCDIFF patches, one exact
seeded runtime configuration, and one independently hash-bound generated-cache
contract.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, NoReturn

import bounded_runtime_pair_activation as activation
import bounded_runtime_pair_restore as pair_restore
import runtime_pair_capacity as capacity_model
from assemble_bounded_cache_port import assemble
from bounded_installer_journal import fsync_directory
from bounded_installer_orchestrator import copy_file_durable, fsync_file
from bounded_installer_stage import load_contract
from bounded_runtime_lock import OWNER, RuntimeLockLease, runtime_lock
from convert_official_cache_bounded import OWNERSHIP_MANIFEST, convert
from runtime_authority import DEFAULT_SCHEMA, load_authority, load_schema


BUILD_MARKER = "runtime-pair-build-owner.json"
TEMP_DROIDS = {
    "official": ".runtime-pair-official.game.droid",
    "default": ".runtime-pair-default.game.droid",
    "seeded": ".runtime-pair-seeded.game.droid",
}
CACHE_NAME = ".runtime-pair-generated-cache"
CACHE_STAGE = re.compile(re.escape(CACHE_NAME) + r"\.stage-[1-9][0-9]*\Z")
ASSEMBLER_STAGE = re.compile(
    r"(?:zeldadoi\.port|zeldadoi\.seeded\.port)\.stage-[1-9][0-9]*\Z"
)
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
UTC_TIMESTAMP = re.compile(
    r"(?:19|20)[0-9]{2}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12][0-9]|3[01])"
    r"T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]Z\Z"
)
MAX_STAGE_EXTRA_ENTRIES = 32
PHASES = (
    "capacity-validated",
    "stage-created",
    "inputs-staged",
    "droids-patched",
    "cache-generated",
    "default-assembled",
    "seeded-assembled",
    "stage-ready",
)


class RuntimePairStageError(ValueError):
    """The pair stage or one of its independent authorities is invalid."""


def reject(message: str) -> NoReturn:
    raise RuntimePairStageError(message)


def canonical_bytes(document: dict[str, Any]) -> bytes:
    return (
        json.dumps(document, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")


def stable_regular(path: Path, expected_sha256: str, label: str) -> tuple[int, str]:
    if HEX64.fullmatch(expected_sha256) is None:
        reject(f"expected {label} SHA-256 is invalid")
    try:
        metadata = path.lstat()
    except OSError as exc:
        reject(f"cannot stat {label}: {exc}")
    if (
        stat.S_ISLNK(metadata.st_mode)
        or not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
        or metadata.st_size <= 0
    ):
        reject(f"{label} must be a nonempty regular single-link file")
    size, digest = activation.file_identity(path, label)
    if digest != expected_sha256:
        reject(f"{label} identity mismatch")
    return size, digest


def marker_document(
    authority: dict[str, Any],
    authority_sha256: str,
    cache_contract_sha256: str,
    default_patch_sha256: str,
    seeded_patch_sha256: str,
    generation_timestamp: str,
) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "owner": OWNER,
        "release_id": authority["release_id"],
        "authority_sha256": authority_sha256,
        "cache_contract_sha256": cache_contract_sha256,
        "default_patch_sha256": default_patch_sha256,
        "seeded_patch_sha256": seeded_patch_sha256,
        "generation_timestamp": generation_timestamp,
    }


def write_marker(stage: Path, document: dict[str, Any]) -> None:
    stage.mkdir(mode=0o700)
    marker = stage / BUILD_MARKER
    descriptor = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb", closefd=True) as handle:
        handle.write(canonical_bytes(document))
        handle.flush()
        os.fsync(handle.fileno())
    fsync_directory(stage)
    fsync_directory(stage.parent)


def verify_marker(stage: Path, expected: dict[str, Any]) -> None:
    marker = stage / BUILD_MARKER
    _, digest = stable_regular(
        marker,
        hashlib.sha256(canonical_bytes(expected)).hexdigest(),
        "runtime-pair build marker",
    )
    del digest
    try:
        observed = json.loads(marker.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        reject(f"runtime-pair build marker is invalid: {exc}")
    if observed != expected:
        reject("runtime-pair build marker authority mismatch")


def expected_cache_paths(contract: dict[str, Any]) -> set[str]:
    return {
        f"{CACHE_NAME}/{item['relative_path']}"
        for item in contract["generated_files"]
    } | {f"{CACHE_NAME}/{OWNERSHIP_MANIFEST}"}


def _relative_allowed(
    relative: str,
    *,
    authority_path: str,
    official_path: str,
    default_archive_path: str,
    default_config_path: str,
    seeded_archive_path: str,
    seeded_config_path: str,
    cache_files: set[str],
) -> tuple[bool, bool]:
    """Return (allowed, directory) for one incomplete owned-stage entry."""
    files = {
        BUILD_MARKER,
        official_path,
        default_archive_path,
        default_config_path,
        seeded_archive_path,
        seeded_config_path,
        authority_path,
        *TEMP_DROIDS.values(),
        *cache_files,
    }
    directories = {
        str(PurePosixPath(authority_path).parent),
        str(PurePosixPath(seeded_config_path).parent),
        CACHE_NAME,
        f"{CACHE_NAME}/assets",
        f"{CACHE_NAME}/assets/data",
    }
    first = PurePosixPath(relative).parts[0]
    if CACHE_STAGE.fullmatch(first):
        suffix = PurePosixPath(*PurePosixPath(relative).parts[1:]).as_posix()
        cache_relative = f"{CACHE_NAME}/{suffix}" if suffix != "." else CACHE_NAME
        return (
            cache_relative in cache_files
            or cache_relative in directories
            or cache_relative == f"{CACHE_NAME}/{OWNERSHIP_MANIFEST}",
            cache_relative in directories,
        )
    if len(PurePosixPath(relative).parts) == 1 and ASSEMBLER_STAGE.fullmatch(relative):
        return True, False
    return relative in files or relative in directories, relative in directories


def cleanup_incomplete_stage(
    state: Path,
    stage: Path,
    expected_marker: dict[str, Any],
    contract: dict[str, Any],
    schema: dict[str, Any],
    authority: dict[str, Any],
) -> dict[str, int]:
    """Remove only a fully inventoried stage bearing this exact build marker."""
    verify_marker(stage, expected_marker)
    official_path = schema["official_source"]["archive"]["path"]
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    cache_files = expected_cache_paths(contract)
    files: list[tuple[Path, int, int]] = []
    directories: list[tuple[Path, int, int]] = []
    pending = [(stage, PurePosixPath())]
    seen = 0
    maximum = len(cache_files) + MAX_STAGE_EXTRA_ENTRIES
    while pending:
        root, prefix = pending.pop()
        with os.scandir(root) as iterator:
            entries = list(iterator)
        for entry in entries:
            seen += 1
            if seen > maximum:
                reject("incomplete runtime-pair stage exceeds its bounded inventory")
            relative = (prefix / entry.name).as_posix()
            allowed, expected_directory = _relative_allowed(
                relative,
                authority_path=schema["authority_manifest_path"],
                official_path=official_path,
                default_archive_path=default["archive_path"],
                default_config_path=default["runtime_config_path"],
                seeded_archive_path=seeded["archive_path"],
                seeded_config_path=seeded["runtime_config_path"],
                cache_files=cache_files,
            )
            if not allowed or entry.is_symlink():
                reject(f"incomplete runtime-pair stage has an unknown path: {relative}")
            path = Path(entry.path)
            metadata = path.lstat()
            if expected_directory:
                if not entry.is_dir(follow_symlinks=False):
                    reject(f"runtime-pair stage directory type mismatch: {relative}")
                directories.append((path, metadata.st_dev, metadata.st_ino))
                pending.append((path, PurePosixPath(relative)))
            else:
                if not entry.is_file(follow_symlinks=False) or metadata.st_nlink != 1:
                    reject(f"runtime-pair stage file type mismatch: {relative}")
                files.append((path, metadata.st_dev, metadata.st_ino))
    stage_metadata = stage.lstat()
    directories.append((stage, stage_metadata.st_dev, stage_metadata.st_ino))
    directories.sort(key=lambda item: len(item[0].parts), reverse=True)
    for path, device, inode in files + directories:
        metadata = path.lstat()
        if (metadata.st_dev, metadata.st_ino) != (device, inode):
            reject("runtime-pair stage entry changed after cleanup inventory")
    for path, _, _ in files:
        path.unlink()
    for path, _, _ in directories:
        path.rmdir()
    fsync_directory(state)
    return {"files_removed": len(files), "directories_removed": len(directories)}


def copy_exact(source: Path, destination: Path, size: int, digest: str, label: str) -> None:
    stable_regular(source, digest, label)
    copy_file_durable(source, destination)
    activation.verify_file(destination, size, digest, f"staged {label}")


def extract_official_droid(
    official: Path, destination: Path, member: dict[str, Any]
) -> None:
    if destination.exists() or destination.is_symlink():
        reject("official game.droid destination already exists")
    with zipfile.ZipFile(official, "r") as archive:
        matches = [
            item for item in archive.infolist()
            if item.filename == member["member"] and not item.is_dir()
        ]
        if len(matches) != 1:
            reject("official archive game.droid member coverage mismatch")
        descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with archive.open(matches[0], "r") as source, os.fdopen(
            descriptor, "wb", closefd=True
        ) as output:
            while block := source.read(1024 * 1024):
                output.write(block)
            output.flush()
            os.fsync(output.fileno())
    activation.verify_file(
        destination, member["size"], member["sha256"], "official game.droid"
    )


def apply_delta(
    official_droid: Path,
    patch: Path,
    patch_sha256: str,
    output: Path,
    expected: dict[str, Any],
    label: str,
) -> None:
    stable_regular(patch, patch_sha256, f"{label} VCDIFF")
    result = subprocess.run(
        ["xdelta3", "-d", "-s", str(official_droid), str(patch), str(output)],
        check=False,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        reject(f"{label} VCDIFF failed with status {result.returncode}: {result.stderr.strip()}")
    fsync_file(output)
    activation.verify_file(
        output, expected["size"], expected["sha256"], f"{label} game.droid"
    )


def enforce_generation_capacity(
    game_root: Path,
    authority_path: Path,
    authority_sha256: str,
    cache_contract_path: Path,
    cache_contract_sha256: str,
    authority_schema_path: Path,
    capacity_schema_path: Path,
) -> dict[str, Any]:
    stats = os.statvfs(game_root)
    model = capacity_model.calculate(
        authority_path,
        authority_sha256,
        cache_contract_path,
        cache_contract_sha256,
        authority_schema_path=authority_schema_path,
        capacity_schema_path=capacity_schema_path,
        allocation_unit_bytes=stats.f_frsize,
    )
    floor = model["floors"]["reinstall_from_exact_official"]
    available_bytes = stats.f_bavail * stats.f_frsize
    available_inodes = stats.f_favail
    capacity_model.enforce_filesystem_capacity(
        game_root, stats, floor["required_free_capacity_bytes"], floor["required_free_inodes"],
        "runtime-pair generation", reject,
    )
    return {
        "capacity_model_status": model["status"],
        "floor": "reinstall_from_exact_official",
        "required_free_logical_bytes": floor["required_free_logical_bytes"],
        "required_free_capacity_bytes": floor["required_free_capacity_bytes"],
        "allocation_unit_bytes": stats.f_frsize,
        "required_free_inodes": floor["required_free_inodes"],
        "available_logical_bytes": available_bytes,
        "available_inodes": available_inodes,
        "logical_floor_only": model["claims"]["logical_byte_floor_only"],
        "regular_file_allocation_unit_ceiling_calculated": model["claims"][
            "regular_file_allocation_unit_ceiling_calculated"
        ],
    }


def reject_other_transactions(state: Path) -> None:
    names = {
        activation.PAIR_JOURNAL,
        activation.PAIR_JOURNAL_NEXT,
        activation.PAIR_CURRENT,
        activation.PAIR_CURRENT_NEXT,
        pair_restore.RESTORE_JOURNAL,
        pair_restore.RESTORE_JOURNAL_NEXT,
        "bounded-transaction",
        "bounded-transaction.next",
        "bounded-restore",
        "bounded-restore.next",
        "runtime-pair-preserve.json",
        "runtime-pair-preserve.next",
    }
    for name in names:
        path = state / name
        if path.exists() or path.is_symlink():
            reject(f"runtime-pair generation overlaps another transaction: {name}")


def checkpoint(name: str, fail_after: str | None) -> None:
    if fail_after == name:
        raise RuntimeError(
            f"injected runtime-pair stage interruption after {name}"
        )


def prepare_stage(
    game_root: Path,
    authority_path: Path,
    expected_authority_sha256: str,
    default_patch: Path,
    expected_default_patch_sha256: str,
    seeded_patch: Path,
    expected_seeded_patch_sha256: str,
    seeded_config: Path,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    generation_timestamp: str,
    *,
    authority_schema_path: Path = DEFAULT_SCHEMA,
    capacity_schema_path: Path = capacity_model.DEFAULT_CAPACITY_SCHEMA,
    tool_root: Path | None = None,
    fail_after: str | None = None,
    lock_lease: RuntimeLockLease | None = None,
) -> dict[str, Any]:
    if UTC_TIMESTAMP.fullmatch(generation_timestamp) is None:
        reject("generation timestamp must be canonical UTC RFC3339 seconds")
    if fail_after is not None and fail_after not in PHASES:
        reject("unknown runtime-pair stage interruption checkpoint")
    if shutil.which("xdelta3") is None:
        reject("xdelta3 is required for runtime-pair generation")
    game_root = activation.exact_root(game_root, "game root")
    state = game_root / ".zeldadoi-speedhack"
    activation.require_state_owner(state)
    authority_schema_path = authority_schema_path.absolute()
    capacity_schema_path = capacity_schema_path.absolute()
    tool_root = (tool_root or Path(__file__).resolve().parents[1]).resolve()
    schema = load_schema(authority_schema_path)
    stable_regular(authority_path, expected_authority_sha256, "runtime authority")
    authority = load_authority(
        authority_path,
        authority_schema_path,
        expected_sha256=expected_authority_sha256,
    )
    contract = load_contract(
        cache_contract_path, expected_cache_contract_sha256
    )
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    official = schema["official_source"]["archive"]
    official_droid = schema["official_source"]["game_droid"]
    stage = state / (activation.STAGE_PREFIX + authority["release_id"])
    expected_marker = marker_document(
        authority,
        expected_authority_sha256,
        expected_cache_contract_sha256,
        expected_default_patch_sha256,
        expected_seeded_patch_sha256,
        generation_timestamp,
    )

    stable_regular(default_patch, expected_default_patch_sha256, "default VCDIFF")
    stable_regular(seeded_patch, expected_seeded_patch_sha256, "seeded VCDIFF")
    activation.verify_file(
        game_root / official["path"],
        official["size"],
        official["sha256"],
        "preserved official archive",
    )
    activation.verify_file(
        game_root / default["archive_path"],
        official["size"],
        official["sha256"],
        "active exact official archive",
    )
    activation.verify_file(
        game_root / default["runtime_config_path"],
        default["runtime_config_size"],
        default["runtime_config_sha256"],
        "installed default runtime config",
    )
    stable_regular(
        seeded_config,
        seeded["runtime_config_sha256"],
        "seeded runtime config",
    )

    with runtime_lock(state, lock_lease):
        reject_other_transactions(state)
        if stage.exists() or stage.is_symlink():
            if stage.is_symlink() or not stage.is_dir():
                reject("runtime-pair stage path is unsafe")
            marker = stage / BUILD_MARKER
            if not marker.exists() and not marker.is_symlink():
                activation.build_context(
                    game_root,
                    stage,
                    expected_authority_sha256,
                    authority_schema_path,
                )
                return {
                    "schema_version": 1,
                    "status": "runtime_pair_stage_already_prepared",
                    "release_id": authority["release_id"],
                    "stage": str(stage),
                    "authority_sha256": expected_authority_sha256,
                    "active_archive_modified": False,
                    "physical_target_executed": False,
                    "production_approved": False,
                }
            cleanup_incomplete_stage(
                state, stage, expected_marker, contract, schema, authority
            )

        generation_capacity = enforce_generation_capacity(
            game_root,
            authority_path,
            expected_authority_sha256,
            cache_contract_path,
            expected_cache_contract_sha256,
            authority_schema_path,
            capacity_schema_path,
        )
        checkpoint("capacity-validated", fail_after)
        write_marker(stage, expected_marker)
        checkpoint("stage-created", fail_after)
        staged_official = stage / official["path"]
        staged_default_config = stage / default["runtime_config_path"]
        staged_seeded_config = stage / seeded["runtime_config_path"]
        staged_authority = stage / schema["authority_manifest_path"]
        staged_seeded_config.parent.mkdir(parents=True, exist_ok=True)
        copy_exact(
            game_root / official["path"],
            staged_official,
            official["size"],
            official["sha256"],
            "official archive mirror",
        )
        copy_exact(
            game_root / default["runtime_config_path"],
            staged_default_config,
            default["runtime_config_size"],
            default["runtime_config_sha256"],
            "default runtime config mirror",
        )
        copy_exact(
            seeded_config,
            staged_seeded_config,
            seeded["runtime_config_size"],
            seeded["runtime_config_sha256"],
            "seeded runtime config",
        )
        copy_exact(
            authority_path,
            staged_authority,
            authority_path.stat().st_size,
            expected_authority_sha256,
            "runtime authority",
        )
        fsync_directory(staged_seeded_config.parent)
        fsync_directory(stage)
        checkpoint("inputs-staged", fail_after)

        extracted = stage / TEMP_DROIDS["official"]
        default_droid = stage / TEMP_DROIDS["default"]
        seeded_droid = stage / TEMP_DROIDS["seeded"]
        extract_official_droid(staged_official, extracted, official_droid)
        apply_delta(
            extracted,
            default_patch,
            expected_default_patch_sha256,
            default_droid,
            default["game_droid"],
            "default",
        )
        apply_delta(
            extracted,
            seeded_patch,
            expected_seeded_patch_sha256,
            seeded_droid,
            seeded["game_droid"],
            "seeded",
        )
        checkpoint("droids-patched", fail_after)
        cache = stage / CACHE_NAME
        convert(
            staged_official,
            cache,
            cache_contract_path,
            generation_timestamp,
            root=tool_root,
        )
        checkpoint("cache-generated", fail_after)
        assemble(
            staged_official,
            default_droid,
            cache,
            stage / default["archive_path"],
            cache_contract_path,
            game_droid_size=default["game_droid"]["size"],
            game_droid_sha256=default["game_droid"]["sha256"],
            output_size=default["archive_size"],
            output_sha256=default["archive_sha256"],
            root=tool_root,
        )
        checkpoint("default-assembled", fail_after)
        assemble(
            staged_official,
            seeded_droid,
            cache,
            stage / seeded["archive_path"],
            cache_contract_path,
            game_droid_size=seeded["game_droid"]["size"],
            game_droid_sha256=seeded["game_droid"]["sha256"],
            output_size=seeded["archive_size"],
            output_sha256=seeded["archive_sha256"],
            root=tool_root,
        )
        checkpoint("seeded-assembled", fail_after)

        for path in (extracted, default_droid, seeded_droid):
            stable_regular(path, activation.sha256_file(path), path.name)
            path.unlink()
        cache_files = expected_cache_paths(contract)
        cache_root_files: list[Path] = []
        cache_root_dirs: list[Path] = []
        for path in cache.rglob("*"):
            relative = f"{CACHE_NAME}/{path.relative_to(cache).as_posix()}"
            if path.is_symlink():
                reject(f"generated cache contains a symlink: {relative}")
            if path.is_dir():
                if relative not in {f"{CACHE_NAME}/assets", f"{CACHE_NAME}/assets/data"}:
                    reject(f"generated cache contains an unknown directory: {relative}")
                cache_root_dirs.append(path)
            elif path.is_file():
                if relative not in cache_files or path.stat().st_nlink != 1:
                    reject(f"generated cache contains an unknown file: {relative}")
                cache_root_files.append(path)
            else:
                reject(f"generated cache contains an unsupported path: {relative}")
        if {f"{CACHE_NAME}/{path.relative_to(cache).as_posix()}" for path in cache_root_files} != cache_files:
            reject("generated cache cleanup inventory is incomplete")
        for path in cache_root_files:
            path.unlink()
        for path in sorted(cache_root_dirs, key=lambda value: len(value.parts), reverse=True):
            path.rmdir()
        cache.rmdir()
        (stage / BUILD_MARKER).unlink()
        fsync_directory(stage)
        fsync_directory(state)

        activation.build_context(
            game_root,
            stage,
            expected_authority_sha256,
            authority_schema_path,
        )
        activation.verify_file(
            game_root / default["archive_path"],
            official["size"],
            official["sha256"],
            "unchanged active official archive",
        )
        checkpoint("stage-ready", fail_after)
        return {
            "schema_version": 1,
            "status": "runtime_pair_stage_prepared",
            "release_id": authority["release_id"],
            "stage": str(stage),
            "authority_sha256": expected_authority_sha256,
            "default_archive_sha256": default["archive_sha256"],
            "seeded_archive_sha256": seeded["archive_sha256"],
            "shared_cache_generated_once": True,
            "generation_capacity": generation_capacity,
            "active_archive_modified": False,
            "stage_ready_for_activation": True,
            "physical_target_executed": False,
            "production_approved": False,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-root", type=Path, required=True)
    parser.add_argument("--authority", type=Path, required=True)
    parser.add_argument("--authority-sha256", required=True)
    parser.add_argument("--default-patch", type=Path, required=True)
    parser.add_argument("--default-patch-sha256", required=True)
    parser.add_argument("--seeded-patch", type=Path, required=True)
    parser.add_argument("--seeded-patch-sha256", required=True)
    parser.add_argument("--seeded-config", type=Path, required=True)
    parser.add_argument("--cache-contract", type=Path, required=True)
    parser.add_argument("--cache-contract-sha256", required=True)
    parser.add_argument("--generation-timestamp", required=True)
    parser.add_argument("--authority-schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument(
        "--capacity-schema",
        type=Path,
        default=capacity_model.DEFAULT_CAPACITY_SCHEMA,
    )
    parser.add_argument("--tool-root", type=Path)
    arguments = parser.parse_args()
    try:
        result = prepare_stage(
            arguments.game_root,
            arguments.authority,
            arguments.authority_sha256,
            arguments.default_patch,
            arguments.default_patch_sha256,
            arguments.seeded_patch,
            arguments.seeded_patch_sha256,
            arguments.seeded_config,
            arguments.cache_contract,
            arguments.cache_contract_sha256,
            arguments.generation_timestamp,
            authority_schema_path=arguments.authority_schema,
            capacity_schema_path=arguments.capacity_schema,
            tool_root=arguments.tool_root,
        )
    except (
        OSError,
        RuntimeError,
        ValueError,
        TypeError,
        KeyError,
        json.JSONDecodeError,
        zipfile.BadZipFile,
    ) as exc:
        print(json.dumps({"status": "invalid", "error": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
