#!/usr/bin/env python3
"""Stream an exact official archive into a contract-bound generated cache."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
import resource
import re
import shutil
import sys
import time
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, BinaryIO

from _common import load_json, project_root, sha256_bytes, sha256_file, write_json
from stream_partition_zdlf import stream_partition_arrays

CONTRACT_PATH = Path("manifests/generated-cache-contract.json")
OWNERSHIP_MANIFEST = "generated-cache-manifest.json"
MEMBERS = {
    "assets/data/data_d": ("dungeon_template", 2, "zdlf_d_"),
    "assets/data/data_r": ("room_template", 3, "zdlf_r_"),
}
DISK_MARGIN_BYTES = 16 * 1024 * 1024
UTC_TIMESTAMP = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
HEX64 = re.compile(r"[0-9a-f]{64}")
PATH_CONTRACT = {
    "root": "assets/data",
    "dungeon_prefix": "assets/data/zdlf_d_",
    "room_prefix": "assets/data/zdlf_r_",
}


def canonical_sha256(value: Any) -> str:
    return sha256_bytes(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    )


class HashingReader:
    def __init__(self, source: BinaryIO):
        self.source = source
        self.digest = hashlib.sha256()
        self.size = 0

    def read(self, size: int = -1) -> bytes:
        chunk = self.source.read(size)
        self.digest.update(chunk)
        self.size += len(chunk)
        return chunk

    @property
    def sha256(self) -> str:
        return self.digest.hexdigest()


class ContractOutputDirectory:
    """Map partitioner's fixed temporary basenames directly to owned names."""

    def __init__(self, path: Path, prefix: str, allow_existing: bool):
        self.path = path
        self.prefix = prefix
        self.allow_existing = allow_existing

    def mkdir(self, *, parents: bool, exist_ok: bool) -> None:
        # The two source profiles intentionally share one final directory.
        if self.path.is_symlink() or (self.path.exists() and not self.path.is_dir()):
            raise ValueError("generated-cache payload directory is unsafe")
        if self.path.exists() and not self.allow_existing:
            raise ValueError("generated-cache payload directory already exists")
        self.path.mkdir(parents=parents, exist_ok=self.allow_existing)

    def __truediv__(self, filename: str) -> Path:
        if not filename.startswith("partition-") or not filename.endswith(".zdlf"):
            raise ValueError(f"unexpected partition filename: {filename!r}")
        raw = filename[len("partition-"):-len(".zdlf")]
        coordinates = tuple(int(part) for part in raw.split("-"))
        return self.path / expected_name(self.prefix, coordinates)


def expected_name(prefix: str, coordinates: tuple[int, ...]) -> str:
    if any(type(index) is not int or index < 0 for index in coordinates):
        raise ValueError(f"invalid generated coordinates: {coordinates}")
    return prefix + "_".join(str(index) for index in coordinates)


def validate_contract(contract: dict[str, Any]) -> dict[str, dict[str, Any]]:
    ownership = contract.get("ownership", {})
    files = contract.get("generated_files")
    if (
        contract.get("schema_version") != 2
        or contract.get("status") != "deterministic_generated_cache_contract_verified"
        or contract.get("format", {}).get("name") != "ZDLF"
        or contract.get("format", {}).get("version") != 1
        or contract.get("format", {}).get("layout") != "standalone lossless template documents"
        or contract.get("format", {}).get("byte_order") != "little-endian"
        or contract.get("generator", {}).get("one_pass") is not True
        or contract.get("generator", {}).get("full_json_tree_materialized") is not False
        or ownership.get("path_contract") != PATH_CONTRACT
        or ownership.get("generated_files_only") is not True
        or ownership.get("remove_only_when_path_and_sha256_match") is not True
        or ownership.get("remove_unknown_or_modified_owned_path") is not False
        or ownership.get("touch_user_save_paths") is not False
        or ownership.get("recursive_cleanup") is not False
        or not isinstance(files, list)
        or not files
    ):
        raise ValueError("generated-cache contract metadata mismatch")
    if contract.get("generated_file_count") != len(files):
        raise ValueError("generated-cache file count mismatch")
    if contract.get("generated_total_bytes") != sum(item.get("size", -1) for item in files):
        raise ValueError("generated-cache byte count mismatch")
    if contract.get("generated_content_set_sha256") != canonical_sha256(files):
        raise ValueError("generated-cache content-set identity mismatch")

    by_path: dict[str, dict[str, Any]] = {}
    owner_id = ownership.get("owner_id")
    for item in files:
        member = item.get("source_member")
        if member not in MEMBERS:
            raise ValueError(f"unexpected generated-cache source member: {member!r}")
        _, depth, prefix = MEMBERS[member]
        coordinates = item.get("source_coordinates")
        if (
            not isinstance(coordinates, list)
            or len(coordinates) != depth
            or any(type(index) is not int or index < 0 for index in coordinates)
        ):
            raise ValueError(f"invalid generated-cache coordinates: {coordinates!r}")
        relative = item.get("relative_path")
        wanted = "assets/data/" + expected_name(prefix, tuple(coordinates))
        if (
            relative != wanted
            or PurePosixPath(relative).is_absolute()
            or ".." in PurePosixPath(relative).parts
            or type(item.get("size")) is not int
            or item["size"] <= 0
            or HEX64.fullmatch(item.get("sha256", "")) is None
            or item.get("owner_id") != owner_id
            or relative in by_path
        ):
            raise ValueError(f"invalid generated-cache file contract: {relative!r}")
        by_path[relative] = item
    return by_path


def validate_destination(output: Path) -> Path:
    if output.exists() or output.is_symlink():
        raise ValueError("output path already exists")
    parent = output.parent
    if not parent.is_dir() or parent.is_symlink():
        raise ValueError("output parent must be an existing non-symlink directory")
    stage = parent / f"{output.name}.stage-{os.getpid()}"
    if stage.exists() or stage.is_symlink():
        raise ValueError(f"staging path already exists: {stage}")
    return stage


def atomic_activate_no_replace(stage: Path, output: Path) -> None:
    """Atomically activate a directory while refusing an existing target."""
    libc = ctypes.CDLL(None, use_errno=True)
    renameat2 = getattr(libc, "renameat2", None)
    if renameat2 is None:
        raise OSError("atomic no-replace directory activation is unavailable")
    renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    renameat2.restype = ctypes.c_int
    result = renameat2(
        -100,
        os.fsencode(stage),
        -100,
        os.fsencode(output),
        1,
    )
    if result != 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error), str(output))


def verify_source_archive(
    official: Path, contract: dict[str, Any]
) -> None:
    expected = contract["source"]["official_port"]
    if (
        official.is_symlink()
        or not official.is_file()
        or official.stat().st_size != expected["size"]
        or sha256_file(official) != expected["sha256"]
    ):
        raise ValueError("official port identity mismatch")


def ownership_manifest(
    root: Path,
    contract_path: Path,
    contract: dict[str, Any],
    generation_timestamp: str,
) -> dict[str, Any]:
    converter = Path(__file__).resolve()
    partitioner = root / contract["generator"]["path"]
    return {
        "schema_version": 1,
        "status": "contract_verified_generated_cache",
        "profile": contract["profile"],
        "generation_timestamp_utc": generation_timestamp,
        "source": contract["source"],
        "format": contract["format"],
        "generator": {
            "path": contract["generator"]["path"],
            "version": contract["generator"]["version"],
            "sha256": sha256_file(partitioner),
            "one_pass": True,
            "full_json_tree_materialized": False,
        },
        "converter": {
            "path": "scripts/convert_official_cache_bounded.py",
            "version": 1,
            "sha256": sha256_file(converter),
        },
        "contract": {
            "path": CONTRACT_PATH.as_posix() if contract_path == root / CONTRACT_PATH else contract_path.name,
            "sha256": sha256_file(contract_path),
        },
        "ownership": contract["ownership"],
        "generated_files": contract["generated_files"],
        "generated_file_count": contract["generated_file_count"],
        "generated_total_bytes": contract["generated_total_bytes"],
        "generated_content_set_sha256": contract["generated_content_set_sha256"],
        "activation": {
            "method": "same_filesystem_directory_replace",
            "all_payload_files_verified_before_activation": True,
            "existing_output_adopted_or_overwritten": False,
        },
    }


def convert(
    official: Path,
    output: Path,
    contract_path: Path,
    generation_timestamp: str,
    *,
    root: Path | None = None,
) -> dict[str, Any]:
    root = (root or project_root()).resolve()
    official = official.absolute()
    output = output.absolute()
    contract_path = contract_path.absolute()
    if UTC_TIMESTAMP.fullmatch(generation_timestamp) is None:
        raise ValueError("generation timestamp must be UTC RFC3339 seconds")
    if contract_path.is_symlink() or not contract_path.is_file():
        raise ValueError("contract must be a regular non-symlink file")
    contract = load_json(contract_path)
    expected_by_path = validate_contract(contract)
    generator_path = root / contract["generator"]["path"]
    if (
        contract["generator"]["path"] != "scripts/stream_partition_zdlf.py"
        or not generator_path.is_file()
        or sha256_file(generator_path) != contract["generator"]["sha256"]
    ):
        raise ValueError("generated-cache generator identity mismatch")
    verify_source_archive(official, contract)
    stage = validate_destination(output)

    required = contract["generated_total_bytes"] + contract_path.stat().st_size + DISK_MARGIN_BYTES
    available = shutil.disk_usage(output.parent).free
    if available < required:
        raise ValueError(
            f"insufficient free space: need {required} bytes, have {available} bytes"
        )

    started = time.perf_counter()
    stage.mkdir(mode=0o700)
    generated: dict[str, dict[str, Any]] = {}
    source_results: list[dict[str, Any]] = []
    with zipfile.ZipFile(official, "r") as archive:
        infos = archive.infolist()
        for member_index, (member, (profile, depth, prefix)) in enumerate(MEMBERS.items()):
            matching = [info for info in infos if info.filename == member and not info.is_dir()]
            if len(matching) != 1:
                raise ValueError(f"expected exactly one source member {member!r}")
            expected_source = contract["source"]["members"][member]
            if matching[0].file_size != expected_source["size"]:
                raise ValueError(f"source member size mismatch: {member}")
            output_directory = stage / "assets/data"
            with archive.open(matching[0], "r") as raw_source:
                source = HashingReader(raw_source)
                result = stream_partition_arrays(
                    source,
                    ContractOutputDirectory(
                        output_directory, prefix, allow_existing=member_index > 0
                    ),  # type: ignore[arg-type]
                    depth,
                )
            if source.size != expected_source["size"] or source.sha256 != expected_source["sha256"]:
                raise ValueError(f"source member identity mismatch: {member}")
            for item in result["partitions"]:
                relative = item["file"].relative_to(stage).as_posix()
                if relative in generated:
                    raise ValueError(f"duplicate generated path: {relative}")
                generated[relative] = {
                    "relative_path": relative,
                    "source_member": member,
                    "source_coordinates": item["path"],
                    "size": item["size"],
                    "sha256": item["sha256"],
                    "owner_id": contract["ownership"]["owner_id"],
                }
            source_results.append({
                "member": member,
                "profile": profile,
                "source_bytes": source.size,
                "source_sha256": source.sha256,
                "partition_count": len(result["partitions"]),
                "container_count": len(result["container_counts"]),
                "trailing_nuls": result["trailing_nuls"],
            })

    if generated != expected_by_path:
        missing = sorted(set(expected_by_path) - set(generated))
        extra = sorted(set(generated) - set(expected_by_path))
        wrong = sorted(
            path for path in set(generated) & set(expected_by_path)
            if generated[path] != expected_by_path[path]
        )
        raise ValueError(
            f"generated cache contract mismatch: missing={len(missing)} "
            f"extra={len(extra)} wrong={len(wrong)}"
        )

    manifest = ownership_manifest(root, contract_path, contract, generation_timestamp)
    write_json(stage / OWNERSHIP_MANIFEST, manifest)
    atomic_activate_no_replace(stage, output)
    elapsed = time.perf_counter() - started
    return {
        "status": "bounded_cache_conversion_verified",
        "elapsed_seconds": elapsed,
        "peak_rss_kib": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
        "source_members": source_results,
        "generated_file_count": len(generated),
        "generated_total_bytes": sum(item["size"] for item in generated.values()),
        "generated_content_set_sha256": canonical_sha256(
            [generated[path] for path in sorted(generated)]
        ),
        "disk_preflight_required_bytes": required,
        "disk_preflight_available_bytes": available,
        "atomic_activation": True,
        "output_name": output.name,
        "staging_retained": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--official", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--contract", type=Path, default=project_root() / CONTRACT_PATH)
    parser.add_argument("--generation-timestamp", required=True)
    args = parser.parse_args()
    try:
        result = convert(
            args.official,
            args.output_dir,
            args.contract,
            args.generation_timestamp,
        )
    except (OSError, EOFError, UnicodeError, ValueError, TypeError, KeyError,
            json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print(f"bounded cache conversion failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
