"""Shared standard-library helpers for project bootstrap tools."""

from __future__ import annotations

import hashlib
import io
import json
import os
import struct
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def portable_path(path: Path, root: Path | None = None) -> str:
    """Return a manifest-safe path without exposing host-specific directories.

    Paths inside the project are stored relative to the project root. Inputs
    outside the project are represented by filename only under an explicit
    ``<external>`` marker so generated reports remain portable and do not leak
    local usernames or directory layouts.
    """
    base = (root or project_root()).expanduser().resolve()
    resolved = path.expanduser().resolve()
    try:
        return resolved.relative_to(base).as_posix()
    except ValueError:
        return f"<external>/{resolved.name}"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, delete=False, prefix=f".{path.name}."
    ) as handle:
        handle.write(text)
        temp_name = handle.name
    os.replace(temp_name, path)


def write_json(path: Path, data: Any) -> None:
    atomic_write_text(path, json.dumps(data, indent=2, sort_keys=False) + "\n")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def safe_member_path(name: str) -> PurePosixPath:
    normalized = PurePosixPath(name.replace("\\", "/"))
    if normalized.is_absolute() or ".." in normalized.parts:
        raise ValueError(f"unsafe archive member path: {name!r}")
    return normalized


def inventory_zip_bytes(data: bytes, include_hashes: bool = True) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        for info in archive.infolist():
            safe_member_path(info.filename)
            entry: dict[str, Any] = {
                "path": info.filename,
                "is_dir": info.is_dir(),
                "size": info.file_size,
                "compressed_size": info.compress_size,
                "compression": info.compress_type,
                "crc32": f"{info.CRC:08x}",
                "external_attr": info.external_attr,
                "archive_order": len(result),
            }
            if include_hashes and not info.is_dir():
                entry["sha256"] = sha256_bytes(archive.read(info))
            result.append(entry)
    return result


def read_port_from_input(path: Path) -> tuple[bytes, dict[str, Any]]:
    """Return the inner .port bytes and metadata from a .port or outer ZIP."""
    data = path.read_bytes()
    if not zipfile.is_zipfile(io.BytesIO(data)):
        raise ValueError(f"not a ZIP-compatible archive: {path}")

    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        if "assets/game.droid" in names:
            return data, {
                "input_kind": "port",
                "input_path": portable_path(path),
                "outer_sha256": None,
                "nested_member": None,
            }

        candidates = [name for name in names if PurePosixPath(name).name.lower() == "zeldadoi.port"]
        if not candidates:
            candidates = [name for name in names if name.lower().endswith(".port")]
        if len(candidates) != 1:
            raise ValueError(
                f"expected exactly one nested .port in {path}; found {len(candidates)}: {candidates}"
            )
        member = candidates[0]
        return archive.read(member), {
            "input_kind": "outer_zip",
            "input_path": portable_path(path),
            "outer_sha256": sha256_bytes(data),
            "outer_size": len(data),
            "nested_member": member,
        }


def parse_gamemaker_chunks(data: bytes) -> list[dict[str, Any]]:
    """Parse the standard FORM/chunk envelope used by GameMaker data files."""
    if len(data) < 8 or data[:4] != b"FORM":
        raise ValueError("GameMaker data does not begin with FORM")
    declared = struct.unpack_from("<I", data, 4)[0]
    if declared + 8 != len(data):
        raise ValueError(
            f"FORM length mismatch: declared payload {declared}, actual payload {len(data) - 8}"
        )

    chunks: list[dict[str, Any]] = []
    offset = 8
    while offset < len(data):
        if offset + 8 > len(data):
            raise ValueError(f"truncated chunk header at offset {offset}")
        raw_name = data[offset : offset + 4]
        try:
            name = raw_name.decode("ascii")
        except UnicodeDecodeError as exc:
            raise ValueError(f"invalid chunk name at offset {offset}: {raw_name!r}") from exc
        length = struct.unpack_from("<I", data, offset + 4)[0]
        payload_start = offset + 8
        payload_end = payload_start + length
        if payload_end > len(data):
            raise ValueError(
                f"chunk {name} overruns file: end {payload_end}, size {len(data)}"
            )
        payload = data[payload_start:payload_end]
        count = struct.unpack_from("<I", payload, 0)[0] if len(payload) >= 4 else None
        chunks.append(
            {
                "name": name,
                "offset": offset,
                "payload_offset": payload_start,
                "length": length,
                "count_word": count,
                "sha256": sha256_bytes(payload),
            }
        )
        offset = payload_end

    if offset != len(data):
        raise ValueError(f"chunk parse ended at {offset}, file size is {len(data)}")
    return chunks


def zip_read(data: bytes, member: str) -> bytes:
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        return archive.read(member)


def find_first_existing(paths: Iterable[Path]) -> Path | None:
    for path in paths:
        if path.is_file():
            return path
    return None


def safe_extract_zip_bytes(data: bytes, destination: Path) -> list[Path]:
    destination.mkdir(parents=True, exist_ok=True)
    created: list[Path] = []
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        for info in archive.infolist():
            member = safe_member_path(info.filename)
            target = destination.joinpath(*member.parts)
            target_resolved = target.resolve()
            if destination.resolve() not in target_resolved.parents and target_resolved != destination.resolve():
                raise ValueError(f"archive extraction escaped destination: {info.filename}")
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(info))
            created.append(target)
    return created
