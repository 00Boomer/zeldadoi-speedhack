"""Staged CRT enum over the existing single-snapshot Dungeon Seed/Aspect parser.

CRT is the only new writable presentation authority. Filter is read solely as
a legacy OFF/FULL alias. No launcher is switched before the VM supports FAST.
"""
import configparser
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from types import FunctionType, SimpleNamespace

import options_override_dungeon_seed_v2 as previous

MODES = ('OFF', 'FAST', 'FULL')
DEFAULT = 'OFF'
PROFILE_KEY = 'SpeedhackCRT'
ENVIRONMENT_KEY = 'ZELDADOI_SPEEDHACK_CRT'
LEGACY_ENVIRONMENT_KEY = 'ZELDADOI_SPEEDHACK_FILTER'
PREVIOUS_SHA = '2f5df6da44917f4dc3acf28f0b51c6c219d1d8af05ec6fabda8f61194ab091e3'
LEGACY_VALUES = {'None': 'OFF', 'CRT': 'FULL'}
dungeon = previous.previous
legacy = dungeon.previous
aspect = legacy.previous
base = aspect.previous


@dataclass(frozen=True)
class CRTOverride(dungeon.DungeonSeedOverride):
    crt_mode: str | None
    crt_input: str | None

    def as_dict(self):
        result = super().as_dict()
        # Retain the old dataclass ABI internally, without a player-facing
        # generic Filter interface or a second environment setting.
        result.pop('filter_name')
        result.pop('filter_is_effective')
        return dict(result, crt_mode=self.crt_mode, crt_input=self.crt_input,
                    crt_is_effective=self.enable_override and self.crt_mode is not None)


def verify_sources():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PREVIOUS_SHA:
        raise ValueError('CRT predecessor identity changed')
    previous.verify_sources()


def _explicit(text, result):
    if not result.enable_override:
        return None, None
    crt = base.raw_ini_option_values(text, 'Preferences', 'CRT')
    old = base.raw_ini_option_values(text, 'Preferences', 'Filter')
    key, values = ('CRT', crt) if crt else ('Filter', old)
    if not values:
        return None, None
    valid = MODES if key == 'CRT' else LEGACY_VALUES
    if result.source_status == 'malformed' or len(values) != 1 or values[0] not in valid:
        raise ValueError('Invalid ' + key + ': expected one canonical ' +
                         ('OFF, FAST or FULL value' if key == 'CRT' else 'None or CRT legacy value'))
    parser = configparser.ConfigParser(interpolation=None, strict=True, empty_lines_in_values=False)
    parser.optionxform = str
    parser.read_string(text)
    if parser.get('Preferences', key) != values[0]:
        raise ValueError('Invalid ' + key + ': multiline value refused')
    return (values[0] if key == 'CRT' else LEGACY_VALUES[values[0]]), key


def parse_override(path, schema=None):
    verify_sources()
    selected = {}

    def parse_snapshot(filename, rules, snapshot):
        # Both layers see the ORIGINAL immutable bytes. Do not rewrite a Filter
        # line in memory or on disk to trick an older parser into accepting FAST.
        proxy = SimpleNamespace(**dict(vars(base), read_override=lambda *_: snapshot))
        namespace = dict(vars(aspect), previous=proxy, MODES=previous.MODES)
        inherited = FunctionType(aspect.parse_override.__code__, namespace,
                                 argdefs=aspect.parse_override.__defaults__)
        result = inherited(filename, rules)
        text = snapshot[0].decode(rules['file']['encoding']) if snapshot[0] is not None and result.enable_override else ''
        mode, key = _explicit(text, result)
        selected.update(mode=mode, key=key)
        environment = dict(result.environment)
        environment.pop(LEGACY_ENVIRONMENT_KEY, None)
        environment.pop(ENVIRONMENT_KEY, None)
        if mode is not None:
            environment[ENVIRONMENT_KEY] = mode
        presentation = dict(schema_version=3, aspect_presentation_sha256=result.presentation_sha256,
                            explicit_external_crt=mode)
        digest = hashlib.sha256(json.dumps(presentation, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        environment[aspect.PRESENTATION_HASH_KEY] = digest
        # The old Filter field is an inert compatibility carrier for the reused
        # seed translator. Only the canonical CRT environment reaches new glue.
        return legacy.FilterOverride(**dict(result.__dict__, environment=environment,
                                           presentation_sha256=digest), filter_name=None)

    namespace = dict(vars(dungeon), _parse_snapshot=parse_snapshot, verify_sources=verify_sources)
    result = FunctionType(dungeon.parse_override.__code__, namespace,
                          argdefs=dungeon.parse_override.__defaults__)(path, schema)
    return CRTOverride(**result.__dict__, crt_mode=selected['mode'], crt_input=selected['key'])


def saved_crt(profile):
    """Read-only compatibility; committing writes ONLY SpeedhackCRT."""
    if profile is None:
        return DEFAULT
    if type(profile) is not dict:
        raise ValueError('invalid CRT profile')
    if PROFILE_KEY in profile:
        value = profile[PROFILE_KEY]
        if type(value) is not str or value not in MODES:
            raise ValueError('invalid saved CRT enumeration')
        return value
    if 'SpeedhackFilter' in profile:
        value = profile['SpeedhackFilter']
        if type(value) is not str or value not in LEGACY_VALUES:
            raise ValueError('invalid saved legacy Filter')
        return LEGACY_VALUES[value]
    if 'Prefs' not in profile:
        return DEFAULT
    prefs = profile['Prefs']
    if type(prefs) is not list:
        raise ValueError('invalid legacy CRT preferences')
    if len(prefs) <= 3:
        return DEFAULT
    if type(prefs[3]) is not bool:
        raise ValueError('invalid legacy CRT boolean')
    return 'FULL' if prefs[3] else 'OFF'


def effective_crt(result, profile):
    if result.enable_override_error is not None:
        raise ValueError(result.enable_override_error)
    if result.enable_override and result.crt_mode is not None:
        if result.crt_mode not in MODES:
            raise ValueError('invalid effective external CRT')
        return result.crt_mode
    return saved_crt(profile)


effective_aspect = previous.effective_aspect
