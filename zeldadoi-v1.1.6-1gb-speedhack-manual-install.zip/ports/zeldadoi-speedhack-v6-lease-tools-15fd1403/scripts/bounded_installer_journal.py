#!/usr/bin/env python3
"""Strict transaction-journal contract for the bounded PortMaster pipeline."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path
from typing import Any


OWNER = "org.zeldadoi.speedhack"
OFFICIAL_PORT_SHA256 = (
    "df37214a5b1dd7e91050a4df686103ade56b53c935792ada0f96766c4413cade"
)
TRANSACTION_NAME = "bounded-transaction"
TRANSACTION_NEXT_NAME = "bounded-transaction.next"
PHASES = (
    "validated",
    "source-preserved",
    "droid-extracted",
    "droid-patched",
    "cache-generated",
    "archive-assembled",
    "activation-prepared",
    "archive-activated",
    "state-committed",
)
FIELDS = (
    "SCHEMA_VERSION",
    "OWNER",
    "PATCH_ID",
    "MANIFEST_SHA256",
    "SOURCE_SHA256",
    "PREVIOUS_ACTIVE_SHA256",
    "OUTPUT_SHA256",
    "PHASE",
    "STAGE_BASENAME",
    "CANDIDATE_BASENAME",
)
HEX64 = re.compile(r"[0-9a-f]{64}")
TOKEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,95}")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def stage_basename(patch_id: str) -> str:
    return f".zeldadoi-bounded-stage-{patch_id}"


def candidate_basename(patch_id: str) -> str:
    return f".zeldadoi.port.bounded-next-{patch_id}"


def validate_record(record: dict[str, str]) -> dict[str, str]:
    missing = sorted(set(FIELDS) - record.keys())
    unknown = sorted(record.keys() - set(FIELDS))
    if missing or unknown:
        raise ValueError(
            f"journal field coverage mismatch: missing={missing} unknown={unknown}"
        )
    if record["SCHEMA_VERSION"] != "1":
        raise ValueError("unsupported bounded transaction journal schema")
    if record["OWNER"] != OWNER:
        raise ValueError("bounded transaction journal owner mismatch")
    patch_id = record["PATCH_ID"]
    if TOKEN.fullmatch(patch_id) is None:
        raise ValueError("invalid bounded transaction patch ID")
    for key in (
        "MANIFEST_SHA256",
        "SOURCE_SHA256",
        "PREVIOUS_ACTIVE_SHA256",
        "OUTPUT_SHA256",
    ):
        if HEX64.fullmatch(record[key]) is None:
            raise ValueError(f"invalid bounded transaction SHA-256: {key}")
    if record["SOURCE_SHA256"] != OFFICIAL_PORT_SHA256:
        raise ValueError("bounded transaction source is not exact official v1.1.6")
    if record["PREVIOUS_ACTIVE_SHA256"] == record["OUTPUT_SHA256"]:
        raise ValueError("bounded transaction previous and output identities must differ")
    if record["PHASE"] not in PHASES:
        raise ValueError("invalid bounded transaction phase")
    if record["STAGE_BASENAME"] != stage_basename(patch_id):
        raise ValueError("bounded transaction stage basename mismatch")
    if record["CANDIDATE_BASENAME"] != candidate_basename(patch_id):
        raise ValueError("bounded transaction candidate basename mismatch")
    return dict(record)


def make_record(
    *,
    patch_id: str,
    manifest_sha256: str,
    previous_active_sha256: str,
    output_sha256: str,
    phase: str = PHASES[0],
) -> dict[str, str]:
    return validate_record({
        "SCHEMA_VERSION": "1",
        "OWNER": OWNER,
        "PATCH_ID": patch_id,
        "MANIFEST_SHA256": manifest_sha256,
        "SOURCE_SHA256": OFFICIAL_PORT_SHA256,
        "PREVIOUS_ACTIVE_SHA256": previous_active_sha256,
        "OUTPUT_SHA256": output_sha256,
        "PHASE": phase,
        "STAGE_BASENAME": stage_basename(patch_id),
        "CANDIDATE_BASENAME": candidate_basename(patch_id),
    })


def serialize_record(record: dict[str, str]) -> str:
    checked = validate_record(record)
    return "".join(f"{key}={checked[key]}\n" for key in FIELDS)


def parse_record_text(text: str) -> dict[str, str]:
    record: dict[str, str] = {}
    for line_number, raw in enumerate(text.splitlines(), 1):
        if not raw or raw.startswith("#"):
            continue
        if "=" not in raw:
            raise ValueError(f"malformed bounded transaction line {line_number}")
        key, value = raw.split("=", 1)
        if not key or not value:
            raise ValueError(f"empty bounded transaction field on line {line_number}")
        if re.fullmatch(r"[A-Z0-9_]+", key) is None:
            raise ValueError(f"invalid bounded transaction key: {key!r}")
        if any(character.isspace() for character in value):
            raise ValueError(f"bounded transaction value contains whitespace: {key}")
        if key in record:
            raise ValueError(f"duplicate bounded transaction field: {key}")
        record[key] = value
    return validate_record(record)


def read_record(path: Path) -> dict[str, str]:
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        metadata = None
    if (
        metadata is None
        or not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
    ):
        raise ValueError("bounded transaction journal must be a regular non-symlink file")
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("bounded transaction journal must be UTF-8") from exc
    return parse_record_text(text)


def verify_owned_state_directory(state_directory: Path) -> None:
    if state_directory.is_symlink() or not state_directory.is_dir():
        raise ValueError("bounded transaction state directory is missing or unsafe")
    owner = state_directory / "owner"
    if (
        not owner.exists()
        or owner.is_symlink()
        or not owner.is_file()
        or owner.stat().st_nlink != 1
        or owner.read_text(encoding="utf-8") != OWNER + "\n"
    ):
        raise ValueError("bounded transaction state directory owner mismatch")


def fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_record_atomic(state_directory: Path, record: dict[str, str]) -> Path:
    """Durably replace the journal; never removes a pre-existing next file."""
    verify_owned_state_directory(state_directory)
    text = serialize_record(record)
    journal = state_directory / TRANSACTION_NAME
    pending = state_directory / TRANSACTION_NEXT_NAME
    if journal.exists() and (
        journal.is_symlink()
        or not journal.is_file()
        or journal.stat().st_nlink != 1
    ):
        raise ValueError("bounded transaction journal path is unsafe")
    if pending.exists() or pending.is_symlink():
        raise ValueError("bounded transaction pending-journal path already exists")
    descriptor = os.open(pending, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
    except BaseException:
        # The pending file is deliberately retained for explicit recovery.
        raise
    os.replace(pending, journal)
    fsync_directory(state_directory)
    return journal


def advance_record(
    state_directory: Path,
    next_phase: str,
    *,
    expected_manifest_sha256: str,
) -> dict[str, str]:
    journal = state_directory / TRANSACTION_NAME
    record = read_record(journal)
    if record["MANIFEST_SHA256"] != expected_manifest_sha256:
        raise ValueError("bounded transaction manifest authority mismatch")
    current_index = PHASES.index(record["PHASE"])
    if current_index + 1 >= len(PHASES) or PHASES[current_index + 1] != next_phase:
        raise ValueError("bounded transaction phase advance must be exactly monotonic")
    advanced = dict(record)
    advanced["PHASE"] = next_phase
    write_record_atomic(state_directory, advanced)
    return advanced


def recovery_decision(
    record: dict[str, str],
    *,
    expected_manifest_sha256: str,
    active_sha256: str,
    preserved_sha256: str | None,
    state_record_matches: bool,
) -> dict[str, Any]:
    """Return a fail-closed recovery action without mutating any path."""
    record = validate_record(record)
    if HEX64.fullmatch(expected_manifest_sha256) is None:
        raise ValueError("expected manifest authority is not a SHA-256")
    if HEX64.fullmatch(active_sha256) is None:
        raise ValueError("active identity is not a SHA-256")
    if preserved_sha256 is not None and HEX64.fullmatch(preserved_sha256) is None:
        raise ValueError("preserved identity is not a SHA-256")
    if record["MANIFEST_SHA256"] != expected_manifest_sha256:
        return {
            "action": "refuse-release-mismatch",
            "may_remove_owned_stages": False,
            "may_write_state": False,
        }

    phase_index = PHASES.index(record["PHASE"])
    preservation_index = PHASES.index("source-preserved")
    activation_index = PHASES.index("activation-prepared")
    if phase_index >= preservation_index:
        if preserved_sha256 != record["SOURCE_SHA256"]:
            return {
                "action": "refuse-preserved-source-mismatch",
                "may_remove_owned_stages": False,
                "may_write_state": False,
            }
    elif preserved_sha256 not in (None, record["SOURCE_SHA256"]):
        return {
            "action": "refuse-preserved-source-mismatch",
            "may_remove_owned_stages": False,
            "may_write_state": False,
        }

    if active_sha256 == record["PREVIOUS_ACTIVE_SHA256"]:
        return {
            "action": "discard-owned-stages-and-retry",
            "may_remove_owned_stages": True,
            "may_write_state": False,
        }
    if active_sha256 != record["OUTPUT_SHA256"]:
        return {
            "action": "refuse-active-payload-mismatch",
            "may_remove_owned_stages": False,
            "may_write_state": False,
        }
    if phase_index < activation_index:
        return {
            "action": "refuse-unrecorded-output-activation",
            "may_remove_owned_stages": False,
            "may_write_state": False,
        }
    if state_record_matches:
        return {
            "action": "cleanup-owned-stages-only",
            "may_remove_owned_stages": True,
            "may_write_state": False,
        }
    return {
        "action": "adopt-exact-output-then-cleanup",
        "may_remove_owned_stages": True,
        "may_write_state": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--journal", type=Path, required=True)
    args = parser.parse_args()
    try:
        record = read_record(args.journal)
    except (OSError, ValueError) as exc:
        print(f"bounded installer journal validation failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(record, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
