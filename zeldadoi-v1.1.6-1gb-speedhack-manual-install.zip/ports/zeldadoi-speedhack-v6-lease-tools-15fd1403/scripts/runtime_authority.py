#!/usr/bin/env python3
"""Strict parser and validator for a payload-free dual-runtime authority file.

The authority file is an installer/release-owned identity record.  It identifies
two archives and their runtime configuration files; it never carries archive,
APK, GameMaker, or user-configuration bytes.  It deliberately does not assert
that either runtime has been built, installed, launched, or behaviorally
validated.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path, PurePosixPath
from typing import Any, NoReturn


DEFAULT_SCHEMA = Path(__file__).resolve().parents[1] / "config/runtime-authority-schema.json"
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
RELEASE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
MAX_UNSIGNED = (1 << 63) - 1

SCHEMA_KEYS = {
    "schema_version",
    "authority_manifest_schema_version",
    "authority_kind",
    "authority_manifest_path",
    "maximum_authority_bytes",
    "official_source",
    "dungeon_seed",
    "runtimes",
    "policy",
}
OFFICIAL_SOURCE_KEYS = {"game_version", "archive", "game_droid"}
ARCHIVE_KEYS = {"path", "size", "sha256"}
GAME_DROID_KEYS = {"member", "size", "sha256"}
DUNGEON_SEED_KEYS = {"algorithm_id"}
RUNTIME_PATH_KEYS = {"runtime_config_path", "archive_path"}
RUNTIMES_KEYS = {"default", "seeded"}
POLICY_KEYS = {
    "manifest_requires_exact_key_coverage",
    "manifest_may_embed_payload",
    "manifest_may_delegate_to_user_configuration",
    "default_runtime_may_differ_from_official_source",
    "seeded_runtime_must_differ_from_default_runtime",
}
AUTHORITY_KEYS = {
    "schema_version",
    "authority_kind",
    "release_id",
    "official_source",
    "dungeon_seed",
    "runtimes",
}
RUNTIME_IDENTITY_KEYS = {
    "runtime_config_path",
    "runtime_config_size",
    "runtime_config_sha256",
    "archive_path",
    "archive_size",
    "archive_sha256",
    "game_droid",
}


class RuntimeAuthorityError(ValueError):
    """The authority file or its schema violates the strict contract."""


def reject(message: str) -> NoReturn:
    raise RuntimeAuthorityError(message)


def _no_duplicate_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            reject(f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def _reject_nonfinite(value: str) -> NoReturn:
    reject(f"non-finite JSON number is forbidden: {value}")


def _read_regular_utf8_json(
    path: Path, maximum_bytes: int, expected_sha256: str | None = None
) -> Any:
    """Read a bounded regular non-symlink UTF-8 JSON file from one descriptor."""
    if type(maximum_bytes) is not int or maximum_bytes <= 0:
        reject("JSON byte limit must be a positive integer")
    try:
        initial = path.lstat()
    except OSError as error:
        reject(f"cannot stat JSON file: {error}")
    if stat.S_ISLNK(initial.st_mode) or not stat.S_ISREG(initial.st_mode):
        reject("authority JSON must be a regular non-symlink file")
    if initial.st_size > maximum_bytes:
        reject("authority JSON exceeds the byte limit")

    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as error:
        reject(f"cannot open authority JSON safely: {error}")
    try:
        opened = os.fstat(descriptor)
        if not stat.S_ISREG(opened.st_mode):
            reject("authority JSON must be a regular file")
        if (opened.st_dev, opened.st_ino) != (initial.st_dev, initial.st_ino):
            reject("authority JSON changed while opening")
        if opened.st_size > maximum_bytes:
            reject("authority JSON exceeds the byte limit")
        chunks: list[bytes] = []
        remaining = maximum_bytes + 1
        while remaining:
            block = os.read(descriptor, min(65536, remaining))
            if not block:
                break
            chunks.append(block)
            remaining -= len(block)
        raw = b"".join(chunks)
        final = os.fstat(descriptor)
        if final.st_size != opened.st_size or len(raw) != opened.st_size:
            reject("authority JSON changed while reading")
        if len(raw) > maximum_bytes:
            reject("authority JSON exceeds the byte limit")
    finally:
        os.close(descriptor)

    if expected_sha256 is not None:
        _sha256(expected_sha256, "expected authority SHA-256")
        if hashlib.sha256(raw).hexdigest() != expected_sha256:
            reject("authority JSON identity mismatch")
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        reject(f"authority JSON is not strict UTF-8: {error}")
    if text.startswith("\ufeff"):
        reject("authority JSON must not include a UTF-8 BOM")
    try:
        return json.loads(
            text,
            object_pairs_hook=_no_duplicate_object,
            parse_constant=_reject_nonfinite,
        )
    except (json.JSONDecodeError, RuntimeAuthorityError) as error:
        reject(f"invalid authority JSON: {error}")


def _exact_object(value: Any, expected: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        reject(f"{label} must be an object")
    actual = set(value)
    if actual != expected:
        reject(
            f"{label} key coverage mismatch: "
            f"missing={sorted(expected - actual)} unknown={sorted(actual - expected)}"
        )
    return value


def _positive_integer(value: Any, label: str) -> int:
    if type(value) is not int or value <= 0 or value > MAX_UNSIGNED:
        reject(f"{label} must be a positive bounded integer")
    return value


def _sha256(value: Any, label: str) -> str:
    if type(value) is not str or HEX64.fullmatch(value) is None:
        reject(f"{label} must be an exact lowercase SHA-256")
    return value


def _safe_relative_posix(value: Any, label: str) -> str:
    if type(value) is not str or not value or "\\" in value or "\x00" in value:
        reject(f"{label} must be a nonempty safe relative POSIX path")
    pure = PurePosixPath(value)
    if (
        pure.is_absolute()
        or value != pure.as_posix()
        or value.startswith("./")
        or value.endswith("/")
        or not pure.parts
        or any(part in {"", ".", ".."} for part in pure.parts)
    ):
        reject(f"{label} must be a safe relative POSIX path")
    return value


def _validate_archive(value: Any, label: str) -> dict[str, Any]:
    record = _exact_object(value, ARCHIVE_KEYS, label)
    _safe_relative_posix(record["path"], f"{label}.path")
    _positive_integer(record["size"], f"{label}.size")
    _sha256(record["sha256"], f"{label}.sha256")
    return record


def _validate_game_droid(value: Any, label: str) -> dict[str, Any]:
    record = _exact_object(value, GAME_DROID_KEYS, label)
    _safe_relative_posix(record["member"], f"{label}.member")
    _positive_integer(record["size"], f"{label}.size")
    _sha256(record["sha256"], f"{label}.sha256")
    return record


def _validate_schema(schema: Any) -> dict[str, Any]:
    document = _exact_object(schema, SCHEMA_KEYS, "runtime authority schema")
    if document["schema_version"] != 1:
        reject("unsupported runtime authority schema")
    if document["authority_manifest_schema_version"] != 1:
        reject("unsupported runtime authority manifest schema")
    if document["authority_kind"] != "zeldadoi-speedhack-runtime-authority":
        reject("unexpected runtime authority kind")
    if document["authority_manifest_path"] != ".zeldadoi-speedhack/runtime-authority.json":
        reject("runtime authority schema manifest path changed")
    _safe_relative_posix(
        document["authority_manifest_path"], "authority_manifest_path"
    )
    _positive_integer(document["maximum_authority_bytes"], "maximum_authority_bytes")

    official = _exact_object(document["official_source"], OFFICIAL_SOURCE_KEYS, "schema official_source")
    if official["game_version"] != "1.1.6":
        reject("runtime authority schema must bind official version 1.1.6")
    _validate_archive(official["archive"], "schema official_source.archive")
    _validate_game_droid(official["game_droid"], "schema official_source.game_droid")

    seed = _exact_object(document["dungeon_seed"], DUNGEON_SEED_KEYS, "schema dungeon_seed")
    if type(seed["algorithm_id"]) is not str or not seed["algorithm_id"]:
        reject("schema dungeon seed algorithm identity is invalid")

    runtimes = _exact_object(document["runtimes"], RUNTIMES_KEYS, "schema runtimes")
    for role in ("default", "seeded"):
        _exact_object(runtimes[role], RUNTIME_PATH_KEYS, f"schema runtimes.{role}")
        _safe_relative_posix(runtimes[role]["runtime_config_path"], f"schema {role} runtime_config_path")
        _safe_relative_posix(runtimes[role]["archive_path"], f"schema {role} archive_path")
    if (
        runtimes["default"]["runtime_config_path"] != "gmloader.json"
        or runtimes["default"]["archive_path"] != "zeldadoi.port"
        or runtimes["seeded"]["runtime_config_path"] != ".zeldadoi-speedhack/gmloader-seeded.json"
        or runtimes["seeded"]["archive_path"] != "zeldadoi.seeded.port"
    ):
        reject("runtime authority schema fixed paths changed")

    if schema_official_path := document["official_source"]["archive"]["path"]:
        if schema_official_path != "zeldadoi.official-v1.1.6.port":
            reject("runtime authority schema preserved-official path changed")

    policy = _exact_object(document["policy"], POLICY_KEYS, "schema policy")
    if policy != {
        "manifest_requires_exact_key_coverage": True,
        "manifest_may_embed_payload": False,
        "manifest_may_delegate_to_user_configuration": False,
        "default_runtime_may_differ_from_official_source": True,
        "seeded_runtime_must_differ_from_default_runtime": True,
    }:
        reject("runtime authority schema payload or user-configuration policy changed")
    return document


def load_schema(path: Path = DEFAULT_SCHEMA) -> dict[str, Any]:
    # The schema is tracked source but receives the same non-symlink/UTF-8 guard.
    return _validate_schema(_read_regular_utf8_json(path, 65536))


def authority_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _same_identity(left: dict[str, Any], right: dict[str, Any]) -> bool:
    return left["size"] == right["size"] and left["sha256"] == right["sha256"]


def validate_document(document: Any, schema: dict[str, Any]) -> dict[str, Any]:
    """Validate an already parsed authority document against the pinned schema."""
    schema = _validate_schema(schema)
    authority = _exact_object(document, AUTHORITY_KEYS, "runtime authority")
    if authority["schema_version"] != schema["authority_manifest_schema_version"]:
        reject("unsupported runtime authority manifest schema")
    if authority["authority_kind"] != schema["authority_kind"]:
        reject("runtime authority kind does not match schema")
    if type(authority["release_id"]) is not str or RELEASE_ID.fullmatch(authority["release_id"]) is None:
        reject("release_id must be a bounded portable token")

    official = _exact_object(authority["official_source"], OFFICIAL_SOURCE_KEYS, "official_source")
    schema_official = schema["official_source"]
    if official["game_version"] != schema_official["game_version"]:
        reject("official game version does not match source authority")
    archive = _validate_archive(official["archive"], "official_source.archive")
    droid = _validate_game_droid(official["game_droid"], "official_source.game_droid")
    if archive != schema_official["archive"] or droid != schema_official["game_droid"]:
        reject("official source identity does not match source authority")

    seed = _exact_object(authority["dungeon_seed"], DUNGEON_SEED_KEYS, "dungeon_seed")
    if seed != schema["dungeon_seed"]:
        reject("dungeon seed algorithm identity does not match source authority")

    runtimes = _exact_object(authority["runtimes"], RUNTIMES_KEYS, "runtimes")
    identities: dict[str, dict[str, Any]] = {}
    for role in ("default", "seeded"):
        runtime = _exact_object(runtimes[role], RUNTIME_IDENTITY_KEYS, f"runtimes.{role}")
        fixed = schema["runtimes"][role]
        if runtime["runtime_config_path"] != fixed["runtime_config_path"]:
            reject(f"runtimes.{role} runtime config path does not match fixed authority")
        if runtime["archive_path"] != fixed["archive_path"]:
            reject(f"runtimes.{role} archive path does not match fixed authority")
        _safe_relative_posix(runtime["runtime_config_path"], f"runtimes.{role}.runtime_config_path")
        _safe_relative_posix(runtime["archive_path"], f"runtimes.{role}.archive_path")
        identities[role] = {
            "runtime_config_size": _positive_integer(
                runtime["runtime_config_size"],
                f"runtimes.{role}.runtime_config_size",
            ),
            "runtime_config_sha256": _sha256(
                runtime["runtime_config_sha256"],
                f"runtimes.{role}.runtime_config_sha256",
            ),
            "size": _positive_integer(runtime["archive_size"], f"runtimes.{role}.archive_size"),
            "sha256": _sha256(runtime["archive_sha256"], f"runtimes.{role}.archive_sha256"),
            "game_droid": _validate_game_droid(runtime["game_droid"], f"runtimes.{role}.game_droid"),
        }

    if _same_identity(identities["default"], identities["seeded"]):
        reject("seeded runtime archive must be distinct from the default archive")
    if identities["default"]["game_droid"] == identities["seeded"]["game_droid"]:
        reject("seeded runtime game.droid must be distinct from the default member")
    return authority


def load_authority(
    path: Path,
    schema_path: Path = DEFAULT_SCHEMA,
    expected_sha256: str | None = None,
) -> dict[str, Any]:
    schema = load_schema(schema_path)
    document = _read_regular_utf8_json(
        path, schema["maximum_authority_bytes"], expected_sha256
    )
    return validate_document(document, schema)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authority", type=Path, required=True)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument("--expected-sha256")
    args = parser.parse_args(argv)
    try:
        authority = load_authority(
            args.authority, args.schema, expected_sha256=args.expected_sha256
        )
    except RuntimeAuthorityError as error:
        print(f"runtime authority rejected: {error}", file=sys.stderr)
        return 1
    print(json.dumps({"release_id": authority["release_id"], "authority_sha256": authority_sha256(args.authority)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
