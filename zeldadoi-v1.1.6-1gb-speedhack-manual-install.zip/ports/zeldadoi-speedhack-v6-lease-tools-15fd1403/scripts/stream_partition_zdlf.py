#!/usr/bin/env python3
"""Bounded one-pass partitioning of nested JSON arrays into standalone ZDLF."""

from __future__ import annotations

import hashlib
import struct
from pathlib import Path
from typing import Any, BinaryIO

from lossless_data_format import MAGIC, VERSION
from stream_encode_zdlf import StreamingEncoder


class PartitionedStreamingEncoder(StreamingEncoder):
    def __init__(
        self,
        source: BinaryIO,
        output_directory: Path,
        partition_depth: int,
    ):
        if partition_depth < 1:
            raise ValueError("partition depth must be positive")
        output_directory.mkdir(parents=True, exist_ok=False)
        self.output_directory = output_directory
        self.partition_depth = partition_depth
        self.partitions: list[dict[str, Any]] = []
        self.container_counts: list[dict[str, Any]] = []
        super().__init__(source, output=None)  # type: ignore[arg-type]

    def _encode_partition(self, path: tuple[int, ...]) -> None:
        output_path = self.output_directory / (
            "partition-" + "-".join(str(index) for index in path) + ".zdlf"
        )
        self.values = 0
        self.max_depth = 0
        self.max_token_bytes = 0
        self.max_object_keys = 0
        digest = hashlib.sha256()
        with output_path.open("w+b") as output:
            self.output = output
            output.write(MAGIC)
            output.write(struct.pack("<BBI", VERSION, 0, 0))
            self._parse_value(0)
            size = output.tell()
            output.seek(0)
            while chunk := output.read(1024 * 1024):
                digest.update(chunk)
        self.partitions.append({
            "path": list(path),
            "file": output_path,
            "size": size,
            "sha256": digest.hexdigest(),
            "values": self.values,
            "max_depth": self.max_depth,
            "max_token_bytes": self.max_token_bytes,
            "max_object_keys": self.max_object_keys,
        })

    def _parse_partition_container(
        self, level: int, path: tuple[int, ...]
    ) -> None:
        self._skip_ws()
        self._expect(ord("["))
        count = 0
        self._skip_ws()
        if self.stream.peek() != ord("]"):
            while True:
                if level == self.partition_depth:
                    self._encode_partition(path + (count,))
                else:
                    self._parse_partition_container(level + 1, path + (count,))
                count += 1
                if count > 0xFFFFFFFF:
                    raise ValueError("partition container exceeds u32 count")
                self._skip_ws()
                delimiter = self.stream.take()
                if delimiter == ord("]"):
                    break
                if delimiter != ord(","):
                    raise ValueError(
                        "expected comma or closing bracket in partition container"
                    )
                self._skip_ws()
        else:
            self.stream.take()
        self.container_counts.append({"path": list(path), "count": count})

    def encode_partitions(self) -> dict[str, Any]:
        self._parse_partition_container(1, ())
        self._skip_ws()
        trailing_nuls = 0
        while self.stream.peek() == 0:
            self.stream.take()
            trailing_nuls += 1
        if self.stream.peek() is not None:
            raise ValueError("non-NUL bytes follow the JSON document")
        return {
            "source_bytes": self.stream.bytes_read,
            "partition_depth": self.partition_depth,
            "trailing_nuls": trailing_nuls,
            "container_counts": sorted(
                self.container_counts, key=lambda item: item["path"]
            ),
            "partitions": self.partitions,
        }


def stream_partition_arrays(
    source: BinaryIO, output_directory: Path, partition_depth: int
) -> dict[str, Any]:
    return PartitionedStreamingEncoder(
        source, output_directory, partition_depth
    ).encode_partitions()
