#!/usr/bin/env python3
"""Launch ZeldaDOI once with an external sparse configuration overlay."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import secrets
import signal
import subprocess
import sys
import time
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any
from dataclasses import dataclass

from bounded_runtime_lock import runtime_lock
from options_override import (
    DEFAULT_SCHEMA,
    OVERRIDE_BASENAME,
    load_schema,
    parse_override,
    resolve_override,
)
from runtime_authority import (
    DEFAULT_SCHEMA as DEFAULT_RUNTIME_AUTHORITY_SCHEMA,
    load_authority,
    load_schema as load_runtime_authority_schema,
)


TOKEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}")
ROLE_VALUES = {"official", "candidate", "jeod"}
PHYSICAL_BASIC_EVIDENCE_ROLES = {
    "exact_official": "official",
    "combined_lazy_candidate": "candidate",
}
ACTIVE_ARCHIVE = "zeldadoi.port"
GAME_DROID_MEMBER = "assets/game.droid"
PHYSICAL_BASIC_BUILD_RECORD = "private-replay-plan-feeder-build-record.json"
PHYSICAL_BASIC_PLAN = "zdlf-replay-plan.jsonl"
PHYSICAL_BASIC_MARKER = "zdlf-replay-plan-markers.txt"
PHYSICAL_OBSERVATION_BUILD_RECORD = (
    "private-replay-observation-feeder-build-record.json"
)
PHYSICAL_OBSERVATION_MARKERS = {
    "input_marker_basename": "zdlf-replay-plan-markers.txt",
    "checkpoint_marker_basename": "zdlf-replay-checkpoint-markers.txt",
    "enemy_state_marker_basename": "zdlf-replay-enemy-state-markers.txt",
    "object_counts_marker_basename": "zdlf-replay-object-counts-markers.txt",
    "timers_marker_basename": "zdlf-replay-timers-markers.txt",
    "ds_sizes_marker_basename": "zdlf-replay-ds-sizes-markers.txt",
    "surfaces_marker_basename": "zdlf-replay-surfaces-markers.txt",
    "runtime_sprites_marker_basename": "zdlf-replay-runtime-sprites-markers.txt",
    "buffers_marker_basename": "zdlf-replay-buffers-markers.txt",
    "loaded_templates_marker_basename": "zdlf-replay-loaded-templates-markers.txt",
    "cache_state_marker_basename": "zdlf-replay-cache-state-markers.txt",
    "audio_events_marker_basename": "zdlf-replay-audio-events-markers.txt",
    "save_state_marker_basename": "zdlf-replay-save-state-markers.txt",
    "frame_capture_marker_basename": "zdlf-replay-frame-capture-markers.txt",
    "rng_state_marker_basename": "zdlf-replay-rng-state-markers.txt",
    "room_template_choice_marker_basename": (
        "zdlf-replay-room-template-choice-markers.txt"
    ),
    "room_transform_choice_marker_basename": (
        "zdlf-replay-room-transform-choice-markers.txt"
    ),
    "frame_timing_marker_basename": "zdlf-replay-frame-timing-markers.txt",
}
TELEMETRY_RELATIVE = Path("saves/speedhack-telemetry")
SPEEDHACK_STATE_RELATIVE = Path("saves/speedhack")
INSTALLER_STATE_RELATIVE = Path(".zeldadoi-speedhack")
OWNER_ID = "org.zeldadoi.speedhack.telemetry"
STATE_OWNER_ID = "org.zeldadoi.speedhack.state"
SEED_RECORD_BASENAME = "dungeon_seed.txt"
SEED_DISPLAY_SECONDS = 3.0
SEED_ENVIRONMENT_KEYS = {
    "ZELDADOI_SPEEDHACK_USE_DUNGEON_SEED",
    "ZELDADOI_SPEEDHACK_DUNGEON_SEED",
    "ZELDADOI_SPEEDHACK_DUNGEON_SEED_ORIGIN",
    "ZELDADOI_SPEEDHACK_RUNTIME_CONFIG_SHA256",
    "ZELDADOI_SPEEDHACK_GENERATION_CONFIG_SHA256",
}
RUNSEED_ENVIRONMENT_KEYS = {
    "ZELDADOI_SPEEDHACK_USE_RUN_SEED",
    "ZELDADOI_SPEEDHACK_RUN_SEED",
    "ZELDADOI_SPEEDHACK_RUN_SEED_ORIGIN",
    "ZELDADOI_SPEEDHACK_RUNSEED_CONFIG_SHA256",
}
CONFIG_ENVIRONMENT_KEYS = {
    "ZELDADOI_SPEEDHACK_ENABLE_OVERRIDE",
    "ZELDADOI_SPEEDHACK_CONFIG_SOURCE",
    "ZELDADOI_SPEEDHACK_LIGHTING_MODE",
    "ZELDADOI_SPEEDHACK_DIFFICULTY",
}
OFFICIAL_GAME_VERSION = "1.1.6"
SPEEDHACK_VERSION = "development-unreleased"
PROJECT_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class ResolvedDungeonSeed:
    enabled: bool
    origin: str
    seed: int | None
    runtime_configuration_sha256: str
    generation_configuration_sha256: str | None

    @property
    def environment(self) -> dict[str, str]:
        if not self.enabled or self.seed is None:
            return {}
        if self.generation_configuration_sha256 is None:
            raise ValueError("enabled dungeon seed lacks a generation identity")
        return {
            "ZELDADOI_SPEEDHACK_USE_DUNGEON_SEED": "1",
            "ZELDADOI_SPEEDHACK_DUNGEON_SEED": str(self.seed),
            "ZELDADOI_SPEEDHACK_DUNGEON_SEED_ORIGIN": self.origin,
            "ZELDADOI_SPEEDHACK_RUNTIME_CONFIG_SHA256": (
                self.runtime_configuration_sha256
            ),
            "ZELDADOI_SPEEDHACK_GENERATION_CONFIG_SHA256": (
                self.generation_configuration_sha256
            ),
        }


@dataclass(frozen=True)
class ResolvedRunSeed:
    """Launcher-only RunSeed selection; no GameMaker RNG behavior is claimed."""

    enabled: bool
    origin: str
    seed: int | None
    runtime_configuration_sha256: str

    @property
    def environment(self) -> dict[str, str]:
        if not self.enabled or self.seed is None:
            return {}
        return {
            "ZELDADOI_SPEEDHACK_USE_RUN_SEED": "1",
            "ZELDADOI_SPEEDHACK_RUN_SEED": str(self.seed),
            "ZELDADOI_SPEEDHACK_RUN_SEED_ORIGIN": self.origin,
            "ZELDADOI_SPEEDHACK_RUNSEED_CONFIG_SHA256": (
                self.runtime_configuration_sha256
            ),
        }


@dataclass(frozen=True)
class PhysicalEvidenceInputIdentity:
    path: Path
    label: str
    size: int
    sha256: str


@dataclass(frozen=True)
class PhysicalBasicEvidence:
    kind: str
    role: str
    payload: Path
    environment: Path
    initial_state: Path
    plan: Path
    build_record: Path
    marker: Path
    pattern: str
    ready_timeout_seconds: int
    build_record_sha256: str
    sampler_size: int
    sampler_sha256: str
    gmloader_config: Path
    gmloader_config_size: int
    gmloader_config_sha256: str
    options_override: Path
    options_override_size: int
    options_override_sha256: str
    input_identities: tuple[PhysicalEvidenceInputIdentity, ...]


def default_sampler() -> Path | None:
    candidates = (
        Path(__file__).resolve().with_name("profile_process.sh"),
        PROJECT_ROOT / "device/tools/profile_process.sh",
    )
    return next((path for path in candidates if path.is_file()), None)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def archive_identities(path: Path) -> tuple[int | None, str | None, str | None]:
    if path.is_symlink() or not path.is_file():
        return None, None, None
    archive_hash = sha256_file(path)
    game_hash = None
    try:
        with zipfile.ZipFile(path) as archive:
            info = archive.getinfo(GAME_DROID_MEMBER)
            with archive.open(info) as handle:
                digest = hashlib.sha256()
                while chunk := handle.read(1024 * 1024):
                    digest.update(chunk)
                game_hash = digest.hexdigest()
    except (OSError, KeyError, zipfile.BadZipFile):
        pass
    return path.stat().st_size, archive_hash, game_hash


def runtime_identity(command: list[str]) -> dict[str, Any]:
    executable = Path(command[0])
    if not executable.is_absolute():
        resolved = None
        for directory in os.environ.get("PATH", "").split(os.pathsep):
            candidate = Path(directory) / executable
            if candidate.is_file() and not candidate.is_symlink():
                resolved = candidate.resolve()
                break
        executable = resolved or executable
    if executable.is_file() and not executable.is_symlink():
        return {
            "basename": executable.name,
            "size": executable.stat().st_size,
            "sha256": sha256_file(executable),
        }
    return {"basename": Path(command[0]).name, "size": None, "sha256": None}


def safe_token(value: str, label: str) -> str:
    if TOKEN.fullmatch(value) is None:
        raise ValueError(f"invalid {label}")
    return value


def regular_single_link(path: Path, label: str, maximum: int | None = None) -> Path:
    path = Path(os.path.abspath(path))
    if path.resolve() != path:
        raise ValueError(f"{label} path must not traverse symbolic components")
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"{label} must be a regular non-symlink file")
    metadata = path.stat()
    if metadata.st_nlink != 1:
        raise ValueError(f"{label} must not be hard-linked")
    if maximum is not None and (metadata.st_size < 1 or metadata.st_size > maximum):
        raise ValueError(f"{label} size is outside its bound")
    return path


def physical_runtime_config(
    command: list[str], game_directory: Path
) -> Path:
    """Bind strict physical evidence to the stage-local GMLoader config."""
    config = regular_single_link(
        game_directory / "gmloader.json",
        "physical evidence GMLoader configuration",
        16 * 1024 * 1024,
    )
    flags = [index for index, value in enumerate(command) if value == "-c"]
    if (
        len(flags) != 1
        or flags[0] + 1 >= len(command)
        or command[flags[0] + 1] != str(config)
    ):
        raise ValueError(
            "physical evidence command must contain one exact -c "
            "stage-local gmloader.json pair"
        )
    try:
        document = json.loads(
            config.read_bytes().decode("utf-8"),
            object_pairs_hook=reject_duplicate_json_pairs,
            parse_constant=reject_nonfinite_json,
        )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError(
            "physical evidence GMLoader configuration is not strict JSON"
        ) from exc
    if not isinstance(document, dict) or document.get("apk_path") != "game.apk":
        raise ValueError(
            "physical evidence GMLoader configuration must select staged game.apk"
        )
    return config


def snapshot_physical_evidence_inputs(
    inputs: tuple[tuple[Path, str], ...],
) -> tuple[PhysicalEvidenceInputIdentity, ...]:
    return tuple(
        PhysicalEvidenceInputIdentity(
            path=path,
            label=label,
            size=path.stat().st_size,
            sha256=sha256_file(path),
        )
        for path, label in inputs
    )


def physical_options_override(result: Any, game_directory: Path) -> Path:
    path = regular_single_link(
        game_directory / OVERRIDE_BASENAME,
        "physical evidence options override",
    )
    if (
        result.source_status != "loaded"
        or result.source_sha256 is None
        or sha256_file(path) != result.source_sha256
    ):
        raise ValueError(
            "physical evidence options override differs from parsed configuration"
        )
    return path


def verify_physical_evidence_inputs(evidence: PhysicalBasicEvidence) -> None:
    for identity in evidence.input_identities:
        path = regular_single_link(identity.path, identity.label)
        if (
            path.stat().st_size != identity.size
            or sha256_file(path) != identity.sha256
        ):
            raise ValueError(f"{identity.label} identity changed after validation")


def physical_basic_evidence(
    args: argparse.Namespace,
    result: Any,
    dungeon_seed: ResolvedDungeonSeed,
) -> PhysicalBasicEvidence | None:
    role = getattr(args, "physical_basic_evidence_role", None)
    environment = getattr(args, "evidence_environment_file", None)
    initial_state = getattr(args, "evidence_initial_state_file", None)
    pattern = getattr(args, "evidence_pattern", "gmloadernext.aarch64")
    ready_timeout = getattr(args, "evidence_ready_timeout_seconds", 15)
    supplied = sum(value is not None for value in (role, environment, initial_state))
    if supplied == 0:
        return None
    if supplied != 3:
        raise ValueError("basic physical evidence arguments must be supplied together")
    if role not in PHYSICAL_BASIC_EVIDENCE_ROLES:
        raise ValueError("invalid basic physical evidence role")
    if args.role != PHYSICAL_BASIC_EVIDENCE_ROLES[role]:
        raise ValueError("launcher role does not match basic physical evidence role")
    if not args.strict_validation:
        raise ValueError("basic physical evidence requires --strict-validation")
    if result.telemetry != "basic":
        raise ValueError("basic physical evidence requires Telemetry=basic")
    if result.profile != "safe" or result.applied_overrides:
        raise ValueError(
            "basic physical evidence requires safe profile with no official-option overrides"
        )
    if dungeon_seed.enabled:
        raise ValueError("ordinary unseeded baseline forbids DungeonSeed injection")
    if TOKEN.fullmatch(pattern) is None:
        raise ValueError("invalid evidence process pattern")
    if type(ready_timeout) is not int or ready_timeout < 1 or ready_timeout > 120:
        raise ValueError("evidence sampler readiness timeout is outside its bound")

    game_directory = args.game_dir.resolve()
    gmloader_config = physical_runtime_config(args.command, game_directory)
    options_override = physical_options_override(result, game_directory)
    if args.sampler is None:
        raise ValueError("basic physical evidence requires an external sampler")
    sampler = regular_single_link(
        Path(args.sampler), "external telemetry sampler", 16 * 1024 * 1024
    )
    payload = regular_single_link(game_directory / "game.apk", "evidence payload")
    plan = regular_single_link(
        game_directory / PHYSICAL_BASIC_PLAN, "evidence replay plan", 512 * 1024 * 1024
    )
    build_record = regular_single_link(
        game_directory / PHYSICAL_BASIC_BUILD_RECORD,
        "evidence build record",
        1024 * 1024,
    )
    environment = regular_single_link(
        Path(environment), "evidence environment report", 16 * 1024 * 1024
    )
    initial_state = regular_single_link(
        Path(initial_state), "evidence initial-state report", 16 * 1024 * 1024
    )
    if not environment.name.endswith(".zeldadoi-environment.txt"):
        raise ValueError("evidence environment report has the wrong basename")
    if not initial_state.name.endswith(".zeldadoi-initial-state.txt"):
        raise ValueError("evidence initial-state report has the wrong basename")
    marker = game_directory / PHYSICAL_BASIC_MARKER
    if marker.exists() or marker.is_symlink():
        raise ValueError("evidence replay marker must be absent before sampling")
    try:
        record = json.loads(
            build_record.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicate_json_pairs,
            parse_constant=reject_nonfinite_json,
        )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError("evidence build record is not strict JSON") from exc
    expected_keys = {
        "schema_version": 1,
        "private_instrumentation": True,
        "role": role,
        "plan_basename": PHYSICAL_BASIC_PLAN,
        "marker_basename": PHYSICAL_BASIC_MARKER,
        "release_payload": False,
        "structural_audit_verified": True,
    }
    if not isinstance(record, dict) or any(
        record.get(key) != value for key, value in expected_keys.items()
    ):
        raise ValueError("evidence build record is not a basic plan-feeder stage")
    identities = (
        (payload, "game_apk_bytes", "game_apk_sha256", "evidence payload"),
        (plan, "plan_bytes", "plan_file_sha256", "evidence replay plan"),
    )
    for path, size_key, hash_key, label in identities:
        if (
            record.get(size_key) != path.stat().st_size
            or record.get(hash_key) != sha256_file(path)
        ):
            raise ValueError(f"{label} identity differs from build record")
    return PhysicalBasicEvidence(
        kind="basic-plan-feeder",
        role=role,
        payload=payload,
        environment=environment,
        initial_state=initial_state,
        plan=plan,
        build_record=build_record,
        marker=marker,
        pattern=pattern,
        ready_timeout_seconds=ready_timeout,
        build_record_sha256=sha256_file(build_record),
        sampler_size=sampler.stat().st_size,
        sampler_sha256=sha256_file(sampler),
        gmloader_config=gmloader_config,
        gmloader_config_size=gmloader_config.stat().st_size,
        gmloader_config_sha256=sha256_file(gmloader_config),
        options_override=options_override,
        options_override_size=options_override.stat().st_size,
        options_override_sha256=sha256_file(options_override),
        input_identities=snapshot_physical_evidence_inputs(
            (
                (payload, "evidence payload"),
                (plan, "evidence replay plan"),
                (build_record, "evidence build record"),
                (environment, "evidence environment report"),
                (initial_state, "evidence initial-state report"),
                (sampler, "external telemetry sampler"),
                (gmloader_config, "physical evidence GMLoader configuration"),
                (options_override, "physical evidence options override"),
            )
        ),
    )


def physical_observation_evidence(
    args: argparse.Namespace,
    result: Any,
    dungeon_seed: ResolvedDungeonSeed,
) -> PhysicalBasicEvidence | None:
    role = getattr(args, "physical_observation_evidence_role", None)
    if role is None:
        return None
    if role not in PHYSICAL_BASIC_EVIDENCE_ROLES:
        raise ValueError("invalid observation physical evidence role")
    if args.role != PHYSICAL_BASIC_EVIDENCE_ROLES[role]:
        raise ValueError(
            "launcher role does not match observation physical evidence role"
        )
    if not args.strict_validation:
        raise ValueError("observation physical evidence requires --strict-validation")
    if result.telemetry != "full":
        raise ValueError("observation physical evidence requires Telemetry=full")
    if result.profile != "safe" or result.applied_overrides:
        raise ValueError(
            "observation physical evidence requires safe profile with no "
            "official-option overrides"
        )
    if dungeon_seed.enabled:
        raise ValueError("ordinary unseeded baseline forbids DungeonSeed injection")
    environment = getattr(args, "evidence_environment_file", None)
    initial_state = getattr(args, "evidence_initial_state_file", None)
    if environment is None or initial_state is None:
        raise ValueError(
            "observation physical evidence arguments must be supplied together"
        )
    pattern = getattr(args, "evidence_pattern", "gmloadernext.aarch64")
    ready_timeout = getattr(args, "evidence_ready_timeout_seconds", 15)
    if TOKEN.fullmatch(pattern) is None:
        raise ValueError("invalid evidence process pattern")
    if type(ready_timeout) is not int or ready_timeout < 1 or ready_timeout > 120:
        raise ValueError("evidence sampler readiness timeout is outside its bound")
    if args.sampler is None:
        raise ValueError("observation physical evidence requires an external sampler")

    game_directory = args.game_dir.resolve()
    gmloader_config = physical_runtime_config(args.command, game_directory)
    options_override = physical_options_override(result, game_directory)
    sampler = regular_single_link(
        Path(args.sampler), "external telemetry sampler", 16 * 1024 * 1024
    )
    payload = regular_single_link(game_directory / "game.apk", "evidence payload")
    plan = regular_single_link(
        game_directory / PHYSICAL_BASIC_PLAN,
        "evidence replay plan",
        512 * 1024 * 1024,
    )
    droid = regular_single_link(
        game_directory / GAME_DROID_MEMBER,
        "evidence game.droid",
        512 * 1024 * 1024,
    )
    build_record = regular_single_link(
        game_directory / PHYSICAL_OBSERVATION_BUILD_RECORD,
        "evidence build record",
        1024 * 1024,
    )
    environment = regular_single_link(
        Path(environment), "evidence environment report", 16 * 1024 * 1024
    )
    initial_state = regular_single_link(
        Path(initial_state), "evidence initial-state report", 16 * 1024 * 1024
    )
    if not environment.name.endswith(".zeldadoi-environment.txt"):
        raise ValueError("evidence environment report has the wrong basename")
    if not initial_state.name.endswith(".zeldadoi-initial-state.txt"):
        raise ValueError("evidence initial-state report has the wrong basename")
    try:
        record = json.loads(
            build_record.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicate_json_pairs,
            parse_constant=reject_nonfinite_json,
        )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError("evidence build record is not strict JSON") from exc
    expected = {
        "schema_version": 17,
        "private_instrumentation": True,
        "role": role,
        "scenario_id": args.scenario,
        "plan_basename": PHYSICAL_BASIC_PLAN,
        "release_payload": False,
        "structural_audit_verified": True,
        **PHYSICAL_OBSERVATION_MARKERS,
    }
    if not isinstance(record, dict) or any(
        record.get(key) != value for key, value in expected.items()
    ):
        raise ValueError(
            "evidence build record is not a schema-17 observation-feeder stage"
        )
    identities = (
        (payload, "game_apk_bytes", "game_apk_sha256", "evidence payload"),
        (droid, "game_droid_bytes", "game_droid_sha256", "evidence game.droid"),
        (plan, "plan_bytes", "plan_file_sha256", "evidence replay plan"),
    )
    for path, size_key, hash_key, label in identities:
        if (
            record.get(size_key) != path.stat().st_size
            or record.get(hash_key) != sha256_file(path)
        ):
            raise ValueError(f"{label} identity differs from build record")
    for basename in PHYSICAL_OBSERVATION_MARKERS.values():
        target = game_directory / basename
        if target.exists() or target.is_symlink():
            raise ValueError(
                "observation evidence markers must be absent before sampling"
            )
    if any(game_directory.glob("zdlf-replay-frame-capture-f*.png")):
        raise ValueError(
            "observation evidence frame captures must be absent before sampling"
        )
    return PhysicalBasicEvidence(
        kind="observation-feeder",
        role=role,
        payload=payload,
        environment=environment,
        initial_state=initial_state,
        plan=plan,
        build_record=build_record,
        marker=game_directory / PHYSICAL_BASIC_MARKER,
        pattern=pattern,
        ready_timeout_seconds=ready_timeout,
        build_record_sha256=sha256_file(build_record),
        sampler_size=sampler.stat().st_size,
        sampler_sha256=sha256_file(sampler),
        gmloader_config=gmloader_config,
        gmloader_config_size=gmloader_config.stat().st_size,
        gmloader_config_sha256=sha256_file(gmloader_config),
        options_override=options_override,
        options_override_size=options_override.stat().st_size,
        options_override_sha256=sha256_file(options_override),
        input_identities=snapshot_physical_evidence_inputs(
            (
                (payload, "evidence payload"),
                (droid, "evidence game.droid"),
                (plan, "evidence replay plan"),
                (build_record, "evidence build record"),
                (environment, "evidence environment report"),
                (initial_state, "evidence initial-state report"),
                (sampler, "external telemetry sampler"),
                (gmloader_config, "physical evidence GMLoader configuration"),
                (options_override, "physical evidence options override"),
            )
        ),
    )


def write_new(path: Path, data: bytes) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb", closefd=True) as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def resolve_dungeon_seed(
    result: Any,
    schema: dict[str, Any],
    random_below: Any = secrets.randbelow,
) -> ResolvedDungeonSeed:
    if not result.use_dungeon_seed:
        return ResolvedDungeonSeed(
            False, "none", None, result.effective_sha256, None
        )
    if result.dungeon_seed_request == "invalid":
        raise ValueError(
            f"{result.dungeon_seed_error}\n"
            "Seeded dungeon mode was requested, but the configured seed is invalid."
        )
    rule = schema["speedhack"]["DungeonSeed"]
    minimum = int(rule["minimum"])
    maximum = int(rule["maximum"])
    if result.dungeon_seed_request == "configured":
        seed = result.dungeon_seed
        origin = "configured"
    elif result.dungeon_seed_request == "generate":
        seed = minimum + int(random_below((maximum - minimum) + 1))
        origin = "generated"
    else:
        raise ValueError("invalid internal dungeon-seed request state")
    if seed is None or seed < minimum or seed > maximum:
        raise ValueError("generated DungeonSeed is outside the configured range")
    runtime_hash = hashlib.sha256(
        json.dumps(
            {
                "configuration_sha256": result.effective_sha256,
                "use_dungeon_seed": True,
                "dungeon_seed": seed,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    identity = schema["dungeon_seed_runtime"]["generation_identity"]
    effective_generation_options: dict[str, int] = {}
    generation_option_keys = identity.get("effective_generation_option_keys")
    generation_option_types = identity.get("effective_generation_option_value_types")
    official_rules = {
        f'{item["section"]}.{item["name"]}': item
        for item in schema["official_options"]
    }
    if (
        identity.get("schema_version") != 2
        or identity.get("algorithm_id") != rule["deterministic_mechanism"]
        or identity.get("official_game_version") != OFFICIAL_GAME_VERSION
        or generation_option_keys != [
            "Preferences.Gore",
            "Preferences.Lighting",
        ]
        or generation_option_types
        != {
            "Preferences.Gore": "integer",
            "Preferences.Lighting": "integer",
        }
        or identity.get("canonical_encoding")
        != "json-utf8-sort-keys-compact-separators-ensure-ascii-v1"
        or identity.get("excludes_seed_origin") is not True
        or identity.get("excludes_telemetry") is not True
        or identity.get("excludes_non_generation_official_options") is not True
        or re.fullmatch(
            r"[0-9a-f]{64}", identity.get("official_game_droid_sha256", "")
        )
        is None
        or re.fullmatch(
            r"[0-9a-f]{64}", identity.get("dungeon_template_corpus_sha256", "")
        )
        is None
    ):
        raise ValueError("dungeon generation identity contract is invalid")
    for key in generation_option_keys:
        option_rule = official_rules.get(key)
        value = result.official_values.get(key)
        if (
            option_rule is None
            or option_rule.get("type") != generation_option_types[key]
            or type(value) is not int
            or value not in option_rule.get("accepted_values", [])
        ):
            raise ValueError(
                "dungeon generation effective option is outside the contract"
            )
        effective_generation_options[key] = value
    generation_payload = json.dumps(
        {
            "schema_version": identity["schema_version"],
            "algorithm_id": identity["algorithm_id"],
            "official_game_version": identity["official_game_version"],
            "official_game_droid_sha256": identity[
                "official_game_droid_sha256"
            ],
            "dungeon_template_corpus_sha256": identity[
                "dungeon_template_corpus_sha256"
            ],
            "dungeon_seed": seed,
            "effective_generation_options": effective_generation_options,
        },
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    generation_hash = hashlib.sha256(generation_payload.encode("utf-8")).hexdigest()
    return ResolvedDungeonSeed(
        True, origin, seed, runtime_hash, generation_hash
    )


def resolve_run_seed(result: Any, schema: dict[str, Any]) -> ResolvedRunSeed:
    """Validate the external RunSeed handoff without retargeting game RNG."""
    if not result.use_run_seed:
        return ResolvedRunSeed(False, "none", None, result.effective_sha256)
    if result.use_dungeon_seed:
        raise ValueError("DungeonSeed and RunSeed cannot both be enabled")
    if result.run_seed_request != "configured" or result.run_seed is None:
        raise ValueError(
            f"{result.run_seed_error or 'Invalid RunSeed'}\n"
            "RunSeed mode was requested, but the configured seed is invalid."
        )
    rule = schema["speedhack"]["RunSeed"]
    minimum = int(rule["minimum"])
    maximum = int(rule["maximum"])
    seed = result.run_seed
    if seed < minimum or seed > maximum:
        raise ValueError("configured RunSeed is outside the configured range")
    runtime_hash = hashlib.sha256(
        json.dumps(
            {
                "configuration_sha256": result.effective_sha256,
                "use_run_seed": True,
                "run_seed": seed,
                "mechanism": rule["deterministic_mechanism"],
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return ResolvedRunSeed(True, "configured", seed, runtime_hash)


def ensure_speedhack_state_root(game_directory: Path) -> Path:
    saves = game_directory / "saves"
    if saves.is_symlink():
        raise ValueError("speedhack saves parent must not be a symlink")
    saves.mkdir(mode=0o700, exist_ok=True)
    if not saves.is_dir():
        raise ValueError("speedhack saves parent is not a directory")
    root = game_directory / SPEEDHACK_STATE_RELATIVE
    if root.is_symlink():
        raise ValueError("speedhack state root must not be a symlink")
    if root.exists():
        if not root.is_dir():
            raise ValueError("speedhack state root is not a directory")
        owner = root / "OWNER"
        if owner.is_symlink() or not owner.is_file():
            raise ValueError("refusing to adopt unowned speedhack state root")
        if owner.read_text(encoding="utf-8") != STATE_OWNER_ID + "\n":
            raise ValueError("speedhack state root owner mismatch")
    else:
        root.mkdir(mode=0o700)
        write_new(root / "OWNER", (STATE_OWNER_ID + "\n").encode("utf-8"))
    return root


def write_seed_record(root: Path, seed: int) -> Path:
    target = root / SEED_RECORD_BASENAME
    if target.is_symlink() or (target.exists() and not target.is_file()):
        raise ValueError("dungeon-seed record path is unsafe")
    temporary = root / f".{SEED_RECORD_BASENAME}.{os.getpid()}.tmp"
    try:
        write_new(temporary, f"DungeonSeed={seed}\n".encode("ascii"))
        os.replace(temporary, target)
    except BaseException:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    return target


def announce_dungeon_seed(
    resolved: ResolvedDungeonSeed,
    sleep: Any = time.sleep,
) -> None:
    if not resolved.enabled or resolved.seed is None:
        return
    action = "Using configured" if resolved.origin == "configured" else "Generated"
    print(f"{action} dungeon seed: {resolved.seed}", flush=True)
    print(f"Loading dungeon seed {resolved.seed}...", flush=True)
    sleep(SEED_DISPLAY_SECONDS)


def reject_duplicate_json_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate runtime configuration key: {key}")
        result[key] = value
    return result


def reject_nonfinite_json(token: str) -> Any:
    raise ValueError(f"non-finite JSON value is forbidden: {token}")


def expected_owned_path(
    game_directory: Path, configured_path: Path, relative: str, label: str
) -> Path:
    fragment = PurePosixPath(relative)
    if (
        fragment.is_absolute()
        or not fragment.parts
        or any(part in {"", ".", ".."} for part in fragment.parts)
    ):
        raise ValueError(f"{label} contract path is unsafe")
    root = game_directory.resolve()
    expected = root.joinpath(*fragment.parts)
    observed = Path(os.path.abspath(configured_path))
    if observed != expected:
        raise ValueError(f"{label} path does not match the owned location")
    cursor = root
    for part in fragment.parts[:-1]:
        cursor = cursor / part
        if cursor.is_symlink() or not cursor.is_dir():
            raise ValueError(f"{label} parent is missing or unsafe")
    return expected


def validate_runtime_config(
    path: Path,
    expected_size: int,
    expected_sha256: str,
    expected_apk_path: str,
    label: str,
) -> None:
    if type(expected_size) is not int or expected_size <= 0:
        raise ValueError(f"{label} size authority is invalid")
    if re.fullmatch(r"[0-9a-f]{64}", expected_sha256) is None:
        raise ValueError(f"{label} identity is invalid")
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"{label} is missing or unsafe")
    try:
        payload = path.read_bytes()
    except OSError as exc:
        raise ValueError(f"{label} could not be read") from exc
    if len(payload) != expected_size:
        raise ValueError(f"{label} size is mismatched")
    if hashlib.sha256(payload).hexdigest() != expected_sha256:
        raise ValueError(f"{label} identity is mismatched")
    try:
        document = json.loads(
            payload.decode("utf-8"), object_pairs_hook=reject_duplicate_json_pairs
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{label} is not canonical readable JSON") from exc
    if not isinstance(document, dict) or document.get("apk_path") != expected_apk_path:
        raise ValueError(f"{label} apk_path does not name the selected archive")


def validate_runtime_archive(
    path: Path,
    expected_size: int,
    expected_sha256: str,
    expected_game_droid: dict[str, Any],
    contract: dict[str, Any],
    label: str,
) -> None:
    if type(expected_size) is not int or expected_size <= 0:
        raise ValueError(f"{label} size authority is invalid")
    if re.fullmatch(r"[0-9a-f]{64}", expected_sha256) is None:
        raise ValueError(f"{label} identity is invalid")
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"{label} is missing or unsafe")
    if path.stat().st_size != expected_size:
        raise ValueError(f"{label} size is mismatched")
    if sha256_file(path) != expected_sha256:
        raise ValueError(f"{label} identity is mismatched")
    maximum_members = contract.get("maximum_members")
    maximum_total = contract.get("maximum_total_uncompressed_bytes")
    if (
        type(maximum_members) is not int
        or maximum_members < 1
        or type(maximum_total) is not int
        or maximum_total < 1
        or contract.get("game_droid_member") != GAME_DROID_MEMBER
        or contract.get("duplicate_members_allowed") is not False
        or contract.get("unsafe_member_paths_allowed") is not False
        or contract.get("symlink_members_allowed") is not False
        or contract.get("installer_state_manifest_authority_required_for_production")
        is not True
        or contract.get("complete_archive_sha256_is_installer_release_authority_only")
        is not True
        or contract.get("runtime_authority_parser_and_launcher_implemented")
        is not True
    ):
        raise ValueError("seeded archive structural contract is invalid")
    try:
        with zipfile.ZipFile(path) as archive:
            members = archive.infolist()
            if not members or len(members) > maximum_members:
                raise ValueError(f"{label} member count is outside the bound")
            names: set[str] = set()
            expanded = 0
            game_droid = []
            for info in members:
                name = info.filename
                item = PurePosixPath(name)
                unix_type = (info.external_attr >> 16) & 0o170000
                if (
                    name in names
                    or "\\" in name
                    or item.is_absolute()
                    or not item.parts
                    or any(part in {"", ".", ".."} for part in item.parts)
                    or unix_type == 0o120000
                ):
                    raise ValueError(f"{label} has an unsafe member inventory")
                names.add(name)
                expanded += info.file_size
                if expanded > maximum_total:
                    raise ValueError(f"{label} expanded size exceeds the bound")
                if name == GAME_DROID_MEMBER:
                    game_droid.append(info)
            if len(game_droid) != 1:
                raise ValueError(f"{label} must contain one {GAME_DROID_MEMBER}")
            expected_member = expected_game_droid.get("member")
            expected_member_size = expected_game_droid.get("size")
            expected_member_sha256 = expected_game_droid.get("sha256")
            if (
                expected_member != GAME_DROID_MEMBER
                or type(expected_member_size) is not int
                or expected_member_size <= 0
                or re.fullmatch(r"[0-9a-f]{64}", str(expected_member_sha256))
                is None
                or game_droid[0].file_size != expected_member_size
            ):
                raise ValueError(f"{label} game.droid authority is invalid or mismatched")
            digest = hashlib.sha256()
            with archive.open(game_droid[0]) as handle:
                while chunk := handle.read(1024 * 1024):
                    digest.update(chunk)
            if digest.hexdigest() != expected_member_sha256:
                raise ValueError(f"{label} game.droid identity is mismatched")
    except (OSError, zipfile.BadZipFile) as exc:
        raise ValueError(f"{label} is not a readable ZIP archive") from exc


def select_runtime_command(
    command: list[str],
    resolved: ResolvedDungeonSeed,
    game_directory: Path,
    schema: dict[str, Any],
    authority: dict[str, Any] | None,
    run_seed: ResolvedRunSeed | None = None,
) -> list[str]:
    selected = list(command)
    seeded_mode_enabled = resolved.enabled or bool(run_seed and run_seed.enabled)
    if authority is None:
        if not seeded_mode_enabled:
            # Developer and host-test launches intentionally retain their
            # unbound path.  A release-bound invocation is handled by
            # ``run_game`` below and never reaches this branch without pair
            # verification.
            return selected
        raise ValueError(
            "seeded runtime is unavailable; seeded mode cannot launch"
        )
    runtime = schema["dungeon_seed_runtime"]
    if (
        runtime.get("selection_policy") != "dual_runtime"
        or runtime.get("enabled_archive_sha256_required") is not True
        or runtime.get("runtime_config_apk_path_must_equal_selected_archive")
        is not True
    ):
        raise ValueError("seeded runtime selection contract is invalid")
    if authority["dungeon_seed"]["algorithm_id"] != runtime["generation_identity"]["algorithm_id"]:
        raise ValueError("runtime authority dungeon-seed algorithm is mismatched")
    default_identity = authority["runtimes"]["default"]
    seeded_identity = authority["runtimes"]["seeded"]
    default_runtime_config = expected_owned_path(
        game_directory,
        game_directory / default_identity["runtime_config_path"],
        runtime["disabled_runtime_config"],
        "default runtime configuration",
    )
    seeded_runtime_config = expected_owned_path(
        game_directory,
        game_directory / seeded_identity["runtime_config_path"],
        runtime["enabled_runtime_config"],
        "seeded runtime configuration",
    )
    for path, identity, expected_apk_path, label in (
        (
            default_runtime_config,
            default_identity,
            runtime["disabled_archive"],
            "default runtime configuration",
        ),
        (
            seeded_runtime_config,
            seeded_identity,
            runtime["enabled_archive"],
            "seeded runtime configuration",
        ),
    ):
        validate_runtime_config(
            path,
            identity["runtime_config_size"],
            identity["runtime_config_sha256"],
            expected_apk_path,
            label,
        )
    for role, identity, label in (
        ("default", default_identity, "default runtime archive"),
        ("seeded", seeded_identity, "seeded runtime archive"),
    ):
        archive_path = expected_owned_path(
            game_directory,
            game_directory / identity["archive_path"],
            identity["archive_path"],
            label,
        )
        validate_runtime_archive(
            archive_path,
            identity["archive_size"],
            identity["archive_sha256"],
            identity["game_droid"],
            runtime["seeded_archive_structural_validation"],
            label,
        )
    default_text = str(default_runtime_config)
    matches = [index for index, value in enumerate(selected) if value == default_text]
    config_flags = [index for index, value in enumerate(selected) if value == "-c"]
    if (
        len(matches) != 1
        or len(config_flags) != 1
        or matches[0] != config_flags[0] + 1
    ):
        raise ValueError(
            "game command does not contain one exact -c default configuration pair"
        )
    if not seeded_mode_enabled:
        return selected
    selected[matches[0]] = str(seeded_runtime_config)
    return selected


def ensure_telemetry_root(game_directory: Path) -> Path:
    saves = game_directory / "saves"
    if saves.is_symlink():
        raise ValueError("telemetry saves parent must not be a symlink")
    saves.mkdir(mode=0o700, exist_ok=True)
    if not saves.is_dir():
        raise ValueError("telemetry saves parent is not a directory")
    root = game_directory / TELEMETRY_RELATIVE
    if root.is_symlink():
        raise ValueError("telemetry root must not be a symlink")
    if root.exists():
        if not root.is_dir():
            raise ValueError("telemetry root is not a directory")
        owner = root / "OWNER"
        if owner.is_symlink() or not owner.is_file():
            raise ValueError("refusing to adopt unowned telemetry root")
        if owner.read_text(encoding="utf-8") != OWNER_ID + "\n":
            raise ValueError("telemetry root owner mismatch")
    else:
        root.mkdir(mode=0o700)
        write_new(root / "OWNER", (OWNER_ID + "\n").encode("utf-8"))
    return root


def create_run_directory(
    root: Path, scenario: str, role: str, run_number: int
) -> tuple[Path, str]:
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    run_id = f"{stamp}-{scenario}-{role}-run{run_number}-{os.getpid()}"
    path = root / run_id
    path.mkdir(mode=0o700)
    write_new(path / "RUNNING", (run_id + "\n").encode("utf-8"))
    return path, run_id


def metadata_document(
    *,
    game_directory: Path,
    command: list[str],
    role: str,
    scenario: str,
    run_number: int,
    run_id: str,
    result: Any,
    dungeon_seed: ResolvedDungeonSeed,
    run_seed: ResolvedRunSeed,
    active_archive_basename: str,
    runtime_authority: dict[str, Any] | None,
    runtime_authority_sha256: str | None,
    physical_evidence: PhysicalBasicEvidence | None = None,
) -> dict[str, Any]:
    archive = (
        physical_evidence.payload
        if physical_evidence is not None
        else game_directory / active_archive_basename
    )
    archive_size, archive_hash, game_hash = archive_identities(archive)
    os_release = Path("/etc/os-release")
    os_release_hash = None
    if os_release.is_file() and not os_release.is_symlink():
        try:
            os_release_hash = sha256_file(os_release)
        except OSError:
            pass
    authority_metadata = None
    if runtime_authority is not None:
        selected_role = "seeded" if (dungeon_seed.enabled or run_seed.enabled) else "default"
        authority_metadata = {
            "release_id": runtime_authority["release_id"],
            "sha256": runtime_authority_sha256,
            "selected_role": selected_role,
            "official_source": runtime_authority["official_source"],
            "selected_runtime": runtime_authority["runtimes"][selected_role],
        }
    document = {
        "schema_version": 1,
        "run_id": run_id,
        "role": role,
        "scenario": scenario,
        "run_number": run_number,
        "active_archive": {
            "basename": archive.name,
            "size": archive_size,
            "sha256": archive_hash,
        },
        "game_droid": {
            "archive_member": GAME_DROID_MEMBER,
            "sha256": game_hash,
        },
        "speedhack_profile": result.profile,
        "telemetry": result.telemetry,
        "enable_override": result.enable_override,
        "configuration_source": result.configuration_source,
        "lighting_mode": result.lighting_mode,
        "configuration_sha256": result.effective_sha256,
        "runtime_configuration_sha256": dungeon_seed.runtime_configuration_sha256,
        "generation_configuration_sha256": (
            dungeon_seed.generation_configuration_sha256
        ),
        "override_source_sha256": result.source_sha256,
        "override_source_status": result.source_status,
        "use_dungeon_seed": dungeon_seed.enabled,
        "dungeon_seed_origin": dungeon_seed.origin,
        "dungeon_seed": dungeon_seed.seed,
        "use_run_seed": run_seed.enabled,
        "run_seed_origin": run_seed.origin,
        "run_seed": run_seed.seed,
        "runseed_runtime_configuration_sha256": run_seed.runtime_configuration_sha256,
        "speedhack_version": os.environ.get(
            "ZELDADOI_SPEEDHACK_VERSION", SPEEDHACK_VERSION
        ),
        "official_game_version": OFFICIAL_GAME_VERSION,
        "runtime_authority": authority_metadata,
        "runtime": runtime_identity(command),
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "os_release_sha256": os_release_hash,
        },
        "start_time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "strict_validation": False,
        "physical_authority_claimed": False,
    }
    if physical_evidence is not None:
        document["physical_evidence"] = {
            "kind": physical_evidence.kind,
            "role": physical_evidence.role,
            "payload_sha256": archive_hash,
            "environment_sha256": sha256_file(physical_evidence.environment),
            "initial_state_sha256": sha256_file(physical_evidence.initial_state),
            "plan_file_sha256": sha256_file(physical_evidence.plan),
            "build_record_sha256": physical_evidence.build_record_sha256,
            "marker_basename": physical_evidence.marker.name,
            "process_selection": "new_after_sampler_start",
            "sampler_size": physical_evidence.sampler_size,
            "sampler_sha256": physical_evidence.sampler_sha256,
            "gmloader_config_basename": physical_evidence.gmloader_config.name,
            "gmloader_config_apk_path": "game.apk",
            "gmloader_config_size": physical_evidence.gmloader_config_size,
            "gmloader_config_sha256": physical_evidence.gmloader_config_sha256,
            "options_override_basename": physical_evidence.options_override.name,
            "options_override_size": physical_evidence.options_override_size,
            "options_override_sha256": physical_evidence.options_override_sha256,
            "input_identity_verification": "before_launch_and_after_exit",
        }
    return document


def start_sampler(
    sampler: Path | None,
    process: subprocess.Popen[Any],
    run_directory: Path,
) -> tuple[subprocess.Popen[Any] | None, Any | None, str | None]:
    if sampler is None:
        return None, None, "no external telemetry sampler was supplied"
    if sampler.is_symlink() or not sampler.is_file():
        return None, None, "external telemetry sampler is missing or unsafe"
    try:
        log = (run_directory / "sampler.log").open("xb")
        sampler_process = subprocess.Popen(
            [
                "bash",
                str(sampler),
                "--pid",
                str(process.pid),
                "--output",
                str(run_directory / "profile"),
                "--interval-ms",
                "100",
                "--activity-marker-file",
                str(run_directory / "activity-markers.txt"),
            ],
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
        )
        return sampler_process, log, None
    except OSError as exc:
        return None, None, f"could not start external telemetry sampler: {exc}"


def start_physical_evidence_sampler(
    sampler: Path | None,
    run_directory: Path,
    run_id: str,
    evidence: PhysicalBasicEvidence,
) -> tuple[subprocess.Popen[Any] | None, Any | None, str | None]:
    if sampler is None:
        return None, None, "no external telemetry sampler was supplied"
    try:
        regular_single_link(sampler, "external telemetry sampler", 16 * 1024 * 1024)
        log = (run_directory / "sampler.log").open("xb")
        process = subprocess.Popen(
            [
                "bash",
                str(sampler),
                "--pattern",
                evidence.pattern,
                "--require-new-process",
                "--output",
                str(run_directory / "profile"),
                "--interval-ms",
                "100",
                "--marker-file",
                str(evidence.marker),
                "--role",
                evidence.role,
                "--run-id",
                run_id,
                "--payload-file",
                str(evidence.payload),
                "--environment-file",
                str(evidence.environment),
                "--initial-state-file",
                str(evidence.initial_state),
                "--plan-file",
                str(evidence.plan),
            ],
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
        )
        deadline = time.monotonic() + evidence.ready_timeout_seconds
        ready = False
        while time.monotonic() < deadline:
            log.flush()
            try:
                with (run_directory / "sampler.log").open("rb") as handle:
                    current = handle.read(65536).decode("utf-8", errors="replace")
            except OSError:
                current = ""
            if "Waiting up to " in current and " for process pattern: " in current:
                ready = True
                break
            status = process.poll()
            if status is not None:
                log.close()
                return (
                    None,
                    None,
                    f"evidence sampler exited before readiness with status {status}",
                )
            time.sleep(0.05)
        if not ready:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            log.close()
            return None, None, "evidence sampler did not reach new-process wait state"
        return process, log, None
    except (OSError, ValueError) as exc:
        return None, None, f"could not start evidence-bound telemetry sampler: {exc}"


def stop_sampler(process: subprocess.Popen[Any] | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def wait_with_forwarded_termination(
    process: subprocess.Popen[bytes] | subprocess.Popen[str],
) -> tuple[int, int | None]:
    """Wait for a child while forwarding launcher termination to that child.

    PortMaster diagnostics commonly wrap GMLoader with this process and then
    terminate the wrapper after a semantic completion marker.  The default
    Python signal action used to kill only this wrapper, orphaning GMLoader
    while muOS resumed its menu.  Keep signal ownership bounded to this wait,
    forward SIGTERM/SIGINT once, and restore the caller's handlers afterward.
    """
    forwarded: list[int | None] = [None]
    previous: dict[int, Any] = {}

    def forward(signum: int, _frame: Any) -> None:
        forwarded[0] = signum
        if process.poll() is None:
            try:
                process.send_signal(signum)
            except ProcessLookupError:
                pass

    for signum in (signal.SIGTERM, signal.SIGINT):
        previous[signum] = signal.getsignal(signum)
        signal.signal(signum, forward)
    try:
        return process.wait(), forwarded[0]
    finally:
        for signum, handler in previous.items():
            signal.signal(signum, handler)


def _run_game(
    args: argparse.Namespace,
    schema: dict[str, Any],
    override: Any,
    dungeon_seed: ResolvedDungeonSeed,
    run_seed: ResolvedRunSeed,
    runtime_authority: dict[str, Any] | None,
    runtime_authority_sha256: str | None,
) -> int:
    game_directory = args.game_dir
    try:
        command = select_runtime_command(
            args.command,
            dungeon_seed,
            args.game_dir.resolve(),
            schema,
            runtime_authority,
            run_seed,
        )
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    try:
        basic_role = getattr(args, "physical_basic_evidence_role", None)
        observation_role = getattr(
            args, "physical_observation_evidence_role", None
        )
        if basic_role is not None and observation_role is not None:
            raise ValueError(
                "basic and observation physical evidence modes are mutually exclusive"
            )
        if run_seed.enabled and (basic_role is not None or observation_role is not None):
            raise ValueError("physical baseline evidence forbids RunSeed injection")
        if basic_role is not None:
            evidence = physical_basic_evidence(args, override, dungeon_seed)
        elif observation_role is not None:
            evidence = physical_observation_evidence(
                args, override, dungeon_seed
            )
        else:
            if (
                getattr(args, "evidence_environment_file", None) is not None
                or getattr(args, "evidence_initial_state_file", None) is not None
            ):
                raise ValueError(
                    "physical evidence reports require an evidence role"
                )
            evidence = None
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    environment = os.environ.copy()
    for key in SEED_ENVIRONMENT_KEYS | RUNSEED_ENVIRONMENT_KEYS | CONFIG_ENVIRONMENT_KEYS:
        environment.pop(key, None)
    environment.update(override.environment)
    environment.update(dungeon_seed.environment)
    environment.update(run_seed.environment)
    active_archive_basename = schema["dungeon_seed_runtime"][
        "enabled_archive" if (dungeon_seed.enabled or run_seed.enabled) else "disabled_archive"
    ]
    if dungeon_seed.enabled:
        try:
            state_root = ensure_speedhack_state_root(game_directory.resolve())
            write_seed_record(state_root, dungeon_seed.seed)
        except (OSError, ValueError) as exc:
            print(f"ERROR: could not record DungeonSeed: {exc}", file=sys.stderr)
            return 2
        announce_dungeon_seed(dungeon_seed)
    run_directory: Path | None = None
    run_id = None
    telemetry_error = None
    if override.telemetry != "off":
        try:
            root = ensure_telemetry_root(game_directory.resolve())
            run_directory, run_id = create_run_directory(
                root, args.scenario, args.role, args.run_number
            )
            environment["ZELDADOI_SPEEDHACK_TELEMETRY_DIR"] = str(run_directory)
            environment["ZELDADOI_SPEEDHACK_ACTIVITY_MARKERS"] = str(
                run_directory / "activity-markers.txt"
            )
            metadata = metadata_document(
                game_directory=game_directory.resolve(),
                command=command,
                role=args.role,
                scenario=args.scenario,
                run_number=args.run_number,
                run_id=run_id,
                result=override,
                dungeon_seed=dungeon_seed,
                run_seed=run_seed,
                active_archive_basename=active_archive_basename,
                runtime_authority=runtime_authority,
                runtime_authority_sha256=runtime_authority_sha256,
                physical_evidence=evidence,
            )
            metadata["strict_validation"] = args.strict_validation
            write_new(
                run_directory / "metadata.json",
                (json.dumps(metadata, indent=2, sort_keys=True) + "\n").encode("utf-8"),
            )
        except (OSError, ValueError) as exc:
            telemetry_error = f"telemetry disabled: {exc}"
            run_directory = None
            if args.strict_validation:
                print(telemetry_error, file=sys.stderr)
                return 1
    sampler_process = None
    sampler_log = None
    if run_directory is not None and evidence is not None:
        sampler_process, sampler_log, sampler_error = start_physical_evidence_sampler(
            args.sampler, run_directory, run_id, evidence
        )
        if sampler_error is not None:
            print(sampler_error, file=sys.stderr)
            return 1
        try:
            verify_physical_evidence_inputs(evidence)
        except (OSError, ValueError) as exc:
            stop_sampler(sampler_process)
            if sampler_log is not None:
                sampler_log.close()
            print(
                f"physical evidence input changed before game launch: {exc}",
                file=sys.stderr,
            )
            return 1
    try:
        game = subprocess.Popen(command, cwd=game_directory, env=environment)
    except OSError as exc:
        stop_sampler(sampler_process)
        if sampler_log is not None:
            sampler_log.close()
        print(f"game launch failed: {exc}", file=sys.stderr)
        return 1
    if run_directory is not None and evidence is None:
        sampler_process, sampler_log, sampler_error = start_sampler(
            args.sampler, game, run_directory
        )
        if sampler_error is not None:
            telemetry_error = sampler_error
            if args.strict_validation:
                game.terminate()
    game_status, forwarded_signal = wait_with_forwarded_termination(game)
    sampler_status = None
    if sampler_process is not None:
        sampler_status = sampler_process.wait()
    if sampler_log is not None:
        sampler_log.close()
    if evidence is not None:
        try:
            verify_physical_evidence_inputs(evidence)
        except (OSError, ValueError) as exc:
            drift_error = f"physical evidence input changed during run: {exc}"
            telemetry_error = (
                drift_error
                if telemetry_error is None
                else f"{telemetry_error}; {drift_error}"
            )
    if run_directory is not None:
        outcome = {
            "game_exit_status": game_status,
            "sampler_exit_status": sampler_status,
            "telemetry_error": telemetry_error,
            "end_time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        try:
            write_new(
                run_directory / "outcome.json",
                (json.dumps(outcome, indent=2, sort_keys=True) + "\n").encode("utf-8"),
            )
            if game_status == 0 and sampler_status == 0 and telemetry_error is None:
                os.replace(run_directory / "RUNNING", run_directory / "COMPLETE")
        except OSError:
            if args.strict_validation:
                return 1
    if telemetry_error is not None and override.telemetry != "off":
        print(telemetry_error, file=sys.stderr)
    if args.strict_validation and (telemetry_error is not None or sampler_status != 0):
        return 1
    if forwarded_signal is not None:
        return 128 + forwarded_signal
    return game_status


def run_game(args: argparse.Namespace) -> int:
    game_directory = args.game_dir
    schema = load_schema(args.schema)

    def resolve_configuration() -> tuple[Any, ResolvedDungeonSeed, ResolvedRunSeed] | None:
        override = parse_override(resolve_override(game_directory), schema)
        if override.enable_override_error is not None:
            print(f"ERROR: {override.enable_override_error}", file=sys.stderr)
            return None
        if override.difficulty_error is not None:
            print(f"ERROR: {override.difficulty_error}", file=sys.stderr)
            return None
        try:
            dungeon_seed = resolve_dungeon_seed(override, schema)
            run_seed = resolve_run_seed(override, schema)
        except ValueError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return None
        return override, dungeon_seed, run_seed

    authority_path = getattr(args, "runtime_authority", None)
    authority_hash = getattr(args, "runtime_authority_sha256", None)
    default_template_hash = getattr(
        args, "default_override_template_sha256", None
    )
    if (authority_path is None) != (authority_hash is None):
        print(
            "ERROR: runtime authority path and SHA-256 must be supplied together",
            file=sys.stderr,
        )
        return 2
    if authority_path is None:
        def run_unbound() -> int:
            resolved = resolve_configuration()
            if resolved is None:
                return 2
            override, dungeon_seed, run_seed = resolved
            if dungeon_seed.enabled:
                print(
                    "ERROR: seeded dungeon runtime is unavailable; seeded mode cannot launch",
                    file=sys.stderr,
                )
                return 2
            if run_seed.enabled:
                print(
                    "ERROR: RunSeed runtime is unavailable; seeded mode cannot launch",
                    file=sys.stderr,
                )
                return 2
            return _run_game(args, schema, override, dungeon_seed, run_seed, None, None)

        # The intentionally unbound developer/test path remains available only
        # when no release authority was supplied.  If an owned state directory
        # exists, it is still serialized with installer activity.
        state_directory = game_directory.resolve() / INSTALLER_STATE_RELATIVE
        if not state_directory.exists() and not state_directory.is_symlink():
            return run_unbound()
        try:
            with runtime_lock(state_directory):
                return run_unbound()
        except (OSError, ValueError) as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 2
    if authority_hash is None:
        print(
            "ERROR: runtime authority path and SHA-256 must be supplied together",
            file=sys.stderr,
        )
        return 2
    if (
        type(default_template_hash) is not str
        or re.fullmatch(r"[0-9a-f]{64}", default_template_hash) is None
    ):
        print(
            "ERROR: release-bound launch requires the default override template SHA-256",
            file=sys.stderr,
        )
        return 2
    try:
        authority_schema = load_runtime_authority_schema(
            DEFAULT_RUNTIME_AUTHORITY_SCHEMA
        )
        authority_relative = authority_schema["authority_manifest_path"]
        authority_path = expected_owned_path(
            game_directory.resolve(),
            authority_path,
            authority_relative,
            "runtime authority",
        )
        state_directory = game_directory.resolve() / INSTALLER_STATE_RELATIVE
        with runtime_lock(state_directory) as lease:
            # This is intentionally a late import.  The unbound developer path
            # does not ship or execute the pair verifier; any release-bound
            # launcher must have passed the renderer's exact component check.
            import bounded_runtime_pair_verify as runtime_pair_verify

            authority = load_authority(
                authority_path,
                DEFAULT_RUNTIME_AUTHORITY_SCHEMA,
                expected_sha256=authority_hash,
            )
            # A literal release authority binds both launcher roles.  Validate
            # the final committed pair while the shared lock is held before a
            # command can select either runtime configuration.  The verifier is
            # deliberately read-only; it also rejects activation/restore
            # journals and other unfinished pair state.
            runtime_pair_verify.verify_installed_pair(
                game_directory.resolve(),
                authority_hash,
                lock_lease=lease,
                require_complete_install=True,
                expected_default_override_template_sha256=default_template_hash,
            )
            resolved = resolve_configuration()
            if resolved is None:
                return 2
            override, dungeon_seed, run_seed = resolved
            return _run_game(
                args,
                schema,
                override,
                dungeon_seed,
                run_seed,
                authority,
                authority_hash,
            )
    except (OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--game-dir", type=Path, required=True)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument("--sampler", type=Path, default=default_sampler())
    parser.add_argument("--role", choices=sorted(ROLE_VALUES), default="candidate")
    parser.add_argument("--scenario", default="normal-gameplay")
    parser.add_argument("--run-number", type=int, default=1)
    parser.add_argument("--strict-validation", action="store_true")
    parser.add_argument(
        "--physical-basic-evidence-role",
        choices=sorted(PHYSICAL_BASIC_EVIDENCE_ROLES),
    )
    parser.add_argument(
        "--physical-observation-evidence-role",
        choices=sorted(PHYSICAL_BASIC_EVIDENCE_ROLES),
    )
    parser.add_argument("--evidence-environment-file", type=Path)
    parser.add_argument("--evidence-initial-state-file", type=Path)
    parser.add_argument("--evidence-pattern", default="gmloadernext.aarch64")
    parser.add_argument(
        "--evidence-ready-timeout-seconds", type=int, default=15
    )
    parser.add_argument("--runtime-authority", type=Path)
    parser.add_argument("--runtime-authority-sha256")
    parser.add_argument("--default-override-template-sha256")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.command and args.command[0] == "--":
        args.command = args.command[1:]
    if not args.command:
        parser.error("a game command is required after --")
    try:
        args.scenario = safe_token(args.scenario, "scenario")
    except ValueError as exc:
        parser.error(str(exc))
    if args.run_number < 1 or args.run_number > 999999:
        parser.error("run number must be between 1 and 999999")
    if (
        args.evidence_ready_timeout_seconds < 1
        or args.evidence_ready_timeout_seconds > 120
    ):
        parser.error("evidence readiness timeout must be between 1 and 120 seconds")
    return args


def main() -> int:
    try:
        return run_game(parse_args())
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        print(f"options override launcher failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
