"""Shared runtime launcher with one immutable Dungeon Seed/CRT snapshot.

Keeps the pinned shared-pair checks, installer lock and ephemeral profile
transport. This staged component does not establish release or gameplay parity.
"""
import inspect
from pathlib import Path
import sys
from types import FunctionType, SimpleNamespace

import launch_with_shared_runtime_authority_v5 as previous
import launch_with_options_override_v5 as ordinary
import options_override_crt_v1 as crt

PINS = {
    Path(previous.__file__): '2d0129e37ece8cb4ea611f75cdda76d9dbab4c63a16ad3ce3cbe698f6a029f54',
    Path(ordinary.__file__): '3e47812111d918330ba57e5ad1cc251a4f1375fc504ef2069fbbd1cc322f96a8',
    Path(crt.__file__): '4b87a461eb5f6c90355408e2d60217aa0150cc4b1fb447c3d8baae0ec7565aff',
    Path(crt.previous.__file__): '2f5df6da44917f4dc3acf28f0b51c6c219d1d8af05ec6fabda8f61194ab091e3',
    Path(crt.base.DEFAULT_SCHEMA): '613ee717877c82b462740e7c617768aab51ce9a0cf9d3aac4faacdd6555c52f7',
}


class _CRTConfigurationRefusal(ValueError):
    pass


def verify_sources():
    for path, pin in PINS.items():
        if previous.previous._checked_sha256(path) != pin:
            raise ValueError('shared CRT launcher predecessor identity changed')
    previous.verify_sources()
    crt.verify_sources()


def _parse_for_launcher(path, schema=None):
    try:
        verify_sources()
        canonical = crt.base.load_schema()
        if schema is not None and schema != canonical:
            raise ValueError('shared CRT launcher options schema differs from pinned authority')
        return crt.parse_override(path, canonical)
    except ValueError as error:
        raise _CRTConfigurationRefusal(str(error)) from error


def bindings(authority_schema_path=previous.previous.authority.DEFAULT_SCHEMA):
    verify_sources()
    old = previous.bindings(authority_schema_path)
    original_scope = old.main.__globals__
    scope = dict(vars(old), parse_override=_parse_for_launcher, __file__=__file__)
    scope['CONFIG_ENVIRONMENT_KEYS'] = set(scope['CONFIG_ENVIRONMENT_KEYS']) | {
        crt.ENVIRONMENT_KEY, crt.LEGACY_ENVIRONMENT_KEY,
        crt.aspect.ENVIRONMENT_KEY, crt.aspect.PRESENTATION_HASH_KEY,
    }
    for name, value in tuple(scope.items()):
        if isinstance(value, FunctionType) and value.__globals__ is original_scope:
            clone = FunctionType(value.__code__, scope, value.__name__, value.__defaults__, value.__closure__)
            clone.__kwdefaults__ = value.__kwdefaults__
            scope[name] = clone
    # Reconstruct the pinned transport body, retaining the shared verifier
    # closure from V5 while replacing its parser and environment authority.
    body = inspect.getsource(previous.previous.previous.transport.prior.run_game)
    old_import = 'import bounded_runtime_pair_verify as runtime_pair_verify'
    if body.count(old_import) != 1:
        raise ValueError('shared CRT launcher final verification seam changed')
    body = body.replace(old_import, 'runtime_pair_verify = shared_runtime_pair_verifier', 1)
    exec(compile(body, '<pinned shared CRT launch>', 'exec'), scope)
    inherited = scope['run_game']
    def run_game(args):
        try:
            return inherited(args)
        except _CRTConfigurationRefusal as error:
            print('ERROR: ' + str(error), file=sys.stderr)
            return 2
    scope['run_game'] = run_game
    return SimpleNamespace(**scope)


def run_game(args): return bindings().run_game(args)
def main(): return bindings().main()


if __name__ == '__main__': raise SystemExit(main())
