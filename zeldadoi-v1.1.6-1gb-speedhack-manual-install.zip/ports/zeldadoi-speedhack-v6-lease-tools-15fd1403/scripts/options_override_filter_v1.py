"""Staged Filter extension of the pinned Aspect/configuration authority.

Only explicit active Preferences.Filter controls the filter. Omission retains
the selected profile, unlike Aspect's established external 16:9 fallback.
The production launcher/VM is not wired by importing this module.
"""
import configparser
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from types import FunctionType, SimpleNamespace

import options_override_aspect_v2 as previous

PREVIOUS_SHA256 = 'a29072b39971356d6af4091050a2a8f9b02b98d16bb57a1773d92530390dc5b6'
FILTERS = ('None', 'CRT')
DEFAULT = 'None'
ENVIRONMENT_KEY = 'ZELDADOI_SPEEDHACK_FILTER'


@dataclass(frozen=True)
class FilterOverride(previous.AspectOverride):
    filter_name: str | None

    def as_dict(self):
        return dict(super().as_dict(), filter_name=self.filter_name,
                    filter_is_effective=self.enable_override and self.filter_name is not None)


def parse_override(path, schema=None):
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PREVIOUS_SHA256:
        raise ValueError('filter predecessor Aspect parser identity changed')
    base = previous.previous
    rules = base.load_schema() if schema is None else schema
    snapshot = base.read_override(path, int(rules['file']['maximum_bytes']))
    # Invocation-local proxy: the unchanged Aspect and base parsers consume
    # these SAME bytes, with no global I/O patch and no second disk read.
    proxy = SimpleNamespace(**dict(vars(base), read_override=lambda *_: snapshot))
    namespace = dict(vars(previous), previous=proxy)
    inherited = FunctionType(previous.parse_override.__code__, namespace,
                             previous.parse_override.__name__, previous.parse_override.__defaults__)
    result = inherited(path, rules)
    selected = None
    if result.enable_override and snapshot[0] is not None:
        text = snapshot[0].decode(rules['file']['encoding'])
        values = base.raw_ini_option_values(text, 'Preferences', 'Filter')
        if values:
            if result.source_status == 'malformed' or len(values) != 1 or values[0] not in FILTERS:
                raise ValueError('Invalid Filter: expected one canonical None or CRT value')
            parser = configparser.ConfigParser(interpolation=None, strict=True,
                                                empty_lines_in_values=False)
            parser.optionxform = str
            parser.read_string(text)
            if parser.get('Preferences', 'Filter') != values[0]:
                raise ValueError('Invalid Filter: multiline value refused')
            selected = values[0]
    environment = dict(result.environment)
    environment.pop(ENVIRONMENT_KEY, None)
    if selected is not None:
        environment[ENVIRONMENT_KEY] = selected
    presentation = dict(schema_version=2, aspect_presentation_sha256=result.presentation_sha256,
                        explicit_external_filter=selected)
    digest = hashlib.sha256(json.dumps(presentation, sort_keys=True,
                            separators=(',', ':')).encode()).hexdigest()
    environment[previous.PRESENTATION_HASH_KEY] = digest
    return FilterOverride(**dict(result.__dict__, environment=environment,
                                  presentation_sha256=digest), filter_name=selected)


def effective_filter(result, saved_preference):
    """Pure enum resolution; legacy carrier mapping belongs to source-bound VM glue."""
    if result.enable_override_error is not None:
        raise ValueError(result.enable_override_error)
    if result.enable_override and result.filter_name is not None:
        if result.filter_name not in FILTERS:
            raise ValueError('invalid effective external Filter')
        return result.filter_name
    if saved_preference is None:
        return DEFAULT
    if type(saved_preference) is not str or saved_preference not in FILTERS:
        raise ValueError('invalid saved Filter enumeration')
    return saved_preference
