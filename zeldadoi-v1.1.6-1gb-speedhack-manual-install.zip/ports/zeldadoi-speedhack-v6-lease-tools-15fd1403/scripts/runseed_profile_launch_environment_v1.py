"""Prepare launch-only identities without choosing a seed/mode or writing saves.

Supply all slots before menu navigation because the player can select RunSeed
inside the already running shared runtime. An identity candidate is not a claim.
"""
from runseed_profile_identity import PREFIX,generate_launch_candidates,validate_launch_candidates


def prepare_environment(environment,*,candidates=None):
    # Never inherit a caller's stale profile candidates or extra slot names.
    result={k:v for k,v in environment.items() if not k.startswith(PREFIX)}
    selected=generate_launch_candidates() if candidates is None else validate_launch_candidates(candidates)
    result.update(selected)
    return result
