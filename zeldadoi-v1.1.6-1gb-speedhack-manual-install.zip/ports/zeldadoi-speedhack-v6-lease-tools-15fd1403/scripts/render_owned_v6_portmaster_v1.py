"""Explicit private PortMaster actions; rendering never installs or runs."""
from pathlib import PurePosixPath
import re

PROGRAM_DIRECTORY = 'zeldadoi-owned-v6-qualification'
MANIFEST = 'private-v6-portmaster-manifest.json'
NAMES = {'setup': 'ZeldaDOI Private Owned V6 Setup.sh',
         'run': 'ZeldaDOI Private Owned V6 Run.sh',
         'restore': 'ZeldaDOI Private Owned V6 Restore.sh'}
REQUIRED = {'scripts/private_v6_qualification_v1.py', 'scripts/prepare_owned_v6_root_v1.py',
            'scripts/launch_with_owned_v6_native_v1.py', 'scripts/prepare_portmaster_runtime_log.py',
            'device/tools/launch_speedhack_beta_v1.py', 'device/tools/beta_bounded_log_capture_v1.py'}
# Same control discovery/get_controls sequence used by accepted private 949a.
CONTROLS = '''XDG_DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
if [ -f /mnt/mmc/MUOS/PortMaster/control.txt ]; then C=/mnt/mmc/MUOS/PortMaster
elif [ -f /mnt/sdcard/MUOS/PortMaster/control.txt ]; then C=/mnt/sdcard/MUOS/PortMaster
elif [ -f /opt/system/Tools/PortMaster/control.txt ]; then C=/opt/system/Tools/PortMaster
elif [ -f /opt/tools/PortMaster/control.txt ]; then C=/opt/tools/PortMaster
elif [ -f "$XDG_DATA_HOME/PortMaster/control.txt" ]; then C="$XDG_DATA_HOME/PortMaster"
elif [ -f /roms/ports/PortMaster/control.txt ]; then C=/roms/ports/PortMaster
elif [ -f /ROMS/PORTS/PortMaster/control.txt ]; then C=/ROMS/PORTS/PortMaster
else printf 'PortMaster controls not found\\n'; exit 2; fi
source "$C/control.txt" || exit 2
[ -n "$CFW_NAME" ] && [ -f "$C/mod_$CFW_NAME.txt" ] && source "$C/mod_$CFW_NAME.txt"
declare -F get_controls >/dev/null || exit 2
get_controls || exit 2
export sdl_controllerconfig GPTOKEYB DEVICE_ARCH
'''


def shell_source(action, manifest_sha256, file_hashes):
    if action not in NAMES or type(manifest_sha256) is not str or re.fullmatch(r'[0-9a-f]{64}', manifest_sha256) is None:
        raise ValueError('exact private action/manifest identity required')
    if (type(file_hashes) is not dict or not REQUIRED <= set(file_hashes) or len(file_hashes) > 256
            or any(type(name) is not str for name in file_hashes)):
        raise ValueError('private launcher source inventory is incomplete')
    checks = [(MANIFEST, manifest_sha256)]
    for name, digest in sorted(file_hashes.items()):
        path = PurePosixPath(name)
        if (len(name) > 256 or re.fullmatch(r'[A-Za-z0-9_.\-/]+', name) is None
                or path.is_absolute() or not path.parts or str(path) != name or '..' in path.parts
                or set(part.lower() for part in path.parts) & {'private', 'input', 'tmp', 'saves', 'logs', 'reports'}
                or path.suffix.lower() == '.port' or path.name.lower() == 'game.droid'
                or name == MANIFEST or type(digest) is not str or re.fullmatch(r'[0-9a-f]{64}', digest) is None):
            raise ValueError('private launcher file identity is unsafe')
        checks.append((name, digest))
    body = f'''#!/bin/bash
set +u
set -o pipefail
umask 077
D=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd -P) || exit 2
K=""
for P in "$D" "$D/../ports" "$D/../../ports"; do
  if [ -f "$P/{PROGRAM_DIRECTORY}/{MANIFEST}" ] && [ ! -L "$P/{PROGRAM_DIRECTORY}" ]; then
    K="$P/{PROGRAM_DIRECTORY}"; break
  fi
done
[ -n "$K" ] || {{ printf 'Private V6 package not found\\n'; exit 2; }}
K=$(CDPATH='' cd -- "$K" && pwd -P) || exit 2
PORTS=$(dirname -- "$K")
[ "$(basename -- "$PORTS")" = ports ] || {{ printf 'Lowercase ports root required\\n'; exit 2; }}
'''
    directories = set()
    for name, _ in checks:
        directories.update(str(p) for p in PurePosixPath(name).parents if str(p) != '.')
    for name in sorted(directories, key=lambda p: (p.count('/'), p)):
        body += f'[ -d "$K/{name}" ] && [ ! -L "$K/{name}" ] || exit 2\n'
    for name, digest in checks:
        body += f'''[ -f "$K/{name}" ] && [ ! -L "$K/{name}" ] || exit 2
printf '%s  %s\\n' '{digest}' "$K/{name}" | sha256sum -c - || exit 2
'''
    source_entries = sorted({name for name, _ in checks if name.startswith(('scripts/', 'device/tools/'))}
                            | {name for name in directories if name.startswith(('scripts', 'device/tools'))})
    allowed = '|'.join('"$K/' + name + '"' for name in source_entries)
    body += f'''find "$K/scripts" "$K/device/tools" -mindepth 1 -print | while IFS= read -r component; do
  case "$component" in
    {allowed}) ;;
    *) printf 'Unexpected source component: %s\\n' "$component"; exit 2 ;;
  esac
done || exit 2
'''
    body += CONTROLS
    body += 'export SDL_GAMECONTROLLERCONFIG="${sdl_controllerconfig:-${SDL_GAMECONTROLLERCONFIG:-}}"\n'
    if action == 'setup':
        body += '''/usr/bin/python3 -I -B "$K/scripts/private_v6_qualification_v1.py" setup \\
    --ports-dir "$PORTS" --artifacts "$K/artifacts" --generation-timestamp '2026-11-14T00:00:00Z'
'''
    elif action == 'run':
        body += '''/usr/bin/python3 -I -B "$K/scripts/private_v6_qualification_v1.py" run \\
    --game-dir "$PORTS/zeldadoi-owned-v6-949a386b2afb" --mapper "$GPTOKEYB"
'''
    else:
        body += '''/usr/bin/python3 -I -B "$K/scripts/private_v6_qualification_v1.py" restore \\
    --game-dir "$PORTS/zeldadoi-owned-v6-949a386b2afb" --artifacts "$K/artifacts"
'''
    return body + '''status=$?
if declare -F pm_finish >/dev/null; then pm_finish; fi
exit "$status"
'''
