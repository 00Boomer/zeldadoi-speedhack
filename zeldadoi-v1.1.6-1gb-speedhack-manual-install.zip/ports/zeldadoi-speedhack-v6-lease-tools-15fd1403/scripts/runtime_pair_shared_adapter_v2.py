"""Invocation-local shared-authority view of the existing pair transactions.

Only authority readers and their schema defaults change. Locks, ownership,
capacity accounting, preservation, crash recovery and transactions are the
existing implementation. Legacy modules and their global bindings stay intact.
This is a host integration seam, not production runtime qualification.
"""
from types import FunctionType, SimpleNamespace

import bounded_runtime_pair_activation as old_activation
import bounded_runtime_pair_verify as old_verify
import bounded_runtime_pair_restore as old_restore
import bounded_runtime_pair_stage as old_stage
import bounded_runtime_pair_install as old_install
import bounded_runtime_pair_migrate as old_migrate
import runtime_pair_capacity as old_capacity
import runtime_authority as old_authority
import runtime_authority_shared_v2 as authority


def _bind(module, **dependencies):
    scope = dict(vars(module), load_schema=authority.load_schema,
                 load_authority=authority.load_authority, **dependencies)
    for name in ('DEFAULT_SCHEMA', 'DEFAULT_AUTHORITY_SCHEMA'):
        if name in scope:
            if scope[name] != old_authority.DEFAULT_SCHEMA:
                raise ValueError('shared transaction inherited schema default changed')
            scope[name] = authority.DEFAULT_SCHEMA
    for name, value in tuple(vars(module).items()):
        if not isinstance(value, FunctionType) or value.__globals__ is not vars(module):
            continue
        defaults = None if value.__defaults__ is None else tuple(
            authority.DEFAULT_SCHEMA if item == old_authority.DEFAULT_SCHEMA else item
            for item in value.__defaults__)
        function = FunctionType(value.__code__, scope, value.__name__, defaults, value.__closure__)
        function.__kwdefaults__ = None if value.__kwdefaults__ is None else {
            key: authority.DEFAULT_SCHEMA if item == old_authority.DEFAULT_SCHEMA else item
            for key, item in value.__kwdefaults__.items()}
        function.__annotations__ = dict(value.__annotations__)
        function.__doc__ = value.__doc__
        scope[name] = function
    return SimpleNamespace(**{key: value for key, value in scope.items()
                             if not key.startswith('__')})


def bindings():
    """Fresh coherent graph; never monkeypatch a shared historical module."""
    capacity = _bind(old_capacity)
    activation = _bind(old_activation, capacity_model=capacity)
    verify = _bind(old_verify, activation=activation)
    restore = _bind(old_restore, activation=activation, pair_verify=verify,
                    capacity_model=capacity)
    stage = _bind(old_stage, activation=activation, pair_restore=restore,
                  capacity_model=capacity)
    install = _bind(old_install, activation=activation, pair_restore=restore,
                    pair_stage=stage, pair_verify=verify, capacity_model=capacity)
    migrate = _bind(old_migrate, activation=activation, pair_install=install,
                    pair_restore=restore, pair_verify=verify, capacity_model=capacity)
    return SimpleNamespace(capacity=capacity, activation=activation, verify=verify,
                           restore=restore, stage=stage, install=install,
                           migrate=migrate)
