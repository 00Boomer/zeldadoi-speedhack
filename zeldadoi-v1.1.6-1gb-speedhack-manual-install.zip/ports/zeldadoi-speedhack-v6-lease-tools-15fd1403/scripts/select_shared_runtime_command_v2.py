"""Existing logical launch roles must resolve to one exact capable payload.

Mode commitment remains in GameMaker. Archive aliases/config paths reuse the
bounded installer layout;they do not create different mode executables.
"""
import launch_with_options_override as legacy
import runtime_authority_shared_v2 as authority


def select_runtime_command(command, resolved, game_directory, options_schema,
        runtime_authority, run_seed=None, *, authority_schema=None):
    if resolved.enabled and run_seed is not None and run_seed.enabled:
        raise ValueError('DungeonSeed and RunSeed are mutually exclusive')
    schema = authority.load_schema() if authority_schema is None else authority_schema
    authority.validate_document(runtime_authority, schema)
    return legacy.select_runtime_command(command, resolved, game_directory,
        options_schema, runtime_authority, run_seed)
