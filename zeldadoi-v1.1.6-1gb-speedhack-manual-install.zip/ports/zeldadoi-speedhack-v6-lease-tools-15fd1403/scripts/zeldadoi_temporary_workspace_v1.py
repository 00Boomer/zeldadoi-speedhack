"""Explicit development workspace ownership, not blanket deletion authority.

Large disposable roots default to project tmp/. Explicit destination-local and
OS compatibility stages retain their requested parent. Historical spellings
are recognized only for inventory. Required/frozen paths are never renamed.
"""
from contextlib import contextmanager
import os
from pathlib import Path
import re
import tempfile

TMP=Path('/tmp')
PROJECT_TMP=Path(__file__).resolve().parents[1]/'tmp'


def project_temp_root():
    # Do not silently fall back to the constrained OS filesystem.
    if PROJECT_TMP.is_symlink() or not PROJECT_TMP.is_dir():
        raise ValueError('project tmp directory absent or symlink')
    if not os.access(PROJECT_TMP,os.R_OK|os.W_OK|os.X_OK):
        raise ValueError('project tmp directory inaccessible')
    return PROJECT_TMP


def child_temp_environment(environment):
    root=str(project_temp_root())
    return dict(environment,TMPDIR=root,TMP=root,TEMP=root)


def namespace(path):
    path=Path(path)
    if not path.is_absolute() or '..' in path.parts or path.parent not in (TMP,PROJECT_TMP):
        return None
    name=path.name
    if name=='zeldadoi' or re.fullmatch(r'zeldadoi\.[A-Za-z0-9_.-]+',name):
        return 'cleanup_owned'
    if re.fullmatch(r'zeldadoi-[A-Za-z0-9_.-]+',name):return 'historical_hyphen'
    if re.fullmatch(r'\.zdlf-[A-Za-z0-9_.-]+',name):return 'historical_dot_zdlf'
    return None


def cleanup_compatible(path):
    return namespace(path)=='cleanup_owned'


def make_workspace(purpose,*,parent=None,required_bytes=0):
    if not isinstance(purpose,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,100}',purpose):
        raise ValueError('invalid ZeldaDOI workspace purpose')
    parent=project_temp_root() if parent is None else Path(parent)
    if not parent.is_absolute() or parent.is_symlink() or not parent.is_dir():
        raise ValueError('invalid workspace parent')
    if type(required_bytes) is not int or required_bytes<0:
        raise ValueError('invalid workspace capacity estimate')
    capacity=os.statvfs(parent)
    if capacity.f_bavail*capacity.f_frsize < required_bytes+1024**3:
        raise ValueError('insufficient destination capacity including 1 GiB reserve')
    if parent==TMP:
        prefix='zeldadoi.'+purpose+'.'
    else:
        # Nested destination-local stages retain correct filesystem affinity.
        prefix='zeldadoi.'+purpose+'.'
    path=Path(tempfile.mkdtemp(prefix=prefix,dir=parent))
    if parent in (TMP,PROJECT_TMP) and not cleanup_compatible(path):
        raise ValueError('workspace outside canonical cleanup namespace')
    return path


@contextmanager
def temporary_workspace(purpose,*,parent=None,required_bytes=0):
    # Small owned stages only: refuse unexpected links/mounts/foreign files.
    path=make_workspace(purpose,parent=parent,required_bytes=required_bytes)
    identity=path.stat()
    try:
        yield path
    finally:
        import shutil
        current=path.lstat()
        if path.is_symlink() or (current.st_dev,current.st_ino)!=(identity.st_dev,identity.st_ino):
            raise ValueError('workspace identity changed; retained')
        for base,dirs,files in os.walk(path,followlinks=False):
            for name in [*dirs,*files]:
                member=Path(base)/name;s=member.lstat()
                # Owned fixture links are removed as links, never traversed.
                if s.st_dev!=identity.st_dev or s.st_uid!=os.getuid():
                    raise ValueError('workspace contains non-owned/link/mount content; retained')
        shutil.rmtree(path)
