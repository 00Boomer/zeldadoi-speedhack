"""Staged 3:2 enum extension of the existing single-Dungeon-Seed parser.

Same INI keys, schema versions, snapshot and authority rules. No production
launcher is switched until the composed VM understands the added string value.
All historical parser files/pins and saved meanings remain unchanged.
"""
from types import FunctionType,SimpleNamespace
from pathlib import Path
import hashlib
import options_override_dungeon_seed_v1 as previous

MODES=('16:9','3:2','4:3','1:1')
DEFAULT='16:9'
PREVIOUS_SHA='0cab10365a9a53e00603f4a6f8eefcb1082ae43e7ed6425aa63b2eeaf88c65a2'
def verify_sources():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest()!=PREVIOUS_SHA:raise ValueError('3:2 predecessor parser identity changed')
    previous.verify_sources()
def _parse_snapshot(path,rules,snapshot):
    filt=previous.previous;aspect=filt.previous;base=aspect.previous
    proxy=SimpleNamespace(**dict(vars(base),read_override=lambda *_:snapshot))
    expanded=SimpleNamespace(**dict(vars(aspect),previous=proxy,MODES=MODES))
    scope=dict(vars(filt),previous=expanded)
    try:return FunctionType(filt.parse_override.__code__,scope,argdefs=filt.parse_override.__defaults__)(path,rules)
    except ValueError as error:
        if str(error)=='Invalid AspectRatio: expected one canonical 16:9, 4:3 or 1:1 value':
            raise ValueError('Invalid AspectRatio: expected one canonical 16:9, 3:2, 4:3 or 1:1 value')from error
        raise
def parse_override(path,schema=None):
    verify_sources()
    scope=dict(vars(previous),_parse_snapshot=_parse_snapshot,verify_sources=verify_sources)
    return FunctionType(previous.parse_override.__code__,scope,argdefs=previous.parse_override.__defaults__)(path,schema)
def effective_aspect(result,saved_preference):
    aspect=previous.previous.previous
    return FunctionType(aspect.effective_aspect.__code__,dict(vars(aspect),MODES=MODES),argdefs=aspect.effective_aspect.__defaults__)(result,saved_preference)
effective_filter=previous.previous.effective_filter
