#!/usr/bin/env python3
"""Launcher-owned RunSeed/DungeonSeed profile-ID candidate model."""

from __future__ import annotations

import re
import secrets
from typing import Callable, Mapping, MutableSet


PREFIX = "ZELDADOI_DETERMINISTIC_PROFILE_ID_SLOT_"
SLOTS = 5
PROFILE_ID_RE = re.compile(r"^[0-9a-f]{64}$")


class ProfileIdentityError(ValueError):
    pass


def generate_launch_candidates(
    entropy: Callable[[int], bytes] = secrets.token_bytes,
) -> dict[str, str]:
    result: dict[str, str] = {}
    for slot in range(SLOTS):
        raw = entropy(32)
        if not isinstance(raw, bytes) or len(raw) != 32:
            raise ProfileIdentityError("profile-ID entropy source returned the wrong shape")
        result[f"{PREFIX}{slot}"] = raw.hex()
    return validate_launch_candidates(result)


def validate_launch_candidates(values: Mapping[str, str]) -> dict[str, str]:
    expected = {f"{PREFIX}{slot}" for slot in range(SLOTS)}
    if set(values) != expected:
        raise ProfileIdentityError("profile-ID candidate environment keys mismatch")
    result = dict(values)
    if any(not isinstance(value, str) or PROFILE_ID_RE.fullmatch(value) is None for value in result.values()):
        raise ProfileIdentityError("profile-ID candidate must be 64 lowercase hexadecimal characters")
    if len(set(result.values())) != SLOTS:
        raise ProfileIdentityError("profile-ID candidates must be unique")
    return result


def claim_new_run_candidate(
    candidates: Mapping[str, str], *, selected_slot: int,
    consumed_slots: MutableSet[int], existing_profile_id: str | None = None,
) -> str:
    if isinstance(selected_slot, bool) or not isinstance(selected_slot, int) or not 0 <= selected_slot < SLOTS:
        raise ProfileIdentityError("selected slot is outside 0..4")
    if existing_profile_id is not None:
        if PROFILE_ID_RE.fullmatch(existing_profile_id) is None:
            raise ProfileIdentityError("existing deterministic profile ID is invalid")
        return existing_profile_id
    checked = validate_launch_candidates(candidates)
    if selected_slot in consumed_slots:
        raise ProfileIdentityError("selected slot's launch candidate was already consumed")
    candidate = checked[f"{PREFIX}{selected_slot}"]
    consumed_slots.add(selected_slot)
    return candidate
