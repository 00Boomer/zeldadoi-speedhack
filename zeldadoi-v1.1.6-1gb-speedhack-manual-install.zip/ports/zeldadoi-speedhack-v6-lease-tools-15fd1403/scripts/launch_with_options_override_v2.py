"""Current launcher successor supplying ephemeral identity candidates once.

Reuse the existing configuration, authority, locking, telemetry and signal flow.
Only the GameMaker child's explicitly supplied environment changes; no parent
environment, seed selection, archive/profile or normal preference is mutated.
The shared-runtime/package approval remains a separate release requirement.
"""
import types
import launch_with_options_override as prior
from runseed_profile_launch_environment_v1 import prepare_environment


class _Subprocess:
    def __getattr__(self,name):return getattr(prior.subprocess,name)

    def Popen(self,*args,**kwargs):
        # Samplers omit env and retain the frozen launcher's exact behavior.
        if kwargs.get('env') is not None:
            try:kwargs={**kwargs,'env':prepare_environment(kwargs['env'])}
            except ValueError as error:
                raise OSError('RunSeed profile identity setup refused: '+str(error)) from error
        return prior.subprocess.Popen(*args,**kwargs)


_namespace=dict(vars(prior),subprocess=_Subprocess())
for _name,_value in tuple(_namespace.items()):
    if isinstance(_value,types.FunctionType) and _value.__globals__ is vars(prior):
        invoke=types.FunctionType(_value.__code__,_namespace,_value.__name__,
            _value.__defaults__,_value.__closure__)
        invoke.__kwdefaults__=_value.__kwdefaults__
        _namespace[_name]=invoke
for _name,_value in _namespace.items():
    if not _name.startswith('__'):globals()[_name]=_value

if __name__=='__main__':raise SystemExit(main())
