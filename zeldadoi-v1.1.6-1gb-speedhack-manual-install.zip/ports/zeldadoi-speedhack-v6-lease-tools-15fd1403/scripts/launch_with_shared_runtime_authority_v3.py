"""Current profile-safe launcher with strict shared V2 runtime authority.

Reuse V2's child-only ephemeral identity setup and V1's configuration, locking,
telemetry and signal handling. The historical modules are never monkeypatched.
Real release publication/candidate capability remains independently gated.
"""
import inspect
from types import FunctionType, SimpleNamespace

import launch_with_options_override_v2 as previous
import runtime_authority_shared_v2 as authority
import select_shared_runtime_command_v2 as selector
import verify_shared_runtime_pair_v2 as verifier


def bindings(authority_schema_path=authority.DEFAULT_SCHEMA):
    schema = authority.load_schema(authority_schema_path)
    def select_command(command, resolved, game_directory, options_schema, runtime_authority, run_seed=None):
        if runtime_authority is None:
            return previous.prior.select_runtime_command(command, resolved, game_directory,
                                                          options_schema, None, run_seed)
        return selector.select_runtime_command(command, resolved, game_directory, options_schema,
                                                runtime_authority, run_seed, authority_schema=schema)
    # A fixture may supply a separately authenticated synthetic schema. It is
    # explicit and local,not a writable global override or authority fallback.
    def verify_pair(*args, **kwargs):
        if 'schema_path' in kwargs:
            raise ValueError('shared launcher verifier schema cannot be overridden')
        return verifier.verify_installed_pair(*args, schema_path=authority_schema_path, **kwargs)
    original_scope = previous._namespace
    scope = dict(original_scope, __file__=__file__,
        DEFAULT_RUNTIME_AUTHORITY_SCHEMA=authority_schema_path,
        load_runtime_authority_schema=authority.load_schema,
        load_authority=authority.load_authority,
        select_runtime_command=select_command,
        shared_runtime_pair_verifier=SimpleNamespace(verify_installed_pair=verify_pair))
    replacements = {'select_runtime_command'}
    for name, value in tuple(original_scope.items()):
        if (name in replacements or not isinstance(value, FunctionType) or
                value.__globals__ is not original_scope):
            continue
        invoke = FunctionType(value.__code__, scope, value.__name__, value.__defaults__, value.__closure__)
        invoke.__kwdefaults__ = value.__kwdefaults__
        scope[name] = invoke
    body = inspect.getsource(previous.prior.run_game)
    old = 'import bounded_runtime_pair_verify as runtime_pair_verify'
    if body.count(old) != 1:
        raise ValueError('shared launcher inherited late verification seam changed')
    body = body.replace(old, 'runtime_pair_verify = shared_runtime_pair_verifier', 1)
    exec(compile(body, '<current strict shared runtime launch>', 'exec'), scope)
    return SimpleNamespace(**scope)


def run_game(args):
    return bindings().run_game(args)


def main():
    return bindings().main()


if __name__ == '__main__': raise SystemExit(main())
