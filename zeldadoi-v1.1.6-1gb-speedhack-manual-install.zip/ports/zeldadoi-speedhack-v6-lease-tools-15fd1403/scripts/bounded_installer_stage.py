#!/usr/bin/env python3
"""Inventory and nonrecursively remove journal-owned bounded installer stages."""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from bounded_installer_journal import (
    OWNER,
    candidate_basename,
    fsync_directory,
    read_record,
    recovery_decision,
    stage_basename,
    validate_record,
    verify_owned_state_directory,
)
from convert_official_cache_bounded import OWNERSHIP_MANIFEST, validate_contract


STAGE_OWNER_NAME = "bounded-stage-owner"
PRESERVED_SOURCE_NAME = "preserved-source.port"
OFFICIAL_DROID_NAME = "official.game.droid"
PATCHED_DROID_NAME = "patched.game.droid"
ACTIVE_CACHE_NAME = "cache"
HEX64 = re.compile(r"[0-9a-f]{64}")
CACHE_STAGE = re.compile(r"cache\.stage-[1-9][0-9]*")


@dataclass(frozen=True)
class OwnedEntry:
    path: Path
    is_directory: bool
    device: int
    inode: int


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def stage_owner_text(record: dict[str, str]) -> str:
    record = validate_record(record)
    return (
        "SCHEMA_VERSION=1\n"
        f"OWNER={OWNER}\n"
        f"PATCH_ID={record['PATCH_ID']}\n"
        f"MANIFEST_SHA256={record['MANIFEST_SHA256']}\n"
        f"STAGE_BASENAME={record['STAGE_BASENAME']}\n"
    )


def create_owned_stage(
    state_directory: Path,
    record: dict[str, str],
    *,
    expected_manifest_sha256: str,
) -> Path:
    """Create and durably mark an absent transaction stage."""
    verify_owned_state_directory(state_directory)
    record = validate_record(record)
    if record["MANIFEST_SHA256"] != expected_manifest_sha256:
        raise ValueError("bounded stage manifest authority mismatch")
    journal = read_record(state_directory / "bounded-transaction")
    if journal != record:
        raise ValueError("bounded stage record does not match durable journal")
    stage = state_directory / stage_basename(record["PATCH_ID"])
    candidate = state_directory / candidate_basename(record["PATCH_ID"])
    if stage.exists() or stage.is_symlink():
        raise ValueError("bounded stage path already exists")
    if candidate.exists() or candidate.is_symlink():
        raise ValueError("bounded candidate path already exists")
    stage.mkdir(mode=0o700)
    marker = stage / STAGE_OWNER_NAME
    descriptor = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            handle.write(stage_owner_text(record))
            handle.flush()
            os.fsync(handle.fileno())
    except BaseException:
        # A partial owned stage remains for explicit journal-guided recovery.
        raise
    fsync_directory(stage)
    fsync_directory(state_directory)
    return stage


def load_contract(path: Path, expected_sha256: str) -> dict[str, Any]:
    if HEX64.fullmatch(expected_sha256) is None:
        raise ValueError("expected generated-cache contract identity is invalid")
    if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1:
        raise ValueError("generated-cache contract must be a regular non-symlink file")
    if sha256_file(path) != expected_sha256:
        raise ValueError("generated-cache contract identity mismatch")
    try:
        contract = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("generated-cache contract must be UTF-8 JSON") from exc
    if not isinstance(contract, dict):
        raise ValueError("generated-cache contract root must be an object")
    validate_contract(contract)
    return contract


def owned_entry(path: Path, *, is_directory: bool) -> OwnedEntry:
    metadata = path.lstat()
    mode = metadata.st_mode
    if stat.S_ISLNK(mode):
        raise ValueError(f"owned stage path must not be a symlink: {path.name}")
    if is_directory and not stat.S_ISDIR(mode):
        raise ValueError(f"owned stage directory has unexpected type: {path.name}")
    if not is_directory and not stat.S_ISREG(mode):
        raise ValueError(f"owned stage file has unexpected type: {path.name}")
    if not is_directory and metadata.st_nlink != 1:
        raise ValueError(f"owned stage file must not be hard-linked: {path.name}")
    return OwnedEntry(path, is_directory, metadata.st_dev, metadata.st_ino)


def scan_cache_root(
    root: Path,
    expected_files: set[str],
) -> tuple[list[OwnedEntry], list[OwnedEntry]]:
    files: list[OwnedEntry] = []
    directories: list[OwnedEntry] = []
    allowed_directories = {"assets", "assets/data"}
    pending = [(root, PurePosixPath())]
    seen = 0
    maximum_entries = len(expected_files) + len(allowed_directories) + 2
    while pending:
        directory, relative_root = pending.pop()
        with os.scandir(directory) as iterator:
            entries = list(iterator)
        for entry in entries:
            seen += 1
            if seen > maximum_entries:
                raise ValueError("owned cache stage exceeds the contract entry bound")
            relative = relative_root / entry.name
            relative_text = relative.as_posix()
            path = Path(entry.path)
            if entry.is_symlink():
                raise ValueError(f"owned cache stage contains symlink: {relative_text}")
            if entry.is_dir(follow_symlinks=False):
                if relative_text not in allowed_directories:
                    raise ValueError(
                        f"owned cache stage contains unexpected directory: {relative_text}"
                    )
                directories.append(owned_entry(path, is_directory=True))
                pending.append((path, relative))
            elif entry.is_file(follow_symlinks=False):
                if relative_text not in expected_files and relative_text != OWNERSHIP_MANIFEST:
                    raise ValueError(
                        f"owned cache stage contains unexpected file: {relative_text}"
                    )
                files.append(owned_entry(path, is_directory=False))
            else:
                raise ValueError(
                    f"owned cache stage contains unsupported path: {relative_text}"
                )
    return files, directories


def inventory_owned_stages(
    state_directory: Path,
    record: dict[str, str],
    contract: dict[str, Any],
) -> tuple[list[OwnedEntry], list[OwnedEntry]]:
    """Preflight the entire owned stage namespace before any removal."""
    verify_owned_state_directory(state_directory)
    record = validate_record(record)
    durable = read_record(state_directory / "bounded-transaction")
    if durable != record:
        raise ValueError("bounded cleanup record does not match durable journal")
    validate_contract(contract)
    expected_files = {
        PurePosixPath(item["relative_path"]).relative_to("assets/data").as_posix()
        for item in contract["generated_files"]
    }
    expected_files = {f"assets/data/{path}" for path in expected_files}

    files: list[OwnedEntry] = []
    directories: list[OwnedEntry] = []
    stage = state_directory / record["STAGE_BASENAME"]
    if stage.exists() or stage.is_symlink():
        stage_entry = owned_entry(stage, is_directory=True)
        with os.scandir(stage) as iterator:
            top_entries = list(iterator)
        if top_entries:
            marker = stage / STAGE_OWNER_NAME
            marker_matches = (
                marker.is_symlink()
                is False
                and marker.is_file()
                and marker.read_text(encoding="utf-8") == stage_owner_text(record)
            )
            incomplete_marker_only = (
                len(top_entries) == 1
                and top_entries[0].name == STAGE_OWNER_NAME
                and not top_entries[0].is_symlink()
                and top_entries[0].is_file(follow_symlinks=False)
            )
            if not marker_matches and not incomplete_marker_only:
                raise ValueError("bounded stage owner marker mismatch")
        cache_roots = 0
        for entry in top_entries:
            path = Path(entry.path)
            if entry.is_symlink():
                raise ValueError(f"bounded stage contains symlink: {entry.name}")
            if entry.is_file(follow_symlinks=False):
                if entry.name not in {
                    STAGE_OWNER_NAME,
                    PRESERVED_SOURCE_NAME,
                    OFFICIAL_DROID_NAME,
                    PATCHED_DROID_NAME,
                }:
                    raise ValueError(f"bounded stage contains unexpected file: {entry.name}")
                files.append(owned_entry(path, is_directory=False))
            elif entry.is_dir(follow_symlinks=False):
                if entry.name != ACTIVE_CACHE_NAME and CACHE_STAGE.fullmatch(entry.name) is None:
                    raise ValueError(
                        f"bounded stage contains unexpected directory: {entry.name}"
                    )
                cache_roots += 1
                if cache_roots > 1:
                    raise ValueError("bounded stage contains multiple cache roots")
                cache_entry = owned_entry(path, is_directory=True)
                cache_files, cache_directories = scan_cache_root(path, expected_files)
                files.extend(cache_files)
                directories.extend(cache_directories)
                directories.append(cache_entry)
            else:
                raise ValueError(f"bounded stage contains unsupported path: {entry.name}")
        directories.append(stage_entry)

    candidate_name = record["CANDIDATE_BASENAME"]
    candidate_pattern = re.compile(re.escape(candidate_name) + r"\.stage-[1-9][0-9]*")
    candidate_stages = 0
    with os.scandir(state_directory) as iterator:
        for entry in iterator:
            if entry.name == candidate_name or candidate_pattern.fullmatch(entry.name):
                if entry.name != candidate_name:
                    candidate_stages += 1
                    if candidate_stages > 1:
                        raise ValueError("bounded state contains multiple candidate stages")
                if entry.is_symlink() or not entry.is_file(follow_symlinks=False):
                    raise ValueError("bounded candidate stage must be a regular file")
                files.append(owned_entry(Path(entry.path), is_directory=False))

    directories.sort(key=lambda item: len(item.path.parts), reverse=True)
    return files, directories


def verify_entry_unchanged(entry: OwnedEntry) -> None:
    metadata = entry.path.lstat()
    if (
        metadata.st_dev != entry.device
        or metadata.st_ino != entry.inode
        or stat.S_ISLNK(metadata.st_mode)
        or (entry.is_directory and not stat.S_ISDIR(metadata.st_mode))
        or (not entry.is_directory and not stat.S_ISREG(metadata.st_mode))
        or (not entry.is_directory and metadata.st_nlink != 1)
    ):
        raise ValueError(f"owned stage entry changed after inventory: {entry.path.name}")


def execute_cleanup_plan(
    state_directory: Path,
    files: list[OwnedEntry],
    directories: list[OwnedEntry],
) -> dict[str, int]:
    """Execute only a fully preflighted, identity-stable nonrecursive plan."""
    verify_owned_state_directory(state_directory)
    for entry in files:
        verify_entry_unchanged(entry)
    for entry in directories:
        verify_entry_unchanged(entry)
    for entry in files:
        entry.path.unlink()
    for entry in directories:
        entry.path.rmdir()
    fsync_directory(state_directory)
    return {"files_removed": len(files), "directories_removed": len(directories)}


def cleanup_after_recovery_decision(
    state_directory: Path,
    contract_path: Path,
    record: dict[str, str],
    *,
    expected_manifest_sha256: str,
    expected_contract_sha256: str,
    active_sha256: str,
    preserved_sha256: str | None,
    state_record_matches: bool,
) -> dict[str, Any]:
    """Clean stages only when the journal's recovery classifier authorizes it."""
    decision = recovery_decision(
        record,
        expected_manifest_sha256=expected_manifest_sha256,
        active_sha256=active_sha256,
        preserved_sha256=preserved_sha256,
        state_record_matches=state_record_matches,
    )
    if not decision["may_remove_owned_stages"]:
        raise ValueError(f"bounded stage cleanup is not authorized: {decision['action']}")
    if decision["may_write_state"]:
        raise ValueError("exact output must be adopted before bounded stage cleanup")
    contract = load_contract(contract_path, expected_contract_sha256)
    files, directories = inventory_owned_stages(state_directory, record, contract)
    removed = execute_cleanup_plan(state_directory, files, directories)
    return {"decision": decision, **removed}
