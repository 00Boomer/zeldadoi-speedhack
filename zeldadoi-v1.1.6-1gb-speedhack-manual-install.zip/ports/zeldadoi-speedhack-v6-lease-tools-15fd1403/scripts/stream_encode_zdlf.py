#!/usr/bin/env python3
"""One-pass bounded-memory JSON-to-inline-ZDLF transcoder."""

from __future__ import annotations

import argparse
import json
import re
import resource
import struct
import sys
import time
from pathlib import Path
from typing import BinaryIO, Any

from lossless_data_format import (
    I64_MAX,
    I64_MIN,
    MAGIC,
    TAG_ARRAY,
    TAG_FALSE,
    TAG_FLOAT64,
    TAG_INT64,
    TAG_NULL,
    TAG_OBJECT,
    TAG_STRING,
    TAG_TRUE,
    VERSION,
)

JSON_WHITESPACE = {0x20, 0x09, 0x0A, 0x0D}
NUMBER_BYTES = set(b"-+0123456789.eE")
STRING_SPECIAL = re.compile(br'["\\\x00-\x1f]')


class ByteStream:
    def __init__(self, source: BinaryIO, chunk_size: int = 64 * 1024):
        self.source = source
        self.chunk_size = chunk_size
        self.buffer = b""
        self.index = 0
        self.bytes_read = 0

    def _fill(self) -> bool:
        if self.index < len(self.buffer):
            return True
        self.buffer = self.source.read(self.chunk_size)
        self.index = 0
        self.bytes_read += len(self.buffer)
        return bool(self.buffer)

    def peek(self) -> int | None:
        return self.buffer[self.index] if self._fill() else None

    def take(self) -> int:
        value = self.peek()
        if value is None:
            raise EOFError("unexpected end of JSON input")
        self.index += 1
        return value

    def skip_while(self, allowed: set[int]) -> None:
        """Skip a byte class without a Python method call for every byte."""
        while self._fill():
            buffer = self.buffer
            index = self.index
            limit = len(buffer)
            while index < limit and buffer[index] in allowed:
                index += 1
            self.index = index
            if index < limit:
                return

    def take_while(self, allowed: set[int]) -> bytes:
        """Take a byte class across chunk boundaries with exact stream state."""
        parts: list[bytes] = []
        while self._fill():
            buffer = self.buffer
            start = self.index
            index = start
            limit = len(buffer)
            while index < limit and buffer[index] in allowed:
                index += 1
            self.index = index
            if index > start:
                parts.append(buffer[start:index])
            if index < limit:
                break
        return b"".join(parts)

    def take_json_string_token(self) -> bytes:
        """Take through the closing quote after its opening quote was read."""
        raw = bytearray(b'"')
        while self._fill():
            buffer = self.buffer
            match = STRING_SPECIAL.search(buffer, self.index)
            if match is None:
                raw.extend(buffer[self.index :])
                self.index = len(buffer)
                continue
            special = match.start()
            raw.extend(buffer[self.index : special + 1])
            self.index = special + 1
            value = buffer[special]
            if value == ord('"'):
                return bytes(raw)
            if value < 0x20:
                raise ValueError("unescaped control byte in JSON string")
            # Preserve the escaped byte verbatim and let json.loads validate
            # the escape spelling. ``take`` correctly crosses chunk edges.
            raw.append(self.take())
        raise EOFError("unexpected end of JSON input")


class StreamingEncoder:
    def __init__(self, source: BinaryIO, output: BinaryIO):
        self.stream = ByteStream(source)
        self.output = output
        self.values = 0
        self.max_depth = 0
        self.max_token_bytes = 0
        self.max_object_keys = 0
        self.trailing_nuls = 0

    def _skip_ws(self) -> None:
        self.stream.skip_while(JSON_WHITESPACE)

    def _expect(self, wanted: int) -> None:
        actual = self.stream.take()
        if actual != wanted:
            raise ValueError(f"expected byte {wanted:#x}, got {actual:#x}")

    def _write_string(self, value: str) -> None:
        encoded = value.encode("utf-8")
        if len(encoded) > 0xFFFFFFFF:
            raise ValueError("string exceeds u32 encoded length")
        self.output.write(struct.pack("<I", len(encoded)))
        self.output.write(encoded)
        self.output.write(b"\x00")

    def _parse_string(self) -> str:
        self._expect(ord('"'))
        raw = self.stream.take_json_string_token()
        self.max_token_bytes = max(self.max_token_bytes, len(raw))
        parsed = json.loads(raw.decode("utf-8"))
        if not isinstance(parsed, str):
            raise ValueError("JSON string token did not decode to string")
        return parsed

    def _parse_number(self) -> int | float:
        raw = self.stream.take_while(NUMBER_BYTES)
        if not raw:
            raise ValueError("empty JSON number token")
        self.max_token_bytes = max(self.max_token_bytes, len(raw))
        token = raw.decode("ascii")
        value = json.loads(token)
        if type(value) not in {int, float}:
            raise ValueError(f"invalid JSON number token {token!r}")
        return value

    def _literal(self, suffix: bytes) -> None:
        for wanted in suffix:
            self._expect(wanted)

    def _parse_value(self, depth: int) -> None:
        self._skip_ws()
        self.max_depth = max(self.max_depth, depth)
        value = self.stream.peek()
        if value is None:
            raise EOFError("missing JSON value")
        self.values += 1
        if value == ord("n"):
            self._literal(b"null")
            self.output.write(bytes((TAG_NULL,)))
        elif value == ord("f"):
            self._literal(b"false")
            self.output.write(bytes((TAG_FALSE,)))
        elif value == ord("t"):
            self._literal(b"true")
            self.output.write(bytes((TAG_TRUE,)))
        elif value == ord('"'):
            parsed = self._parse_string()
            self.output.write(bytes((TAG_STRING,)))
            self._write_string(parsed)
        elif value == ord("["):
            self._parse_array(depth)
        elif value == ord("{"):
            self._parse_object(depth)
        elif value in NUMBER_BYTES:
            number = self._parse_number()
            if type(number) is int:
                if not I64_MIN <= number <= I64_MAX:
                    raise ValueError(f"integer is outside signed 64-bit range: {number}")
                self.output.write(struct.pack("<Bq", TAG_INT64, number))
            else:
                self.output.write(struct.pack("<Bd", TAG_FLOAT64, number))
        else:
            raise ValueError(f"unexpected JSON byte {value:#x}")

    def _parse_array(self, depth: int) -> None:
        self._expect(ord("["))
        self.output.write(bytes((TAG_ARRAY,)))
        count_offset = self.output.tell()
        self.output.write(b"\x00\x00\x00\x00")
        count = 0
        self._skip_ws()
        if self.stream.peek() != ord("]"):
            while True:
                self._parse_value(depth + 1)
                count += 1
                if count > 0xFFFFFFFF:
                    raise ValueError("array exceeds u32 count")
                self._skip_ws()
                delimiter = self.stream.take()
                if delimiter == ord("]"):
                    break
                if delimiter != ord(","):
                    raise ValueError("expected comma or closing bracket in array")
        else:
            self.stream.take()
        end = self.output.tell()
        self.output.seek(count_offset)
        self.output.write(struct.pack("<I", count))
        self.output.seek(end)

    def _parse_object(self, depth: int) -> None:
        self._expect(ord("{"))
        self.output.write(bytes((TAG_OBJECT,)))
        count_offset = self.output.tell()
        self.output.write(b"\x00\x00\x00\x00")
        count = 0
        keys: set[str] = set()
        self._skip_ws()
        if self.stream.peek() != ord("}"):
            while True:
                self._skip_ws()
                key = self._parse_string()
                if key in keys:
                    raise ValueError(f"duplicate JSON object key: {key!r}")
                keys.add(key)
                self.max_object_keys = max(self.max_object_keys, len(keys))
                self._write_string(key)
                self._skip_ws()
                self._expect(ord(":"))
                self._parse_value(depth + 1)
                count += 1
                if count > 0xFFFFFFFF:
                    raise ValueError("object exceeds u32 count")
                self._skip_ws()
                delimiter = self.stream.take()
                if delimiter == ord("}"):
                    break
                if delimiter != ord(","):
                    raise ValueError("expected comma or closing brace in object")
        else:
            self.stream.take()
        end = self.output.tell()
        self.output.seek(count_offset)
        self.output.write(struct.pack("<I", count))
        self.output.seek(end)

    def encode(self) -> dict[str, int]:
        self.output.write(MAGIC)
        self.output.write(struct.pack("<BBI", VERSION, 0, 0))
        self._parse_value(0)
        self._skip_ws()
        while self.stream.peek() == 0:
            self.stream.take()
            self.trailing_nuls += 1
        if self.stream.peek() is not None:
            raise ValueError("non-NUL bytes follow the JSON document")
        end = self.output.tell()
        self.output.seek(6)
        self.output.write(struct.pack("<I", self.trailing_nuls))
        self.output.seek(end)
        return {
            "source_bytes": self.stream.bytes_read,
            "output_bytes": end,
            "values": self.values,
            "max_depth": self.max_depth,
            "max_token_bytes": self.max_token_bytes,
            "max_object_keys": self.max_object_keys,
            "trailing_nuls": self.trailing_nuls,
        }


def stream_encode(source: BinaryIO, output: BinaryIO) -> dict[str, int]:
    return StreamingEncoder(source, output).encode()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    started = time.perf_counter()
    try:
        with args.input.open("rb") as source, args.output.open("w+b") as output:
            metrics = stream_encode(source, output)
    except (OSError, EOFError, UnicodeError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"streaming ZDLF encode failed: {exc}", file=sys.stderr)
        return 1
    elapsed = time.perf_counter() - started
    usage = resource.getrusage(resource.RUSAGE_SELF)
    metrics.update({
        "elapsed_seconds": elapsed,
        "peak_rss_kib": int(usage.ru_maxrss),
        "input_path": args.input.name,
        "output_path": args.output.name,
    })
    print(json.dumps(metrics, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
