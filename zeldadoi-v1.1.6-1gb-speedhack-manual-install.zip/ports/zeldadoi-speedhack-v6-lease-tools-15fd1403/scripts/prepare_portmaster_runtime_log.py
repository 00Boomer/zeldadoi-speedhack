#!/usr/bin/env python3
"""Create one private launcher log beneath the project-owned patch directory.

The PortMaster shell entrypoint calls this before redirecting its own stdout.
It never touches the game directory, saves, or a user-owned log file.  The
returned path names a newly created regular file beneath an ownership-marked
directory; no existing log path is reopened.
"""

from __future__ import annotations

import argparse
import os
import re
import secrets
import stat
import sys
from pathlib import Path


OWNER = "org.zeldadoi.speedhack.portmaster-launcher-log"
DIRECTORY = ".zeldadoi-speedhack-launcher-logs"
OWNER_FILE = "OWNER"
LOG_NAME = re.compile(r"launcher-[0-9]+-[0-9a-f]{32}[.]log\Z")
RUNTIME_EXECUTABLES = ("gmloadernext.aarch64", "tools/splash")


def reject(message: str) -> None:
    raise ValueError(message)


def real_directory(path: Path, label: str) -> Path:
    try:
        metadata = path.lstat()
    except OSError as exc:
        raise ValueError(f"cannot stat {label}: {exc}") from exc
    if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
        reject(f"{label} must be a real directory")
    absolute = Path(os.path.abspath(path))
    if absolute.resolve() != absolute:
        reject(f"{label} must not traverse a symbolic path component")
    return absolute


def owned_log_directory(patch_directory: Path) -> Path:
    root = real_directory(patch_directory, "speedhack runtime directory")
    directory = root / DIRECTORY
    try:
        directory.mkdir(mode=0o700)
    except FileExistsError:
        pass
    try:
        metadata = directory.lstat()
    except OSError as exc:
        raise ValueError(f"cannot stat launcher log directory: {exc}") from exc
    if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
        reject("launcher log directory is unsafe")
    owner = directory / OWNER_FILE
    if owner.exists() or owner.is_symlink():
        metadata = owner.lstat()
        if (
            stat.S_ISLNK(metadata.st_mode)
            or not stat.S_ISREG(metadata.st_mode)
            or metadata.st_nlink != 1
        ):
            reject("launcher log owner is unsafe")
        try:
            value = owner.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            raise ValueError("launcher log owner is unreadable") from exc
        if value != OWNER + "\n":
            reject("launcher log owner mismatch")
    else:
        descriptor = os.open(
            owner,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            handle.write(OWNER + "\n")
            handle.flush()
            os.fsync(handle.fileno())
    return directory


def prepare_runtime_executables(
    patch_directory: Path, game_directory: Path
) -> None:
    """Set execute bits only on the two exact, single-link runtime files."""
    patch = real_directory(patch_directory, "speedhack runtime directory")
    game = real_directory(game_directory, "ZeldaDOI game directory")
    if patch.parent != game.parent:
        reject("speedhack and game directories must share the PortMaster root")
    real_directory(game / "tools", "ZeldaDOI tools directory")
    for relative in RUNTIME_EXECUTABLES:
        executable = game / relative
        try:
            before = executable.lstat()
        except OSError as exc:
            raise ValueError(f"cannot stat runtime executable {relative}: {exc}") from exc
        if (
            stat.S_ISLNK(before.st_mode)
            or not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or executable.resolve() != executable
        ):
            reject(f"runtime executable is unsafe: {relative}")
        os.chmod(
            executable,
            stat.S_IMODE(before.st_mode)
            | stat.S_IXUSR
            | stat.S_IXGRP
            | stat.S_IXOTH,
        )
        after = executable.lstat()
        if (
            not stat.S_ISREG(after.st_mode)
            or after.st_nlink != 1
            or after.st_dev != before.st_dev
            or after.st_ino != before.st_ino
        ):
            reject(f"runtime executable identity changed: {relative}")


def create_log(patch_directory: Path) -> Path:
    directory = owned_log_directory(patch_directory)
    for _ in range(16):
        name = f"launcher-{os.getpid()}-{secrets.token_hex(16)}.log"
        if LOG_NAME.fullmatch(name) is None:
            reject("launcher log name construction failed")
        path = directory / name
        try:
            descriptor = os.open(
                path,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
            )
        except FileExistsError:
            continue
        with os.fdopen(descriptor, "wb", closefd=True) as handle:
            handle.flush()
            os.fsync(handle.fileno())
        metadata = path.lstat()
        if (
            stat.S_ISLNK(metadata.st_mode)
            or not stat.S_ISREG(metadata.st_mode)
            or metadata.st_nlink != 1
        ):
            reject("new launcher log is unsafe")
        return path
    reject("could not allocate a unique launcher log")
    raise AssertionError("unreachable")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--patch-directory", type=Path, required=True)
    parser.add_argument("--game-directory", type=Path, required=True)
    args = parser.parse_args()
    try:
        prepare_runtime_executables(
            args.patch_directory, args.game_directory
        )
        print(create_log(args.patch_directory))
    except (OSError, ValueError) as exc:
        print(f"launcher log preparation failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
