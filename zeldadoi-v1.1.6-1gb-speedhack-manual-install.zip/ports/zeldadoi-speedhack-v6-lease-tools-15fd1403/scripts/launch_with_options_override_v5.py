"""Staged canonical CRT/four-Aspect handoff using the existing transport.

No production package is switched by this module. Both old Filter and new CRT
parent environment values are removed before applying this immutable snapshot.
"""
import hashlib
from pathlib import Path
import sys
from types import FunctionType

import launch_with_options_override_v4 as previous
import launch_with_options_override_v2 as transport
import options_override_crt_v1 as crt

PINS = {
    Path(previous.__file__): 'e7f687326fa99fa15f0ae4a04dc941cd160341d73558c4643fcbd9723aa8868c',
    Path(transport.__file__): 'dfc74f237d1cd6222527a96ff15eaaf8140664a9d693084328d144f61ad4d272',
    Path(crt.__file__): '4b87a461eb5f6c90355408e2d60217aa0150cc4b1fb447c3d8baae0ec7565aff',
}


class _CRTConfigurationRefusal(ValueError):
    pass


def _parse_for_launcher(*args, **kwargs):
    try:
        if any(hashlib.sha256(path.read_bytes()).hexdigest() != pin for path, pin in PINS.items()):
            raise ValueError('CRT launcher predecessor identity changed')
        return crt.parse_override(*args, **kwargs)
    except ValueError as error:
        raise _CRTConfigurationRefusal(str(error)) from error


_namespace = dict(transport._namespace)
_namespace['parse_override'] = _parse_for_launcher
_namespace['CONFIG_ENVIRONMENT_KEYS'] = set(_namespace['CONFIG_ENVIRONMENT_KEYS']) | {
    crt.ENVIRONMENT_KEY, crt.LEGACY_ENVIRONMENT_KEY,
    crt.aspect.ENVIRONMENT_KEY, crt.aspect.PRESENTATION_HASH_KEY,
}
for _name, _value in tuple(_namespace.items()):
    if isinstance(_value, FunctionType) and _value.__globals__ is transport._namespace:
        _invoke = FunctionType(_value.__code__, _namespace, _value.__name__,
                               _value.__defaults__, _value.__closure__)
        _invoke.__kwdefaults__ = _value.__kwdefaults__
        _namespace[_name] = _invoke
for _name, _value in _namespace.items():
    if not _name.startswith('__'):
        globals()[_name] = _value

_inherited_run_game = run_game


def run_game(args):
    try:
        return _inherited_run_game(args)
    except _CRTConfigurationRefusal as error:
        print('ERROR: ' + str(error), file=sys.stderr)
        return 2


_namespace['run_game'] = run_game


if __name__ == '__main__':
    raise SystemExit(main())
