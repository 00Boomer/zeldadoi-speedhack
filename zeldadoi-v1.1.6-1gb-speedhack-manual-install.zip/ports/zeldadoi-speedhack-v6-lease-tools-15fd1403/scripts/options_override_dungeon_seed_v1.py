"""Staged single-Dungeon-Seed successor of the existing Filter parser.

Read one bounded snapshot, retain the existing authority/options/Filter rules,
and explicitly distinguish the two historical seed mappings. ConfigVersion=2
selects the current per-level backend through UseDungeonSeed/DungeonSeed.
Version 1 RunSeed input is a deprecated spelling for that SAME backend; version
1 DungeonSeed input is NOT an alias and refuses. No save, launch or VM mutation
occurs here. Production launcher/carrier composition remains unqualified.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from types import FunctionType, SimpleNamespace

import options_override_filter_v1 as previous

BEHAVIOR_ID = 'dungeon-generated-setup-v1'
BACKEND = 'current_runseed_per_level_generation'
SUPPORTED_CONFIG_VERSIONS = (1, 2)
PINS = {
    Path(previous.__file__): 'efee3e2103b1ca27e4bd71ba5c477aaa1eba7b140befca8bd015902c444134e8',
    Path(previous.previous.__file__): 'a29072b39971356d6af4091050a2a8f9b02b98d16bb57a1773d92530390dc5b6',
    Path(previous.previous.previous.__file__): 'ab1f69c2db340d1f5403c0c9923c930b927300ef027ac526cdae95ef9842ea20',
}
FINISH_FIELDS = (
    'source_status', 'source_sha256', 'enable_override', 'enable_override_error',
    'config_version', 'profile', 'telemetry', 'lighting_mode', 'difficulty',
    'difficulty_error', 'use_dungeon_seed', 'dungeon_seed', 'dungeon_seed_request',
    'dungeon_seed_error', 'use_run_seed', 'run_seed', 'run_seed_request',
    'run_seed_error', 'official_values', 'applied_overrides', 'environment',
    'diagnostics',
)


@dataclass(frozen=True)
class DungeonSeedOverride(previous.FilterOverride):
    public_seed_mode: str | None
    seed_behavior_id: str | None
    deprecated_seed_input: bool

    def as_dict(self):
        value = super().as_dict()
        # Old fields remain an internal launcher ABI, not two public products.
        internal = {key: value.pop(key) for key in (
            'use_dungeon_seed', 'dungeon_seed', 'dungeon_seed_request', 'dungeon_seed_error',
            'use_run_seed', 'run_seed', 'run_seed_request', 'run_seed_error')}
        return dict(value, public_seed_mode=self.public_seed_mode,
            seed_behavior_id=self.seed_behavior_id, deprecated_seed_input=self.deprecated_seed_input,
            selected_backend=BACKEND if self.use_run_seed else None,
            internal_legacy_launcher_handoff=internal,
            production_launcher_wired=False, save_compatibility_qualified=False)


def verify_sources():
    for path, pin in PINS.items():
        if not path.is_file() or path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != pin:
            raise ValueError('Dungeon Seed parser predecessor identity changed')


def _parse_snapshot(path, rules, snapshot):
    """Invocation-local snapshot binding; no global I/O or import patching."""
    aspect = previous.previous
    base = aspect.previous
    base_proxy = SimpleNamespace(**dict(vars(base), read_override=lambda *_: snapshot))
    aspect_proxy = SimpleNamespace(**dict(vars(aspect), previous=base_proxy))
    namespace = dict(vars(previous), previous=aspect_proxy)
    invoke = FunctionType(previous.parse_override.__code__, namespace,
                          argdefs=previous.parse_override.__defaults__)
    return invoke(path, rules)


def _canonical_seed(text, key, base):
    values = base.raw_ini_option_values(text, 'Speedhack', key)
    if len(values) != 1:
        raise ValueError('Dungeon Seed requires exactly one '+key)
    raw = values[0]
    if (not raw.isascii() or not raw.isdecimal() or raw.startswith('0')
            or len(raw) > 10 or not 1 <= int(raw) <= 2147483646):
        raise ValueError('Invalid '+key+': expected canonical decimal 1..2147483646')
    return int(raw)


def parse_override(path, schema=None):
    verify_sources()
    base = previous.previous.previous
    rules = deepcopy(base.load_schema() if schema is None else schema)
    snapshot = base.read_override(path, int(rules['file']['maximum_bytes']))
    text = ''
    if snapshot[0] is not None:
        try:
            text = snapshot[0].decode(rules['file']['encoding'])
        except UnicodeDecodeError:
            pass  # The inherited parser owns malformed encoding policy.
    versions = base.raw_ini_option_values(text, 'Speedhack', 'ConfigVersion')
    if len(versions) == 1 and versions[0].strip() == '2':
        # The old parser compares the selected default exactly; changing an
        # invocation-local schema permits V2 without rewriting any input bytes.
        rules['speedhack']['ConfigVersion'] = dict(rules['speedhack']['ConfigVersion'],
                                                   default=2, accepted_values=[1, 2])
    result = _parse_snapshot(path, rules, snapshot)
    if result.enable_override_error is not None:
        raise ValueError(result.enable_override_error)
    if result.enable_override and result.source_status == 'malformed':
        raise ValueError('Active Dungeon Seed configuration is malformed; overlay refused')
    mode = None if not result.enable_override else 'Random'
    deprecated = False
    if result.enable_override:
        if result.difficulty_error is not None:
            raise ValueError(result.difficulty_error)
        if result.use_dungeon_seed and result.use_run_seed:
            raise ValueError('Only one Dungeon Seed request may be enabled')
        if result.use_dungeon_seed:
            if result.config_version != 2:
                raise ValueError('Legacy ConfigVersion=1 DungeonSeed uses a different mapping; '
                    'preserve the file and explicitly select ConfigVersion=2 for the current Dungeon Seed')
            seed = _canonical_seed(text, 'DungeonSeed', base)
            # Reuse the current per-level backend; never launch old DSeed by
            # mistake. Rebuild the existing configuration digest from these
            # actual internal fields, preserving presentation and all options.
            fields = {key: getattr(result, key) for key in FINISH_FIELDS}
            fields.update(use_dungeon_seed=False, dungeon_seed=None, dungeon_seed_request='disabled',
                dungeon_seed_error=None, use_run_seed=True, run_seed=seed,
                run_seed_request='configured', run_seed_error=None)
            rebuilt = base.finish_result(**fields)
            result = previous.FilterOverride(**dict(result.__dict__, **rebuilt.__dict__))
            mode = 'Dungeon Seed'
        elif result.use_run_seed:
            if result.config_version != 1:
                raise ValueError('ConfigVersion=2 uses UseDungeonSeed/DungeonSeed; RunSeed is a legacy input only')
            _canonical_seed(text, 'RunSeed', base)
            if result.run_seed_request != 'configured' or result.run_seed_error is not None:
                raise ValueError(result.run_seed_error or 'Invalid legacy RunSeed request')
            mode = 'Dungeon Seed'
            deprecated = True
    return DungeonSeedOverride(**result.__dict__, public_seed_mode=mode,
        seed_behavior_id=BEHAVIOR_ID if mode == 'Dungeon Seed' else None,
        deprecated_seed_input=deprecated)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file', type=Path)
    args = parser.parse_args()
    try:
        value = parse_override(args.file)
    except (OSError, ValueError) as error:
        parser.exit(1, str(error)+'\n')
    print(json.dumps(value.as_dict(), indent=2, sort_keys=True))
