#!/usr/bin/env python3
"""Compose exact runtime-pair generation, activation, and read-only verification.

This host-verified component starts from an already preserved exact official
archive.  It routes an unfinished activation directly back into the activator
instead of attempting to regenerate a stage after the default archive has
already moved.  First-install preservation and prior-pair migration are
deliberately outside this component.
"""

from __future__ import annotations

import argparse
import json
import os
import stat
import sys
import zipfile
from pathlib import Path
from typing import Any, NoReturn

import bounded_runtime_pair_activation as activation
import bounded_runtime_pair_restore as pair_restore
import bounded_runtime_pair_stage as pair_stage
import bounded_runtime_pair_verify as pair_verify
import install_options_override_default as override_default
import runtime_pair_capacity as capacity_model
from bounded_installer_orchestrator import initialize_owned_state_directory
from bounded_runtime_lock import (
    OWNER,
    RuntimeLockLease,
    fsync_directory,
    runtime_lock,
)
from runtime_authority import DEFAULT_SCHEMA, load_authority, load_schema


PHASES = (
    "stage-prepared",
    "pair-activated",
    "pair-verified",
    "default-override-installed",
    "install-committed",
)
FIRST_INSTALL_PHASES = (
    "first-install-capacity-validated",
    "first-install-state-initialized",
    "preserve-validated",
    "preserve-candidate-created",
    "source-preserved",
)
PRESERVE_RECORD = "runtime-pair-preserve.json"
PRESERVE_RECORD_NEXT = "runtime-pair-preserve.next"
PRESERVE_PHASES = ("validated", "candidate-created", "source-preserved")
PRESERVE_KEYS = {
    "schema_version",
    "owner",
    "release_id",
    "authority_sha256",
    "official_archive_size",
    "official_archive_sha256",
    "candidate_basename",
    "cache_contract_sha256",
    "capacity_schema_sha256",
    "required_free_logical_bytes",
    "required_free_capacity_bytes",
    "required_free_inodes",
    "allocation_unit_bytes",
    "logical_floor_only",
    "regular_file_allocation_unit_ceiling_calculated",
    "phase",
}


class RuntimePairInstallError(ValueError):
    """The composed pair install cannot safely select one recovery route."""


def reject(message: str) -> NoReturn:
    raise RuntimePairInstallError(message)


def checkpoint(name: str, fail_after: str | None) -> None:
    if fail_after == name:
        raise RuntimeError(f"injected runtime-pair install interruption after {name}")


def state_present(state: Path, names: tuple[str, ...]) -> bool:
    return any((state / name).exists() or (state / name).is_symlink() for name in names)


def install_current_document(
    authority: dict[str, Any],
    authority_sha256: str,
    template_sha256: str,
    disposition: str,
) -> dict[str, Any]:
    return pair_verify.validate_install_current(
        {
            "schema_version": 1,
            "owner": OWNER,
            "release_id": authority["release_id"],
            "authority_sha256": authority_sha256,
            "default_override_template_sha256": template_sha256,
            "default_override_disposition": disposition,
            "phase": "complete",
        }
    )


def commit_complete_install(
    state: Path,
    authority: dict[str, Any],
    authority_sha256: str,
    template_sha256: str,
    disposition: str,
) -> dict[str, Any]:
    """Publish the pair only after its override disposition is durable."""
    expected = install_current_document(
        authority,
        authority_sha256,
        template_sha256,
        disposition,
    )
    target = state / pair_verify.INSTALL_CURRENT
    pending = state / pair_verify.INSTALL_CURRENT_NEXT

    if target.exists() or target.is_symlink():
        if pending.exists() or pending.is_symlink():
            reject("complete and pending runtime-pair install markers coexist")
        current = pair_verify.validate_install_current(
            activation.read_json(target, "runtime-pair complete-install marker")
        )
        for key in (
            "release_id",
            "authority_sha256",
            "default_override_template_sha256",
        ):
            if current[key] != expected[key]:
                reject("runtime-pair complete-install marker identity mismatch")
        return {"status": "complete_install_already_committed", "record": current}

    if pending.exists() or pending.is_symlink():
        recovered = pair_verify.validate_install_current(
            activation.read_json(pending, "pending runtime-pair complete-install marker")
        )
        for key in (
            "release_id",
            "authority_sha256",
            "default_override_template_sha256",
        ):
            if recovered[key] != expected[key]:
                reject("pending runtime-pair complete-install marker mismatch")
        fsync_recovered_install_current(pending, activation.canonical_bytes(expected))
        os.replace(pending, target)
        fsync_directory(state)
        return {"status": "complete_install_commit_recovered", "record": recovered}

    activation.write_atomic(
        state,
        pair_verify.INSTALL_CURRENT,
        pair_verify.INSTALL_CURRENT_NEXT,
        activation.canonical_bytes(expected),
    )
    return {"status": "complete_install_committed", "record": expected}


def fsync_recovered_install_current(pending: Path, expected: bytes) -> None:
    """Verify and durably flush an exact pending publication marker."""
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(pending, flags)
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size != len(expected)
        ):
            reject("pending runtime-pair complete-install marker is unsafe")
        chunks: list[bytes] = []
        remaining = before.st_size
        while remaining:
            chunk = os.read(descriptor, remaining)
            if not chunk:
                reject("pending runtime-pair complete-install marker changed during read")
            chunks.append(chunk)
            remaining -= len(chunk)
        if b"".join(chunks) != expected:
            reject("pending runtime-pair complete-install marker bytes mismatch")
        os.fsync(descriptor)
        after = os.fstat(descriptor)
        if (
            after.st_dev != before.st_dev
            or after.st_ino != before.st_ino
            or after.st_mode != before.st_mode
            or after.st_nlink != 1
            or after.st_size != len(expected)
        ):
            reject("pending runtime-pair complete-install marker identity changed")
    finally:
        os.close(descriptor)
    current = pending.lstat()
    if (
        pending.is_symlink()
        or current.st_dev != after.st_dev
        or current.st_ino != after.st_ino
        or current.st_mode != after.st_mode
        or current.st_nlink != 1
        or current.st_size != len(expected)
    ):
        reject("pending runtime-pair complete-install namespace changed")


def preserve_candidate_basename(release_id: str) -> str:
    return f".zeldadoi.official-v1.1.6.port.runtime-pair-preserve-{release_id}"


def validate_preserve_record(document: dict[str, Any]) -> dict[str, Any]:
    if set(document) != PRESERVE_KEYS:
        reject("runtime-pair preservation record key coverage mismatch")
    if document["schema_version"] != 2 or document["owner"] != OWNER:
        reject("runtime-pair preservation record schema or owner mismatch")
    if document["phase"] not in PRESERVE_PHASES:
        reject("runtime-pair preservation record phase mismatch")
    if document["candidate_basename"] != preserve_candidate_basename(
        document["release_id"]
    ):
        reject("runtime-pair preservation candidate basename mismatch")
    for key in (
        "authority_sha256",
        "official_archive_sha256",
        "cache_contract_sha256",
        "capacity_schema_sha256",
    ):
        if type(document[key]) is not str or activation.HEX64.fullmatch(
            document[key]
        ) is None:
            reject(f"runtime-pair preservation digest is invalid: {key}")
    for key in (
        "official_archive_size",
        "required_free_logical_bytes",
        "required_free_capacity_bytes",
        "required_free_inodes",
        "allocation_unit_bytes",
    ):
        if type(document[key]) is not int or document[key] <= 0:
            reject(f"runtime-pair preservation integer is invalid: {key}")
    if (
        document["logical_floor_only"] is not False
        or document["regular_file_allocation_unit_ceiling_calculated"] is not True
    ):
        reject("runtime-pair preservation capacity kind mismatch")
    return dict(document)


def preservation_record(
    authority: dict[str, Any],
    authority_sha256: str,
    capacity: dict[str, Any],
) -> dict[str, Any]:
    official = authority["official_source"]["archive"]
    floor = capacity["floors"]["first_install_from_unpreserved_official"]
    return validate_preserve_record({
        "schema_version": 2,
        "owner": OWNER,
        "release_id": authority["release_id"],
        "authority_sha256": authority_sha256,
        "official_archive_size": official["size"],
        "official_archive_sha256": official["sha256"],
        "candidate_basename": preserve_candidate_basename(authority["release_id"]),
        "cache_contract_sha256": capacity["inputs"]["cache_contract_sha256"],
        "capacity_schema_sha256": capacity["inputs"]["capacity_schema_sha256"],
        "required_free_logical_bytes": floor["required_free_logical_bytes"],
        "required_free_capacity_bytes": floor["required_free_capacity_bytes"],
        "required_free_inodes": floor["required_free_inodes"],
        "allocation_unit_bytes": capacity["inputs"]["allocation_unit_bytes"],
        "logical_floor_only": capacity["claims"]["logical_byte_floor_only"],
        "regular_file_allocation_unit_ceiling_calculated": capacity["claims"][
            "regular_file_allocation_unit_ceiling_calculated"
        ],
        "phase": "validated",
    })


def static_preserve_equal(left: dict[str, Any], right: dict[str, Any]) -> bool:
    return all(left[key] == right[key] for key in PRESERVE_KEYS - {"phase"})


def write_preserve_record(state: Path, document: dict[str, Any]) -> None:
    activation.write_atomic(
        state,
        PRESERVE_RECORD,
        PRESERVE_RECORD_NEXT,
        activation.canonical_bytes(validate_preserve_record(document)),
    )


def reconcile_preserve_pending(
    state: Path, expected: dict[str, Any]
) -> dict[str, Any] | None:
    target = state / PRESERVE_RECORD
    pending = state / PRESERVE_RECORD_NEXT
    if not pending.exists() and not pending.is_symlink():
        return None
    observed = validate_preserve_record(
        activation.read_json(pending, "pending runtime-pair preservation record")
    )
    if not static_preserve_equal(observed, expected):
        reject("pending runtime-pair preservation authority mismatch")
    if target.exists() or target.is_symlink():
        current = validate_preserve_record(
            activation.read_json(target, "runtime-pair preservation record")
        )
        if not static_preserve_equal(current, observed):
            reject("pending runtime-pair preservation release mismatch")
        current_index = PRESERVE_PHASES.index(current["phase"])
        if (
            current_index + 1 >= len(PRESERVE_PHASES)
            or observed["phase"] != PRESERVE_PHASES[current_index + 1]
        ):
            reject("pending runtime-pair preservation is not the exact next phase")
    elif observed["phase"] != "validated":
        reject("orphan pending runtime-pair preservation is not initial")
    os.replace(pending, target)
    fsync_directory(state)
    return observed


def advance_preserve_record(
    state: Path, record: dict[str, Any], phase: str
) -> dict[str, Any]:
    current = PRESERVE_PHASES.index(record["phase"])
    if current + 1 >= len(PRESERVE_PHASES) or PRESERVE_PHASES[current + 1] != phase:
        reject("runtime-pair preservation phase advance is not monotonic")
    updated = dict(record)
    updated["phase"] = phase
    write_preserve_record(state, updated)
    return updated


def enforce_floor(
    root: Path,
    floor: dict[str, int],
    label: str,
    expected_allocation_unit_bytes: int,
) -> dict[str, int]:
    stats = os.statvfs(root)
    if stats.f_frsize != expected_allocation_unit_bytes:
        reject(f"filesystem allocation unit changed before {label}")
    available_bytes = stats.f_bavail * stats.f_frsize
    available_inodes = stats.f_favail
    required_capacity = floor.get("required_free_capacity_bytes")
    if type(required_capacity) is not int or required_capacity <= 0:
        reject(f"allocation-unit capacity floor is absent for {label}")
    required_capacity = capacity_model.enforce_filesystem_capacity(
        root, stats, required_capacity, floor["required_free_inodes"], label, reject,
    )
    return {
        "available_logical_bytes": available_bytes,
        "available_inodes": available_inodes,
        "required_free_capacity_bytes": required_capacity,
        "allocation_unit_bytes": stats.f_frsize,
    }


def remove_owned_partial_candidate(candidate: Path, maximum_size: int) -> None:
    metadata = candidate.lstat()
    if (
        stat.S_ISLNK(metadata.st_mode)
        or not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
        or metadata.st_size > maximum_size
    ):
        reject("interrupted preservation candidate is unsafe or foreign")
    identity = (metadata.st_dev, metadata.st_ino)
    observed = candidate.lstat()
    if (observed.st_dev, observed.st_ino) != identity:
        reject("interrupted preservation candidate identity changed")
    candidate.unlink()
    fsync_directory(candidate.parent)


def preserve_official(
    root: Path,
    state: Path,
    authority: dict[str, Any],
    authority_sha256: str,
    capacity: dict[str, Any],
    fail_after: str | None,
) -> dict[str, Any]:
    expected = preservation_record(authority, authority_sha256, capacity)
    official = authority["official_source"]["archive"]
    active = root / authority["runtimes"]["default"]["archive_path"]
    preserved = root / official["path"]
    candidate = root / expected["candidate_basename"]
    reconcile_preserve_pending(state, expected)
    record_path = state / PRESERVE_RECORD

    if not record_path.exists() and not record_path.is_symlink():
        if preserved.exists() or preserved.is_symlink():
            activation.verify_file(
                preserved, official["size"], official["sha256"], "preserved official"
            )
            if candidate.exists() or candidate.is_symlink():
                reject("unowned preservation candidate collides with exact source")
            return {"status": "official_source_already_preserved", "recovered": False}
        if candidate.exists() or candidate.is_symlink():
            reject("unowned preservation candidate exists before transaction")
        activation.verify_file(
            active, official["size"], official["sha256"], "active official source"
        )
        write_preserve_record(state, expected)
        checkpoint("preserve-validated", fail_after)
        record = expected
        recovered = False
    else:
        record = validate_preserve_record(
            activation.read_json(record_path, "runtime-pair preservation record")
        )
        if not static_preserve_equal(record, expected):
            reject("runtime-pair preservation record authority mismatch")
        recovered = True

    phase_index = PRESERVE_PHASES.index(record["phase"])
    if phase_index < PRESERVE_PHASES.index("candidate-created"):
        activation.verify_file(
            active, official["size"], official["sha256"], "active official source"
        )
        if candidate.exists() or candidate.is_symlink():
            try:
                activation.verify_file(
                    candidate,
                    official["size"],
                    official["sha256"],
                    "preservation candidate",
                )
            except ValueError:
                remove_owned_partial_candidate(candidate, official["size"])
        if not candidate.exists() and not candidate.is_symlink():
            pair_stage.copy_exact(
                active,
                candidate,
                official["size"],
                official["sha256"],
                "official preservation candidate",
            )
            fsync_directory(root)
        record = advance_preserve_record(state, record, "candidate-created")
        phase_index = PRESERVE_PHASES.index(record["phase"])
        checkpoint("preserve-candidate-created", fail_after)

    if phase_index < PRESERVE_PHASES.index("source-preserved"):
        activation.verify_file(
            active, official["size"], official["sha256"], "active official source"
        )
        candidate_exists = candidate.exists() or candidate.is_symlink()
        preserved_exists = preserved.exists() or preserved.is_symlink()
        if candidate_exists and not preserved_exists:
            activation.verify_file(
                candidate,
                official["size"],
                official["sha256"],
                "preservation candidate",
            )
            activation.atomic_activate_no_replace(candidate, preserved)
            fsync_directory(root)
        elif not candidate_exists and preserved_exists:
            activation.verify_file(
                preserved,
                official["size"],
                official["sha256"],
                "preserved official source",
            )
        else:
            reject("official preservation rename boundary is inconsistent")
        record = advance_preserve_record(state, record, "source-preserved")
        checkpoint("source-preserved", fail_after)

    activation.verify_file(
        preserved, official["size"], official["sha256"], "preserved official source"
    )
    if candidate.exists() or candidate.is_symlink():
        reject("preservation candidate remains after source commitment")
    observed = validate_preserve_record(
        activation.read_json(record_path, "committed preservation record")
    )
    if observed != record or observed["phase"] != "source-preserved":
        reject("committed preservation record changed before cleanup")
    record_path.unlink()
    fsync_directory(state)
    return {"status": "official_source_preserved", "recovered": recovered}


def install_pair(
    game_root: Path,
    authority_path: Path,
    expected_authority_sha256: str,
    default_patch: Path,
    expected_default_patch_sha256: str,
    seeded_patch: Path,
    expected_seeded_patch_sha256: str,
    seeded_config: Path,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    generation_timestamp: str,
    *,
    default_override_template_path: Path,
    expected_default_override_template_sha256: str,
    authority_schema_path: Path = DEFAULT_SCHEMA,
    capacity_schema_path: Path = capacity_model.DEFAULT_CAPACITY_SCHEMA,
    tool_root: Path | None = None,
    fail_after: str | None = None,
    lock_lease: RuntimeLockLease | None = None,
) -> dict[str, Any]:
    if fail_after is not None and fail_after not in PHASES + FIRST_INSTALL_PHASES:
        reject("unknown runtime-pair install interruption checkpoint")

    root = activation.exact_root(game_root, "game root")
    authority = load_authority(
        authority_path,
        authority_schema_path,
        expected_sha256=expected_authority_sha256,
    )
    schema = load_schema(authority_schema_path)
    filesystem = os.statvfs(root)
    capacity = capacity_model.calculate(
        authority_path,
        expected_authority_sha256,
        cache_contract_path,
        expected_cache_contract_sha256,
        authority_schema_path=authority_schema_path,
        capacity_schema_path=capacity_schema_path,
        allocation_unit_bytes=filesystem.f_frsize,
    )
    official = schema["official_source"]["archive"]
    default = authority["runtimes"]["default"]
    activation.verify_file(
        root / default["runtime_config_path"],
        default["runtime_config_size"],
        default["runtime_config_sha256"],
        "installed default runtime config",
    )
    state = root / ".zeldadoi-speedhack"
    preserved = root / official["path"]
    state_exists = state.exists() or state.is_symlink()
    if not state_exists:
        if preserved.exists() or preserved.is_symlink():
            reject("preserved official source exists without owned installer state")
        activation.verify_file(
            root / default["archive_path"],
            official["size"],
            official["sha256"],
            "active official source",
        )
        enforce_floor(
            root,
            capacity["floors"]["first_install_from_unpreserved_official"],
            "first runtime-pair install",
            capacity["inputs"]["allocation_unit_bytes"],
        )
        checkpoint("first-install-capacity-validated", fail_after)
        state, _ = initialize_owned_state_directory(root)
        checkpoint("first-install-state-initialized", fail_after)
    else:
        activation.require_state_owner(state)

    if lock_lease is None:
        with runtime_lock(state) as operation_lease:
            return install_pair(
                root,
                authority_path,
                expected_authority_sha256,
                default_patch,
                expected_default_patch_sha256,
                seeded_patch,
                expected_seeded_patch_sha256,
                seeded_config,
                cache_contract_path,
                expected_cache_contract_sha256,
                generation_timestamp,
                default_override_template_path=default_override_template_path,
                expected_default_override_template_sha256=(
                    expected_default_override_template_sha256
                ),
                authority_schema_path=authority_schema_path,
                capacity_schema_path=capacity_schema_path,
                tool_root=tool_root,
                fail_after=fail_after,
                lock_lease=operation_lease,
            )

    preservation_names = (PRESERVE_RECORD, PRESERVE_RECORD_NEXT)
    preservation_active = state_present(state, preservation_names)
    if preservation_active or not (preserved.exists() or preserved.is_symlink()):
        if not preservation_active:
            activation.verify_file(
                root / default["archive_path"],
                official["size"],
                official["sha256"],
                "active official source",
            )
            enforce_floor(
                root,
                capacity["floors"]["first_install_from_unpreserved_official"],
                "first runtime-pair install",
                capacity["inputs"]["allocation_unit_bytes"],
            )
            checkpoint("first-install-capacity-validated", fail_after)
        with runtime_lock(state, lock_lease):
            preservation_result = preserve_official(
                root,
                state,
                authority,
                expected_authority_sha256,
                capacity,
                fail_after,
            )
    else:
        activation.verify_file(
            preserved,
            official["size"],
            official["sha256"],
            "preserved official source",
        )
        preservation_result = {
            "status": "official_source_already_preserved",
            "recovered": False,
        }

    stage = state / (activation.STAGE_PREFIX + authority["release_id"])

    restore_names = (
        pair_restore.RESTORE_JOURNAL,
        pair_restore.RESTORE_JOURNAL_NEXT,
    )
    if state_present(state, restore_names):
        reject("runtime-pair install cannot overlap an unfinished pair restore")

    activation_names = (
        activation.PAIR_JOURNAL,
        activation.PAIR_JOURNAL_NEXT,
        activation.PAIR_CURRENT,
        activation.PAIR_CURRENT_NEXT,
    )
    resumed_activation = state_present(state, activation_names)
    stage_result: dict[str, Any] | None = None
    if not resumed_activation:
        stage_result = pair_stage.prepare_stage(
            root,
            authority_path,
            expected_authority_sha256,
            default_patch,
            expected_default_patch_sha256,
            seeded_patch,
            expected_seeded_patch_sha256,
            seeded_config,
            cache_contract_path,
            expected_cache_contract_sha256,
            generation_timestamp,
            authority_schema_path=authority_schema_path,
            capacity_schema_path=capacity_schema_path,
            tool_root=tool_root,
            lock_lease=lock_lease,
        )
        checkpoint("stage-prepared", fail_after)

    activation_result = activation.activate_pair(
        root,
        stage,
        expected_authority_sha256,
        cache_contract_path=cache_contract_path,
        expected_cache_contract_sha256=expected_cache_contract_sha256,
        schema_path=authority_schema_path,
        capacity_schema_path=capacity_schema_path,
        lock_lease=lock_lease,
    )
    checkpoint("pair-activated", fail_after)
    verification = pair_verify.verify_installed_pair(
        root,
        expected_authority_sha256,
        schema_path=authority_schema_path,
        lock_lease=lock_lease,
        allow_pending_install_commit=True,
    )
    checkpoint("pair-verified", fail_after)
    override_result = override_default.install_default(
        root,
        default_override_template_path,
        expected_default_override_template_sha256,
        lock_lease=lock_lease,
    )
    checkpoint("default-override-installed", fail_after)
    disposition = (
        "created_in_game_authority_default_override"
        if override_result["created"]
        else "preserved_existing_user_override"
    )
    install_commit = commit_complete_install(
        state,
        authority,
        expected_authority_sha256,
        expected_default_override_template_sha256,
        disposition,
    )
    checkpoint("install-committed", fail_after)
    final_verification = pair_verify.verify_installed_pair(
        root,
        expected_authority_sha256,
        schema_path=authority_schema_path,
        lock_lease=lock_lease,
        require_complete_install=True,
        expected_default_override_template_sha256=(
            expected_default_override_template_sha256
        ),
    )
    return {
        "schema_version": 1,
        "status": "runtime_pair_install_composed_host_contract",
        "release_id": authority["release_id"],
        "authority_sha256": expected_authority_sha256,
        "preservation_status": preservation_result["status"],
        "preservation_recovered": preservation_result["recovered"],
        "stage_status": None if stage_result is None else stage_result["status"],
        "activation_status": activation_result["status"],
        "verification_status": verification["status"],
        "default_override_status": override_result["status"],
        "default_override_created": override_result["created"],
        "existing_user_override_preserved": override_result["preserved_existing"],
        "complete_install_status": install_commit["status"],
        "complete_install_disposition": install_commit["record"][
            "default_override_disposition"
        ],
        "complete_install_verified": final_verification[
            "complete_install_verified"
        ],
        "resumed_activation": resumed_activation,
        "generation_and_activation_use_shared_lock_contract": True,
        "continuous_lock_across_generation_and_activation": True,
        "first_install_preservation_integrated": True,
        "restore_first_migration_integrated": False,
        "user_files_touched": False,
        "physical_target_executed": False,
        "production_approved": False,
        "safe_profile_approved": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-root", type=Path, required=True)
    parser.add_argument("--authority", type=Path, required=True)
    parser.add_argument("--authority-sha256", required=True)
    parser.add_argument("--default-patch", type=Path, required=True)
    parser.add_argument("--default-patch-sha256", required=True)
    parser.add_argument("--seeded-patch", type=Path, required=True)
    parser.add_argument("--seeded-patch-sha256", required=True)
    parser.add_argument("--seeded-config", type=Path, required=True)
    parser.add_argument("--cache-contract", type=Path, required=True)
    parser.add_argument("--cache-contract-sha256", required=True)
    parser.add_argument("--generation-timestamp", required=True)
    parser.add_argument("--default-override-template", type=Path, required=True)
    parser.add_argument("--default-override-template-sha256", required=True)
    parser.add_argument("--authority-schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument(
        "--capacity-schema",
        type=Path,
        default=capacity_model.DEFAULT_CAPACITY_SCHEMA,
    )
    parser.add_argument("--tool-root", type=Path)
    arguments = parser.parse_args()
    try:
        result = install_pair(
            arguments.game_root,
            arguments.authority,
            arguments.authority_sha256,
            arguments.default_patch,
            arguments.default_patch_sha256,
            arguments.seeded_patch,
            arguments.seeded_patch_sha256,
            arguments.seeded_config,
            arguments.cache_contract,
            arguments.cache_contract_sha256,
            arguments.generation_timestamp,
            default_override_template_path=arguments.default_override_template,
            expected_default_override_template_sha256=(
                arguments.default_override_template_sha256
            ),
            authority_schema_path=arguments.authority_schema,
            capacity_schema_path=arguments.capacity_schema,
            tool_root=arguments.tool_root,
        )
    except (
        OSError,
        RuntimeError,
        ValueError,
        TypeError,
        KeyError,
        json.JSONDecodeError,
        zipfile.BadZipFile,
    ) as exc:
        print(json.dumps({"status": "invalid", "error": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
