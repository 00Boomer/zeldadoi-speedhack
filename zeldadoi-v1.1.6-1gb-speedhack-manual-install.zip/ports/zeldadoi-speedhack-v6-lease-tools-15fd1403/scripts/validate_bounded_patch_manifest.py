#!/usr/bin/env python3
"""Validate a release-pinned archive-contained bounded installer manifest."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path, PurePosixPath
from typing import Any


OFFICIAL_PORT_SIZE = 104829399
OFFICIAL_PORT_SHA256 = (
    "df37214a5b1dd7e91050a4df686103ade56b53c935792ada0f96766c4413cade"
)
OFFICIAL_DROID_MEMBER = "assets/game.droid"
OFFICIAL_DROID_SIZE = 5048816
OFFICIAL_DROID_SHA256 = (
    "d1c7f76420650d27d1abd6003657e81841efe5c28d35f012166a3ec4b981c047"
)
OFFICIAL_DATA_MEMBERS = {
    "assets/data/data_d": {
        "size": 4056482,
        "sha256": "dc90eaec81f8c88ef7fa27f2e7f48fac17706773fee28291a4570ef2e04cab91",
        "coordinate_depth": 2,
        "prefix": "assets/data/zdlf_d_",
    },
    "assets/data/data_r": {
        "size": 46944719,
        "sha256": "7aa240abbad5f44f235a2c15ddaf91fc2035b9c1725bf3db030b863778a8394e",
        "coordinate_depth": 3,
        "prefix": "assets/data/zdlf_r_",
    },
}
OWNER_ID = "zeldadoi-speedhack-generated-cache-v1"
PATH_CONTRACT = {
    "root": "assets/data",
    "dungeon_prefix": "assets/data/zdlf_d_",
    "room_prefix": "assets/data/zdlf_r_",
}
HEX64 = re.compile(r"[0-9a-f]{64}")
UINT = re.compile(r"0|[1-9][0-9]{0,17}")
TOKEN = re.compile(r"[A-Za-z0-9._-]+")

ARTIFACT_FIELDS = {
    "DROID_PATCH": None,
    "CACHE_CONTRACT": "generated-cache-contract.json",
    "COMMON": "_common.py",
    "LOSSLESS_FORMAT": "lossless_data_format.py",
    "STREAM_ENCODER": "stream_encode_zdlf.py",
    "PARTITIONER": "stream_partition_zdlf.py",
    "CONVERTER": "convert_official_cache_bounded.py",
    "ASSEMBLER": "assemble_bounded_cache_port.py",
    "JOURNAL": "bounded_installer_journal.py",
    "STAGE": "bounded_installer_stage.py",
    "RUNTIME_LOCK": "bounded_runtime_lock.py",
    "MANIFEST_VALIDATOR": "validate_bounded_patch_manifest.py",
    "ORCHESTRATOR": "bounded_installer_orchestrator.py",
    "VERIFIER": "bounded_installer_verify.py",
    "RESTORER": "bounded_installer_restore.py",
}

# Schema 2 remains backward compatible with the original single-runtime
# package.  A dual-runtime package is selected only when this complete,
# independently hash-bound extension is present.  Partial extensions are
# rejected instead of falling back to the legacy installer.
PAIR_ARTIFACT_FIELDS = {
    "RUNTIME_AUTHORITY": "runtime-authority.json",
    "SEEDED_DROID_PATCH": "seeded-game-droid.vcdiff",
    "SEEDED_RUNTIME_CONFIG": "gmloader-seeded.json",
    "RUNTIME_AUTHORITY_SCHEMA": "runtime-authority-schema.json",
    "RUNTIME_PAIR_CAPACITY_SCHEMA": "runtime-pair-capacity-schema.json",
    "RUNTIME_AUTHORITY_MODULE": "runtime_authority.py",
    "RUNTIME_AUTHORITY_BUILDER": "build_runtime_authority.py",
    "RUNTIME_PAIR_CAPACITY": "runtime_pair_capacity.py",
    "RUNTIME_PAIR_STAGE": "bounded_runtime_pair_stage.py",
    "RUNTIME_PAIR_ACTIVATOR": "bounded_runtime_pair_activation.py",
    "RUNTIME_PAIR_VERIFIER": "bounded_runtime_pair_verify.py",
    "RUNTIME_PAIR_RESTORER": "bounded_runtime_pair_restore.py",
    "RUNTIME_PAIR_INSTALLER": "bounded_runtime_pair_install.py",
    "OPTIONS_OVERRIDE_DEFAULT_INSTALLER": "install_options_override_default.py",
}
PAIR_METADATA_FIELDS = {
    "RUNTIME_MODE",
    "RUNTIME_RELEASE_ID",
}
PAIR_FIELDS = PAIR_METADATA_FIELDS | {
    f"{prefix}_{suffix}"
    for prefix in PAIR_ARTIFACT_FIELDS
    for suffix in ("FILE", "SIZE", "SHA256")
}

# A migration-capable dual-runtime release additionally binds one exact prior
# pair.  The install entrypoint may then use the restore-first migrator for all
# states (official first install, prior-pair upgrade, or exact new-pair
# re-entry).  As with the pair extension, any partial migration authority is a
# hard error rather than an invitation to fall back to a non-migrating install.
MIGRATION_ARTIFACT_FIELDS = {
    "PRIOR_RUNTIME_AUTHORITY": "prior-runtime-authority.json",
    "PRIOR_CACHE_CONTRACT": "prior-generated-cache-contract.json",
    "RUNTIME_PAIR_MIGRATOR": "bounded_runtime_pair_migrate.py",
}
MIGRATION_METADATA_FIELDS = {
    "RUNTIME_MIGRATION_MODE",
    "PRIOR_RUNTIME_RELEASE_ID",
}
MIGRATION_FIELDS = MIGRATION_METADATA_FIELDS | {
    f"{prefix}_{suffix}"
    for prefix in MIGRATION_ARTIFACT_FIELDS
    for suffix in ("FILE", "SIZE", "SHA256")
}

REQUIRED_FIELDS = {
    "SCHEMA_VERSION",
    "PATCH_ID",
    "PROFILE",
    "SOURCE_NAME",
    "SOURCE_SIZE",
    "SOURCE_SHA256",
    "SOURCE_GAME_DROID_MEMBER",
    "SOURCE_GAME_DROID_SIZE",
    "SOURCE_GAME_DROID_SHA256",
    "PATCHED_GAME_DROID_SIZE",
    "PATCHED_GAME_DROID_SHA256",
    "CACHE_GENERATED_FILES",
    "CACHE_GENERATED_BYTES",
    "CACHE_GENERATED_CONTENT_SET_SHA256",
    "CACHE_OWNER_ID",
    "CACHE_LAYOUT",
    "CACHE_STAGE_PERSISTENT",
    "OUTPUT_ARTIFACT_COUNT",
    "OUTPUT_SIZE",
    "OUTPUT_SHA256",
    "PYTHON_MIN_VERSION",
    "RENAMEAT2_NOREPLACE_REQUIRED",
    "DISK_MARGIN_BYTES",
    "REINSTALL_REQUIRED_FREE_BYTES",
    "FIRST_INSTALL_REQUIRED_FREE_BYTES",
    "REQUIRED_FREE_INODES",
} | {
    f"{prefix}_{suffix}"
    for prefix in ARTIFACT_FIELDS
    for suffix in ("FILE", "SIZE", "SHA256")
}


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def parse_manifest(path: Path) -> dict[str, str]:
    if path.is_symlink() or not path.is_file():
        raise ValueError("bounded patch manifest must be a regular non-symlink file")
    fields: dict[str, str] = {}
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw or raw.startswith("#"):
            continue
        if "=" not in raw:
            raise ValueError(f"malformed manifest line {line_number}")
        key, value = raw.split("=", 1)
        if not key or not value:
            raise ValueError(f"empty manifest field on line {line_number}")
        if re.fullmatch(r"[A-Z0-9_]+", key) is None:
            raise ValueError(f"invalid manifest key: {key!r}")
        if any(character.isspace() for character in value):
            raise ValueError(f"manifest value contains whitespace: {key}")
        if key in fields:
            raise ValueError(f"duplicate manifest field: {key}")
        fields[key] = value
    missing = sorted(REQUIRED_FIELDS - fields.keys())
    unknown = sorted(
        fields.keys() - (REQUIRED_FIELDS | PAIR_FIELDS | MIGRATION_FIELDS)
    )
    if missing or unknown:
        raise ValueError(
            f"manifest field coverage mismatch: missing={missing} unknown={unknown}"
        )
    observed_pair_fields = fields.keys() & PAIR_FIELDS
    if observed_pair_fields and observed_pair_fields != PAIR_FIELDS:
        pair_missing = sorted(PAIR_FIELDS - fields.keys())
        raise ValueError(
            "dual-runtime manifest field coverage mismatch: "
            f"missing={pair_missing}"
        )
    observed_migration_fields = fields.keys() & MIGRATION_FIELDS
    if observed_migration_fields and observed_migration_fields != MIGRATION_FIELDS:
        migration_missing = sorted(MIGRATION_FIELDS - fields.keys())
        raise ValueError(
            "runtime-pair migration field coverage mismatch: "
            f"missing={migration_missing}"
        )
    if observed_migration_fields and observed_pair_fields != PAIR_FIELDS:
        raise ValueError("runtime-pair migration requires the complete dual extension")
    return fields


def load_runtime_authority_module(path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(
        "_zeldadoi_schema2_runtime_authority", path
    )
    if spec is None or spec.loader is None:
        raise ValueError("cannot load packaged runtime-authority validator")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_runtime_pair_capacity_module(path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(
        "_zeldadoi_schema2_runtime_pair_capacity", path
    )
    if spec is None or spec.loader is None:
        raise ValueError("cannot load packaged runtime-pair capacity validator")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_pair_capacity_schema(path: Path) -> None:
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("runtime-pair capacity schema is not valid UTF-8 JSON") from exc
    expected_keys = {
        "schema_version",
        "status",
        "maximum_cache_contract_bytes",
        "activation_metadata_bytes",
        "activation_metadata_inodes",
        "restore_metadata_bytes",
        "restore_metadata_inodes",
        "generation_margin_bytes",
        "generation_metadata_inodes",
        "policy",
    }
    expected_policy = {
        "logical_bytes_not_allocated_blocks",
        "both_runtime_archives_retained_before_activation",
        "both_patched_game_droids_budgeted",
        "one_shared_generated_cache_budgeted",
        "staged_official_mirror_budgeted",
        "staged_default_config_mirror_budgeted",
        "maximum_runtime_authority_size_reserved",
        "first_install_preserved_official_copy_budgeted",
        "migration_restores_prior_pair_before_new_generation",
        "old_and_new_pairs_may_not_overlap",
        "physical_measurement_may_raise_floors",
    }
    if (
        not isinstance(document, dict)
        or set(document) != expected_keys
        or document.get("schema_version") != 1
        or document.get("status") != "provisional_host_logical_capacity_policy"
        or not isinstance(document.get("policy"), dict)
        or set(document["policy"]) != expected_policy
        or any(document["policy"].get(key) is not True for key in expected_policy)
    ):
        raise ValueError("runtime-pair capacity schema contract mismatch")
    for key in expected_keys - {"schema_version", "status", "policy"}:
        if type(document.get(key)) is not int or document[key] <= 0:
            raise ValueError("runtime-pair capacity schema numeric policy is invalid")


def validate_runtime_pair_extension(
    fields: dict[str, str], artifact_paths: dict[str, Path]
) -> dict[str, Any] | None:
    if not (fields.keys() & PAIR_FIELDS):
        return None
    if fields["RUNTIME_MODE"] != "dual":
        raise ValueError("dual-runtime schema-2 extension requires RUNTIME_MODE=dual")
    release_id = fields["RUNTIME_RELEASE_ID"]
    if TOKEN.fullmatch(release_id) is None:
        raise ValueError("invalid runtime-pair release ID")

    pair_paths: dict[str, Path] = {}
    seen = {path.name for path in artifact_paths.values()}
    for prefix, expected_name in PAIR_ARTIFACT_FIELDS.items():
        filename = fields[f"{prefix}_FILE"]
        if filename in seen:
            raise ValueError(f"artifact filename is reused: {filename}")
        seen.add(filename)
        path = safe_artifact(artifact_paths["DROID_PATCH"].parent, filename, expected_name)
        if (
            uint(fields, f"{prefix}_SIZE") <= 0
            or path.stat().st_size != uint(fields, f"{prefix}_SIZE")
            or sha256_file(path) != sha(fields, f"{prefix}_SHA256")
        ):
            raise ValueError(f"runtime-pair artifact identity mismatch: {filename}")
        pair_paths[prefix] = path

    validate_pair_capacity_schema(pair_paths["RUNTIME_PAIR_CAPACITY_SCHEMA"])
    authority_module = load_runtime_authority_module(
        pair_paths["RUNTIME_AUTHORITY_MODULE"]
    )
    schema = authority_module.load_schema(pair_paths["RUNTIME_AUTHORITY_SCHEMA"])
    authority = authority_module.load_authority(
        pair_paths["RUNTIME_AUTHORITY"],
        pair_paths["RUNTIME_AUTHORITY_SCHEMA"],
        expected_sha256=fields["RUNTIME_AUTHORITY_SHA256"],
    )
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    official = authority["official_source"]
    if (
        authority["release_id"] != release_id
        or official["archive"]["size"] != uint(fields, "SOURCE_SIZE")
        or official["archive"]["sha256"] != fields["SOURCE_SHA256"]
        or official["game_droid"]["size"] != uint(fields, "SOURCE_GAME_DROID_SIZE")
        or official["game_droid"]["sha256"] != fields["SOURCE_GAME_DROID_SHA256"]
        or default["game_droid"]["size"] != uint(fields, "PATCHED_GAME_DROID_SIZE")
        or default["game_droid"]["sha256"] != fields["PATCHED_GAME_DROID_SHA256"]
        or default["archive_size"] != uint(fields, "OUTPUT_SIZE")
        or default["archive_sha256"] != fields["OUTPUT_SHA256"]
        or seeded["archive_sha256"] == default["archive_sha256"]
        or seeded["game_droid"]["sha256"] == default["game_droid"]["sha256"]
        or seeded["runtime_config_size"]
        != uint(fields, "SEEDED_RUNTIME_CONFIG_SIZE")
        or seeded["runtime_config_sha256"]
        != fields["SEEDED_RUNTIME_CONFIG_SHA256"]
        or schema["official_source"]["archive"]["sha256"]
        != fields["SOURCE_SHA256"]
    ):
        raise ValueError("runtime authority diverges from schema-2 release authority")
    return {
        "release_id": release_id,
        "authority_sha256": fields["RUNTIME_AUTHORITY_SHA256"],
        "authority": authority,
        "pair_paths": pair_paths,
        "seeded_archive_size": seeded["archive_size"],
        "seeded_archive_sha256": seeded["archive_sha256"],
        "pair_artifact_count": len(pair_paths),
    }


def validate_runtime_migration_extension(
    fields: dict[str, str],
    artifact_paths: dict[str, Path],
    pair: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if not (fields.keys() & MIGRATION_FIELDS):
        return None
    if pair is None:
        raise ValueError("runtime-pair migration requires a dual runtime authority")
    if fields["RUNTIME_MIGRATION_MODE"] != "restore-first":
        raise ValueError(
            "runtime-pair migration extension requires "
            "RUNTIME_MIGRATION_MODE=restore-first"
        )
    prior_release_id = fields["PRIOR_RUNTIME_RELEASE_ID"]
    if TOKEN.fullmatch(prior_release_id) is None:
        raise ValueError("invalid prior runtime-pair release ID")

    pair_paths = pair["pair_paths"]
    migration_paths: dict[str, Path] = {}
    seen = {
        *(path.name for path in artifact_paths.values()),
        *(path.name for path in pair_paths.values()),
    }
    for prefix, expected_name in MIGRATION_ARTIFACT_FIELDS.items():
        filename = fields[f"{prefix}_FILE"]
        if filename in seen:
            raise ValueError(f"artifact filename is reused: {filename}")
        seen.add(filename)
        path = safe_artifact(
            artifact_paths["DROID_PATCH"].parent, filename, expected_name
        )
        if (
            uint(fields, f"{prefix}_SIZE") <= 0
            or path.stat().st_size != uint(fields, f"{prefix}_SIZE")
            or sha256_file(path) != sha(fields, f"{prefix}_SHA256")
        ):
            raise ValueError(f"runtime-pair migration artifact identity mismatch: {filename}")
        migration_paths[prefix] = path

    authority_module = load_runtime_authority_module(
        pair_paths["RUNTIME_AUTHORITY_MODULE"]
    )
    prior_authority = authority_module.load_authority(
        migration_paths["PRIOR_RUNTIME_AUTHORITY"],
        pair_paths["RUNTIME_AUTHORITY_SCHEMA"],
        expected_sha256=fields["PRIOR_RUNTIME_AUTHORITY_SHA256"],
    )
    if (
        prior_authority["release_id"] != prior_release_id
        or prior_release_id == pair["release_id"]
        or prior_authority["official_source"] != pair["authority"]["official_source"]
    ):
        raise ValueError("prior runtime authority diverges from migration authority")

    try:
        prior_cache = json.loads(
            migration_paths["PRIOR_CACHE_CONTRACT"].read_text(encoding="utf-8")
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("prior generated-cache contract is not valid UTF-8 JSON") from exc
    capacity_module = load_runtime_pair_capacity_module(
        pair_paths["RUNTIME_PAIR_CAPACITY"]
    )
    try:
        capacity_module.validate_cache_contract(prior_cache, prior_authority)
    except (ValueError, TypeError, KeyError) as exc:
        raise ValueError(
            "prior generated-cache contract diverges from prior runtime authority"
        ) from exc
    return {
        "mode": "restore-first",
        "prior_release_id": prior_release_id,
        "prior_authority_sha256": fields["PRIOR_RUNTIME_AUTHORITY_SHA256"],
        "prior_cache_contract_sha256": fields["PRIOR_CACHE_CONTRACT_SHA256"],
        "migration_artifact_count": len(migration_paths),
    }


def uint(fields: dict[str, str], key: str) -> int:
    value = fields[key]
    if UINT.fullmatch(value) is None:
        raise ValueError(f"manifest field must be a canonical unsigned integer: {key}")
    return int(value)


def sha(fields: dict[str, str], key: str) -> str:
    value = fields[key]
    if HEX64.fullmatch(value) is None:
        raise ValueError(f"manifest field must be a lowercase SHA-256: {key}")
    return value


def safe_artifact(root: Path, relative: str, expected_name: str | None) -> Path:
    pure = PurePosixPath(relative)
    if (
        pure.is_absolute()
        or len(pure.parts) != 1
        or ".." in pure.parts
        or TOKEN.fullmatch(relative) is None
        or relative.startswith(".")
        or (expected_name is not None and relative != expected_name)
    ):
        raise ValueError(f"unsafe or unexpected artifact filename: {relative!r}")
    path = root / relative
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"artifact must be a regular non-symlink file: {relative}")
    return path


def validate_cache_contract(
    contract: dict[str, Any], fields: dict[str, str]
) -> None:
    source = contract.get("source", {}).get("official_port", {})
    source_members = contract.get("source", {}).get("members", {})
    generator = contract.get("generator", {})
    ownership = contract.get("ownership", {})
    generated_files = contract.get("generated_files")
    if (
        contract.get("schema_version") != 2
        or contract.get("status") != "deterministic_generated_cache_contract_verified"
        or contract.get("profile") != "safe"
        or source.get("size") != uint(fields, "SOURCE_SIZE")
        or source.get("sha256") != fields["SOURCE_SHA256"]
        or set(source_members) != set(OFFICIAL_DATA_MEMBERS)
        or any(
            source_members[name].get("size") != expected["size"]
            or source_members[name].get("sha256") != expected["sha256"]
            for name, expected in OFFICIAL_DATA_MEMBERS.items()
        )
        or contract.get("generated_file_count")
        != uint(fields, "CACHE_GENERATED_FILES")
        or contract.get("generated_total_bytes")
        != uint(fields, "CACHE_GENERATED_BYTES")
        or contract.get("generated_content_set_sha256")
        != fields["CACHE_GENERATED_CONTENT_SET_SHA256"]
        or ownership.get("owner_id") != fields["CACHE_OWNER_ID"]
        or ownership.get("path_contract") != PATH_CONTRACT
        or ownership.get("generated_files_only") is not True
        or ownership.get("remove_only_when_path_and_sha256_match") is not True
        or ownership.get("remove_unknown_or_modified_owned_path") is not False
        or ownership.get("touch_user_save_paths") is not False
        or ownership.get("recursive_cleanup") is not False
        or generator.get("path") != "scripts/stream_partition_zdlf.py"
        or generator.get("sha256") != fields["PARTITIONER_SHA256"]
        or generator.get("version") != 1
        or generator.get("one_pass") is not True
        or generator.get("full_json_tree_materialized") is not False
        or contract.get("format") != {
            "name": "ZDLF",
            "version": 1,
            "layout": "standalone lossless template documents",
            "byte_order": "little-endian",
        }
        or not isinstance(generated_files, list)
    ):
        raise ValueError("generated-cache contract is not bound to the release manifest")

    if (
        len(generated_files) != uint(fields, "CACHE_GENERATED_FILES")
        or sum(
            item.get("size", -1) if isinstance(item, dict) else -1
            for item in generated_files
        )
        != uint(fields, "CACHE_GENERATED_BYTES")
        or canonical_sha256(generated_files)
        != fields["CACHE_GENERATED_CONTENT_SET_SHA256"]
    ):
        raise ValueError("generated-cache contract file set does not reconcile")

    seen_paths: set[str] = set()
    for item in generated_files:
        if not isinstance(item, dict):
            raise ValueError("generated-cache file record must be an object")
        member = item.get("source_member")
        member_contract = OFFICIAL_DATA_MEMBERS.get(member)
        coordinates = item.get("source_coordinates")
        if (
            member_contract is None
            or not isinstance(coordinates, list)
            or len(coordinates) != member_contract["coordinate_depth"]
            or any(type(index) is not int or index < 0 for index in coordinates)
        ):
            raise ValueError("generated-cache source coordinates are invalid")
        relative = item.get("relative_path")
        wanted = member_contract["prefix"] + "_".join(map(str, coordinates))
        if (
            relative != wanted
            or relative in seen_paths
            or type(item.get("size")) is not int
            or item["size"] <= 0
            or HEX64.fullmatch(item.get("sha256", "")) is None
            or item.get("owner_id") != OWNER_ID
        ):
            raise ValueError("generated-cache file record is invalid")
        seen_paths.add(relative)


def validate(
    manifest_path: Path,
    artifacts_directory: Path,
    expected_manifest_sha256: str,
) -> dict[str, Any]:
    if HEX64.fullmatch(expected_manifest_sha256) is None:
        raise ValueError("expected manifest SHA-256 must be a lowercase SHA-256")
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError("bounded patch manifest must be a regular non-symlink file")
    actual_manifest_sha256 = sha256_file(manifest_path)
    if actual_manifest_sha256 != expected_manifest_sha256:
        raise ValueError("bounded patch manifest does not match independent release authority")
    if artifacts_directory.is_symlink() or not artifacts_directory.is_dir():
        raise ValueError("artifacts directory must be a real directory")

    fields = parse_manifest(manifest_path)
    if fields["SCHEMA_VERSION"] != "2":
        raise ValueError("unsupported bounded patch manifest schema")
    if TOKEN.fullmatch(fields["PATCH_ID"]) is None:
        raise ValueError("invalid patch ID")
    if fields["PROFILE"] != "safe":
        raise ValueError("bounded installer accepts only the safe profile")
    if (
        fields["SOURCE_NAME"] != "zeldadoi.port"
        or uint(fields, "SOURCE_SIZE") != OFFICIAL_PORT_SIZE
        or sha(fields, "SOURCE_SHA256") != OFFICIAL_PORT_SHA256
        or fields["SOURCE_GAME_DROID_MEMBER"] != OFFICIAL_DROID_MEMBER
        or uint(fields, "SOURCE_GAME_DROID_SIZE") != OFFICIAL_DROID_SIZE
        or sha(fields, "SOURCE_GAME_DROID_SHA256") != OFFICIAL_DROID_SHA256
    ):
        raise ValueError("manifest does not target the exact supported official source")

    artifact_paths: dict[str, Path] = {}
    seen_names: set[str] = set()
    for prefix, expected_name in ARTIFACT_FIELDS.items():
        filename = fields[f"{prefix}_FILE"]
        if filename in seen_names:
            raise ValueError(f"artifact filename is reused: {filename}")
        seen_names.add(filename)
        path = safe_artifact(artifacts_directory, filename, expected_name)
        if (
            uint(fields, f"{prefix}_SIZE") <= 0
            or path.stat().st_size != uint(fields, f"{prefix}_SIZE")
            or sha256_file(path) != sha(fields, f"{prefix}_SHA256")
        ):
            raise ValueError(f"artifact identity mismatch: {filename}")
        artifact_paths[prefix] = path

    try:
        contract = json.loads(
            artifact_paths["CACHE_CONTRACT"].read_text(encoding="utf-8")
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("generated-cache contract is not valid UTF-8 JSON") from exc
    if not isinstance(contract, dict):
        raise ValueError("generated-cache contract root must be an object")
    validate_cache_contract(contract, fields)
    pair = validate_runtime_pair_extension(fields, artifact_paths)
    migration = validate_runtime_migration_extension(fields, artifact_paths, pair)

    numeric_positive = (
        "PATCHED_GAME_DROID_SIZE",
        "CACHE_GENERATED_FILES",
        "CACHE_GENERATED_BYTES",
        "OUTPUT_SIZE",
        "DISK_MARGIN_BYTES",
        "REINSTALL_REQUIRED_FREE_BYTES",
        "FIRST_INSTALL_REQUIRED_FREE_BYTES",
        "REQUIRED_FREE_INODES",
    )
    if any(uint(fields, key) <= 0 for key in numeric_positive):
        raise ValueError("bounded manifest counts and sizes must be positive")
    for key in (
        "PATCHED_GAME_DROID_SHA256",
        "CACHE_GENERATED_CONTENT_SET_SHA256",
        "OUTPUT_SHA256",
    ):
        sha(fields, key)
    if fields["CACHE_OWNER_ID"] != OWNER_ID:
        raise ValueError("unexpected generated-cache owner")
    if (
        fields["CACHE_LAYOUT"] != "archive-contained"
        or fields["CACHE_STAGE_PERSISTENT"] != "0"
        or fields["OUTPUT_ARTIFACT_COUNT"] != "1"
        or fields["PYTHON_MIN_VERSION"] != "3.10"
        or fields["RENAMEAT2_NOREPLACE_REQUIRED"] != "1"
    ):
        raise ValueError("unsupported bounded pipeline or activation policy")

    work_bytes = (
        uint(fields, "CACHE_GENERATED_BYTES")
        + uint(fields, "PATCHED_GAME_DROID_SIZE")
        + uint(fields, "OUTPUT_SIZE")
        + uint(fields, "DISK_MARGIN_BYTES")
    )
    reinstall = uint(fields, "REINSTALL_REQUIRED_FREE_BYTES")
    first_install = uint(fields, "FIRST_INSTALL_REQUIRED_FREE_BYTES")
    if reinstall < work_bytes:
        raise ValueError("reinstall free-byte budget does not cover bounded pipeline peak")
    if first_install < reinstall + OFFICIAL_PORT_SIZE:
        raise ValueError("first-install budget does not cover preserved official source")
    if uint(fields, "REQUIRED_FREE_INODES") < uint(fields, "CACHE_GENERATED_FILES") + 16:
        raise ValueError("free-inode budget does not cover generated cache and stages")

    result = {
        "status": "bounded_patch_manifest_schema2_verified",
        "schema_version": 2,
        "manifest_sha256": actual_manifest_sha256,
        "patch_id": fields["PATCH_ID"],
        "profile": fields["PROFILE"],
        "artifact_count": len(artifact_paths),
        "generated_file_count": uint(fields, "CACHE_GENERATED_FILES"),
        "generated_total_bytes": uint(fields, "CACHE_GENERATED_BYTES"),
        "output_size": uint(fields, "OUTPUT_SIZE"),
        "reinstall_required_free_bytes": reinstall,
        "first_install_required_free_bytes": first_install,
        "required_free_inodes": uint(fields, "REQUIRED_FREE_INODES"),
        "source_archive_materialized": False,
        "archive_contained_cache": True,
        "single_activation_artifact": True,
        "runtime_mode": "single" if pair is None else "dual",
        "runtime_migration_mode": "none" if migration is None else migration["mode"],
        "production_manifest": False,
    }
    if pair is not None:
        result.update({
            "runtime_pair_release_id": pair["release_id"],
            "runtime_authority_sha256": pair["authority_sha256"],
            "seeded_archive_size": pair["seeded_archive_size"],
            "seeded_archive_sha256": pair["seeded_archive_sha256"],
            "pair_artifact_count": pair["pair_artifact_count"],
            "single_activation_artifact": False,
            "dual_runtime_pair_authorized": True,
        })
    if migration is not None:
        result.update({
            "prior_runtime_pair_release_id": migration["prior_release_id"],
            "prior_runtime_authority_sha256": migration[
                "prior_authority_sha256"
            ],
            "prior_cache_contract_sha256": migration[
                "prior_cache_contract_sha256"
            ],
            "migration_artifact_count": migration["migration_artifact_count"],
            "restore_first_migration_authorized": True,
        })
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--artifacts-dir", type=Path, required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    args = parser.parse_args()
    try:
        result = validate(
            args.manifest, args.artifacts_dir, args.expected_manifest_sha256
        )
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(f"bounded patch manifest validation failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
