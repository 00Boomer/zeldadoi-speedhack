"""Current Aspect parser + existing V2 profile-identity launch transport.

Private diagnostic composition seam for the current Aspect-capable runtime;
not release/package approval. Old launchers and their receipts stay immutable.
No new Rendering key, configuration authority, save writer or seed digest.
"""
from types import FunctionType
import sys
import launch_with_options_override_v2 as previous
import options_override_aspect_v2 as aspect


class _AspectConfigurationRefusal(ValueError):
    pass


def _parse_for_launcher(*args,**kwargs):
    try:return aspect.parse_override(*args,**kwargs)
    except ValueError as error:raise _AspectConfigurationRefusal(str(error)) from error


_namespace=dict(previous._namespace)
_namespace['parse_override']=_parse_for_launcher
# The predecessor strips known managed fields before applying the single-read
# configuration. Extend that invocation-local set so stale parent Aspect values
# cannot survive a missing/inactive override. Never mutate the original set.
_namespace['CONFIG_ENVIRONMENT_KEYS']=set(_namespace['CONFIG_ENVIRONMENT_KEYS'])|{
    aspect.ENVIRONMENT_KEY,aspect.PRESENTATION_HASH_KEY}
for _name,_value in tuple(_namespace.items()):
    if isinstance(_value,FunctionType) and _value.__globals__ is previous._namespace:
        _invoke=FunctionType(_value.__code__,_namespace,_value.__name__,
                             _value.__defaults__,_value.__closure__)
        _invoke.__kwdefaults__=_value.__kwdefaults__
        _namespace[_name]=_invoke
for _name,_value in _namespace.items():
    if not _name.startswith('__'):globals()[_name]=_value


_inherited_run_game=run_game


def run_game(args):
    try:return _inherited_run_game(args)
    except _AspectConfigurationRefusal as error:
        print('ERROR: '+str(error),file=sys.stderr)
        return 2


_namespace['run_game']=run_game


if __name__=='__main__':raise SystemExit(main())
