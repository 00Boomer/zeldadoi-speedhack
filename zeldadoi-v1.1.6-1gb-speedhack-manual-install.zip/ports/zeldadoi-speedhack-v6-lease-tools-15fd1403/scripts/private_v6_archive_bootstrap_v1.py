"""Inactive fixed-candidate bootstrap over the existing shared transactions.

Only the stage producer differs: reconstruct exact 956a from the qualified
full-archive delta, rather than run the game.droid/cache converter. No original
installation is a permitted root. No CLI or public release builder selects it.
"""
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
from types import FunctionType, SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'device/tools')]
import owned_v6_native_component_v1 as component
import runtime_pair_shared_adapter_v2 as transactions
import install_options_override_default_crt_v1 as defaults
from bounded_installer_orchestrator import initialize_owned_state_directory
from bounded_runtime_lock import runtime_lock, verify_runtime_lock_lease
from zeldadoi_temporary_workspace_v1 import make_workspace

ROOT_NAME = 'zeldadoi-owned-v6-949a386b2afb'
RELEASE_ID = 'owned-v6-949a-qualification-v1'
STAGE_PREFIX = 'zeldadoi.private-v6-archive-stage.'
BASE_SHA = '533d4bc8745d35f6a2b3b35a26a3aa49572bd55e29db4c0647311d82b1b129cf'
ENROLLMENT_SHA = 'fc96a3da110cc3c0dada79e1303210dae93a319121aae0e021ee0d86c30d2b02'
CACHE_SHA = 'bd1a040b745d82a5970b663bbd5c82fa7549e357fbbe6148c25a33c17fd3a5f9'
PATCH = dict(path='game.xdelta', bytes=2627476,
             sha256='e53d6572ef97947cc17e992973632c8c3cd49d9869a2d37b4728bd2a2bc9ee99')
DECODER = dict(path='xdelta3-aarch64', bytes=269056,
               sha256='74a6cb55ed600b2315d37c8273d7aae4041915bddfad47a6a834387f50283148')
# Original game-library prerequisites copied from the supported owner source,
# not distributed by this bootstrap and never removed by native rollback.
GAME_LIBRARIES = [
    dict(path='lib/arm64-v8a/libc++_shared.so', bytes=7812664,
         sha256='c0e171711d7efd3ebacdf4939ad120d8ec9b3bc6ef4f6a722d330bb112d244d8'),
    dict(path='lib/arm64-v8a/libcompiler_rt.so', bytes=112128,
         sha256='d9a4cc6e5e835e618a2ca6111ec4d4a4ce2176a7af229ea8c57fb1d431c52ed1'),
    dict(path='lib/arm64-v8a/libm.so', bytes=229352,
         sha256='4c74a629dd3393decc2491b2adccf702061b5cbd6ecc05282929db05555b90cb'),
    dict(path='lib/arm64-v8a/libopenal.so', bytes=17296872,
         sha256='a2cc486fd9d2194c2a3519e1459e66a707c34ba94f68fb9a7a6ff9a66070ffc8'),
]
PINS = {
    'scripts/owned_v6_native_component_v1.py': 'f5e8fb4ccf5a39b2f69013a684669cd28a1aa6581e9a4f0cd1a27f8807da535b',
    'scripts/runtime_pair_shared_adapter_v2.py': '4bbd1d7fb5f41d59a509e313cb85b44373da5ccbecb3e42967f08224291e9c18',
    'scripts/install_options_override_default_crt_v1.py': '4236dbfe59ad2a21a8f39274729ff69c9a8097dd67a9b90a782929fcbd7deb6c',
    'scripts/bounded_installer_orchestrator.py': '8eb711aca96afe3535066f22e88450d33f8af29b0e953ead26d19f90b5720b08',
    'scripts/bounded_runtime_pair_install.py': '832e1e2001349fae6c77c40381b4372011219f92e32415732ceade248e7854d5',
    'scripts/bounded_runtime_pair_stage.py': 'ec439d56860003f8a0c3777cc64e3fc8de336ae2ee9adee1da49716d2d30ae8c',
    'scripts/bounded_runtime_pair_activation.py': '9acba0f4942ef8333f6b189e47529f2dad03d7d420eba2e00cafb76f06497ff3',
    'scripts/bounded_runtime_pair_restore.py': '301d924d146fd92ddadc306bf597020569c1bb95ed0c751d8eae621440eab02e',
    'scripts/runtime_pair_capacity.py': '68b8f9d2b1223582c99ed5a4c4d228ec0d5620b2fb5fa9d6297444f4c851785a',
    'config/runtime-pair-capacity-schema.json': '119151d01e04b2edab009df9cbc49400f0f4fba5a919336204fc276a732a3b50',
    'config/owned-v6-qualification-runtime-authority-v1.json': '533d4bc8745d35f6a2b3b35a26a3aa49572bd55e29db4c0647311d82b1b129cf',
    'config/owned-v6-qualification-native-enrollment-v1.json': 'fc96a3da110cc3c0dada79e1303210dae93a319121aae0e021ee0d86c30d2b02',
}


def configuration(role):
    apk = {'default': 'zeldadoi.port', 'seeded': 'zeldadoi.seeded.port'}[role]
    return (json.dumps(dict(apk_path=apk, save_dir='saves', force_platform='os_android'),
                       sort_keys=True) + '\n').encode()


def _sources():
    for name, digest in PINS.items():
        component.native.checked_file(ROOT / name, maximum=2 * 1024**2, digest=digest)
    component._sources()


def _root(path):
    root = component.ordinary.safe(Path(path).absolute(), directory=True)
    component.native.require(root.name == ROOT_NAME and root.parent.name == 'ports',
                             'only the explicitly named private qualification root is supported')
    return root


def _context(artifacts):
    _sources()
    artifacts, enrollment, _, selected, _ = component._context(artifacts, ENROLLMENT_SHA)
    component.native.require(enrollment['shared_authority_sha256'] == BASE_SHA,
                             'private bootstrap authority identity differs')
    base = component.native.shared.load_authority(artifacts / 'runtime-authority.json', expected_sha256=BASE_SHA)
    component.native.require(base['release_id'] == RELEASE_ID, 'private release identity differs')
    for role, row in base['runtimes'].items():
        raw = configuration(role)
        component.native.require(row['runtime_config_size'] == len(raw) and
            row['runtime_config_sha256'] == hashlib.sha256(raw).hexdigest(), 'private config differs')
    return SimpleNamespace(artifacts=artifacts, enrollment=enrollment, selected=selected, base=base)


def _install_inputs(root, context):
    rows = [PATCH, DECODER, dict(context.selected['native'], path='gmloadernext.aarch64'),
            *context.selected['source_companions']]
    for row in rows:
        component.ordinary.checked(context.artifacts / row['path'], row['bytes'], row['sha256'])
    component.ordinary.check_elf(context.artifacts / DECODER['path'])
    component.native.checked_file(context.artifacts / 'generated-cache-contract.json',
                                  maximum=16 * 1024**2, digest=CACHE_SHA)
    component.native.checked_file(context.artifacts / 'options_override.default.ini',
                                  maximum=65536, digest=component.DEFAULT_OVERRIDE_TEMPLATE_SHA256)
    for row in context.selected['library_files']:
        component.ordinary.checked(root / 'libs.aarch64' / row['path'], row['bytes'], row['sha256'])
    for row in GAME_LIBRARIES:
        component.ordinary.checked(root / row['path'], row['bytes'], row['sha256'])
    seeded = configuration('seeded')
    component.ordinary.checked(context.artifacts / 'gmloader-seeded.json', len(seeded), hashlib.sha256(seeded).hexdigest())


@contextmanager
def _decoder(context):
    # Same sealed, authenticated executable-FD boundary as the accepted beta.
    path = context.artifacts / DECODER['path']
    component.ordinary.checked(path, DECODER['bytes'], DECODER['sha256'])
    with path.open('rb') as source: raw = source.read(DECODER['bytes'] + 1)
    component.native.require(len(raw) == DECODER['bytes'] and
                             hashlib.sha256(raw).hexdigest() == DECODER['sha256'], 'decoder snapshot differs')
    descriptor = os.memfd_create('owned-v6-xdelta', os.MFD_ALLOW_SEALING)
    try:
        with os.fdopen(os.dup(descriptor), 'wb') as out: out.write(raw); out.flush()
        os.fchmod(descriptor, 0o500)
        fcntl.fcntl(descriptor, fcntl.F_ADD_SEALS, fcntl.F_SEAL_SEAL | fcntl.F_SEAL_SHRINK |
                    fcntl.F_SEAL_GROW | fcntl.F_SEAL_WRITE)
        yield descriptor
    finally:
        os.close(descriptor)


def _decode(context, official, output):
    row = context.selected['base_payload']
    def limits():
        resource.setrlimit(resource.RLIMIT_FSIZE, (row['bytes'],) * 2)
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    with _decoder(context) as descriptor, output.open('xb') as out:
        result = subprocess.run(['/proc/self/fd/' + str(descriptor), '-d', '-c', '-D', '-R', '-s',
            str(official), str(context.artifacts / PATCH['path'])], stdout=out,
            stderr=subprocess.DEVNULL, timeout=600, pass_fds=(descriptor,), preexec_fn=limits,
            env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'TMPDIR': str(output.parent)})
        out.flush(); os.fsync(out.fileno())
    component.native.require(result.returncode == 0, 'archive decoder raw exit ' + str(result.returncode))
    component.ordinary.checked(output, row['bytes'], row['sha256'])
    return result.returncode


def _expected(context):
    base = context.base
    official = base['official_source']['archive']
    expected = {official['path']: (official['size'], official['sha256']),
                '.zeldadoi-speedhack/runtime-authority.json': (
                    (context.artifacts / 'runtime-authority.json').stat().st_size, BASE_SHA)}
    for role, row in base['runtimes'].items():
        expected[row['archive_path']] = (row['archive_size'], row['archive_sha256'])
        expected[row['runtime_config_path']] = (row['runtime_config_size'], row['runtime_config_sha256'])
    return expected


def _ready(stage, context, graph):
    try:
        component.ordinary.safe(stage, directory=True)
        expected = _expected(context)
        graph.activation.stage_inventory(stage, set(expected))
        for name, (size, digest) in expected.items(): component.ordinary.checked(stage / name, size, digest)
    except (OSError, ValueError) as error:
        raise ValueError('private archive stage incomplete or changed; preserved for inspection: ' + str(error)) from error


def _prepare(root, context, graph, lease):
    state = root / '.zeldadoi-speedhack'
    verify_runtime_lock_lease(state, lease)
    official = context.base['official_source']['archive']
    for name in (official['path'], context.base['runtimes']['default']['archive_path']):
        component.ordinary.checked(root / name, official['size'], official['sha256'])
    default = configuration('default')
    component.ordinary.checked(root / 'gmloader.json', len(default), hashlib.sha256(default).hexdigest())
    target = state / (graph.activation.STAGE_PREFIX + RELEASE_ID)
    stages = [p for p in state.iterdir() if p.name.startswith(STAGE_PREFIX)]
    component.native.require(len(stages) <= 1, 'multiple private archive stages; preserve for inspection')
    if os.path.lexists(target):
        component.native.require(not stages, 'archive handoff and temporary stage coexist')
        _ready(target, context, graph)
        return dict(status='private_v6_archive_stage_already_ready', stage=str(target), decoder_executed=False)
    if stages:
        stage = stages[0]
        before = stage.stat()
        _ready(stage, context, graph)  # Never repair or delete incomplete stages.
        after = stage.stat()
        component.native.require((before.st_dev, before.st_ino, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_ctime_ns), 'archive stage changed')
        decoded = None
    else:
        stage = make_workspace('private-v6-archive-stage', parent=state,
                               required_bytes=sum(size for size, _ in _expected(context).values()) + 65536)
        component.ordinary.fsync_dir(state)
        component._copy(root / official['path'], stage / official['path'], official['size'], official['sha256'])
        decoded = _decode(context, root / official['path'], stage / 'zeldadoi.port')
        row = context.selected['base_payload']
        component._copy(stage / 'zeldadoi.port', stage / 'zeldadoi.seeded.port', row['bytes'], row['sha256'])
        for role, record in context.base['runtimes'].items():
            target_config = stage / record['runtime_config_path']
            target_config.parent.mkdir(exist_ok=True)
            with target_config.open('xb') as out:
                out.write(configuration(role)); out.flush(); os.fsync(out.fileno())
        source = context.artifacts / 'runtime-authority.json'
        component._copy(source, stage / '.zeldadoi-speedhack/runtime-authority.json', source.stat().st_size, BASE_SHA)
        _ready(stage, context, graph)
    _install_inputs(root, context)
    verify_runtime_lock_lease(state, lease)
    component.ordinary.fsync_dir(stage / '.zeldadoi-speedhack')
    component.ordinary.fsync_dir(stage)
    component.ordinary.publish_new(stage, target)
    component.ordinary.fsync_dir(state)
    _ready(target, context, graph)
    return dict(status='private_v6_archive_stage_ready', stage=str(target),
                decoder_executed=decoded is not None, decoder_raw_exit=decoded)


def _graph(context):
    graph = transactions.bindings()
    def prepare_stage(root, authority, digest, default_patch, default_sha, seeded_patch, seeded_sha,
                      seeded_config, cache, cache_sha, timestamp, **kwargs):
        component.native.require(Path(authority) == context.artifacts / 'runtime-authority.json' and digest == BASE_SHA and
            Path(default_patch) == Path(seeded_patch) == context.artifacts / PATCH['path'] and
            default_sha == seeded_sha == PATCH['sha256'] and
            Path(cache) == context.artifacts / 'generated-cache-contract.json' and cache_sha == CACHE_SHA and
            Path(seeded_config) == context.artifacts / 'gmloader-seeded.json' and
            kwargs.get('authority_schema_path') == component.native.shared.DEFAULT_SCHEMA and
            kwargs.get('capacity_schema_path') == graph.capacity.DEFAULT_CAPACITY_SCHEMA and
            graph.stage.UTC_TIMESTAMP.fullmatch(timestamp) is not None,
            'private full-archive producer call differs')
        return _prepare(root, context, graph, kwargs['lock_lease'])
    old = graph.install.install_pair.__globals__
    # Source preservation also uses copy_exact from this dependency. Retain
    # every original stage helper; replace only the archive-producing entry.
    stage = SimpleNamespace(**dict(vars(graph.stage), prepare_stage=prepare_stage))
    scope = dict(old, pair_stage=stage, override_default=defaults)
    for name, fn in tuple(scope.items()):
        if isinstance(fn, FunctionType) and fn.__globals__ is old:
            copy = FunctionType(fn.__code__, scope, fn.__name__, fn.__defaults__, fn.__closure__)
            copy.__kwdefaults__ = fn.__kwdefaults__; scope[name] = copy
    return graph, scope['install_pair']


def install(game_root, artifacts, generation_timestamp):
    root, context = _root(game_root), _context(artifacts)
    _install_inputs(root, context)
    default = configuration('default')
    component.ordinary.checked(root / 'gmloader.json', len(default), hashlib.sha256(default).hexdigest())
    graph, install_pair = _graph(context)
    fs = os.statvfs(root)
    free = fs.f_bavail * fs.f_frsize
    component.native.require(free >= 1024**3, 'private installation requires the 1GiB filesystem reserve')
    if not os.path.lexists(root / '.zeldadoi-speedhack'):
        official = context.base['official_source']['archive']
        component.ordinary.checked(root / 'zeldadoi.port', official['size'], official['sha256'])
        component.native.require(not os.path.lexists(root / official['path']),
                                 'preserved source exists without owned state')
        # Retain the original first-install capacity check before state creation.
        model = graph.capacity.calculate(context.artifacts / 'runtime-authority.json', BASE_SHA,
            context.artifacts / 'generated-cache-contract.json', CACHE_SHA,
            allocation_unit_bytes=fs.f_frsize)
        checked = graph.install.enforce_floor(root, model['floors']['first_install_from_unpreserved_official'],
            'first private runtime-pair install', model['inputs']['allocation_unit_bytes'])
        component.native.require(checked['available_logical_bytes'] >= 1024**3 + checked[
            'required_free_capacity_bytes'], 'first private installation would consume the 1GiB reserve')
    else:
        graph.activation.require_state_owner(root / '.zeldadoi-speedhack')
    official = context.base['official_source']['archive']
    if not os.path.lexists(root / official['path']):
        component.native.require(free >= 1024**3 + official['size'],
                                 'source preservation would consume the 1GiB reserve')
    environment = component.ordinary.environment()
    state, _ = initialize_owned_state_directory(root)
    with runtime_lock(state) as lease:
        # Probe only under the same lock as the transactions; never alongside a
        # running game. It applies to reuse too, without a host/native bypass.
        component.ordinary.probe_decoder(context.artifacts, {'decoder': DECODER})
        base = install_pair(root, context.artifacts / 'runtime-authority.json', BASE_SHA,
            context.artifacts / PATCH['path'], PATCH['sha256'], context.artifacts / PATCH['path'], PATCH['sha256'],
            context.artifacts / 'gmloader-seeded.json', context.artifacts / 'generated-cache-contract.json', CACHE_SHA,
            generation_timestamp, default_override_template_path=context.artifacts / 'options_override.default.ini',
            expected_default_override_template_sha256=component.DEFAULT_OVERRIDE_TEMPLATE_SHA256,
            lock_lease=lease)
        native = component.install(root, context.artifacts, ENROLLMENT_SHA, lease=lease)
    return dict(status='private_v6_bootstrap_installed', base=base, native=native, environment=environment,
                GameMaker_executed=False, production_approved=False, READY=False)


def verify(game_root, artifacts):
    root, context = _root(game_root), _context(artifacts)
    return component.verify(root, context.artifacts, ENROLLMENT_SHA)


def restore(game_root, artifacts):
    root, context = _root(game_root), _context(artifacts)
    component.native.checked_file(context.artifacts / 'generated-cache-contract.json',
                                  maximum=16 * 1024**2, digest=CACHE_SHA)
    state = root / '.zeldadoi-speedhack'
    with runtime_lock(state) as lease:
        graph, _ = _graph(context)
        # The archive producer owns this separate temporary stage namespace.
        component.native.require(not any(p.name.startswith(STAGE_PREFIX) for p in state.iterdir()),
            'unfinished private archive stage; preserve it and resolve Setup before Restore')
        pair_restore = graph.restore
        # Refuse a competing base transaction before removing owned native
        # files. Existing restore journals own their own stage and recovery.
        if any(os.path.lexists(state / name)
               for name in (pair_restore.RESTORE_JOURNAL, pair_restore.RESTORE_JOURNAL_NEXT)):
            # This Restore starts the base journal only after native removal has finished.
            component.native.require(not any(os.path.lexists(state / name)
                for name in ('native', component.REMOVE_JOURNAL)),
                'base Restore and native removal state overlap; preserve both for review')
        else:
            pair_restore.reject_other_transactions(root, state, None, None)
            if any(os.path.lexists(state / name) for name in ('native', component.REMOVE_JOURNAL)):
                schema = pair_restore.load_schema(pair_restore.DEFAULT_SCHEMA)
                if pair_restore.already_restored(root, state, schema) is None:
                    _, authority, _, _ = pair_restore.verify_installed_pair(
                        root, state, pair_restore.DEFAULT_SCHEMA, BASE_SHA,
                        context.artifacts / 'generated-cache-contract.json', CACHE_SHA,
                        graph.capacity.DEFAULT_CAPACITY_SCHEMA)
                    if os.path.lexists(state / graph.verify.INSTALL_CURRENT):
                        graph.verify.verify_install_current(state, authority, BASE_SHA)
        native = component.remove(root, context.artifacts, ENROLLMENT_SHA, lease=lease)
        base = pair_restore.restore_pair(root, BASE_SHA,
            cache_contract_path=context.artifacts / 'generated-cache-contract.json',
            expected_cache_contract_sha256=CACHE_SHA, lock_lease=lease)
    return dict(status='private_v6_bootstrap_restored', native=native, base=base, GameMaker_executed=False)


if __name__ == '__main__':
    print('Inactive private qualification bootstrap: no package entrypoint is enrolled.', file=sys.stderr)
    raise SystemExit(2)
