"""Bind the tested owned controller to the owner's selected V6 candidate root.

No native/game/save implementation changes. The exact accepted bootstrap,
preparer and locked mapper controller bodies are reused with one root binding.
Selection is not installation, physical qualification or public release.
"""
import hashlib
import json
from pathlib import Path
import sys
from types import FunctionType, SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'device/tools')]
import private_v6_qualification_v1 as previous

SELECTION = 'config/v6-release-candidate-selection-v1.json'
SELECTION_SHA256 = 'dfa36129ee2ac70fd8fa746d1c6e2a46dbff56a2e49c6dca93f0626aa87cc016'
PINS = {
    'scripts/private_v6_qualification_v1.py':
        '93f53f0a308d1733d2cd3c1a2bf3e82ff4eacd826fecfd3f816126120bcd32da',
    'scripts/private_v6_archive_bootstrap_v1.py':
        '61892121153af41ed716a6e855d12eb9597c8e0f84c0e5b11a0214baaf9d590b',
    'scripts/prepare_owned_v6_root_v1.py':
        '7d35c16a1f25dc11ecf9daf25b64e76cfebcbe0f1aaf767d87689389217a962d',
}


def selection():
    native = previous.launcher.native
    native.checked_file(ROOT / SELECTION, maximum=65536, digest=SELECTION_SHA256)
    value = json.loads((ROOT / SELECTION).read_text())
    native.require(value['native_production_candidate_selected'] is True and
                   value['public_distribution_approved'] is False and
                   value['release_approved'] is False,
                   'exact candidate selection, not release approval, required')
    native.checked_file(ROOT / 'config/owned-v6-native-candidate-binding-v1.json',
                        maximum=65536, digest=value['retained_native_binding_sha256'])
    contract = native.contract()
    native.require((contract['native']['sha256'],
                    contract['base_payload']['game_droid_sha256'],
                    contract['base_payload']['sha256'], contract['fixed_child_environment']) ==
                   (value['native_sha256'], value['game_sha256'],
                    value['archive_sha256'], value['fixed_child_environment']),
                   'selected native/game/archive/environment differs')
    return value


def _bind(module, **replacements):
    """Same function code/defaults/closures; only the explicit globals differ."""
    original = vars(module)
    result = SimpleNamespace()
    scope = vars(result)
    scope.update(original, **replacements)
    for name, fn in original.items():
        if isinstance(fn, FunctionType) and fn.__globals__ is original:
            copy = FunctionType(fn.__code__, scope, fn.__name__, fn.__defaults__, fn.__closure__)
            copy.__kwdefaults__ = fn.__kwdefaults__
            scope[name] = copy
    return result


def bindings():
    value = selection()
    for module, name in ((previous, 'scripts/private_v6_qualification_v1.py'),
                         (previous.bootstrap, 'scripts/private_v6_archive_bootstrap_v1.py'),
                         (previous.preparation, 'scripts/prepare_owned_v6_root_v1.py')):
        previous.launcher.native.require(Path(module.__file__).resolve() == ROOT / name,
                                         'candidate implementation origin differs')
        previous.launcher.native.checked_file(ROOT / name, maximum=2 * 1024**2, digest=PINS[name])
    previous.verify_sources()
    bootstrap = _bind(previous.bootstrap, ROOT_NAME=value['game_directory'])
    preparation = _bind(previous.preparation, bootstrap=bootstrap)
    controller = _bind(previous, bootstrap=bootstrap, preparation=preparation)
    previous.launcher.native.require(bootstrap.BASE_SHA == value['runtime_authority_sha256'] and
                                     bootstrap.ENROLLMENT_SHA == value['native_enrollment_sha256'],
                                     'candidate transaction authority differs')
    return controller


def launcher_filenames():
    """Names exposed in the player's Ports menu."""
    return {
        'setup': 'ZeldaDOI Speedhack Installer.sh',
        'run': 'ZeldaDOI Speedhack Launcher.sh',
        'restore': 'ZeldaDOI Speedhack Remover.sh',
    }


def package_metadata():
    """Current identities only; a publisher still needs its own reviewed provenance.

    These values replace inherited build labels. They do not transfer an old
    package's readiness, owner invitation, native adoption or release approval.
    """
    value = selection()
    return dict(game_build=value['game_sha256'][:12],
                game_droid_sha256=value['game_sha256'],
                native_sha256=value['native_sha256'],
                native_production_candidate_selected=value['native_production_candidate_selected'],
                root=value['game_directory'], program=value['program_directory'],
                launcher_files=launcher_filenames(),
                READY=False, owner_test_authorized=False,
                production_native_adopted=False, release_approved=False)


def shell_source(action, manifest_sha256, file_hashes):
    """Render the accepted shell with only fixed names and its entrypoint changed."""
    import render_owned_v6_portmaster_v1 as renderer
    value = selection()
    previous.launcher.native.checked_file(Path(renderer.__file__), maximum=65536,
        digest='ab295a0cf6820de5113676a204454bc2841167a46185516632717e2fe6a4e9de')
    adapted = _bind(renderer,
        PROGRAM_DIRECTORY=value['program_directory'], MANIFEST=value['manifest'],
        NAMES=launcher_filenames(),
        REQUIRED=renderer.REQUIRED | {'scripts/v6_release_candidate_v1.py', SELECTION})
    result = adapted.shell_source(action, manifest_sha256, file_hashes)
    old = '"$K/scripts/private_v6_qualification_v1.py" ' + action + ' '
    new = '"$K/scripts/v6_release_candidate_v1.py" ' + action + ' '
    if result.count(old) != 1:
        raise ValueError('exact shell entrypoint seam differs')
    result = result.replace(old, new)
    old_root = '"$PORTS/' + previous.bootstrap.ROOT_NAME + '"'
    if result.count(old_root) != (0 if action == 'setup' else 1):
        raise ValueError('exact shell root seam differs')
    return result.replace(old_root, '"$PORTS/' + value['game_directory'] + '"')


def main(argv=None):
    try:
        controller = bindings()
    except (OSError, ValueError, TypeError, KeyError) as error:
        print('V6 candidate selection refused: ' + str(error), file=sys.stderr)
        return 2
    return controller.main(argv)


if __name__ == '__main__':
    raise SystemExit(main())
