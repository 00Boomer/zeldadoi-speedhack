"""Shared-runtime Filter successor over the frozen V3 authority launcher.

This module combines the single-read Aspect/Filter child transport from V4
with V3's shared-pair verification and runtime selection.  It is deliberately
only a staged runtime component: a release contract/renderer adoption remains
separate, and neither predecessor namespace is modified.
"""
from __future__ import annotations

import hashlib
import inspect
import os
from pathlib import Path
import stat
import sys
from types import FunctionType, SimpleNamespace

import launch_with_options_override_v4 as previous
import launch_with_shared_runtime_authority_v3 as shared_previous
import runtime_authority_shared_v2 as authority
import select_shared_runtime_command_v2 as selector
import verify_shared_runtime_pair_v2 as verifier


PINS = {
    Path(previous.__file__): "e7f687326fa99fa15f0ae4a04dc941cd160341d73558c4643fcbd9723aa8868c",
    Path(shared_previous.__file__): "a2eb54886fb05b472fceed6d4b857fec85af624cebb92fcb0d6dcecd0e83fe14",
    Path(authority.__file__): "ee231a83369e6e088637bf999e86bf240fa172d24c6ce9b2a05f321454aa3ee3",
    Path(selector.__file__): "68002c692bf7922218d3179e4067a1dc2eadf1fdd33239c85bab5b03214a98a6",
    Path(verifier.__file__): "e0e0cc890975b0da3afe45d49ecfcb14c23837ee567da22f96d3d621af07629c",
    Path(authority.DEFAULT_SCHEMA): "445228b6091da3a4753c6d0fac8191d956a50bec273a4a51b910f66534aa1050",
}


def _checked_sha256(path: Path) -> str:
    """Hash one regular, single-link file while refusing namespace races."""
    before = path.lstat()
    if path.is_symlink() or not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise ValueError("shared Filter launcher dependency is unsafe")
    descriptor = os.open(
        path,
        os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0),
    )
    try:
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or (
                opened.st_dev, opened.st_ino, opened.st_mode, opened.st_size,
                opened.st_mtime_ns, opened.st_ctime_ns,
            )
            != (
                before.st_dev, before.st_ino, before.st_mode, before.st_size,
                before.st_mtime_ns, before.st_ctime_ns,
            )
        ):
            raise ValueError("shared Filter launcher dependency changed before read")
        digest = hashlib.sha256()
        while block := os.read(descriptor, 1024 * 1024):
            digest.update(block)
        after = os.fstat(descriptor)
        if (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_nlink,
            after.st_size,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ) != (
            opened.st_dev,
            opened.st_ino,
            opened.st_mode,
            opened.st_nlink,
            opened.st_size,
            opened.st_mtime_ns,
            opened.st_ctime_ns,
        ):
            raise ValueError("shared Filter launcher dependency changed during read")
    finally:
        os.close(descriptor)
    observed = path.lstat()
    if (
        path.is_symlink()
        or (
            observed.st_dev, observed.st_ino, observed.st_mode, observed.st_nlink,
            observed.st_size, observed.st_mtime_ns, observed.st_ctime_ns,
        )
        != (
            after.st_dev, after.st_ino, after.st_mode, after.st_nlink,
            after.st_size, after.st_mtime_ns, after.st_ctime_ns,
        )
    ):
        raise ValueError("shared Filter launcher dependency changed after read")
    return digest.hexdigest()


def _verify_predecessors(authority_schema_path=authority.DEFAULT_SCHEMA) -> None:
    # A fixture may choose a separate schema for execution, but that never
    # relaxes the inventory pin on the canonical shipped schema.
    Path(authority_schema_path)
    for path, pin in PINS.items():
        if _checked_sha256(path) != pin:
            raise ValueError("shared Filter launcher predecessor identity changed")


def bindings(authority_schema_path=authority.DEFAULT_SCHEMA):
    """Return an invocation-local shared launcher with Filter-aware transport."""
    _verify_predecessors(authority_schema_path)
    schema = authority.load_schema(authority_schema_path)

    def select_command(
        command, resolved, game_directory, options_schema, runtime_authority, run_seed=None
    ):
        if runtime_authority is None:
            return previous.transport.prior.select_runtime_command(
                command, resolved, game_directory, options_schema, None, run_seed
            )
        return selector.select_runtime_command(
            command, resolved, game_directory, options_schema, runtime_authority,
            run_seed, authority_schema=schema
        )

    def verify_pair(*args, **kwargs):
        if "schema_path" in kwargs:
            raise ValueError("shared launcher verifier schema cannot be overridden")
        return verifier.verify_installed_pair(
            *args, schema_path=authority_schema_path, **kwargs
        )

    original_scope = previous._namespace
    scope = dict(
        original_scope,
        __file__=__file__,
        DEFAULT_RUNTIME_AUTHORITY_SCHEMA=authority_schema_path,
        load_runtime_authority_schema=authority.load_schema,
        load_authority=authority.load_authority,
        select_runtime_command=select_command,
        shared_runtime_pair_verifier=SimpleNamespace(verify_installed_pair=verify_pair),
    )
    for name, value in tuple(original_scope.items()):
        if (
            name == "select_runtime_command"
            or not isinstance(value, FunctionType)
            or value.__globals__ is not original_scope
        ):
            continue
        invoke = FunctionType(
            value.__code__, scope, value.__name__, value.__defaults__, value.__closure__
        )
        invoke.__kwdefaults__ = value.__kwdefaults__
        scope[name] = invoke

    body = inspect.getsource(previous.transport.prior.run_game)
    old = "import bounded_runtime_pair_verify as runtime_pair_verify"
    if body.count(old) != 1:
        raise ValueError("shared Filter launcher inherited late verification seam changed")
    body = body.replace(old, "runtime_pair_verify = shared_runtime_pair_verifier", 1)
    exec(compile(body, "<current strict shared Filter runtime launch>", "exec"), scope)
    inherited_run_game = scope["run_game"]

    def run_game(args):
        try:
            return inherited_run_game(args)
        except previous._FilterConfigurationRefusal as error:
            print("ERROR: " + str(error), file=sys.stderr)
            return 2

    scope["run_game"] = run_game
    return SimpleNamespace(**scope)


def run_game(args):
    return bindings().run_game(args)


def main():
    return bindings().main()


if __name__ == "__main__":
    raise SystemExit(main())
