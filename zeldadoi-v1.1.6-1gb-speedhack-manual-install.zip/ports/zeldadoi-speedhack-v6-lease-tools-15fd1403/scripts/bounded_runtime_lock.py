#!/usr/bin/env python3
"""Shared fail-closed installer/runtime lock for owned ZeldaDOI state."""

from __future__ import annotations

import fcntl
import os
import re
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator


OWNER = "org.zeldadoi.speedhack"
OWNER_NAME = "owner"
LOCK_NAME = "lock"
PID_NAME = "pid"
PID_LINE = re.compile(r"[1-9][0-9]*\n")


@dataclass(frozen=True)
class RuntimeLockLease:
    """Exact ownership token for deliberate same-process lock composition."""

    root_directory: Path
    state_directory: Path
    root_identity: os.stat_result
    state_identity: os.stat_result
    lock_identity: os.stat_result
    pid_identity: os.stat_result
    pid_text: str
    guard_fd: int = -1


def fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def verify_owned_state_directory(state_directory: Path) -> None:
    if state_directory.is_symlink() or not state_directory.is_dir():
        raise ValueError("runtime state directory is missing or unsafe")
    owner = state_directory / OWNER_NAME
    if owner.is_symlink() or not owner.is_file():
        raise ValueError("runtime state directory owner is missing or unsafe")
    try:
        value = owner.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("runtime state directory owner is not UTF-8") from exc
    if value != OWNER + "\n":
        raise ValueError("runtime state directory owner mismatch")


def _same_identity(path: Path, expected: os.stat_result, kind: str) -> bool:
    try:
        observed = path.lstat()
    except FileNotFoundError:
        return False
    if kind == "directory" and not path.is_dir():
        return False
    if kind == "file" and not path.is_file():
        return False
    return (
        not path.is_symlink()
        and observed.st_dev == expected.st_dev
        and observed.st_ino == expected.st_ino
        and observed.st_mode == expected.st_mode
        and observed.st_ctime_ns == expected.st_ctime_ns
    )


def _same_directory_inode(path: Path, expected: os.stat_result) -> bool:
    """Compare a mutable namespace directory without requiring stable ctime."""
    try:
        observed = path.lstat()
    except FileNotFoundError:
        return False
    return (
        not path.is_symlink()
        and path.is_dir()
        and observed.st_dev == expected.st_dev
        and observed.st_ino == expected.st_ino
        and observed.st_mode == expected.st_mode
    )


def _same_pid_identity(
    path: Path, expected: os.stat_result, expected_text: str
) -> bool:
    if not _same_identity(path, expected, "file"):
        return False
    try:
        return path.read_text(encoding="ascii") == expected_text
    except (OSError, UnicodeDecodeError):
        return False


@contextmanager
def _state_guard(state_directory: Path) -> Iterator[int]:
    """Hold the state-directory inode across owner recovery and child lifetime."""
    verify_owned_state_directory(state_directory)
    before = state_directory.lstat()
    descriptor = os.open(state_directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(descriptor)
        if (opened.st_dev, opened.st_ino, opened.st_mode) != (before.st_dev, before.st_ino, before.st_mode):
            raise ValueError("runtime state directory changed before locking")
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("another installer or runtime operation is active") from error
        if not _same_directory_inode(state_directory, opened):
            raise ValueError("runtime state directory changed while locking")
        verify_owned_state_directory(state_directory)
        yield descriptor
    finally:
        # Unlocking explicitly would also release the game's inherited lease.
        os.close(descriptor)


def recover_stale_lock(state_directory: Path) -> bool:
    """Recover only while no process holds the state-directory guard."""
    with _state_guard(state_directory):
        return _recover_stale_lock(state_directory)


def _recover_stale_lock(state_directory: Path) -> bool:
    """Remove only an exact lock whose recorded process no longer exists."""
    verify_owned_state_directory(state_directory)
    lock = state_directory / LOCK_NAME
    if lock.is_symlink() or not lock.is_dir():
        raise ValueError("runtime lock path is unsafe")
    with os.scandir(lock) as iterator:
        entries = list(iterator)
    if len(entries) != 1 or entries[0].name != PID_NAME:
        raise ValueError("runtime lock contents are unsafe")
    pid_path = lock / PID_NAME
    if pid_path.is_symlink() or not pid_path.is_file():
        raise ValueError("runtime lock PID path is unsafe")
    lock_identity = lock.lstat()
    pid_identity = pid_path.lstat()
    try:
        text = pid_path.read_text(encoding="ascii")
    except UnicodeDecodeError as exc:
        raise ValueError("runtime lock PID is not ASCII") from exc
    if PID_LINE.fullmatch(text) is None:
        raise ValueError("runtime lock PID is malformed")
    try:
        os.kill(int(text), 0)
    except ProcessLookupError:
        if not _same_pid_identity(pid_path, pid_identity, text) or not _same_identity(
            lock, lock_identity, "directory"
        ):
            raise ValueError("runtime lock identity changed during recovery")
        pid_path.unlink()
        lock.rmdir()
        fsync_directory(state_directory)
        return True
    except PermissionError:
        pass
    raise ValueError("another installer or runtime operation is active")


def verify_runtime_lock_lease(
    state_directory: Path, lease: RuntimeLockLease
) -> None:
    """Reject a stale, foreign, replaced, or cross-state nested lease."""
    if not isinstance(lease, RuntimeLockLease):
        raise ValueError("runtime lock lease type is invalid")
    verify_owned_state_directory(state_directory)
    state = state_directory.resolve()
    root = state.parent.resolve()
    if (
        lease.root_directory != root
        or lease.state_directory != state
        or lease.pid_text != f"{os.getpid()}\n"
    ):
        raise ValueError("runtime lock lease does not belong to this operation")
    if not _same_directory_inode(
        root, lease.root_identity
    ) or not _same_directory_inode(state, lease.state_identity):
        raise ValueError("runtime lock namespace identity changed while held")
    lock = state / LOCK_NAME
    pid_path = lock / PID_NAME
    if not _same_pid_identity(
        pid_path, lease.pid_identity, lease.pid_text
    ) or not _same_identity(lock, lease.lock_identity, "directory"):
        raise ValueError("runtime lock lease identity changed while held")
    try:
        descriptor_identity = os.fstat(lease.guard_fd)
    except OSError as error:
        raise ValueError("runtime lock guard descriptor changed while held") from error
    if not _same_directory_inode(state, descriptor_identity):
        raise ValueError("runtime lock guard descriptor changed while held")


@contextmanager
def runtime_lock(
    state_directory: Path,
    lease: RuntimeLockLease | None = None,
) -> Iterator[RuntimeLockLease]:
    """Hold a new lock or validate one explicit outer-operation lease."""
    if lease is not None:
        verify_runtime_lock_lease(state_directory, lease)
        try:
            yield lease
        finally:
            verify_runtime_lock_lease(state_directory, lease)
        return
    verify_owned_state_directory(state_directory)
    state_directory = state_directory.resolve()
    with _state_guard(state_directory) as guard_fd:
        with _pid_lock(state_directory, guard_fd) as owned_lease:
            yield owned_lease


@contextmanager
def _pid_lock(state_directory: Path, guard_fd: int) -> Iterator[RuntimeLockLease]:
    root_directory = state_directory.parent.resolve()
    lock = state_directory / LOCK_NAME
    if lock.exists() or lock.is_symlink():
        _recover_stale_lock(state_directory)
    if lock.exists() or lock.is_symlink():
        raise ValueError("another installer or runtime operation is active")
    lock.mkdir(mode=0o700)
    pid_path = lock / PID_NAME
    descriptor = os.open(
        pid_path,
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_NOFOLLOW", 0),
        0o600,
    )
    pid_text = f"{os.getpid()}\n"
    with os.fdopen(descriptor, "w", encoding="ascii", closefd=True) as handle:
        handle.write(pid_text)
        handle.flush()
        os.fsync(handle.fileno())
    pid_identity = pid_path.lstat()
    fsync_directory(lock)
    lock_identity = lock.lstat()
    fsync_directory(state_directory)
    owned_lease = RuntimeLockLease(
        root_directory=root_directory,
        state_directory=state_directory,
        root_identity=root_directory.lstat(),
        state_identity=state_directory.lstat(),
        lock_identity=lock_identity,
        pid_identity=pid_identity,
        pid_text=pid_text,
        guard_fd=guard_fd,
    )
    try:
        yield owned_lease
    finally:
        verify_runtime_lock_lease(state_directory, owned_lease)
        pid_path.unlink()
        lock.rmdir()
        fsync_directory(state_directory)
