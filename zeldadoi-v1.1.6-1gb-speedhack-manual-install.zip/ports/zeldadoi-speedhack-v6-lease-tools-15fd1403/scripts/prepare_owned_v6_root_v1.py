"""Prepare only the fixed private qualification root from exact original files.

This explicit action copies eight whitelisted inputs, never profiles or saves.
It does not install the patch, execute a native binary, or launch GameMaker.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'device/tools')]
import private_v6_archive_bootstrap_v1 as bootstrap
from zeldadoi_temporary_workspace_v1 import make_workspace

BOOTSTRAP_SHA = '61892121153af41ed716a6e855d12eb9597c8e0f84c0e5b11a0214baaf9d590b'
STAGE_PREFIX = 'zeldadoi.owned-v6-root.'
MARKER = '.qualification-root.json'


def verify_sources():
    native = bootstrap.component.native
    native.require(Path(bootstrap.__file__).resolve() == ROOT / 'scripts/private_v6_archive_bootstrap_v1.py',
                   'root preparer bootstrap origin differs')
    native.checked_file(Path(bootstrap.__file__), maximum=2 * 1024**2, digest=BOOTSTRAP_SHA)
    bootstrap._sources()


def inputs():
    archive = bootstrap.component.native.shared.load_schema()['official_source']['archive']
    rows = [dict(path='zeldadoi.port', bytes=archive['size'], sha256=archive['sha256'])]
    rows += [dict(row, path='libs.aarch64/' + row['path'])
             for row in bootstrap.component.native.contract()['library_files']]
    rows += [dict(row) for row in bootstrap.GAME_LIBRARIES]
    bootstrap.component.native.require(len(rows) == 8 and len({r['path'] for r in rows}) == 8,
                                       'fixed original prerequisite inventory differs')
    return rows


def generated(rows):
    marker = dict(schema='owned_v6_private_root_preparation_v1',
                  release_id=bootstrap.RELEASE_ID, root=bootstrap.ROOT_NAME,
                  original_inputs=rows, profiles_or_saves_copied=False,
                  GameMaker_or_native_executed=False, production_approved=False, release=False)
    return {'gmloader.json': bootstrap.configuration('default'),
            MARKER: (json.dumps(marker, sort_keys=True, indent=2) + '\n').encode()}


def verify_prepared(root):
    """Check inventory and bytes only; target ownership/modes need qualification."""
    root = bootstrap._root(root)
    rows = inputs()
    expected = {r['path']: (r['bytes'], r['sha256']) for r in rows}
    for name, raw in generated(rows).items(): expected[name] = (len(raw), hashlib.sha256(raw).hexdigest())
    observed = set()
    for path in root.rglob('*'):
        bootstrap.component.native.require(not path.is_symlink(), 'prepared root contains a symlink')
        if path.is_dir():
            bootstrap.component.native.require(str(path.relative_to(root)) in
                {'libs.aarch64', 'lib', 'lib/arm64-v8a'}, 'prepared root contains an unexpected directory')
            continue
        name = str(path.relative_to(root))
        bootstrap.component.native.require(name in expected, 'prepared root contains an unexpected file')
        observed.add(name)
    bootstrap.component.native.require(observed == set(expected), 'prepared root inventory is incomplete')
    for name, (size, digest) in expected.items():
        bootstrap.component.ordinary.checked(root / name, size, digest)
    return dict(status='verified_private_root_inventory_and_bytes', root=str(root), files=len(expected),
                verification_scope='inventory_and_bytes_only', ownership_and_permissions_qualified=False,
                profiles_or_saves_copied=False, GameMaker_or_native_executed=False,
                production_approved=False, READY=False, release=False)


def prepare(ports_directory):
    verify_sources()
    ordinary = bootstrap.component.ordinary
    ports = ordinary.safe(Path(ports_directory).absolute(), directory=True)
    bootstrap.component.native.require(ports.name == 'ports', 'explicit real ports directory required')
    fd = os.open(ports, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        pending = sorted(p.name for p in ports.iterdir() if p.name.startswith(STAGE_PREFIX))
        bootstrap.component.native.require(not pending, 'held root-preparation stage requires review: ' + repr(pending))
        target = ports / bootstrap.ROOT_NAME
        if os.path.lexists(target):
            result = verify_prepared(target)
            os.fsync(fd)
            return dict(result, status='existing_private_root_inventory_and_bytes_verified')
        donor = ordinary.safe(ports / 'zeldadoi', directory=True)
        rows = inputs()
        # Authenticate all prerequisites before creating a disposable stage.
        for row in rows: ordinary.checked(donor / row['path'], row['bytes'], row['sha256'])
        extra = generated(rows)
        required = sum(r['bytes'] for r in rows) + sum(len(b) for b in extra.values()) + 65536
        stage = make_workspace('owned-v6-root', parent=ports, required_bytes=required)
        for row in rows:
            bootstrap.component._copy(donor / row['path'], stage / row['path'], row['bytes'], row['sha256'])
        for name, raw in extra.items():
            with (stage / name).open('xb') as out:
                out.write(raw); out.flush(); os.fsync(out.fileno())
        # The fixed-name guard applies after publication; authenticate the
        # staging bytes against the same explicit expected inventory here.
        entries = list(stage.rglob('*'))
        bootstrap.component.native.require(not any(p.is_symlink() for p in entries),
                                           'root staging contains a symlink')
        bootstrap.component.native.require({str(p.relative_to(stage)) for p in entries if p.is_dir()}
            == {'libs.aarch64', 'lib', 'lib/arm64-v8a'}, 'root staging directory inventory differs')
        expected = {r['path'] for r in rows} | set(extra)
        bootstrap.component.native.require({str(p.relative_to(stage)) for p in entries
            if not p.is_dir()} == expected, 'root staging inventory differs')
        for row in rows: ordinary.checked(stage / row['path'], row['bytes'], row['sha256'])
        for name, raw in extra.items(): ordinary.checked(stage / name, len(raw), hashlib.sha256(raw).hexdigest())
        fs = os.statvfs(ports)
        bootstrap.component.native.require(fs.f_bavail * fs.f_frsize >= 1024**3,
                                           'root preparation would consume the filesystem reserve')
        for path in sorted([p for p in stage.rglob('*') if p.is_dir()], key=lambda p: len(p.parts), reverse=True) + [stage]:
            ordinary.fsync_dir(path)
        for row in rows: ordinary.checked(donor / row['path'], row['bytes'], row['sha256'])
        ordinary.publish_new(stage, target)
        os.fsync(fd)
        result = verify_prepared(target)
        return dict(result, status='created_private_root_inventory_and_bytes_verified')
    finally:
        os.close(fd)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'verify'))
    parser.add_argument('--ports-dir', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.action == 'prepare': result = prepare(args.ports_dir)
        else:
            verify_sources()
            ports = bootstrap.component.ordinary.safe(args.ports_dir.absolute(), directory=True)
            bootstrap.component.native.require(ports.name == 'ports', 'explicit real ports directory required')
            result = verify_prepared(ports / bootstrap.ROOT_NAME)
    except (OSError, ValueError, TypeError, KeyError) as error:
        print('private V6 root preparation refused: ' + str(error), file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__': raise SystemExit(main())
