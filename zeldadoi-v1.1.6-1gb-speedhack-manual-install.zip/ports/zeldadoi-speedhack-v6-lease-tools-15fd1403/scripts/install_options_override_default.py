#!/usr/bin/env python3
"""Create the owned fast-lighting override only when no user override exists."""

from __future__ import annotations

import argparse
import ctypes
import errno
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path
from typing import Any

from bounded_runtime_lock import (
    RuntimeLockLease,
    fsync_directory,
    runtime_lock,
    verify_owned_state_directory,
    verify_runtime_lock_lease,
)


TARGET_NAME = "options_override.ini"
PENDING_NAME = "options-override.default.next"
STATE_NAME = ".zeldadoi-speedhack"
MAXIMUM_TEMPLATE_BYTES = 65_536
HEX64 = re.compile(r"[0-9a-f]{64}")
RENAME_NOREPLACE = 1


class OptionsDefaultError(ValueError):
    """The default override cannot be installed without touching user data."""


def same_directory_identity(
    observed: os.stat_result, expected: os.stat_result
) -> bool:
    return (
        stat.S_ISDIR(observed.st_mode)
        and observed.st_dev == expected.st_dev
        and observed.st_ino == expected.st_ino
        and observed.st_mode == expected.st_mode
    )


def rename_no_replace(
    source: Path,
    destination: Path,
    lock_lease: RuntimeLockLease,
) -> None:
    """Atomically move *source* into an absent *destination* name.

    The target RG35XX SP filesystem physically supports renameat2 with
    RENAME_NOREPLACE but returns ENOSYS for hard-link creation.  There is no
    weaker check-then-rename fallback: absence of the measured primitive is a
    fail-closed installer capability error.
    """
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    source_fd = destination_fd = -1
    try:
        source_fd = os.open(source.parent, flags)
        destination_fd = os.open(destination.parent, flags)
        source_parent = os.fstat(source_fd)
        destination_parent = os.fstat(destination_fd)
        if (
            not same_directory_identity(source_parent, lock_lease.state_identity)
            or not same_directory_identity(
                destination_parent, lock_lease.root_identity
            )
            or source_parent.st_dev != destination_parent.st_dev
        ):
            raise OptionsDefaultError(
                "no-replace activation directories do not match the held lease"
            )
        verify_runtime_lock_lease(source.parent, lock_lease)
        libc = ctypes.CDLL(None, use_errno=True)
        call = getattr(libc, "renameat2", None)
        if call is None:
            raise OSError(errno.ENOSYS, "renameat2 is unavailable")
        call.argtypes = [
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_uint,
        ]
        call.restype = ctypes.c_int
        result = call(
            source_fd,
            os.fsencode(source.name),
            destination_fd,
            os.fsencode(destination.name),
            RENAME_NOREPLACE,
        )
        if result != 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code), str(destination))
        verify_runtime_lock_lease(source.parent, lock_lease)
        # Persist both sides of the cross-directory namespace move before the
        # helper can report success.
        os.fsync(source_fd)
        os.fsync(destination_fd)
    finally:
        if destination_fd >= 0:
            os.close(destination_fd)
        if source_fd >= 0:
            os.close(source_fd)


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def exact_directory(path: Path, label: str) -> Path:
    if path.is_symlink() or not path.is_dir():
        raise OptionsDefaultError(f"{label} must be a real directory")
    resolved = path.resolve()
    if resolved.is_symlink() or not resolved.is_dir():
        raise OptionsDefaultError(f"{label} resolution is unsafe")
    return resolved


def read_template(path: Path, expected_sha256: str) -> bytes:
    if HEX64.fullmatch(expected_sha256) is None:
        raise OptionsDefaultError("default override digest is invalid")
    try:
        metadata = path.lstat()
    except FileNotFoundError as exc:
        raise OptionsDefaultError("default override template is missing") from exc
    if (
        path.is_symlink()
        or not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
        or metadata.st_size <= 0
        or metadata.st_size > MAXIMUM_TEMPLATE_BYTES
    ):
        raise OptionsDefaultError("default override template is unsafe")
    payload = path.read_bytes()
    if len(payload) != metadata.st_size or digest(payload) != expected_sha256:
        raise OptionsDefaultError("default override template identity mismatch")
    required = (
        b"[Speedhack]",
        b"EnableOverride=0",
        b"ConfigVersion=1",
        b"Profile=custom",
        b"LightingMode=fast",
        b"UseDungeonSeed=0",
        b"UseRunSeed=0",
        b"RunSeed=",
    )
    if any(token not in payload for token in required):
        raise OptionsDefaultError("default override template semantics mismatch")
    return payload


def regular_existing(path: Path, label: str) -> os.stat_result:
    metadata = path.lstat()
    if path.is_symlink() or not stat.S_ISREG(metadata.st_mode):
        raise OptionsDefaultError(f"{label} is not a safe regular file")
    return metadata


def pending_payload(pending: Path, template: bytes) -> tuple[bytes, os.stat_result]:
    metadata = regular_existing(pending, "pending default override")
    if metadata.st_nlink not in (1, 2) or metadata.st_size > len(template):
        raise OptionsDefaultError("pending default override ownership mismatch")
    observed = pending.read_bytes()
    if len(observed) != metadata.st_size:
        raise OptionsDefaultError("pending default override changed during inspection")
    return observed, metadata


def fsync_complete_pending(pending: Path, template: bytes) -> os.stat_result:
    """Revalidate and durably flush a recovered complete pending file."""
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(pending, flags)
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size != len(template)
        ):
            raise OptionsDefaultError("recovered pending default override is unsafe")
        chunks: list[bytes] = []
        remaining = before.st_size
        while remaining:
            chunk = os.read(descriptor, remaining)
            if not chunk:
                raise OptionsDefaultError(
                    "recovered pending default override changed during read"
                )
            chunks.append(chunk)
            remaining -= len(chunk)
        if b"".join(chunks) != template:
            raise OptionsDefaultError("recovered pending default override mismatch")
        os.fsync(descriptor)
        after = os.fstat(descriptor)
        if (
            after.st_dev != before.st_dev
            or after.st_ino != before.st_ino
            or after.st_mode != before.st_mode
            or after.st_nlink != 1
            or after.st_size != len(template)
        ):
            raise OptionsDefaultError(
                "recovered pending default override identity changed"
            )
    finally:
        os.close(descriptor)
    current = pending.lstat()
    if (
        pending.is_symlink()
        or current.st_dev != after.st_dev
        or current.st_ino != after.st_ino
        or current.st_mode != after.st_mode
        or current.st_nlink != 1
    ):
        raise OptionsDefaultError("recovered pending namespace identity changed")
    return after


def remove_owned_pending(pending: Path, template: bytes) -> bool:
    if not pending.exists() and not pending.is_symlink():
        return False
    observed, metadata = pending_payload(pending, template)
    if metadata.st_nlink != 1 or not template.startswith(observed):
        raise OptionsDefaultError("pending default override is foreign or linked")
    pending.unlink()
    fsync_directory(pending.parent)
    return True


def write_pending(pending: Path, template: bytes) -> os.stat_result:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(pending, flags, 0o600)
    try:
        offset = 0
        while offset < len(template):
            written = os.write(descriptor, template[offset:])
            if written <= 0:
                raise OSError("short write while creating default override")
            offset += written
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    fsync_directory(pending.parent)
    observed, metadata = pending_payload(pending, template)
    if metadata.st_nlink != 1 or observed != template:
        raise OptionsDefaultError("pending default override verification failed")
    return metadata


def reconcile_existing_target(
    target: Path,
    pending: Path,
    template: bytes,
) -> dict[str, Any]:
    target_metadata = regular_existing(target, "existing options override")
    recovered_link = False
    removed_pending = False
    if pending.exists() or pending.is_symlink():
        observed, pending_metadata = pending_payload(pending, template)
        same_inode = (
            pending_metadata.st_dev == target_metadata.st_dev
            and pending_metadata.st_ino == target_metadata.st_ino
        )
        if same_inode:
            if observed != template or pending_metadata.st_nlink != 2:
                raise OptionsDefaultError("linked pending default override is inconsistent")
            pending.unlink()
            fsync_directory(pending.parent)
            recovered_link = True
            removed_pending = True
        elif observed == template and pending_metadata.st_nlink == 1:
            pending.unlink()
            fsync_directory(pending.parent)
            removed_pending = True
        else:
            raise OptionsDefaultError("pending default override conflicts with user configuration")
    return {
        "schema_version": 1,
        "status": "preserved_existing_user_override",
        "created": False,
        "preserved_existing": True,
        "target": TARGET_NAME,
        "existing_size": target_metadata.st_size,
        "recovered_committed_link": recovered_link,
        "removed_owned_pending": removed_pending,
        "user_configuration_modified": False,
        "saves_modified": False,
        "foreign_files_modified": False,
    }


def install_default_locked(
    root: Path,
    state: Path,
    template: bytes,
    lock_lease: RuntimeLockLease,
) -> dict[str, Any]:
    target = root / TARGET_NAME
    pending = state / PENDING_NAME
    if target.exists() or target.is_symlink():
        return reconcile_existing_target(target, pending, template)

    recovered_partial = False
    if pending.exists() or pending.is_symlink():
        observed, metadata = pending_payload(pending, template)
        if metadata.st_nlink != 1 or not template.startswith(observed):
            raise OptionsDefaultError("pending default override is foreign or unrecoverable")
        if observed != template:
            pending.unlink()
            fsync_directory(state)
            recovered_partial = True
            pending_metadata = write_pending(pending, template)
        else:
            pending_metadata = fsync_complete_pending(pending, template)
    else:
        pending_metadata = write_pending(pending, template)

    try:
        rename_no_replace(pending, target, lock_lease)
    except FileExistsError:
        return reconcile_existing_target(target, pending, template)
    except OSError as exc:
        if exc.errno == errno.EEXIST:
            return reconcile_existing_target(target, pending, template)
        raise

    # The move crosses from the owned state directory into the game root.
    # Persist both namespace changes before reporting a committed default.
    fsync_directory(state)
    fsync_directory(root)
    target_metadata = regular_existing(target, "created options override")
    if (
        pending.exists()
        or pending.is_symlink()
        or target_metadata.st_nlink != 1
        or target_metadata.st_dev != pending_metadata.st_dev
        or target_metadata.st_ino != pending_metadata.st_ino
        or target.read_bytes() != template
    ):
        raise OptionsDefaultError("created default override activation verification failed")
    final = regular_existing(target, "committed options override")
    if final.st_nlink != 1 or target.read_bytes() != template:
        raise OptionsDefaultError("committed default override verification failed")
    return {
        "schema_version": 1,
        "status": "created_in_game_authority_default_override",
        "created": True,
        "preserved_existing": False,
        "target": TARGET_NAME,
        "template_size": len(template),
        "template_sha256": digest(template),
        "activation_method": "renameat2_rename_noreplace",
        "recovered_partial_pending": recovered_partial,
        "user_configuration_modified": False,
        "saves_modified": False,
        "foreign_files_modified": False,
    }


def install_default(
    game_root: Path,
    template_path: Path,
    expected_template_sha256: str,
    *,
    lock_lease: RuntimeLockLease | None = None,
) -> dict[str, Any]:
    root = exact_directory(game_root, "game root")
    state = root / STATE_NAME
    verify_owned_state_directory(state)
    template = read_template(template_path, expected_template_sha256)
    if lock_lease is None:
        with runtime_lock(state) as operation_lease:
            return install_default(
                root,
                template_path,
                expected_template_sha256,
                lock_lease=operation_lease,
            )
    verify_runtime_lock_lease(state, lock_lease)
    return install_default_locked(root, state, template, lock_lease)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-root", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--template-sha256", required=True)
    arguments = parser.parse_args()
    try:
        result = install_default(
            arguments.game_root,
            arguments.template,
            arguments.template_sha256,
        )
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "invalid", "error": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
