#!/usr/bin/env python3
"""Authority-bound capacity model for the ZeldaDOI runtime pair.

This is a payload-free host contract.  It always calculates logical lower
bounds from exact artifact lengths and explicit tracked margins.  When a live
filesystem allocation unit is supplied, it also calculates an exact ceiling
for the known regular files by rounding each file independently.  Directory
metadata and other filesystem implementation costs remain covered only by the
explicit margins; this does not establish complete physical target capacity.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path, PurePosixPath
from typing import Any, NoReturn

from bounded_runtime_lock import OWNER
from runtime_authority import DEFAULT_SCHEMA as DEFAULT_AUTHORITY_SCHEMA
from runtime_authority import load_authority, load_schema


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CAPACITY_SCHEMA = ROOT / "config/runtime-pair-capacity-schema.json"
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
MAX_JSON_BYTES = 16 * 1024 * 1024
MAX_ALLOCATION_UNIT_BYTES = 1 << 30
CAPACITY_SCHEMA_KEYS = {
    "schema_version",
    "status",
    "maximum_cache_contract_bytes",
    "activation_metadata_bytes",
    "activation_metadata_inodes",
    "restore_metadata_bytes",
    "restore_metadata_inodes",
    "generation_margin_bytes",
    "generation_metadata_inodes",
    "policy",
}
POLICY = {
    "logical_bytes_not_allocated_blocks": True,
    "both_runtime_archives_retained_before_activation": True,
    "both_patched_game_droids_budgeted": True,
    "one_shared_generated_cache_budgeted": True,
    "staged_official_mirror_budgeted": True,
    "staged_default_config_mirror_budgeted": True,
    "maximum_runtime_authority_size_reserved": True,
    "first_install_preserved_official_copy_budgeted": True,
    "migration_restores_prior_pair_before_new_generation": True,
    "old_and_new_pairs_may_not_overlap": True,
    "physical_measurement_may_raise_floors": True,
}
CACHE_OWNER = "zeldadoi-speedhack-generated-cache-v1"
CACHE_PATH_ROOT = "assets/data"
CACHE_PREFIXES = {
    "assets/data/data_d": "assets/data/zdlf_d_",
    "assets/data/data_r": "assets/data/zdlf_r_",
}
CACHE_COORDINATE_DEPTHS = {
    "assets/data/data_d": 2,
    "assets/data/data_r": 3,
}


class RuntimePairCapacityError(ValueError):
    """An authority, cache identity, or capacity invariant failed."""


def reject(message: str) -> NoReturn:
    raise RuntimePairCapacityError(message)


def _is_vfat_mount(root: Path) -> bool:
    """Identify the effective mount using the path and its device number."""
    try:
        resolved = root.resolve(strict=True)
        device = resolved.stat().st_dev
        device_number = f"{os.major(device)}:{os.minor(device)}".encode("ascii")
        target = os.fsencode(resolved)
        deepest = 0
        filesystem_types = set()
        with Path("/proc/self/mountinfo").open("rb") as mounts:
            for line in mounts:
                before, separator, after = line.partition(b" - ")
                fields = before.split()
                if not separator or len(fields) < 5 or fields[2] != device_number:
                    continue
                mount = re.sub(rb"\\([0-7]{3})", lambda match: bytes([int(match[1], 8)]), fields[4])
                if target != mount and not target.startswith(mount.rstrip(b"/") + b"/"):
                    continue
                if len(mount) > deepest:
                    deepest = len(mount)
                    filesystem_types.clear()
                if len(mount) == deepest:
                    filesystem_types.add(after.split(maxsplit=1)[0])
        return filesystem_types == {b"vfat"}
    except (IndexError, OSError, ValueError):
        return False


def enforce_filesystem_capacity(
    root: Path,
    stats: os.statvfs_result,
    required_bytes: int,
    required_inodes: int,
    label: str,
    refuse,
) -> int:
    """Return the actual byte floor after checking the filesystem capacity."""
    unit = stats.f_frsize
    available_bytes = stats.f_bavail * unit
    if available_bytes < required_bytes:
        refuse(f"insufficient free capacity bytes for {label}")
    if stats.f_favail >= required_inodes:
        return required_bytes

    if not (
        stats.f_favail == 0
        and getattr(stats, "f_files", None) == getattr(stats, "f_ffree", None) == 0
        and unit >= 512
        and _is_vfat_mount(root)
    ):
        refuse(f"insufficient free inodes for {label}")

    # Linux vfat counts free clusters. Reserve space for each new directory
    # plus its parent entry, including the maximum 20 long-name slots and
    # one short-name slot even when their start crosses a cluster boundary.
    name_bytes = 21 * 32
    entry_units = 2 + (name_bytes + unit - 1) // unit
    capacity_with_directory_entries = required_bytes + required_inodes * unit * entry_units
    if available_bytes < capacity_with_directory_entries:
        refuse(f"insufficient free capacity bytes for {label} including FAT directory entries")
    return capacity_with_directory_entries


def duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            reject(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_nonfinite(value: str) -> NoReturn:
    reject(f"non-finite JSON value is forbidden: {value}")


def _positive(value: Any, label: str) -> int:
    if type(value) is not int or value <= 0 or value > (1 << 63) - 1:
        reject(f"{label} must be a positive bounded integer")
    return value


def allocation_unit(value: Any) -> int:
    if (
        type(value) is not int
        or value <= 0
        or value > MAX_ALLOCATION_UNIT_BYTES
    ):
        reject("filesystem allocation unit must be a positive bounded integer")
    return value


def allocated_size(size: int, unit: int) -> int:
    if type(size) is not int or size <= 0:
        reject("regular-file size must be a positive integer")
    unit = allocation_unit(unit)
    return ((size + unit - 1) // unit) * unit


def _sha(value: Any, label: str) -> str:
    if type(value) is not str or HEX64.fullmatch(value) is None:
        reject(f"{label} must be an exact lowercase SHA-256")
    return value


def stable_file_identity(path: Path, maximum: int, label: str) -> tuple[int, str, bytes]:
    """Read one regular, single-link file through a stable descriptor."""
    try:
        initial = path.lstat()
    except OSError as exc:
        reject(f"cannot stat {label}: {exc}")
    if (
        stat.S_ISLNK(initial.st_mode)
        or not stat.S_ISREG(initial.st_mode)
        or initial.st_nlink != 1
        or initial.st_size < 2
        or initial.st_size > maximum
    ):
        reject(f"{label} must be a bounded regular single-link file")
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or (opened.st_dev, opened.st_ino) != (initial.st_dev, initial.st_ino)
            or opened.st_size != initial.st_size
        ):
            reject(f"{label} changed while opening")
        chunks: list[bytes] = []
        remaining = maximum + 1
        digest = hashlib.sha256()
        while remaining:
            block = os.read(descriptor, min(1024 * 1024, remaining))
            if not block:
                break
            chunks.append(block)
            digest.update(block)
            remaining -= len(block)
        final = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    raw = b"".join(chunks)
    if (
        len(raw) != opened.st_size
        or final.st_size != opened.st_size
        or final.st_mtime_ns != opened.st_mtime_ns
        or final.st_ctime_ns != opened.st_ctime_ns
    ):
        reject(f"{label} changed while reading")
    return len(raw), digest.hexdigest(), raw


def strict_json(path: Path, maximum: int, expected_sha256: str, label: str) -> tuple[dict[str, Any], int]:
    _sha(expected_sha256, f"expected {label} SHA-256")
    size, digest, raw = stable_file_identity(path, maximum, label)
    if digest != expected_sha256:
        reject(f"{label} identity mismatch")
    if raw.startswith(b"\xef\xbb\xbf"):
        reject(f"{label} must not contain a UTF-8 BOM")
    try:
        value = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=duplicate_keys,
            parse_constant=reject_nonfinite,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        reject(f"{label} is not strict UTF-8 JSON: {exc}")
    if not isinstance(value, dict):
        reject(f"{label} must be a JSON object")
    return value, size


def load_capacity_schema(path: Path) -> dict[str, Any]:
    size, _, raw = stable_file_identity(path, MAX_JSON_BYTES, "capacity schema")
    del size
    try:
        document = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=duplicate_keys,
            parse_constant=reject_nonfinite,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        reject(f"capacity schema is not strict UTF-8 JSON: {exc}")
    if not isinstance(document, dict) or set(document) != CAPACITY_SCHEMA_KEYS:
        reject("capacity schema key coverage mismatch")
    if (
        document["schema_version"] != 1
        or document["status"] != "provisional_host_logical_capacity_policy"
        or document["policy"] != POLICY
    ):
        reject("capacity schema policy mismatch")
    for key in CAPACITY_SCHEMA_KEYS - {"schema_version", "status", "policy"}:
        _positive(document[key], f"capacity schema {key}")
    return document


def validate_cache_contract(
    document: dict[str, Any],
    authority: dict[str, Any],
    allocation_unit_bytes: int | None = None,
) -> dict[str, int | str]:
    official = authority["official_source"]["archive"]
    source = document.get("source", {}).get("official_port", {})
    ownership = document.get("ownership", {})
    generated = document.get("generated_files")
    count = document.get("generated_file_count")
    total = document.get("generated_total_bytes")
    if (
        document.get("schema_version") != 2
        or document.get("status") != "deterministic_generated_cache_contract_verified"
        or source.get("size") != official["size"]
        or source.get("sha256") != official["sha256"]
        or ownership.get("owner_id") != CACHE_OWNER
        or ownership.get("path_contract")
        != {
            "root": CACHE_PATH_ROOT,
            "dungeon_prefix": CACHE_PREFIXES["assets/data/data_d"],
            "room_prefix": CACHE_PREFIXES["assets/data/data_r"],
        }
        or ownership.get("generated_files_only") is not True
        or ownership.get("remove_only_when_path_and_sha256_match") is not True
        or ownership.get("remove_unknown_or_modified_owned_path") is not False
        or ownership.get("touch_user_save_paths") is not False
        or ownership.get("recursive_cleanup") is not False
        or type(count) is not int
        or count <= 0
        or type(total) is not int
        or total <= 0
        or not isinstance(generated, list)
        or len(generated) != count
    ):
        reject("generated-cache contract is not bound to runtime authority")
    seen: set[str] = set()
    observed_total = 0
    allocated_total = 0
    if allocation_unit_bytes is not None:
        allocation_unit_bytes = allocation_unit(allocation_unit_bytes)
    for item in generated:
        if not isinstance(item, dict):
            reject("generated-cache file record must be an object")
        source_member = item.get("source_member")
        coordinates = item.get("source_coordinates")
        prefix = CACHE_PREFIXES.get(source_member)
        relative = item.get("relative_path")
        item_size = item.get("size")
        if (
            prefix is None
            or not isinstance(coordinates, list)
            or len(coordinates) != CACHE_COORDINATE_DEPTHS[source_member]
            or any(type(value) is not int or value < 0 for value in coordinates)
            or relative != prefix + "_".join(map(str, coordinates))
            or relative in seen
            or type(item_size) is not int
            or item_size <= 0
            or item.get("owner_id") != CACHE_OWNER
            or HEX64.fullmatch(item.get("sha256", "")) is None
        ):
            reject("generated-cache file record is invalid")
        pure = PurePosixPath(relative)
        if pure.is_absolute() or any(part in {"", ".", ".."} for part in pure.parts):
            reject("generated-cache path is unsafe")
        seen.add(relative)
        observed_total += item_size
        if allocation_unit_bytes is not None:
            allocated_total += allocated_size(item_size, allocation_unit_bytes)
    content_set_sha256 = hashlib.sha256(
        json.dumps(generated, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if observed_total != total:
        reject("generated-cache byte total does not reconcile")
    if content_set_sha256 != document.get("generated_content_set_sha256"):
        reject("generated-cache content-set identity does not reconcile")
    result: dict[str, int | str] = {
        "generated_file_count": count,
        "generated_total_bytes": total,
        "generated_content_set_sha256": content_set_sha256,
    }
    if allocation_unit_bytes is not None:
        result["generated_allocation_unit_bytes"] = allocated_total
    return result


def canonical_size(document: dict[str, Any]) -> int:
    return len(
        (json.dumps(document, indent=2, sort_keys=True, allow_nan=False) + "\n").encode(
            "utf-8"
        )
    )


def current_state_size(authority: dict[str, Any], authority_sha256: str) -> int:
    return canonical_size({
        "schema_version": 1,
        "owner": OWNER,
        "release_id": authority["release_id"],
        "authority_sha256": authority_sha256,
        "default_archive_sha256": authority["runtimes"]["default"]["archive_sha256"],
        "seeded_archive_sha256": authority["runtimes"]["seeded"]["archive_sha256"],
        "seeded_config_sha256": authority["runtimes"]["seeded"]["runtime_config_sha256"],
    })


def load_bound_authority(
    path: Path, expected_sha256: str, authority_schema_path: Path
) -> tuple[dict[str, Any], int]:
    _sha(expected_sha256, "expected runtime authority SHA-256")
    before_size, before_hash, _ = stable_file_identity(
        path, MAX_JSON_BYTES, "runtime authority"
    )
    if before_hash != expected_sha256:
        reject("runtime authority identity mismatch")
    authority = load_authority(
        path, authority_schema_path, expected_sha256=expected_sha256
    )
    after_size, after_hash, _ = stable_file_identity(
        path, MAX_JSON_BYTES, "runtime authority"
    )
    if (before_size, before_hash) != (after_size, after_hash):
        reject("runtime authority changed during validation")
    return authority, before_size


def calculate(
    authority_path: Path,
    expected_authority_sha256: str,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    *,
    authority_schema_path: Path = DEFAULT_AUTHORITY_SCHEMA,
    capacity_schema_path: Path = DEFAULT_CAPACITY_SCHEMA,
    allocation_unit_bytes: int | None = None,
) -> dict[str, Any]:
    if allocation_unit_bytes is not None:
        allocation_unit_bytes = allocation_unit(allocation_unit_bytes)
    _, capacity_schema_sha256, _ = stable_file_identity(
        capacity_schema_path, MAX_JSON_BYTES, "capacity schema"
    )
    capacity = load_capacity_schema(capacity_schema_path)
    _, authority_schema_sha256, _ = stable_file_identity(
        authority_schema_path, MAX_JSON_BYTES, "runtime authority schema"
    )
    authority_schema = load_schema(authority_schema_path)
    authority, authority_size = load_bound_authority(
        authority_path, expected_authority_sha256, authority_schema_path
    )
    cache_document, cache_size = strict_json(
        cache_contract_path,
        capacity["maximum_cache_contract_bytes"],
        expected_cache_contract_sha256,
        "generated-cache contract",
    )
    cache = validate_cache_contract(
        cache_document, authority, allocation_unit_bytes
    )
    official = authority["official_source"]["archive"]
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]

    generation_components = {
        "generated_cache": cache["generated_total_bytes"],
        "default_patched_game_droid": default["game_droid"]["size"],
        "seeded_patched_game_droid": seeded["game_droid"]["size"],
        "default_output_archive": default["archive_size"],
        "seeded_output_archive": seeded["archive_size"],
        "staged_official_mirror": official["size"],
        "staged_default_config_mirror": default["runtime_config_size"],
        "staged_seeded_config": seeded["runtime_config_size"],
        "maximum_authority_reserve": authority_schema["maximum_authority_bytes"],
        "generation_margin": capacity["generation_margin_bytes"],
    }
    generation_bytes = sum(generation_components.values())
    generation_files = cache["generated_file_count"] + 8
    generation_inodes = generation_files + capacity["generation_metadata_inodes"]
    activation = {
        "required_free_logical_bytes": capacity["activation_metadata_bytes"],
        "required_free_inodes": capacity["activation_metadata_inodes"],
    }
    restore = {
        "required_free_logical_bytes": official["size"]
        + capacity["restore_metadata_bytes"],
        "required_free_inodes": 1 + capacity["restore_metadata_inodes"],
    }
    reinstall = {
        "required_free_logical_bytes": generation_bytes,
        "required_free_inodes": generation_inodes,
    }
    first_install = {
        "required_free_logical_bytes": generation_bytes + official["size"],
        "required_free_inodes": generation_inodes + 1,
    }
    generation_capacity_components: dict[str, int] | None = None
    if allocation_unit_bytes is not None:
        generation_capacity_components = {
            "generated_cache": cache["generated_allocation_unit_bytes"],
            "default_patched_game_droid": allocated_size(
                default["game_droid"]["size"], allocation_unit_bytes
            ),
            "seeded_patched_game_droid": allocated_size(
                seeded["game_droid"]["size"], allocation_unit_bytes
            ),
            "default_output_archive": allocated_size(
                default["archive_size"], allocation_unit_bytes
            ),
            "seeded_output_archive": allocated_size(
                seeded["archive_size"], allocation_unit_bytes
            ),
            "staged_official_mirror": allocated_size(
                official["size"], allocation_unit_bytes
            ),
            "staged_default_config_mirror": allocated_size(
                default["runtime_config_size"], allocation_unit_bytes
            ),
            "staged_seeded_config": allocated_size(
                seeded["runtime_config_size"], allocation_unit_bytes
            ),
            "maximum_authority_reserve": allocated_size(
                authority_schema["maximum_authority_bytes"],
                allocation_unit_bytes,
            ),
            # This is an explicit free-space reserve, not one regular file.
            "generation_margin": capacity["generation_margin_bytes"],
        }
        generation_capacity_bytes = sum(generation_capacity_components.values())
        activation["required_free_capacity_bytes"] = allocated_size(
            capacity["activation_metadata_bytes"], allocation_unit_bytes
        )
        restore["required_free_capacity_bytes"] = allocated_size(
            official["size"], allocation_unit_bytes
        ) + allocated_size(capacity["restore_metadata_bytes"], allocation_unit_bytes)
        reinstall["required_free_capacity_bytes"] = generation_capacity_bytes
        first_install["required_free_capacity_bytes"] = (
            generation_capacity_bytes
            + allocated_size(official["size"], allocation_unit_bytes)
        )
    authority_allocated = (
        allocated_size(authority_size, allocation_unit_bytes)
        if allocation_unit_bytes is not None
        else None
    )
    current_size = current_state_size(authority, expected_authority_sha256)
    current_allocated = (
        allocated_size(current_size, allocation_unit_bytes)
        if allocation_unit_bytes is not None
        else None
    )
    installed_pair = {
        "official_archive_bytes": official["size"],
        "official_archive_sha256": official["sha256"],
        "default_archive_bytes": default["archive_size"],
        "seeded_archive_bytes": seeded["archive_size"],
        "seeded_config_bytes": seeded["runtime_config_size"],
        "authority_bytes": authority_size,
        "current_state_bytes": current_size,
    }
    if allocation_unit_bytes is not None:
        installed_pair.update(
            {
                "official_archive_capacity_bytes": allocated_size(
                    official["size"], allocation_unit_bytes
                ),
                "default_archive_capacity_bytes": allocated_size(
                    default["archive_size"], allocation_unit_bytes
                ),
                "seeded_archive_capacity_bytes": allocated_size(
                    seeded["archive_size"], allocation_unit_bytes
                ),
                "seeded_config_capacity_bytes": allocated_size(
                    seeded["runtime_config_size"], allocation_unit_bytes
                ),
                "authority_capacity_bytes": authority_allocated,
                "current_state_capacity_bytes": current_allocated,
            }
        )
    inputs = {
        "runtime_authority_sha256": expected_authority_sha256,
        "runtime_authority_size": authority_size,
        "cache_contract_sha256": expected_cache_contract_sha256,
        "cache_contract_size": cache_size,
        "capacity_schema_sha256": capacity_schema_sha256,
        "authority_schema_sha256": authority_schema_sha256,
        "release_id": authority["release_id"],
    }
    if allocation_unit_bytes is not None:
        inputs["allocation_unit_bytes"] = allocation_unit_bytes
    claims = {
        "payload_embedded": False,
        "logical_byte_floor_only": allocation_unit_bytes is None,
        "regular_file_allocation_unit_ceiling_calculated": (
            allocation_unit_bytes is not None
        ),
        "allocated_filesystem_blocks_measured": False,
        "directory_metadata_allocation_measured": False,
        "physical_target_executed": False,
        "production_pair_generated": False,
        "safe_profile_approved": False,
    }
    result = {
        "schema_version": 1,
        "status": (
            "runtime_pair_allocation_unit_capacity_host_model"
            if allocation_unit_bytes is not None
            else "runtime_pair_logical_capacity_host_model"
        ),
        "inputs": inputs,
        "cache": cache,
        "generation_components_logical_bytes": generation_components,
        "floors": {
            "activation_after_complete_stage": activation,
            "restore_complete_pair": restore,
            "reinstall_from_exact_official": reinstall,
            "first_install_from_unpreserved_official": first_install,
        },
        "installed_pair": installed_pair,
        "claims": claims,
    }
    if generation_capacity_components is not None:
        result["generation_components_capacity_bytes"] = (
            generation_capacity_components
        )
    return result


def restore_first_migration(prior: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    if prior["schema_version"] != 1 or new["schema_version"] != 1:
        reject("migration capacity model schema mismatch")
    prior_pair = prior["installed_pair"]
    new_pair = new["installed_pair"]
    if (
        prior_pair.get("official_archive_bytes")
        != new_pair.get("official_archive_bytes")
        or prior_pair.get("official_archive_sha256")
        != new_pair.get("official_archive_sha256")
    ):
        reject("migration authorities do not share the exact official source")
    prior_restore = prior["floors"]["restore_complete_pair"]
    new_generation = new["floors"]["reinstall_from_exact_official"]
    official_bytes = prior_pair["official_archive_bytes"]
    reclaimed_bytes = max(
        0,
        prior_pair["default_archive_bytes"]
        + prior_pair["seeded_archive_bytes"]
        + prior_pair["seeded_config_bytes"]
        + prior_pair["authority_bytes"]
        + prior_pair["current_state_bytes"]
        - official_bytes,
    )
    reclaimed_inodes = 4
    required_bytes = max(
        prior_restore["required_free_logical_bytes"],
        max(0, new_generation["required_free_logical_bytes"] - reclaimed_bytes),
    )
    required_inodes = max(
        prior_restore["required_free_inodes"],
        max(0, new_generation["required_free_inodes"] - reclaimed_inodes),
    )
    result = {
        "ordering": "restore-prior-completely-before-generating-new-pair",
        "old_new_pair_overlap_bytes_budgeted": 0,
        "reclaimed_after_prior_restore_logical_bytes": reclaimed_bytes,
        "reclaimed_after_prior_restore_inodes": reclaimed_inodes,
        "required_initial_free_logical_bytes": required_bytes,
        "required_initial_free_inodes": required_inodes,
        "formula": "max(prior_restore_floor,new_reinstall_floor-prior_restore_reclaim)",
        "prior_authority_sha256": prior["inputs"]["runtime_authority_sha256"],
        "new_authority_sha256": new["inputs"]["runtime_authority_sha256"],
    }
    prior_unit = prior["inputs"].get("allocation_unit_bytes")
    new_unit = new["inputs"].get("allocation_unit_bytes")
    if (prior_unit is None) != (new_unit is None):
        reject("migration capacity models use different capacity bases")
    if prior_unit is not None:
        if prior_unit != new_unit:
            reject("migration capacity models use different allocation units")
        reclaimed_capacity = max(
            0,
            prior_pair["default_archive_capacity_bytes"]
            + prior_pair["seeded_archive_capacity_bytes"]
            + prior_pair["seeded_config_capacity_bytes"]
            + prior_pair["authority_capacity_bytes"]
            + prior_pair["current_state_capacity_bytes"]
            - prior_pair["official_archive_capacity_bytes"],
        )
        result.update(
            {
                "allocation_unit_bytes": prior_unit,
                "reclaimed_after_prior_restore_capacity_bytes": reclaimed_capacity,
                "required_initial_free_capacity_bytes": max(
                    prior_restore["required_free_capacity_bytes"],
                    max(
                        0,
                        new_generation["required_free_capacity_bytes"]
                        - reclaimed_capacity,
                    ),
                ),
            }
        )
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authority", type=Path, required=True)
    parser.add_argument("--expected-authority-sha256", required=True)
    parser.add_argument("--cache-contract", type=Path, required=True)
    parser.add_argument("--expected-cache-contract-sha256", required=True)
    parser.add_argument("--authority-schema", type=Path, default=DEFAULT_AUTHORITY_SCHEMA)
    parser.add_argument("--capacity-schema", type=Path, default=DEFAULT_CAPACITY_SCHEMA)
    parser.add_argument("--allocation-unit-bytes", type=int)
    arguments = parser.parse_args()
    try:
        result = calculate(
            arguments.authority,
            arguments.expected_authority_sha256,
            arguments.cache_contract,
            arguments.expected_cache_contract_sha256,
            authority_schema_path=arguments.authority_schema,
            capacity_schema_path=arguments.capacity_schema,
            allocation_unit_bytes=arguments.allocation_unit_bytes,
        )
    except (RuntimePairCapacityError, ValueError, OSError) as exc:
        print(f"runtime pair capacity: FAIL: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
