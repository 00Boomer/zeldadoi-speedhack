"""Read-only V2 authority through the existing installed-pair verification.

Do not change ownership,locks,archives,save paths or transaction schemas.
This successor supplies only the shared exact-byte authority reader.
"""
from types import FunctionType
import bounded_runtime_pair_verify as legacy
import runtime_authority_shared_v2 as authority


def verify_installed_pair(game_root, expected_authority_sha256, *,
        schema_path=authority.DEFAULT_SCHEMA, lock_lease=None,
        require_complete_install=False, allow_pending_install_commit=False,
        expected_default_override_template_sha256=None):
    scope = dict(vars(legacy), load_schema=authority.load_schema,
                 load_authority=authority.load_authority)
    function = FunctionType(legacy.verify_installed_pair.__code__, scope,
        legacy.verify_installed_pair.__name__, legacy.verify_installed_pair.__defaults__)
    function.__kwdefaults__ = legacy.verify_installed_pair.__kwdefaults__
    result = function(game_root, expected_authority_sha256, schema_path=schema_path,
        lock_lease=lock_lease, require_complete_install=require_complete_install,
        allow_pending_install_commit=allow_pending_install_commit,
        expected_default_override_template_sha256=expected_default_override_template_sha256)
    return dict(result, runtime_architecture=authority.ARCHITECTURE,
        exact_shared_payload_verified=True, in_game_mode_capability_qualified=False)
