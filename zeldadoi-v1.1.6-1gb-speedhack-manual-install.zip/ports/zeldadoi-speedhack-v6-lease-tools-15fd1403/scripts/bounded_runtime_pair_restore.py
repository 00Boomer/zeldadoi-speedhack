#!/usr/bin/env python3
"""Crash-recoverable exact restore for the installed ZeldaDOI runtime pair.

The component restores the default archive from the preserved exact official
source and removes only the independently authorized seeded/pair-owned files.
It does not remove user configuration, saves, telemetry, or unknown files.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path
from typing import Any

import bounded_installer_journal as installer_journal
import bounded_runtime_pair_activation as activation
import bounded_runtime_pair_verify as pair_verify
import build_runtime_authority as authority_builder
import runtime_pair_capacity as capacity_model
from bounded_runtime_lock import (
    OWNER,
    RuntimeLockLease,
    fsync_directory,
    runtime_lock,
)
from runtime_authority import DEFAULT_SCHEMA, RELEASE_ID, load_authority, load_schema


RESTORE_JOURNAL = "runtime-pair-restore.json"
RESTORE_JOURNAL_NEXT = "runtime-pair-restore.next"
RESTORE_STAGE_PREFIX = ".zeldadoi-runtime-pair-restore-"
RESTORE_CANDIDATE_PREFIX = ".zeldadoi.port.runtime-pair-restore-next-"
QUARANTINE_FILES = {
    "seeded_archive": "zeldadoi.seeded.port",
    "seeded_config": "gmloader-seeded.json",
    "authority": "runtime-authority.json",
    "current": "runtime-pair-current.json",
}
PHASES = (
    "validated",
    "candidate-created",
    "seeded-archive-quarantined",
    "seeded-config-quarantined",
    "authority-quarantined",
    "current-quarantined",
    "default-official-restored",
    "cleanup-complete",
)
CLEANUP_CHECKPOINTS = (
    "cleanup-seeded-archive",
    "cleanup-seeded-config",
    "cleanup-authority",
    "cleanup-current",
    "cleanup-stage-removed",
)
INJECTION_POINTS = PHASES + ("after-default-replace",) + CLEANUP_CHECKPOINTS
JOURNAL_KEYS = {
    "schema_version",
    "owner",
    "release_id",
    "authority_sha256",
    "authority_size",
    "official_archive_sha256",
    "official_archive_size",
    "default_archive_sha256",
    "default_archive_size",
    "default_config_sha256",
    "default_config_size",
    "seeded_archive_sha256",
    "seeded_archive_size",
    "seeded_config_sha256",
    "seeded_config_size",
    "current_sha256",
    "current_size",
    "cache_contract_sha256",
    "capacity_schema_sha256",
    "restore_required_free_logical_bytes",
    "restore_required_free_capacity_bytes",
    "restore_required_free_inodes",
    "capacity_allocation_unit_bytes",
    "capacity_logical_floor_only",
    "capacity_regular_file_allocation_unit_ceiling_calculated",
    "stage_basename",
    "candidate_basename",
    "phase",
}
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
MAX_SIZE = 1 << 40


class RuntimePairRestoreError(ValueError):
    """The restore state is unsafe, foreign, or identity-inconsistent."""


def reject(message: str) -> None:
    raise RuntimePairRestoreError(message)


def canonical_bytes(document: dict[str, Any]) -> bytes:
    return (
        json.dumps(document, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")


def current_document(authority: dict[str, Any], authority_sha256: str) -> dict[str, Any]:
    return activation.validate_current(
        {
            "schema_version": 1,
            "owner": OWNER,
            "release_id": authority["release_id"],
            "authority_sha256": authority_sha256,
            "default_archive_sha256": authority["runtimes"]["default"][
                "archive_sha256"
            ],
            "seeded_archive_sha256": authority["runtimes"]["seeded"][
                "archive_sha256"
            ],
            "seeded_config_sha256": authority["runtimes"]["seeded"][
                "runtime_config_sha256"
            ],
        }
    )


def validate_record(document: dict[str, Any]) -> dict[str, Any]:
    version = document.get("schema_version") if type(document) is dict else None
    if type(version) is not int or version not in (3, 4):
        reject("runtime-pair restore schema mismatch")
    keys = JOURNAL_KEYS | {"install_current_sha256"} if version == 4 else JOURNAL_KEYS
    activation.validate_document_keys(document, keys, "runtime-pair restore")
    if document["owner"] != OWNER:
        reject("runtime-pair restore owner mismatch")
    release_id = document["release_id"]
    if type(release_id) is not str or RELEASE_ID.fullmatch(release_id) is None:
        reject("runtime-pair restore release ID is invalid")
    for key in keys:
        value = document[key]
        if key == "install_current_sha256" and value is None:
            continue
        if key.endswith("_sha256") and (
            type(value) is not str or HEX64.fullmatch(value) is None
        ):
            reject(f"runtime-pair restore digest is invalid: {key}")
        if key.endswith("_size") and (
            type(value) is not int or value <= 0 or value > MAX_SIZE
        ):
            reject(f"runtime-pair restore size is invalid: {key}")
    if (
        type(document["restore_required_free_logical_bytes"]) is not int
        or document["restore_required_free_logical_bytes"] <= 0
        or type(document["restore_required_free_capacity_bytes"]) is not int
        or document["restore_required_free_capacity_bytes"] <= 0
        or type(document["restore_required_free_inodes"]) is not int
        or document["restore_required_free_inodes"] <= 0
        or type(document["capacity_allocation_unit_bytes"]) is not int
        or document["capacity_allocation_unit_bytes"] <= 0
        or document["capacity_logical_floor_only"] is not False
        or document[
            "capacity_regular_file_allocation_unit_ceiling_calculated"
        ] is not True
    ):
        reject("runtime-pair restore capacity receipt is invalid")
    if document["stage_basename"] != RESTORE_STAGE_PREFIX + release_id:
        reject("runtime-pair restore stage basename mismatch")
    if document["candidate_basename"] != RESTORE_CANDIDATE_PREFIX + release_id:
        reject("runtime-pair restore candidate basename mismatch")
    if document["phase"] not in PHASES:
        reject("runtime-pair restore phase is invalid")
    return dict(document)


def static_record_equal(left: dict[str, Any], right: dict[str, Any]) -> bool:
    return left.keys() == right.keys() and all(
        left[key] == right[key] for key in left.keys() - {"phase"}
    )


def write_record(state: Path, record: dict[str, Any]) -> None:
    activation.write_atomic(
        state,
        RESTORE_JOURNAL,
        RESTORE_JOURNAL_NEXT,
        canonical_bytes(validate_record(record)),
    )


def advance_record(state: Path, record: dict[str, Any], phase: str) -> dict[str, Any]:
    current_index = PHASES.index(record["phase"])
    if current_index + 1 >= len(PHASES) or PHASES[current_index + 1] != phase:
        reject("runtime-pair restore phase advance must be exactly monotonic")
    updated = dict(record)
    updated["phase"] = phase
    write_record(state, updated)
    return updated


def reconcile_pending_record(state: Path, expected_authority_sha256: str) -> None:
    target = state / RESTORE_JOURNAL
    pending = state / RESTORE_JOURNAL_NEXT
    if not pending.exists() and not pending.is_symlink():
        return
    pending_record = validate_record(
        activation.read_json(pending, "pending runtime-pair restore")
    )
    if pending_record["authority_sha256"] != expected_authority_sha256:
        reject("pending runtime-pair restore authority mismatch")
    if target.exists() or target.is_symlink():
        current = validate_record(
            activation.read_json(target, "runtime-pair restore")
        )
        if not static_record_equal(current, pending_record):
            reject("pending runtime-pair restore release mismatch")
        current_index = PHASES.index(current["phase"])
        if (
            current_index + 1 >= len(PHASES)
            or pending_record["phase"] != PHASES[current_index + 1]
        ):
            reject("pending runtime-pair restore is not the exact next phase")
    elif pending_record["phase"] != "validated":
        reject("orphan pending runtime-pair restore is not the initial phase")
    os.replace(pending, target)
    fsync_directory(state)


def verify_record_authority(
    record: dict[str, Any], authority: dict[str, Any], schema: dict[str, Any]
) -> None:
    official = schema["official_source"]["archive"]
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    expected = {
        "release_id": authority["release_id"],
        "authority_sha256": record["authority_sha256"],
        "official_archive_sha256": official["sha256"],
        "official_archive_size": official["size"],
        "default_archive_sha256": default["archive_sha256"],
        "default_archive_size": default["archive_size"],
        "default_config_sha256": default["runtime_config_sha256"],
        "default_config_size": default["runtime_config_size"],
        "seeded_archive_sha256": seeded["archive_sha256"],
        "seeded_archive_size": seeded["archive_size"],
        "seeded_config_sha256": seeded["runtime_config_sha256"],
        "seeded_config_size": seeded["runtime_config_size"],
    }
    for key, value in expected.items():
        if record[key] != value:
            reject(f"runtime-pair restore authority mismatch: {key}")
    current_payload = canonical_bytes(
        current_document(authority, record["authority_sha256"])
    )
    if (
        record["current_size"] != len(current_payload)
        or record["current_sha256"] != hashlib.sha256(current_payload).hexdigest()
    ):
        reject("runtime-pair restore current-state authority mismatch")


def make_record(
    authority: dict[str, Any],
    schema: dict[str, Any],
    authority_sha256: str,
    authority_size: int,
    capacity: dict[str, Any],
) -> dict[str, Any]:
    official = schema["official_source"]["archive"]
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    current_payload = canonical_bytes(current_document(authority, authority_sha256))
    return validate_record(
        {
            "schema_version": 4,
            "install_current_sha256": None,
            "owner": OWNER,
            "release_id": authority["release_id"],
            "authority_sha256": authority_sha256,
            "authority_size": authority_size,
            "official_archive_sha256": official["sha256"],
            "official_archive_size": official["size"],
            "default_archive_sha256": default["archive_sha256"],
            "default_archive_size": default["archive_size"],
            "default_config_sha256": default["runtime_config_sha256"],
            "default_config_size": default["runtime_config_size"],
            "seeded_archive_sha256": seeded["archive_sha256"],
            "seeded_archive_size": seeded["archive_size"],
            "seeded_config_sha256": seeded["runtime_config_sha256"],
            "seeded_config_size": seeded["runtime_config_size"],
            "current_sha256": hashlib.sha256(current_payload).hexdigest(),
            "current_size": len(current_payload),
            "cache_contract_sha256": capacity["cache_contract_sha256"],
            "capacity_schema_sha256": capacity["capacity_schema_sha256"],
            "restore_required_free_logical_bytes": capacity[
                "required_free_logical_bytes"
            ],
            "restore_required_free_capacity_bytes": capacity[
                "required_free_capacity_bytes"
            ],
            "restore_required_free_inodes": capacity["required_free_inodes"],
            "capacity_allocation_unit_bytes": capacity[
                "allocation_unit_bytes"
            ],
            "capacity_logical_floor_only": capacity["logical_floor_only"],
            "capacity_regular_file_allocation_unit_ceiling_calculated": capacity[
                "regular_file_allocation_unit_ceiling_calculated"
            ],
            "stage_basename": RESTORE_STAGE_PREFIX + authority["release_id"],
            "candidate_basename": RESTORE_CANDIDATE_PREFIX
            + authority["release_id"],
            "phase": "validated",
        }
    )


def fixed_paths(
    root: Path, state: Path, schema: dict[str, Any], authority: dict[str, Any]
) -> dict[str, Path]:
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    return {
        "preserved": authority_builder.fixed_path(
            root,
            schema["official_source"]["archive"]["path"],
            "preserved official archive",
        ),
        "default_archive": authority_builder.fixed_path(
            root, default["archive_path"], "default runtime archive"
        ),
        "default_config": authority_builder.fixed_path(
            root, default["runtime_config_path"], "default runtime config"
        ),
        "seeded_archive": authority_builder.fixed_path(
            root, seeded["archive_path"], "seeded runtime archive"
        ),
        "seeded_config": authority_builder.fixed_path(
            root, seeded["runtime_config_path"], "seeded runtime config"
        ),
        "authority": authority_builder.fixed_path(
            root, schema["authority_manifest_path"], "runtime authority"
        ),
        "current": state / activation.PAIR_CURRENT,
    }


def restore_capacity_receipt(
    root: Path,
    authority_path: Path,
    expected_authority_sha256: str,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    schema_path: Path,
    capacity_schema_path: Path,
) -> dict[str, Any]:
    """Calculate the authority-bound complete-pair restore floor."""
    stats = os.statvfs(root)
    model = capacity_model.calculate(
        authority_path,
        expected_authority_sha256,
        cache_contract_path,
        expected_cache_contract_sha256,
        authority_schema_path=schema_path,
        capacity_schema_path=capacity_schema_path,
        allocation_unit_bytes=stats.f_frsize,
    )
    floor = model["floors"]["restore_complete_pair"]
    return {
        "capacity_model_status": model["status"],
        "cache_contract_sha256": model["inputs"]["cache_contract_sha256"],
        "capacity_schema_sha256": model["inputs"]["capacity_schema_sha256"],
        "required_free_logical_bytes": floor["required_free_logical_bytes"],
        "required_free_capacity_bytes": floor["required_free_capacity_bytes"],
        "required_free_inodes": floor["required_free_inodes"],
        "allocation_unit_bytes": stats.f_frsize,
        "logical_floor_only": model["claims"]["logical_byte_floor_only"],
        "regular_file_allocation_unit_ceiling_calculated": model["claims"][
            "regular_file_allocation_unit_ceiling_calculated"
        ],
    }


def enforce_restore_capacity(
    root: Path,
    authority_path: Path,
    expected_authority_sha256: str,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    schema_path: Path,
    capacity_schema_path: Path,
) -> dict[str, Any]:
    """Enforce the initial restore floor before creating a transaction journal."""
    receipt = restore_capacity_receipt(
        root,
        authority_path,
        expected_authority_sha256,
        cache_contract_path,
        expected_cache_contract_sha256,
        schema_path,
        capacity_schema_path,
    )
    stats = os.statvfs(root)
    available_bytes = stats.f_bavail * stats.f_frsize
    available_inodes = stats.f_favail
    if stats.f_frsize != receipt["allocation_unit_bytes"]:
        reject("filesystem allocation unit changed before runtime-pair restore")
    capacity_model.enforce_filesystem_capacity(
        root, stats, receipt["required_free_capacity_bytes"], receipt["required_free_inodes"],
        "runtime-pair restore", reject,
    )
    return {
        **receipt,
        "available_logical_bytes": available_bytes,
        "available_inodes": available_inodes,
    }


def verify_archive(
    path: Path, size: int, digest: str, game_droid: dict[str, Any], label: str
) -> None:
    observed = authority_builder.archive_identity(path, label)
    if observed != {"size": size, "sha256": digest, "game_droid": game_droid}:
        reject(f"{label} identity mismatch")


def verify_installed_pair(
    root: Path,
    state: Path,
    schema_path: Path,
    expected_authority_sha256: str,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    capacity_schema_path: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Path], dict[str, Any]]:
    schema = load_schema(schema_path)
    authority_path = root / schema["authority_manifest_path"]
    authority = load_authority(
        authority_path, schema_path, expected_sha256=expected_authority_sha256
    )
    authority_size, authority_sha256 = activation.file_identity(
        authority_path, "installed runtime authority"
    )
    if authority_sha256 != expected_authority_sha256:
        reject("installed runtime authority changed after validation")
    paths = fixed_paths(root, state, schema, authority)
    official_schema = schema["official_source"]
    verify_archive(
        paths["preserved"],
        official_schema["archive"]["size"],
        official_schema["archive"]["sha256"],
        official_schema["game_droid"],
        "preserved official archive",
    )
    for role in ("default", "seeded"):
        runtime = authority["runtimes"][role]
        verify_archive(
            paths[f"{role}_archive"],
            runtime["archive_size"],
            runtime["archive_sha256"],
            runtime["game_droid"],
            f"installed {role} runtime archive",
        )
        config = authority_builder.config_identity(
            paths[f"{role}_config"],
            runtime["archive_path"],
            f"installed {role} runtime config",
        )
        if config != {
            "size": runtime["runtime_config_size"],
            "sha256": runtime["runtime_config_sha256"],
        }:
            reject(f"installed {role} runtime config identity mismatch")
    expected_current = current_document(authority, expected_authority_sha256)
    observed_current = activation.validate_current(
        activation.read_json(paths["current"], "runtime-pair current state")
    )
    if observed_current != expected_current:
        reject("runtime-pair current state mismatch")
    current_size, current_sha256 = activation.file_identity(
        paths["current"], "runtime-pair current state"
    )
    capacity = enforce_restore_capacity(
        root,
        authority_path,
        expected_authority_sha256,
        cache_contract_path,
        expected_cache_contract_sha256,
        schema_path,
        capacity_schema_path,
    )
    record = make_record(
        authority, schema, expected_authority_sha256, authority_size, capacity
    )
    if (
        current_size != record["current_size"]
        or current_sha256 != record["current_sha256"]
    ):
        reject("runtime-pair current state is not canonical")
    return schema, authority, paths, record


def reject_other_transactions(
    root: Path, state: Path, allowed_stage: str | None, allowed_candidate: str | None
) -> None:
    forbidden_names = {
        activation.PAIR_JOURNAL,
        activation.PAIR_JOURNAL_NEXT,
        activation.PAIR_CURRENT_NEXT,
        installer_journal.TRANSACTION_NAME,
        installer_journal.TRANSACTION_NEXT_NAME,
        "current.next",
        "runtime-pair-preserve.json",
        "runtime-pair-preserve.next",
        pair_verify.INSTALL_CURRENT_NEXT,
    }
    for entry in state.iterdir():
        if entry.name in forbidden_names:
            reject(f"another installer transaction is unfinished: {entry.name}")
        if (
            entry.name.startswith(activation.STAGE_PREFIX)
            or entry.name.startswith(".zeldadoi-bounded-stage-")
            or (
                entry.name.startswith(RESTORE_STAGE_PREFIX)
                and entry.name != allowed_stage
            )
        ):
            reject(f"foreign or unfinished installer stage is present: {entry.name}")
    for entry in root.iterdir():
        if (
            entry.name.startswith(".zeldadoi.port.bounded-next-")
            or (
                entry.name.startswith(RESTORE_CANDIDATE_PREFIX)
                and entry.name != allowed_candidate
            )
        ):
            reject(f"foreign or unfinished installer candidate is present: {entry.name}")


def all_absent(paths: tuple[Path, ...]) -> bool:
    return all(not path.exists() and not path.is_symlink() for path in paths)


def already_restored(
    root: Path, state: Path, schema: dict[str, Any]
) -> dict[str, Any] | None:
    official = schema["official_source"]
    preserved = authority_builder.fixed_path(
        root, official["archive"]["path"], "preserved official archive"
    )
    active = root / schema["runtimes"]["default"]["archive_path"]
    try:
        verify_archive(
            preserved,
            official["archive"]["size"],
            official["archive"]["sha256"],
            official["game_droid"],
            "preserved official archive",
        )
        verify_archive(
            active,
            official["archive"]["size"],
            official["archive"]["sha256"],
            official["game_droid"],
            "restored default archive",
        )
    except (OSError, ValueError):
        return None
    pair_paths = (
        root / schema["runtimes"]["seeded"]["archive_path"],
        root / schema["runtimes"]["seeded"]["runtime_config_path"],
        root / schema["authority_manifest_path"],
        state / activation.PAIR_CURRENT,
        state / pair_verify.INSTALL_CURRENT,
        state / pair_verify.INSTALL_CURRENT_NEXT,
    )
    if not all_absent(pair_paths):
        reject("official active archive has unexpected runtime-pair owned state")
    reject_other_transactions(root, state, None, None)
    return {
        "status": "runtime_pair_restore_already_official",
        "official_archive_sha256": official["archive"]["sha256"],
        "recovered": False,
    }


def record_paths(root: Path, state: Path, record: dict[str, Any]) -> dict[str, Path]:
    stage = state / record["stage_basename"]
    return {
        "stage": stage,
        "candidate": root / record["candidate_basename"],
        "default_archive": root / "zeldadoi.port",
        "preserved": root / "zeldadoi.official-v1.1.6.port",
        "seeded_archive": root / "zeldadoi.seeded.port",
        "seeded_config": state / "gmloader-seeded.json",
        "authority": state / "runtime-authority.json",
        "current": state / activation.PAIR_CURRENT,
        "q_seeded_archive": stage / QUARANTINE_FILES["seeded_archive"],
        "q_seeded_config": stage / QUARANTINE_FILES["seeded_config"],
        "q_authority": stage / QUARANTINE_FILES["authority"],
        "q_current": stage / QUARANTINE_FILES["current"],
    }


def ensure_stage(state: Path, stage: Path) -> None:
    if not stage.exists() and not stage.is_symlink():
        stage.mkdir(mode=0o700)
        fsync_directory(state)
    if stage.is_symlink() or not stage.is_dir():
        reject("runtime-pair restore stage is unsafe")


def stage_inventory(stage: Path) -> None:
    allowed = set(QUARANTINE_FILES.values())
    for entry in stage.iterdir():
        if entry.name not in allowed:
            reject(f"runtime-pair restore stage contains foreign entry: {entry.name}")
        if entry.is_symlink() or not entry.is_file():
            reject(f"runtime-pair restore stage entry is unsafe: {entry.name}")


def copy_official_candidate(source: Path, candidate: Path, record: dict[str, Any]) -> None:
    if candidate.exists() or candidate.is_symlink():
        try:
            activation.verify_file(
                candidate,
                record["official_archive_size"],
                record["official_archive_sha256"],
                "existing runtime-pair restore candidate",
            )
            return
        except ValueError:
            metadata = candidate.lstat()
            if (
                stat.S_ISLNK(metadata.st_mode)
                or not stat.S_ISREG(metadata.st_mode)
                or metadata.st_nlink != 1
                or metadata.st_size > record["official_archive_size"]
            ):
                reject("interrupted restore candidate is unsafe or foreign")
            # The durable validated journal and fixed previously-absent basename
            # establish ownership of this incomplete copy.  No other phase may
            # repair or remove an identity-mismatched candidate.
            candidate.unlink()
            fsync_directory(candidate.parent)
    source_fd, opened = authority_builder.open_regular(
        source, authority_builder.MAX_ARCHIVE_BYTES, "preserved official archive"
    )
    target_fd = -1
    try:
        target_fd = os.open(
            candidate,
            os.O_WRONLY
            | os.O_CREAT
            | os.O_EXCL
            | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        copied = 0
        while block := os.read(source_fd, 1024 * 1024):
            view = memoryview(block)
            while view:
                written = os.write(target_fd, view)
                if written <= 0:
                    reject("runtime-pair restore candidate write failed")
                view = view[written:]
            copied += len(block)
        if copied != opened.st_size:
            reject("preserved official archive changed during copy")
        os.fchmod(target_fd, 0o644)
        os.fsync(target_fd)
    finally:
        os.close(source_fd)
        if target_fd >= 0:
            os.close(target_fd)
    fsync_directory(candidate.parent)
    activation.verify_file(
        candidate,
        record["official_archive_size"],
        record["official_archive_sha256"],
        "runtime-pair restore candidate",
    )


def location_state(path: Path, size: int, digest: str, label: str) -> str:
    if not path.exists() and not path.is_symlink():
        return "absent"
    activation.verify_file(path, size, digest, label)
    return "exact"


def quarantine_one(
    source: Path,
    target: Path,
    size: int,
    digest: str,
    label: str,
) -> None:
    source_state = location_state(source, size, digest, f"installed {label}")
    target_state = location_state(target, size, digest, f"quarantined {label}")
    if source_state == "exact" and target_state == "absent":
        activation.atomic_activate_no_replace(source, target)
        fsync_directory(source.parent)
        fsync_directory(target.parent)
        return
    if source_state == "absent" and target_state == "exact":
        return
    reject(f"{label} must exist in exactly one installed or quarantine location")


def checkpoint(name: str, fail_after: str | None) -> None:
    if fail_after == name:
        raise RuntimeError(f"injected runtime-pair restore interruption after {name}")


def verify_recovery_authority(
    root: Path,
    state: Path,
    record: dict[str, Any],
    schema_path: Path,
) -> dict[str, Any] | None:
    paths = record_paths(root, state, record)
    installed = paths["authority"]
    quarantined = paths["q_authority"]
    locations = [
        path
        for path in (installed, quarantined)
        if path.exists() or path.is_symlink()
    ]
    if len(locations) == 1:
        authority = load_authority(
            locations[0], schema_path, expected_sha256=record["authority_sha256"]
        )
        activation.verify_file(
            locations[0],
            record["authority_size"],
            record["authority_sha256"],
            "runtime-pair restore authority",
        )
        verify_record_authority(record, authority, load_schema(schema_path))
        return authority
    if len(locations) > 1:
        reject("runtime authority exists in multiple restore locations")
    if PHASES.index(record["phase"]) < PHASES.index("default-official-restored"):
        reject("runtime authority disappeared before restore commitment")
    return None


def verify_recovery_capacity(
    root: Path,
    state: Path,
    record: dict[str, Any],
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    schema_path: Path,
    capacity_schema_path: Path,
) -> None:
    """Revalidate the recorded initial floor without blocking on current space."""
    if PHASES.index(record["phase"]) >= PHASES.index(
        "default-official-restored"
    ):
        return
    paths = record_paths(root, state, record)
    locations = [
        path
        for path in (paths["authority"], paths["q_authority"])
        if path.exists() or path.is_symlink()
    ]
    if len(locations) != 1:
        reject("runtime authority location is ambiguous during capacity recovery")
    receipt = restore_capacity_receipt(
        root,
        locations[0],
        record["authority_sha256"],
        cache_contract_path,
        expected_cache_contract_sha256,
        schema_path,
        capacity_schema_path,
    )
    expected = {
        "cache_contract_sha256": receipt["cache_contract_sha256"],
        "capacity_schema_sha256": receipt["capacity_schema_sha256"],
        "restore_required_free_logical_bytes": receipt[
            "required_free_logical_bytes"
        ],
        "restore_required_free_capacity_bytes": receipt[
            "required_free_capacity_bytes"
        ],
        "restore_required_free_inodes": receipt["required_free_inodes"],
        "capacity_allocation_unit_bytes": receipt["allocation_unit_bytes"],
        "capacity_logical_floor_only": receipt["logical_floor_only"],
        "capacity_regular_file_allocation_unit_ceiling_calculated": receipt[
            "regular_file_allocation_unit_ceiling_calculated"
        ],
    }
    for key, value in expected.items():
        if record[key] != value:
            reject(f"runtime-pair restore capacity receipt mismatch: {key}")


def validate_phase_layout(
    root: Path,
    state: Path,
    paths: dict[str, Path],
    record: dict[str, Any],
    schema_path: Path,
) -> None:
    """Reject inconsistent recovery state before performing another mutation."""
    schema = load_schema(schema_path)
    official = schema["official_source"]
    verify_archive(
        paths["preserved"],
        official["archive"]["size"],
        official["archive"]["sha256"],
        official["game_droid"],
        "preserved official archive during pair restore",
    )
    activation.verify_file(
        root / "gmloader.json",
        record["default_config_size"],
        record["default_config_sha256"],
        "default runtime config during pair restore",
    )

    phase_index = PHASES.index(record["phase"])
    default_index = PHASES.index("default-official-restored")
    active = activation.classify_file(
        paths["default_archive"],
        (
            (
                "default",
                record["default_archive_size"],
                record["default_archive_sha256"],
            ),
            (
                "official",
                record["official_archive_size"],
                record["official_archive_sha256"],
            ),
        ),
        "default archive in runtime-pair restore state",
    )
    try:
        candidate = location_state(
            paths["candidate"],
            record["official_archive_size"],
            record["official_archive_sha256"],
            "runtime-pair restore candidate",
        )
    except ValueError:
        metadata = paths["candidate"].lstat()
        if (
            record["phase"] != "validated"
            or stat.S_ISLNK(metadata.st_mode)
            or not stat.S_ISREG(metadata.st_mode)
            or metadata.st_nlink != 1
            or metadata.st_size > record["official_archive_size"]
        ):
            reject("interrupted restore candidate is unsafe or foreign")
        candidate = "owned-incomplete"
    if phase_index < PHASES.index("candidate-created"):
        # The exact candidate is the permitted copy-before-journal-update window.
        if active != "default" or candidate not in {
            "absent",
            "exact",
            "owned-incomplete",
        }:
            reject("validated runtime-pair restore layout is inconsistent")
    elif phase_index < default_index:
        rename_window = (
            record["phase"] == "current-quarantined"
            and active == "official"
            and candidate == "absent"
        )
        if not rename_window and not (active == "default" and candidate == "exact"):
            reject("pre-activation runtime-pair restore layout is inconsistent")
    elif active != "official" or candidate != "absent":
        reject("committed runtime-pair restore archive layout is inconsistent")

    if paths["stage"].exists() or paths["stage"].is_symlink():
        if paths["stage"].is_symlink() or not paths["stage"].is_dir():
            reject("runtime-pair restore stage is unsafe")
        stage_inventory(paths["stage"])
    first_quarantine = PHASES.index("seeded-archive-quarantined")
    if first_quarantine <= phase_index < default_index and not paths["stage"].is_dir():
        reject("runtime-pair restore stage disappeared before commitment")

    components = (
        (
            "seeded-archive-quarantined",
            "seeded_archive",
            "q_seeded_archive",
            "seeded_archive_size",
            "seeded_archive_sha256",
            "seeded runtime archive",
        ),
        (
            "seeded-config-quarantined",
            "seeded_config",
            "q_seeded_config",
            "seeded_config_size",
            "seeded_config_sha256",
            "seeded runtime config",
        ),
        (
            "authority-quarantined",
            "authority",
            "q_authority",
            "authority_size",
            "authority_sha256",
            "runtime authority",
        ),
        (
            "current-quarantined",
            "current",
            "q_current",
            "current_size",
            "current_sha256",
            "runtime-pair current state",
        ),
    )
    for phase, source_key, target_key, size_key, digest_key, label in components:
        threshold = PHASES.index(phase)
        source_status = location_state(
            paths[source_key], record[size_key], record[digest_key], f"installed {label}"
        )
        target_status = location_state(
            paths[target_key],
            record[size_key],
            record[digest_key],
            f"quarantined {label}",
        )
        if phase_index < threshold:
            move_window = (
                phase_index + 1 == threshold
                and source_status == "absent"
                and target_status == "exact"
            )
            if not move_window and not (
                source_status == "exact" and target_status == "absent"
            ):
                reject(f"pre-quarantine {label} layout is inconsistent")
        elif phase_index < default_index:
            if source_status != "absent" or target_status != "exact":
                reject(f"quarantined {label} layout is inconsistent")
        elif source_status != "absent" or target_status not in {"absent", "exact"}:
            reject(f"committed {label} cleanup layout is inconsistent")


def cleanup_quarantine(
    paths: dict[str, Path], record: dict[str, Any], fail_after: str | None
) -> None:
    stage = paths["stage"]
    if not stage.exists() and not stage.is_symlink():
        return
    if stage.is_symlink() or not stage.is_dir():
        reject("runtime-pair restore cleanup stage is unsafe")
    stage_inventory(stage)
    cleanup = (
        (
            "q_seeded_archive",
            record["seeded_archive_size"],
            record["seeded_archive_sha256"],
            "cleanup-seeded-archive",
        ),
        (
            "q_seeded_config",
            record["seeded_config_size"],
            record["seeded_config_sha256"],
            "cleanup-seeded-config",
        ),
        (
            "q_authority",
            record["authority_size"],
            record["authority_sha256"],
            "cleanup-authority",
        ),
        (
            "q_current",
            record["current_size"],
            record["current_sha256"],
            "cleanup-current",
        ),
    )
    for key, size, digest, marker in cleanup:
        path = paths[key]
        if path.exists() or path.is_symlink():
            activation.verify_file(path, size, digest, f"runtime-pair {marker}")
            path.unlink()
            fsync_directory(stage)
        checkpoint(marker, fail_after)
    if any(stage.iterdir()):
        reject("runtime-pair restore stage is not empty after exact cleanup")
    stage.rmdir()
    fsync_directory(stage.parent)
    checkpoint("cleanup-stage-removed", fail_after)


def run_restore(
    root: Path,
    state: Path,
    record: dict[str, Any],
    schema_path: Path,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    capacity_schema_path: Path,
    fail_after: str | None,
) -> dict[str, Any]:
    paths = record_paths(root, state, record)
    reject_other_transactions(
        root, state, record["stage_basename"], record["candidate_basename"]
    )
    authority = verify_recovery_authority(root, state, record, schema_path)
    verify_recovery_capacity(
        root,
        state,
        record,
        cache_contract_path,
        expected_cache_contract_sha256,
        schema_path,
        capacity_schema_path,
    )
    validate_phase_layout(root, state, paths, record, schema_path)

    marker = state / pair_verify.INSTALL_CURRENT
    if marker.exists() or marker.is_symlink():
        marker_sha = record.get("install_current_sha256")
        if record["schema_version"] != 4 or record["phase"] != "validated" or (
            authority is None or marker_sha is None
        ):
            reject("install completion marker is unexpected in this Restore state")
        pair_verify.verify_install_current(state, authority, record["authority_sha256"])
        if activation.file_identity(marker, "install completion marker")[1] != marker_sha:
            reject("install completion marker changed since Restore began")
        marker.unlink()
        fsync_directory(state)

    phase_index = PHASES.index(record["phase"])
    if phase_index < PHASES.index("candidate-created"):
        copy_official_candidate(paths["preserved"], paths["candidate"], record)
        record = advance_record(state, record, "candidate-created")
        checkpoint("candidate-created", fail_after)

    quarantine_steps = (
        (
            "seeded-archive-quarantined",
            "seeded_archive",
            "q_seeded_archive",
            "seeded_archive_size",
            "seeded_archive_sha256",
            "seeded runtime archive",
        ),
        (
            "seeded-config-quarantined",
            "seeded_config",
            "q_seeded_config",
            "seeded_config_size",
            "seeded_config_sha256",
            "seeded runtime config",
        ),
        (
            "authority-quarantined",
            "authority",
            "q_authority",
            "authority_size",
            "authority_sha256",
            "runtime authority",
        ),
        (
            "current-quarantined",
            "current",
            "q_current",
            "current_size",
            "current_sha256",
            "runtime-pair current state",
        ),
    )
    for next_phase, source_key, target_key, size_key, digest_key, label in quarantine_steps:
        if PHASES.index(record["phase"]) < PHASES.index(next_phase):
            ensure_stage(state, paths["stage"])
            stage_inventory(paths["stage"])
            quarantine_one(
                paths[source_key],
                paths[target_key],
                record[size_key],
                record[digest_key],
                label,
            )
            record = advance_record(state, record, next_phase)
            checkpoint(next_phase, fail_after)

    if PHASES.index(record["phase"]) < PHASES.index("default-official-restored"):
        active_state = activation.classify_file(
            paths["default_archive"],
            (
                (
                    "default",
                    record["default_archive_size"],
                    record["default_archive_sha256"],
                ),
                (
                    "official",
                    record["official_archive_size"],
                    record["official_archive_sha256"],
                ),
            ),
            "default archive at restore activation",
        )
        candidate_state = location_state(
            paths["candidate"],
            record["official_archive_size"],
            record["official_archive_sha256"],
            "official restore candidate before activation",
        )
        if active_state == "default" and candidate_state == "exact":
            os.replace(paths["candidate"], paths["default_archive"])
            fsync_directory(root)
            checkpoint("after-default-replace", fail_after)
        elif not (active_state == "official" and candidate_state == "absent"):
            reject("default archive restore rename window is inconsistent")
        record = advance_record(state, record, "default-official-restored")
        checkpoint("default-official-restored", fail_after)

    activation.verify_file(
        paths["default_archive"],
        record["official_archive_size"],
        record["official_archive_sha256"],
        "restored official default archive",
    )
    if not all_absent(
        (
            paths["seeded_archive"],
            paths["seeded_config"],
            paths["authority"],
            paths["current"],
            paths["candidate"],
        )
    ):
        reject("restored pair retains an installed owned artifact")

    if record["phase"] == "default-official-restored":
        cleanup_quarantine(paths, record, fail_after)
        record = advance_record(state, record, "cleanup-complete")
        checkpoint("cleanup-complete", fail_after)
    elif record["phase"] == "cleanup-complete":
        if paths["stage"].exists() or paths["stage"].is_symlink():
            reject("cleanup-complete restore retains a stage")
    else:
        reject("runtime-pair restore did not reach a final phase")

    journal = state / RESTORE_JOURNAL
    observed_journal = validate_record(
        activation.read_json(
            journal, "runtime-pair restore journal before removal"
        )
    )
    if observed_journal != record:
        reject("runtime-pair restore journal changed before removal")
    journal.unlink()
    fsync_directory(state)
    return {
        "status": "runtime_pair_restore_complete",
        "release_id": record["release_id"],
        "official_archive_sha256": record["official_archive_sha256"],
        "recovered": True,
        "restore_capacity": {
            "cache_contract_sha256": record["cache_contract_sha256"],
            "capacity_schema_sha256": record["capacity_schema_sha256"],
            "required_free_logical_bytes": record[
                "restore_required_free_logical_bytes"
            ],
            "required_free_capacity_bytes": record[
                "restore_required_free_capacity_bytes"
            ],
            "required_free_inodes": record["restore_required_free_inodes"],
            "allocation_unit_bytes": record["capacity_allocation_unit_bytes"],
            "logical_floor_only": record["capacity_logical_floor_only"],
            "regular_file_allocation_unit_ceiling_calculated": record[
                "capacity_regular_file_allocation_unit_ceiling_calculated"
            ],
        },
        "restore_capacity_initial_preflight_enforced": True,
        "user_files_touched": False,
        "physical_target_executed": False,
        "safe_profile_approved": False,
    }


def restore_pair(
    game_root: Path,
    expected_authority_sha256: str,
    *,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    schema_path: Path = DEFAULT_SCHEMA,
    capacity_schema_path: Path = capacity_model.DEFAULT_CAPACITY_SCHEMA,
    fail_after: str | None = None,
    lock_lease: RuntimeLockLease | None = None,
) -> dict[str, Any]:
    if type(expected_authority_sha256) is not str or HEX64.fullmatch(
        expected_authority_sha256
    ) is None:
        reject("expected runtime authority must be a lowercase SHA-256")
    if fail_after is not None and fail_after not in INJECTION_POINTS:
        reject("unknown runtime-pair restore interruption checkpoint")
    root = authority_builder.fixed_root(game_root)
    state = root / ".zeldadoi-speedhack"
    activation.require_state_owner(state)
    schema = load_schema(schema_path)

    with runtime_lock(state, lock_lease):
        recovering = any(
            (state / name).exists() or (state / name).is_symlink()
            for name in (RESTORE_JOURNAL, RESTORE_JOURNAL_NEXT)
        )
        reconcile_pending_record(state, expected_authority_sha256)
        journal_path = state / RESTORE_JOURNAL
        if not journal_path.exists() and not journal_path.is_symlink():
            restored = already_restored(root, state, schema)
            if restored is not None:
                restored.update(
                    {
                        "restore_capacity_initial_preflight_enforced": False,
                        "user_files_touched": False,
                        "physical_target_executed": False,
                        "safe_profile_approved": False,
                    }
                )
                return restored
            reject_other_transactions(root, state, None, None)
            _, _, _, record = verify_installed_pair(
                root,
                state,
                schema_path,
                expected_authority_sha256,
                cache_contract_path,
                expected_cache_contract_sha256,
                capacity_schema_path,
            )
            marker = state / pair_verify.INSTALL_CURRENT
            if marker.exists() or marker.is_symlink():
                authority = load_authority(
                    state / "runtime-authority.json",
                    schema_path,
                    expected_sha256=expected_authority_sha256,
                )
                pair_verify.verify_install_current(
                    state, authority, expected_authority_sha256
                )
                record["install_current_sha256"] = activation.file_identity(
                    marker, "install completion marker"
                )[1]
            write_record(state, record)
            checkpoint("validated", fail_after)
        else:
            record = validate_record(
                activation.read_json(journal_path, "runtime-pair restore")
            )
            if record["authority_sha256"] != expected_authority_sha256:
                reject("runtime-pair restore expected authority mismatch")
            if (
                record["official_archive_size"]
                != schema["official_source"]["archive"]["size"]
                or record["official_archive_sha256"]
                != schema["official_source"]["archive"]["sha256"]
            ):
                reject("runtime-pair restore official source authority mismatch")
        result = run_restore(
            root,
            state,
            record,
            schema_path,
            cache_contract_path,
            expected_cache_contract_sha256,
            capacity_schema_path,
            fail_after,
        )
        result["recovered"] = recovering
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-root", type=Path, required=True)
    parser.add_argument("--expected-authority-sha256", required=True)
    parser.add_argument("--cache-contract", type=Path, required=True)
    parser.add_argument("--cache-contract-sha256", required=True)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument(
        "--capacity-schema",
        type=Path,
        default=capacity_model.DEFAULT_CAPACITY_SCHEMA,
    )
    args = parser.parse_args()
    try:
        result = restore_pair(
            args.game_root,
            args.expected_authority_sha256,
            cache_contract_path=args.cache_contract,
            expected_cache_contract_sha256=args.cache_contract_sha256,
            schema_path=args.schema,
            capacity_schema_path=args.capacity_schema,
        )
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"runtime-pair restore failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
