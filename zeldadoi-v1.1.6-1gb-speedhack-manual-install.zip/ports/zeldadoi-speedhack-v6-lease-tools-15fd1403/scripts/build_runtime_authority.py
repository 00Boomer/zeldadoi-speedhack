#!/usr/bin/env python3
"""Build a deterministic, payload-free dual-runtime authority document."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, NoReturn

from runtime_authority import (
    DEFAULT_SCHEMA,
    RuntimeAuthorityError,
    load_schema,
    validate_document,
)


GAME_DROID_MEMBER = "assets/game.droid"
MAX_CONFIG_BYTES = 1024 * 1024
MAX_ARCHIVE_BYTES = 1024 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 4096
MAX_EXPANDED_BYTES = 1024 * 1024 * 1024


class RuntimeAuthorityBuildError(ValueError):
    """A fixed input or atomic-output invariant failed."""


def reject(message: str) -> NoReturn:
    raise RuntimeAuthorityBuildError(message)


def reject_duplicate_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            reject(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_nonfinite(token: str) -> NoReturn:
    reject(f"non-finite JSON value is forbidden: {token}")


def fixed_root(root: Path) -> Path:
    absolute = Path(os.path.abspath(root))
    try:
        metadata = absolute.lstat()
    except OSError as exc:
        reject(f"cannot stat runtime root: {exc}")
    if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
        reject("runtime root must be a real directory")
    if absolute.resolve() != absolute:
        reject("runtime root must not traverse symbolic path components")
    return absolute


def fixed_path(root: Path, relative: str, label: str) -> Path:
    pure = PurePosixPath(relative)
    if (
        pure.is_absolute()
        or not pure.parts
        or any(part in {"", ".", ".."} for part in pure.parts)
        or pure.as_posix() != relative
    ):
        reject(f"{label} schema path is unsafe")
    path = root.joinpath(*pure.parts)
    cursor = root
    for part in pure.parts[:-1]:
        cursor /= part
        if cursor.is_symlink() or not cursor.is_dir():
            reject(f"{label} parent is missing or unsafe")
    return path


def open_regular(path: Path, maximum: int, label: str) -> tuple[int, os.stat_result]:
    try:
        initial = path.lstat()
    except OSError as exc:
        reject(f"cannot stat {label}: {exc}")
    if stat.S_ISLNK(initial.st_mode) or not stat.S_ISREG(initial.st_mode):
        reject(f"{label} must be a regular non-symlink file")
    if initial.st_nlink != 1:
        reject(f"{label} must not be hard-linked")
    if initial.st_size < 1 or initial.st_size > maximum:
        reject(f"{label} size is outside its bound")
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        reject(f"cannot open {label} safely: {exc}")
    opened = os.fstat(descriptor)
    if (
        not stat.S_ISREG(opened.st_mode)
        or (opened.st_dev, opened.st_ino) != (initial.st_dev, initial.st_ino)
        or opened.st_nlink != 1
        or opened.st_size != initial.st_size
    ):
        os.close(descriptor)
        reject(f"{label} changed while opening")
    return descriptor, opened


def config_identity(path: Path, expected_apk_path: str, label: str) -> dict[str, Any]:
    descriptor, opened = open_regular(path, MAX_CONFIG_BYTES, label)
    try:
        chunks: list[bytes] = []
        remaining = MAX_CONFIG_BYTES + 1
        while remaining:
            block = os.read(descriptor, min(65536, remaining))
            if not block:
                break
            chunks.append(block)
            remaining -= len(block)
        payload = b"".join(chunks)
        final = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    if (
        len(payload) != opened.st_size
        or final.st_size != opened.st_size
        or final.st_mtime_ns != opened.st_mtime_ns
        or final.st_ctime_ns != opened.st_ctime_ns
    ):
        reject(f"{label} changed while reading")
    if payload.startswith(b"\xef\xbb\xbf"):
        reject(f"{label} must not contain a UTF-8 BOM")
    try:
        document = json.loads(
            payload.decode("utf-8"),
            object_pairs_hook=reject_duplicate_pairs,
            parse_constant=reject_nonfinite,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        reject(f"{label} is not strict JSON: {exc}")
    if not isinstance(document, dict) or document.get("apk_path") != expected_apk_path:
        reject(f"{label} apk_path does not name the fixed archive")
    return {
        "size": len(payload),
        "sha256": hashlib.sha256(payload).hexdigest(),
    }


def safe_archive_member(info: zipfile.ZipInfo, seen: set[str], label: str) -> None:
    name = info.filename
    path = PurePosixPath(name)
    unix_type = (info.external_attr >> 16) & 0o170000
    if (
        not name
        or name in seen
        or "\\" in name
        or path.is_absolute()
        or not path.parts
        or any(part in {"", ".", ".."} for part in path.parts)
        or unix_type == stat.S_IFLNK
        or info.flag_bits & 0x1
    ):
        reject(f"{label} has an unsafe archive member")
    seen.add(name)


def archive_identity(path: Path, label: str) -> dict[str, Any]:
    descriptor, opened = open_regular(path, MAX_ARCHIVE_BYTES, label)
    try:
        with os.fdopen(descriptor, "rb", closefd=True) as handle:
            digest = hashlib.sha256()
            while chunk := handle.read(1024 * 1024):
                digest.update(chunk)
            handle.seek(0)
            try:
                with zipfile.ZipFile(handle) as archive:
                    members = archive.infolist()
                    if not members or len(members) > MAX_ARCHIVE_MEMBERS:
                        reject(f"{label} member count is outside its bound")
                    seen: set[str] = set()
                    expanded = 0
                    game_droid: list[zipfile.ZipInfo] = []
                    for info in members:
                        safe_archive_member(info, seen, label)
                        expanded += info.file_size
                        if expanded > MAX_EXPANDED_BYTES:
                            reject(f"{label} expanded size exceeds its bound")
                        if info.filename == GAME_DROID_MEMBER:
                            game_droid.append(info)
                    if len(game_droid) != 1 or game_droid[0].is_dir():
                        reject(f"{label} must contain one regular {GAME_DROID_MEMBER}")
                    member_digest = hashlib.sha256()
                    with archive.open(game_droid[0]) as member:
                        while chunk := member.read(1024 * 1024):
                            member_digest.update(chunk)
            except zipfile.BadZipFile as exc:
                reject(f"{label} is not a readable ZIP archive: {exc}")
            final = os.fstat(handle.fileno())
    except OSError as exc:
        reject(f"cannot read {label}: {exc}")
    if (
        final.st_size != opened.st_size
        or final.st_mtime_ns != opened.st_mtime_ns
        or final.st_ctime_ns != opened.st_ctime_ns
    ):
        reject(f"{label} changed while reading")
    return {
        "size": opened.st_size,
        "sha256": digest.hexdigest(),
        "game_droid": {
            "member": GAME_DROID_MEMBER,
            "size": game_droid[0].file_size,
            "sha256": member_digest.hexdigest(),
        },
    }


def build_document(root: Path, release_id: str, schema: dict[str, Any]) -> dict[str, Any]:
    root = fixed_root(root)
    official_schema = schema["official_source"]
    runtime_schema = schema["runtimes"]
    official_path = fixed_path(
        root, official_schema["archive"]["path"], "preserved official archive"
    )
    official = archive_identity(official_path, "preserved official archive")
    if (
        official["size"] != official_schema["archive"]["size"]
        or official["sha256"] != official_schema["archive"]["sha256"]
        or official["game_droid"] != official_schema["game_droid"]
    ):
        reject("preserved official source identity is mismatched")

    runtime_records: dict[str, dict[str, Any]] = {}
    for role in ("default", "seeded"):
        fixed = runtime_schema[role]
        config_path = fixed_path(
            root, fixed["runtime_config_path"], f"{role} runtime configuration"
        )
        archive_path = fixed_path(
            root, fixed["archive_path"], f"{role} runtime archive"
        )
        config = config_identity(
            config_path, fixed["archive_path"], f"{role} runtime configuration"
        )
        archive = archive_identity(archive_path, f"{role} runtime archive")
        runtime_records[role] = {
            "runtime_config_path": fixed["runtime_config_path"],
            "runtime_config_size": config["size"],
            "runtime_config_sha256": config["sha256"],
            "archive_path": fixed["archive_path"],
            "archive_size": archive["size"],
            "archive_sha256": archive["sha256"],
            "game_droid": archive["game_droid"],
        }

    document = {
        "schema_version": schema["authority_manifest_schema_version"],
        "authority_kind": schema["authority_kind"],
        "release_id": release_id,
        "official_source": official_schema,
        "dungeon_seed": schema["dungeon_seed"],
        "runtimes": runtime_records,
    }
    try:
        return validate_document(document, schema)
    except RuntimeAuthorityError as exc:
        reject(f"generated runtime authority is invalid: {exc}")


def canonical_bytes(document: dict[str, Any]) -> bytes:
    return (
        json.dumps(document, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")


def fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_no_replace(path: Path, payload: bytes) -> None:
    if path.exists() or path.is_symlink():
        reject("refusing to overwrite runtime authority")
    parent = path.parent
    if parent.is_symlink() or not parent.is_dir():
        reject("runtime authority parent is missing or unsafe")
    temporary: Path | None = None
    linked = False
    try:
        descriptor, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=parent)
        temporary = Path(name)
        os.fchmod(descriptor, 0o644)
        with os.fdopen(descriptor, "wb", closefd=True) as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path, follow_symlinks=False)
        linked = True
        fsync_directory(parent)
    except FileExistsError:
        reject("refusing to overwrite runtime authority")
    finally:
        if temporary is not None:
            try:
                temporary.unlink()
                fsync_directory(parent)
            except FileNotFoundError:
                pass
    if not linked or path.is_symlink() or not path.is_file():
        reject("runtime authority activation failed")


def build(root: Path, release_id: str, schema_path: Path) -> dict[str, Any]:
    schema = load_schema(schema_path)
    fixed = fixed_root(root)
    output = fixed_path(
        fixed, schema["authority_manifest_path"], "runtime authority output"
    )
    document = build_document(fixed, release_id, schema)
    payload = canonical_bytes(document)
    write_no_replace(output, payload)
    return {
        "schema_version": 1,
        "status": "dual_runtime_authority_generated",
        "release_id": release_id,
        "authority_relative_path": schema["authority_manifest_path"],
        "authority_bytes": len(payload),
        "authority_sha256": hashlib.sha256(payload).hexdigest(),
        "official_source_verified": True,
        "default_runtime_verified": True,
        "seeded_runtime_verified": True,
        "payload_embedded": False,
        "installer_integrated": False,
        "production_authority": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--release-id", required=True)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    args = parser.parse_args()
    try:
        result = build(args.root, args.release_id, args.schema)
    except (OSError, KeyError, TypeError, RuntimeAuthorityBuildError,
            RuntimeAuthorityError) as exc:
        print(json.dumps({"status": "invalid", "error": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
