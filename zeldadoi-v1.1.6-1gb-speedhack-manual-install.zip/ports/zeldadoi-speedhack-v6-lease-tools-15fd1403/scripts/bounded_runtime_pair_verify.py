#!/usr/bin/env python3
"""Strictly read-only verification of an installed ZeldaDOI runtime pair.

The verifier consumes an independently supplied runtime-authority SHA-256.  It
does not acquire or recover an installer lock, reconcile pending state, remove
staging data, or otherwise mutate the installation.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import bounded_installer_journal as installer_journal
import bounded_runtime_pair_activation as activation
from bounded_runtime_lock import RuntimeLockLease, verify_runtime_lock_lease
import build_runtime_authority as authority_builder
from runtime_authority import DEFAULT_SCHEMA, load_authority, load_schema


HEX64 = re.compile(r"[0-9a-f]{64}\Z")
INSTALL_CURRENT = "runtime-pair-install-current.json"
INSTALL_CURRENT_NEXT = "runtime-pair-install-current.next"
INSTALL_DISPOSITIONS = {
    "created_in_game_authority_default_override",
    "preserved_existing_user_override",
}
INSTALL_CURRENT_KEYS = {
    "schema_version",
    "owner",
    "release_id",
    "authority_sha256",
    "default_override_template_sha256",
    "default_override_disposition",
    "phase",
}
PAIR_TRANSIENT_NAMES = {
    activation.PAIR_JOURNAL,
    activation.PAIR_JOURNAL_NEXT,
    activation.PAIR_CURRENT_NEXT,
    "lock",
}
INSTALLER_TRANSIENT_NAMES = {
    "current.next",
    installer_journal.TRANSACTION_NAME,
    installer_journal.TRANSACTION_NEXT_NAME,
    "runtime-pair-preserve.json",
    "runtime-pair-preserve.next",
    "runtime-pair-restore.json",
    "runtime-pair-restore.next",
    INSTALL_CURRENT_NEXT,
}
INSTALLER_TRANSIENT_PREFIXES = (
    ".zeldadoi-bounded-stage-",
    ".zeldadoi.port.bounded-next-",
    ".zeldadoi-runtime-pair-restore-",
)


class RuntimePairVerifyError(ValueError):
    """The installed pair is incomplete, unsafe, or identity-mismatched."""


def reject(message: str) -> None:
    raise RuntimePairVerifyError(message)


def exact_identity(observed: dict[str, Any], expected: dict[str, Any], label: str) -> None:
    if observed != expected:
        reject(f"{label} identity mismatch")


def verify_no_unfinished_state(
    state: Path,
    release_id: str,
    *,
    allow_held_lock: bool = False,
    allow_pending_install_commit: bool = False,
) -> None:
    expected_stage = activation.STAGE_PREFIX + release_id
    for entry in state.iterdir():
        name = entry.name
        if name == "lock" and allow_held_lock:
            continue
        if name == INSTALL_CURRENT_NEXT and allow_pending_install_commit:
            continue
        if (
            name in PAIR_TRANSIENT_NAMES
            or name in INSTALLER_TRANSIENT_NAMES
            or name == expected_stage
            or name.startswith(activation.STAGE_PREFIX)
            or name.startswith(INSTALLER_TRANSIENT_PREFIXES)
        ):
            reject(f"unfinished installer/runtime-pair state is present: {name}")


def expected_current_document(
    authority: dict[str, Any], expected_authority_sha256: str
) -> dict[str, Any]:
    return activation.validate_current(
        {
            "schema_version": 1,
            "owner": activation.OWNER,
            "release_id": authority["release_id"],
            "authority_sha256": expected_authority_sha256,
            "default_archive_sha256": authority["runtimes"]["default"][
                "archive_sha256"
            ],
            "seeded_archive_sha256": authority["runtimes"]["seeded"][
                "archive_sha256"
            ],
            "seeded_config_sha256": authority["runtimes"]["seeded"][
                "runtime_config_sha256"
            ],
        }
    )


def validate_install_current(document: dict[str, Any]) -> dict[str, Any]:
    """Validate the final complete-install publication marker."""
    if set(document) != INSTALL_CURRENT_KEYS:
        reject("runtime-pair install-current key coverage mismatch")
    if document["schema_version"] != 1 or document["owner"] != activation.OWNER:
        reject("runtime-pair install-current schema or owner mismatch")
    if (
        type(document["release_id"]) is not str
        or not document["release_id"]
        or type(document["authority_sha256"]) is not str
        or HEX64.fullmatch(document["authority_sha256"]) is None
        or type(document["default_override_template_sha256"]) is not str
        or HEX64.fullmatch(document["default_override_template_sha256"]) is None
    ):
        reject("runtime-pair install-current identity is invalid")
    if document["default_override_disposition"] not in INSTALL_DISPOSITIONS:
        reject("runtime-pair install-current override disposition is invalid")
    if document["phase"] != "complete":
        reject("runtime-pair install-current phase is not complete")
    return dict(document)


def verify_install_current(
    state: Path,
    authority: dict[str, Any],
    expected_authority_sha256: str,
    expected_default_override_template_sha256: str | None = None,
) -> dict[str, Any]:
    """Read and bind the complete-install marker without mutating state."""
    pending = state / INSTALL_CURRENT_NEXT
    if pending.exists() or pending.is_symlink():
        reject("pending runtime-pair install-current state is present")
    marker = state / INSTALL_CURRENT
    if marker.is_symlink() or not marker.is_file() or marker.stat().st_nlink != 1:
        reject("runtime-pair complete-install marker is missing or unsafe")
    observed = validate_install_current(
        activation.read_json(marker, "runtime-pair complete-install marker")
    )
    if (
        observed["release_id"] != authority["release_id"]
        or observed["authority_sha256"] != expected_authority_sha256
    ):
        reject("runtime-pair complete-install marker authority mismatch")
    if expected_default_override_template_sha256 is not None:
        if (
            type(expected_default_override_template_sha256) is not str
            or HEX64.fullmatch(expected_default_override_template_sha256) is None
            or observed["default_override_template_sha256"]
            != expected_default_override_template_sha256
        ):
            reject("runtime-pair complete-install marker template identity mismatch")
    return observed


def verify_installed_pair(
    game_root: Path,
    expected_authority_sha256: str,
    *,
    schema_path: Path = DEFAULT_SCHEMA,
    lock_lease: RuntimeLockLease | None = None,
    require_complete_install: bool = False,
    allow_pending_install_commit: bool = False,
    expected_default_override_template_sha256: str | None = None,
) -> dict[str, Any]:
    """Verify the final installed pair without changing any filesystem state."""
    if HEX64.fullmatch(expected_authority_sha256) is None:
        reject("expected runtime authority must be a lowercase SHA-256")

    root = authority_builder.fixed_root(game_root)
    state = root / ".zeldadoi-speedhack"
    activation.require_state_owner(state)
    if lock_lease is not None:
        verify_runtime_lock_lease(state, lock_lease)
    if allow_pending_install_commit and lock_lease is None:
        reject("pending install-commit allowance requires the held operation lease")
    schema = load_schema(schema_path)
    authority_path = authority_builder.fixed_path(
        root, schema["authority_manifest_path"], "runtime authority"
    )
    authority = load_authority(
        authority_path,
        schema_path,
        expected_sha256=expected_authority_sha256,
    )
    _, observed_authority_sha256 = activation.file_identity(
        authority_path, "installed runtime authority"
    )
    if observed_authority_sha256 != expected_authority_sha256:
        reject("runtime authority identity changed after validation")

    official_rule = schema["official_source"]
    official_path = authority_builder.fixed_path(
        root, official_rule["archive"]["path"], "preserved official archive"
    )
    official = authority_builder.archive_identity(
        official_path, "preserved official archive"
    )
    exact_identity(
        official,
        {
            "size": official_rule["archive"]["size"],
            "sha256": official_rule["archive"]["sha256"],
            "game_droid": official_rule["game_droid"],
        },
        "preserved official archive",
    )

    verified: dict[str, dict[str, Any]] = {}
    for role in ("default", "seeded"):
        runtime = authority["runtimes"][role]
        archive_path = authority_builder.fixed_path(
            root, runtime["archive_path"], f"installed {role} runtime archive"
        )
        archive = authority_builder.archive_identity(
            archive_path, f"installed {role} runtime archive"
        )
        exact_identity(
            archive,
            {
                "size": runtime["archive_size"],
                "sha256": runtime["archive_sha256"],
                "game_droid": runtime["game_droid"],
            },
            f"installed {role} runtime archive",
        )

        config_path = authority_builder.fixed_path(
            root,
            runtime["runtime_config_path"],
            f"installed {role} runtime configuration",
        )
        config = authority_builder.config_identity(
            config_path,
            runtime["archive_path"],
            f"installed {role} runtime configuration",
        )
        exact_identity(
            config,
            {
                "size": runtime["runtime_config_size"],
                "sha256": runtime["runtime_config_sha256"],
            },
            f"installed {role} runtime configuration",
        )
        verified[role] = {"archive": archive, "config": config}

    observed_current = activation.validate_current(
        activation.read_json(
            state / activation.PAIR_CURRENT, "runtime-pair current state"
        )
    )
    if observed_current != expected_current_document(
        authority, expected_authority_sha256
    ):
        reject("runtime-pair current state does not match the authority")
    install_current = None
    if require_complete_install:
        if expected_default_override_template_sha256 is None:
            reject("complete-install verification requires the expected template identity")
        install_current = verify_install_current(
            state,
            authority,
            expected_authority_sha256,
            expected_default_override_template_sha256,
        )
    verify_no_unfinished_state(
        state,
        authority["release_id"],
        allow_held_lock=lock_lease is not None,
        allow_pending_install_commit=allow_pending_install_commit,
    )
    if lock_lease is not None:
        verify_runtime_lock_lease(state, lock_lease)

    return {
        "schema_version": 1,
        "status": "installed_runtime_pair_verified_read_only",
        "release_id": authority["release_id"],
        "authority_sha256": expected_authority_sha256,
        "official_archive_sha256": official["sha256"],
        "official_game_droid_sha256": official["game_droid"]["sha256"],
        "default_archive_sha256": verified["default"]["archive"]["sha256"],
        "default_game_droid_sha256": verified["default"]["archive"][
            "game_droid"
        ]["sha256"],
        "default_config_sha256": verified["default"]["config"]["sha256"],
        "seeded_archive_sha256": verified["seeded"]["archive"]["sha256"],
        "seeded_game_droid_sha256": verified["seeded"]["archive"][
            "game_droid"
        ]["sha256"],
        "seeded_config_sha256": verified["seeded"]["config"]["sha256"],
        "read_only": True,
        "complete_install_required": require_complete_install,
        "complete_install_verified": install_current is not None,
        "host_contract_only": True,
        "schema2_installer_integrated": False,
        "production_authority": False,
        "physical_target_executed": False,
        "safe_profile_approved": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-root", type=Path, required=True)
    parser.add_argument("--expected-authority-sha256", required=True)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument(
        "--expected-default-override-template-sha256", required=True
    )
    args = parser.parse_args()
    try:
        result = verify_installed_pair(
            args.game_root,
            args.expected_authority_sha256,
            schema_path=args.schema,
            require_complete_install=True,
            expected_default_override_template_sha256=(
                args.expected_default_override_template_sha256
            ),
        )
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"installed runtime-pair verification failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
