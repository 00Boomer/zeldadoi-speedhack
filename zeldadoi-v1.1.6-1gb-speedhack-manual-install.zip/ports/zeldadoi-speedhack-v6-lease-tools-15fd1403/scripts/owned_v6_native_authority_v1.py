"""Inactive exact V6 native companion to the existing shared-payload authority.

No installer, launcher default or production approval is changed. This module
validates a separately pinned, qualification-only enrollment and checks the
same providers used by the accepted private native. It never executes a file.
"""
import hashlib
import os
from pathlib import Path
import stat

import runtime_authority as legacy
import runtime_authority_shared_v2 as shared

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / 'config/owned-v6-native-candidate-binding-v1.json'
CONTRACT_SHA = '434e159dbd34316676fa745db8a091087229b82a87cf7a8ed1e9c52258867081'
ENROLLMENT_PATH = '.zeldadoi-speedhack/native/authority.json'
PINS = {
    ROOT / 'scripts/runtime_authority.py': 'ae2079a9e94549cebcff261c4ce5b7f66ef98a26deaada79777e6d139a6083f0',
    ROOT / 'scripts/runtime_authority_shared_v2.py': 'ee231a83369e6e088637bf999e86bf240fa172d24c6ce9b2a05f321454aa3ee3',
    ROOT / 'config/runtime-authority-shared-schema-v2.json': '445228b6091da3a4753c6d0fac8191d956a50bec273a4a51b910f66534aa1050',
}
KEYS = {'schema_version', 'purpose', 'shared_authority_sha256', 'native',
        'source_companions', 'fixed_child_environment', 'production_native_adopted', 'release_approved'}


def require(value, reason):
    if not value:
        raise ValueError('owned V6 native candidate: ' + reason)


def checked_file(path, *, maximum, size=None, digest=None, executable=False):
    """One stable, single-link regular-file descriptor; no process execution."""
    path = Path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and
            0 < before.st_size <= maximum, 'bounded regular file required')
    require(size is None or before.st_size == size, 'file size differs')
    require(not executable or os.access(path, os.X_OK), 'native is not executable')
    identity = lambda row: (row.st_dev, row.st_ino, row.st_mode, row.st_nlink,
                            row.st_size, row.st_mtime_ns, row.st_ctime_ns)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        require(identity(os.fstat(fd)) == identity(before), 'file changed before read')
        result = hashlib.sha256()
        count = 0
        while True:
            block = os.read(fd, 65536)
            if not block:
                break
            count += len(block)
            require(count <= maximum, 'file grew beyond bound')
            result.update(block)
        require(count == before.st_size and identity(os.fstat(fd)) == identity(before) ==
                identity(path.lstat()), 'file changed during read')
        actual = result.hexdigest()
        require(digest is None or actual == digest, 'file hash differs')
        return actual
    finally:
        os.close(fd)


def contract():
    for path, digest in PINS.items():
        checked_file(path, maximum=2 * 1024**2, digest=digest)
    require(Path(legacy.__file__).resolve() == ROOT / 'scripts/runtime_authority.py' and
            Path(shared.__file__).resolve() == ROOT / 'scripts/runtime_authority_shared_v2.py',
            'authority helper origin differs')
    return legacy._read_regular_utf8_json(CONTRACT, 65536, CONTRACT_SHA)


def validate_binding(document, base_authority):
    selected = contract()
    legacy._exact_object(document, KEYS, 'owned native candidate enrollment')
    require(type(document['schema_version']) is int and document['schema_version'] == 1 and
            document['purpose'] == selected['purpose'], 'qualification enrollment/version differs')
    require(document['production_native_adopted'] is False and document['release_approved'] is False,
            'production or release approval cannot be granted here')
    legacy._sha256(document['shared_authority_sha256'], 'shared_authority_sha256')
    for name in ('native', 'source_companions', 'fixed_child_environment'):
        require(document[name] == selected[name], name + ' differs from exact candidate')
    shared.validate_document(base_authority, shared.load_schema())
    payload = selected['base_payload']
    for role in ('default', 'seeded'):
        actual = base_authority['runtimes'][role]
        require(actual['archive_size'] == payload['bytes'] and actual['archive_sha256'] == payload['sha256'] and
                actual['game_droid'] == {'member': 'assets/game.droid', 'size': payload['game_droid_bytes'],
                                        'sha256': payload['game_droid_sha256']},
                'shared payload is not the tested V6 candidate')
    return document


def owned_path(root, relative):
    root = Path(root).resolve(strict=True)
    require(root.is_dir(), 'game directory missing')
    path = root / relative
    require(path.resolve(strict=True) == path, 'owned path contains a symlink')
    return path


def verify_native_and_providers(root):
    """Exact target admission only; archive/install checks remain in the launcher."""
    selected = contract()
    native = selected['native']
    binary = owned_path(root, native['path'])
    checked_file(binary, maximum=native['bytes'], size=native['bytes'],
                 digest=native['sha256'], executable=True)
    require(not os.path.lexists('/etc/ld.so.preload'), 'unqualified system preload')
    library = owned_path(root, selected['library_directory'])
    expected = {row['path']: row for row in selected['library_files']}
    require(library.is_dir() and {path.name for path in library.iterdir()} == set(expected),
            'native library directory inventory differs')
    for name, row in expected.items():
        path = owned_path(root, selected['library_directory'] + '/' + name)
        checked_file(path, maximum=4 * 1024**2, size=row['bytes'], digest=row['sha256'])
    for row in selected['providers']:
        path = (owned_path(root, row['path']) if row['kind'] == 'game_relative'
                else Path(row['path']).resolve(strict=True))
        checked_file(path, maximum=4 * 1024**2, digest=row['sha256'])
    return binary, library


def child_environment(environment, library):
    """Use the qualified search directory; never change the parent's environment."""
    selected = contract()
    require(type(environment) is dict and all(type(k) is str and type(v) is str
                                            for k, v in environment.items()), 'child environment shape')
    require(not environment.get('GLIBC_TUNABLES'), 'unqualified loader tunables')
    result = dict(environment)
    for name in tuple(result):
        if name.startswith('LD_'):
            require(name == 'LD_LIBRARY_PATH' or not result[name], 'unqualified loader environment: ' + name)
            del result[name]
    result['LD_LIBRARY_PATH'] = str(library)
    result.update(selected['fixed_child_environment'])
    return result
