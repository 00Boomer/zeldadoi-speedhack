"""Explicit private qualification entrypoint; never selected by a public launcher.

Install/verify/restore delegate to the accepted fixed-candidate bootstrap.
Run delegates to the accepted owned-native hook and its shared launcher. No
automatic installation, new transaction, save conversion or native change.
"""
import argparse
from contextlib import contextmanager
import fcntl
import json
import hashlib
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'device/tools')]
import private_v6_archive_bootstrap_v1 as bootstrap
import launch_with_owned_v6_native_v1 as launcher
import prepare_owned_v6_root_v1 as preparation
import launch_speedhack_beta_v1 as mapper_source
import beta_bounded_log_capture_v1 as capture
import prepare_portmaster_runtime_log as log_files
import snapshot_ordinary_save_carrier as saved_input_reader
from bounded_runtime_lock import runtime_lock

PINS = {
    'scripts/private_v6_archive_bootstrap_v1.py':
        '61892121153af41ed716a6e855d12eb9597c8e0f84c0e5b11a0214baaf9d590b',
    'scripts/launch_with_owned_v6_native_v1.py':
        '10fc25db1dec9fe4c3a7f4dcba5603a2b498a762a16c4fc48ef59c31c7cd54f6',
    'scripts/prepare_owned_v6_root_v1.py':
        '7d35c16a1f25dc11ecf9daf25b64e76cfebcbe0f1aaf767d87689389217a962d',
    'device/tools/launch_speedhack_beta_v1.py':
        'fd756b975686968a4ad23785939d650561aab84ea982f9d44ad7200246b914b7',
    'device/tools/beta_bounded_log_capture_v1.py':
        'ff3689c1521d1df79674137f6026dd79824274f6307c63cc3629d5fa7c9bf476',
    'scripts/prepare_portmaster_runtime_log.py':
        '62761704238bff713a6c085ebfe11ac76fb714156741e0e89de68922073aa406',
}


SAVED_INPUT_TRANSACTIONS = ('Users_Temp', 'Users_ZDLF_RunSeed_New_v2', 'Users_ZDLF_RunSeed_Previous_v2',
                            'Users_ZDLF_RunSeed_New_v3', 'Users_ZDLF_RunSeed_Previous_v3')
SAVED_INPUT_READER_SHA256 = 'cbf6b79b919283a46872abdabc5d5eef65a64b92d649cdbd5b2da00eb0e0c31c'

def verify_sources():
    for module, relative in ((bootstrap, 'scripts/private_v6_archive_bootstrap_v1.py'),
                             (launcher, 'scripts/launch_with_owned_v6_native_v1.py'),
                             (preparation, 'scripts/prepare_owned_v6_root_v1.py'),
                             (mapper_source, 'device/tools/launch_speedhack_beta_v1.py'),
                             (capture, 'device/tools/beta_bounded_log_capture_v1.py'),
                             (log_files, 'scripts/prepare_portmaster_runtime_log.py')):
        launcher.native.require(Path(module.__file__).resolve() == ROOT / relative,
                                'private entrypoint dependency origin differs')
        launcher.native.checked_file(ROOT / relative, maximum=2 * 1024**2,
                                     digest=PINS[relative])
    launcher.native.require(Path(saved_input_reader.__file__).resolve() == ROOT / 'device/tools/snapshot_ordinary_save_carrier.py',
                            'saved-input reader origin differs')
    launcher.native.checked_file(ROOT / 'device/tools/snapshot_ordinary_save_carrier.py',
                                 maximum=2 * 1024**2, digest=SAVED_INPUT_READER_SHA256)
    bootstrap._sources()
    launcher._verify_previous()


def _system_preflight(root):
    bootstrap.component.ordinary.environment()
    # Validate the same already-qualified system providers before any decoder
    # or mapper starts. Final game/library checks remain in the owned hook.
    launcher.native.child_environment(dict(os.environ), root / '.zeldadoi-speedhack/native/libs.aarch64')
    for row in launcher.native.contract()['providers']:
        if row['kind'] == 'system_absolute':
            launcher.native.checked_file(Path(row['path']).resolve(strict=True),
                                         maximum=4 * 1024**2, digest=row['sha256'])


def _preparation_marker(root):
    root = bootstrap._root(root)
    raw = preparation.generated(preparation.inputs())[preparation.MARKER]
    launcher.native.checked_file(root / preparation.MARKER, maximum=65536,
                                 size=len(raw), digest=hashlib.sha256(raw).hexdigest())


def setup(ports_directory, artifacts, generation_timestamp):
    """Explicit setup/recovery, never an automatic action on normal Run."""
    verify_sources()
    ports = bootstrap.component.ordinary.safe(Path(ports_directory).absolute(), directory=True)
    launcher.native.require(ports.name == 'ports', 'explicit real ports directory required')
    launcher.native.require(type(generation_timestamp) is str and 0 < len(generation_timestamp) <= 128,
                            'bounded generation timestamp required')
    root = ports / bootstrap.ROOT_NAME
    _system_preflight(root)
    bootstrap._context(artifacts)
    pending = [p.name for p in ports.iterdir() if p.name.startswith(preparation.STAGE_PREFIX)]
    launcher.native.require(not pending, 'held root preparation requires review')
    if not os.path.lexists(root):
        preparation.prepare(ports)
    # Installed or post-game roots need the provenance marker, not the
    # initial ten-file-only verifier. Shared transactions own resume/recovery.
    _preparation_marker(root)
    return execute('install', root, artifacts=artifacts, generation_timestamp=generation_timestamp)


@contextmanager
def _session_logs(root, action):
    """Owned bounded stdout/stderr, using the accepted head/tail collector."""
    limit = 1024**2 if action == 'setup' else capture.MAX_LOG_BYTES
    directory = log_files.owned_log_directory(ROOT)
    directory_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        fcntl.flock(directory_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        launcher.native.require(len(list(directory.iterdir())) + 3 <= 1 + 3 * 64,
                                'private log capacity reached; retain logs before another session')
        fs = os.statvfs(directory)
        launcher.native.require(fs.f_bavail * fs.f_frsize >= 1024**3 + 2 * capture.MAX_LOG_BYTES + 65536,
                                'private logging would consume the filesystem reserve')
        report_fd, report_name = tempfile.mkstemp(prefix='owned-v6-', suffix='.json', dir=directory)
        streams = [tempfile.mkstemp(prefix='owned-v6-', suffix='.' + label, dir=directory)
                   for label in ('stdout', 'stderr')]
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
    record = dict(schema='private_owned_v6_portmaster_session_v1', action=action, game_root=str(root),
                  runtime_authority_sha256=bootstrap.BASE_SHA, qualification_only=True, release=False,
                  log_limit_bytes=limit,
                  launcher_result_source='inherited shared launcher, not universally raw child status',
                  private_v6_launcher_result=None, logs_incomplete=False)
    outputs, readers, originals, threads = [], [], [], []
    truncated, errors = [False], []
    def drain(reader, output):
        try: capture.drain_head_tail(reader, output, limit, truncated, errors)
        except BaseException as error:
            errors.append(type(error).__name__ + ': ' + str(error)[:1024])
            if not reader.closed: reader.close()
    try:
        selected = launcher.native.contract()
        record.update(entrypoint_file_sha256=launcher.native.checked_file(Path(__file__), maximum=2 * 1024**2),
                      expected_native_sha256=selected['native']['sha256'],
                      expected_game_droid_sha256=selected['base_payload']['game_droid_sha256'])
        for number, label in ((1, 'stdout'), (2, 'stderr')):
            fd, name = streams[number - 1]
            output = os.fdopen(fd, 'wb'); outputs.append(output); record[label] = str(name)
            read_fd, write_fd = os.pipe(); reader = os.fdopen(read_fd, 'rb'); readers.append(reader)
            sys.stdout.flush(); sys.stderr.flush()
            old_fd = os.dup(number); originals.append((number, old_fd))
            os.dup2(write_fd, number); os.close(write_fd)
            thread = threading.Thread(target=drain, args=(reader, output), daemon=True)
            thread.start(); threads.append(thread)
        yield record
    except BaseException as error:
        record['exception'] = dict(kind=type(error).__name__, detail=str(error)[:1024])
        raise
    finally:
        try: sys.stdout.flush(); sys.stderr.flush()
        except (OSError, ValueError) as error: errors.append(str(error))
        for number, old_fd in originals:
            os.dup2(old_fd, number); os.close(old_fd)
        for thread in threads: thread.join(timeout=10)
        if any(thread.is_alive() for thread in threads): errors.append('bounded log drain did not finish')
        for i, reader in enumerate(readers):
            if (i >= len(threads) or not threads[i].is_alive()) and not reader.closed: reader.close()
        for fd, _ in streams[len(outputs):]: os.close(fd)
        for output in outputs:
            try: output.flush(); os.fsync(output.fileno())
            except (OSError, ValueError) as error: errors.append(str(error))
            finally: output.close()
        record['logs_incomplete'] = truncated[0]
        record['capture_errors'] = errors
        with os.fdopen(report_fd, 'w') as out:
            json.dump(record, out, sort_keys=True); out.write('\n'); out.flush(); os.fsync(out.fileno())
        bootstrap.component.ordinary.fsync_dir(directory)
        print(json.dumps({'private_v6_session_record': report_name}), flush=True)
        if errors: raise OSError('bounded private session capture failed')


_RETIRED_SEEDED_KEYS = ('__ZDLF_DeterministicSaveMode_v1', '__ZDLF_RunSeedCheckpoint_v2', '__ZDLF_RunSeedCheckpoint_v3', '__ZDLF_DungeonSeedCheckpoint_v1', '__ZDLF_RunSeedConsumedState_v1', '__ZDLF_RunSeedConsumedState_v2')


_GENERATION_CARRIER_KEY = "__ZDLF_DungeonGenerationSave_v1"
_GENERATION_CARRIER_MAX = 1024


def _require_generation_envelope(carrier):
    """Check the inner checksum only. GameMaker still validates the full save."""
    refused = "malformed Dungeon Seed checkpoint carrier; Users was not changed"
    if carrier is None or not carrier or not carrier.isascii():
        raise ValueError(refused)
    try:
        frame = json.loads(carrier)
    except (ValueError, RecursionError) as error:
        raise ValueError(refused) from error
    if type(frame) is not list or len(frame) != 11 or any(type(field) is not str for field in frame):
        raise ValueError(refused)
    fields = json.dumps(frame[:-1], ensure_ascii=True, separators=(",", ":"))
    digest = hashlib.sha256(fields.encode("ascii")).hexdigest()
    expected = fields[:-1] + "," + json.dumps(digest) + "]"
    if carrier != expected:
        raise ValueError(refused)
    if frame[:5] != ['zdoi116-dungeon-generation-save', '1', 'zdoi-runseed-pm31-dual-schrage-v2', 'zdoi116-runseed-level-stream-v1', 'a251e590e0ae50ebcfb6120b58ededc438d2e079b0bfeddfae4c36bb2911b9cd']:
        raise ValueError('unsupported Dungeon Seed checkpoint identity; Users was not changed')


def _refuse_retired_users(payload):
    """Check retired keys and explicit generation envelopes without building the Users tree."""
    terminator = int(payload.endswith(b"\0"))
    if payload.find(b"\0", 0, len(payload) - terminator) != -1:
        raise ValueError("invalid Users string terminator")
    text = payload.decode("utf-8")
    whitespace = json.decoder.WHITESPACE.match
    string_token = json.decoder.scanstring
    retired_found = False
    generation_envelopes = []

    def reject_constant(value):
        raise ValueError("non-finite Users JSON number: " + value)

    primitive = json.JSONDecoder(parse_constant=reject_constant).raw_decode

    def expect(index, token):
        index = whitespace(text, index).end()
        if not text.startswith(token, index):
            raise ValueError("malformed Users JSON")
        return index + 1

    def value_end(index, scope=None):
        nonlocal retired_found
        index = whitespace(text, index).end()
        if text.startswith("{", index):
            index = whitespace(text, index + 1).end()
            if text.startswith("}", index):
                return index + 1
            keys = set()
            while True:
                key, end = string_token(text, expect(index, '"'))
                if key in keys:
                    raise ValueError("duplicate JSON object key")
                keys.add(key)
                if scope is not None and key in _RETIRED_SEEDED_KEYS:
                    retired_found = True
                index = whitespace(text, expect(end, ":")).end()
                if scope == "SaveData" and key == _GENERATION_CARRIER_KEY:
                    if text.startswith('"', index):
                        carrier, index = string_token(text, index + 1)
                        generation_envelopes.append(carrier if len(carrier) <= _GENERATION_CARRIER_MAX else None)
                    else:
                        generation_envelopes.append(None)
                        index = value_end(index)
                else:
                    child_scope = "SaveData" if scope == "profile" and key == "SaveData" else None
                    index = value_end(index, child_scope)
                index = whitespace(text, index).end()
                if text.startswith("}", index):
                    return index + 1
                index = expect(index, ",")
        if text.startswith("[", index):
            index = whitespace(text, index + 1).end()
            if text.startswith("]", index):
                return index + 1
            while True:
                index = whitespace(text, value_end(index)).end()
                if text.startswith("]", index):
                    return index + 1
                index = expect(index, ",")
        return primitive(text, index)[1]

    index = whitespace(text, 0).end()
    if not text.startswith("[", index):
        raise ValueError("unsupported Users profile shape")
    index += 1
    for slot in range(5):
        index = whitespace(text, index).end()
        if not text.startswith("{", index):
            raise ValueError("unsupported Users profile shape")
        index = whitespace(text, value_end(index, "profile")).end()
        delimiter = "]" if slot == 4 else ","
        if not text.startswith(delimiter, index):
            raise ValueError("unsupported Users profile shape")
        index += 1
    if whitespace(text, index).end() != len(text) - terminator:
        raise ValueError("malformed Users JSON")
    if retired_found:
        raise ValueError("incompatible experimental Dungeon Seed save; Users was not changed")
    for carrier in generation_envelopes:
        _require_generation_envelope(carrier)


def _guard_saved_input(root):
    """Read-only bootstrap protection; saved-rule compatibility remains in GML."""
    saves = root / 'saves'
    if os.path.lexists(saves):
        launcher.native.require(not saves.is_symlink() and saves.is_dir() and saves.resolve(strict=True) == saves,
                                'saved-input directory is unsafe')
    for name in SAVED_INPUT_TRANSACTIONS:
        if os.path.lexists(saves / name):
            raise ValueError('pending Users transaction requires separate review')
    active = saves / 'Users'
    if not os.path.lexists(active):
        return
    try:
        fd, before = saved_input_reader._open_regular_single_link(active, maximum=saved_input_reader.MAX_ARCHIVE_BYTES)
        try:
            with os.fdopen(os.dup(fd), 'rb') as stream:
                raw = stream.read(saved_input_reader.MAX_ARCHIVE_BYTES + 1)
            if len(raw) != before.st_size:
                raise ValueError('Users archive changed or was truncated')
            _, payload, _ = saved_input_reader._parse_xzip(raw)
            _refuse_retired_users(payload)
            saved_input_reader._verify_unchanged(fd, before, 'Users')
        finally:
            os.close(fd)
    except saved_input_reader.SnapshotError as error:
        raise ValueError('Users archive refused: ' + str(error)) from error


def _run_with_mapper(root, mapper):
    # Hold the existing shared lock before starting a mapper, so a second Run
    # cannot introduce another mapper into the first game's session.
    with runtime_lock(root / '.zeldadoi-speedhack') as lease:
        with _session_logs(root, 'run') as record:
            bootstrap.component.ordinary.environment()
            _preparation_marker(root)
            command = mapper_source.mapper_command(mapper)
            mapper_env = launcher.native.child_environment(dict(os.environ),
                root / '.zeldadoi-speedhack/native/libs.aarch64')
            mapper_env['SDL_GAMECONTROLLERCONFIG'] = mapper_env.get('sdl_controllerconfig',
                mapper_env.get('SDL_GAMECONTROLLERCONFIG', ''))
            launcher.native.require(os.environ.get('SDL_GAMECONTROLLERCONFIG', '') ==
                mapper_env['SDL_GAMECONTROLLERCONFIG'], 'PortMaster controller environment was not prepared')
            with mapper_source.mapper_snapshot(command) as (fd, digest):
                process = None
                record['mapper_sha256'] = digest
                record['mapper_started'] = False
                def start_mapper():
                    nonlocal process
                    launcher.native.require(process is None, 'duplicate mapper launch refused')
                    _guard_saved_input(root)
                    process = subprocess.Popen(['/proc/self/fd/' + str(fd), *command[1:]],
                        pass_fds=(fd,), cwd=root, env=mapper_env,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    record['mapper_started'] = True
                    try: process.wait(timeout=0.25)
                    except subprocess.TimeoutExpired: return
                    raise OSError('PortMaster mapper exited before game launch')
                term_sent = forced_kill = False
                try:
                    result = launcher.run_game(launch_arguments(root), root / launcher.native.ENROLLMENT_PATH,
                        bootstrap.ENROLLMENT_SHA, lock_lease=lease, before_game=start_mapper)
                    record['private_v6_launcher_result'] = result
                finally:
                    if process is not None:
                        if process.poll() is None: process.terminate(); term_sent = True
                        try: mapper_status = process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            process.kill(); forced_kill = True; mapper_status = process.wait(timeout=10)
                        record.update(mapper_status=mapper_status, mapper_term_sent=term_sent, mapper_forced_kill=forced_kill)
                if process is None:
                    launcher.native.require(result != 0, 'successful game result without mapper launch refused')
                elif forced_kill or mapper_status not in ({0, -signal.SIGTERM} if term_sent else {0}):
                    raise OSError('PortMaster mapper cleanup failed')
                print(json.dumps({'private_v6_launcher_result': result}), flush=True)
                return result


def launch_arguments(root):
    """Fixed shared-launch arguments; no arbitrary executable or authority input."""
    return argparse.Namespace(
        game_dir=root, schema=ROOT / 'config/options-override-schema.json',
        sampler=None, role='candidate', scenario='owned-v6-qualification',
        run_number=1, strict_validation=False, physical_basic_evidence_role=None,
        physical_observation_evidence_role=None, evidence_environment_file=None,
        evidence_initial_state_file=None, evidence_pattern='gmloadernext.aarch64',
        evidence_ready_timeout_seconds=15,
        runtime_authority=root / '.zeldadoi-speedhack/runtime-authority.json',
        runtime_authority_sha256=bootstrap.BASE_SHA,
        default_override_template_sha256=bootstrap.component.DEFAULT_OVERRIDE_TEMPLATE_SHA256,
        command=[str(root / 'gmloadernext.aarch64'), '-c', str(root / 'gmloader.json')])


def execute(action, game_root, *, artifacts=None, generation_timestamp=None, mapper=None):
    verify_sources()
    root = bootstrap._root(game_root)
    if action == 'run':
        launcher.native.require(artifacts is None and generation_timestamp is None,
                                'run does not accept installer inputs')
        if mapper is not None: return _run_with_mapper(root, mapper)
        bootstrap.component.ordinary.environment()
        return launcher.run_game(launch_arguments(root),
            root / launcher.native.ENROLLMENT_PATH, bootstrap.ENROLLMENT_SHA,
            before_game=lambda: _guard_saved_input(root))
    launcher.native.require(action in {'install', 'verify', 'restore'}, 'unsupported private action')
    launcher.native.require(mapper is None, 'mapper is only valid for run')
    launcher.native.require(artifacts is not None, 'explicit artifact directory required')
    if action == 'install':
        launcher.native.require(type(generation_timestamp) is str and
                                0 < len(generation_timestamp) <= 128,
                                'bounded generation timestamp required')
        return bootstrap.install(root, artifacts, generation_timestamp)
    launcher.native.require(generation_timestamp is None, 'timestamp is only valid for install')
    return (bootstrap.verify if action == 'verify' else bootstrap.restore)(root, artifacts)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    command = commands.add_parser('setup')
    command.add_argument('--ports-dir', type=Path, required=True)
    command.add_argument('--artifacts', type=Path, required=True)
    command.add_argument('--generation-timestamp', required=True)
    for action in ('install', 'verify', 'restore', 'run'):
        command = commands.add_parser(action)
        command.add_argument('--game-dir', type=Path, required=True)
        if action != 'run':
            command.add_argument('--artifacts', type=Path, required=True)
        if action == 'install':
            command.add_argument('--generation-timestamp', required=True)
        if action == 'run':
            command.add_argument('--mapper')
    args = parser.parse_args(argv)
    try:
        if args.action == 'setup':
            verify_sources()
            with _session_logs(args.ports_dir / bootstrap.ROOT_NAME, 'setup') as record:
                result = setup(args.ports_dir, args.artifacts, args.generation_timestamp)
                record['setup_result'] = result['status']
                print(json.dumps(result, sort_keys=True), flush=True)
            return 0
        if args.action == 'restore':
            verify_sources()
            with _session_logs(args.game_dir, 'restore') as record:
                result = execute('restore', args.game_dir, artifacts=args.artifacts)
                record['restore_result'] = result['status']
                print(json.dumps(result, sort_keys=True), flush=True)
            return 0
        result = execute(args.action, args.game_dir,
                         artifacts=getattr(args, 'artifacts', None),
                         generation_timestamp=getattr(args, 'generation_timestamp', None),
                         mapper=getattr(args, 'mapper', None))
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as error:
        print('private V6 qualification refused: ' + str(error), file=sys.stderr)
        return 2
    if args.action == 'run':
        # Keep the inherited result visible even when the shell encodes a
        # negative Popen return value as an unsigned exit byte.
        print(json.dumps({'private_v6_launcher_result': result}), flush=True)
        return result
    print(json.dumps(result, sort_keys=True), flush=True)
    return 0


if __name__ == '__main__':
    print('Use the bundled guarded V6 launcher.', file=sys.stderr)
    raise SystemExit(2)
