#!/usr/bin/env python3
"""Restore one exact prior runtime pair, then install one exact new pair.

Both runtime authorities and cache contracts are independently supplied and
validated before mutation.  Old and new pairs never coexist: a complete prior
pair is restored to the preserved official source before the new pair install
composition begins.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import zipfile
from pathlib import Path
from typing import Any, NoReturn

import bounded_runtime_pair_activation as activation
import bounded_runtime_pair_install as pair_install
import bounded_runtime_pair_restore as pair_restore
import bounded_runtime_pair_verify as pair_verify
import runtime_pair_capacity as capacity_model
from bounded_runtime_lock import RuntimeLockLease, runtime_lock
from runtime_authority import DEFAULT_SCHEMA, load_authority, load_schema


PHASES = ("prior-pair-restored", "new-pair-installed")


class RuntimePairMigrationError(ValueError):
    """The prior/new pair migration route is unsafe or ambiguous."""


def reject(message: str) -> NoReturn:
    raise RuntimePairMigrationError(message)


def checkpoint(name: str, fail_after: str | None) -> None:
    if fail_after == name:
        raise RuntimeError(f"injected runtime-pair migration interruption after {name}")


def exists(path: Path) -> bool:
    return path.exists() or path.is_symlink()


def enforce_migration_floor(root: Path, receipt: dict[str, Any]) -> dict[str, int]:
    stats = os.statvfs(root)
    available_bytes = stats.f_bavail * stats.f_frsize
    available_inodes = stats.f_favail
    if stats.f_frsize != receipt.get("allocation_unit_bytes"):
        reject("filesystem allocation unit changed before pair migration")
    capacity_model.enforce_filesystem_capacity(
        root, stats, receipt["required_initial_free_capacity_bytes"], receipt["required_initial_free_inodes"],
        "restore-first pair migration", reject,
    )
    return {
        "available_logical_bytes": available_bytes,
        "available_inodes": available_inodes,
        "required_initial_free_capacity_bytes": receipt[
            "required_initial_free_capacity_bytes"
        ],
        "allocation_unit_bytes": stats.f_frsize,
    }


def migration_result(
    prior_authority: dict[str, Any],
    new_authority: dict[str, Any],
    expected_prior_authority_sha256: str,
    expected_new_authority_sha256: str,
    prior_restore_status: str | None,
    installed: dict[str, Any],
    migration_capacity: dict[str, Any],
    migration_floor: dict[str, int] | None,
    *,
    first_install: bool,
) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "status": "runtime_pair_migration_composed_host_contract",
        "prior_release_id": prior_authority["release_id"],
        "new_release_id": new_authority["release_id"],
        "prior_authority_sha256": expected_prior_authority_sha256,
        "new_authority_sha256": expected_new_authority_sha256,
        "prior_restore_status": prior_restore_status,
        "new_install_status": installed["status"],
        "migration_capacity": migration_capacity,
        "migration_initial_floor_observed": migration_floor,
        "first_install_without_prior_pair": first_install,
        "restore_first": True,
        "continuous_lock_across_restore_and_install": True,
        "old_new_pair_overlap_bytes_budgeted": 0,
        "user_files_touched": False,
        "physical_target_executed": False,
        "production_approved": False,
        "safe_profile_approved": False,
    }


def migrate_pair(
    game_root: Path,
    new_authority_path: Path,
    expected_new_authority_sha256: str,
    default_patch: Path,
    expected_default_patch_sha256: str,
    seeded_patch: Path,
    expected_seeded_patch_sha256: str,
    seeded_config: Path,
    new_cache_contract_path: Path,
    expected_new_cache_contract_sha256: str,
    prior_authority_path: Path,
    expected_prior_authority_sha256: str,
    prior_cache_contract_path: Path,
    expected_prior_cache_contract_sha256: str,
    generation_timestamp: str,
    *,
    default_override_template_path: Path,
    expected_default_override_template_sha256: str,
    authority_schema_path: Path = DEFAULT_SCHEMA,
    capacity_schema_path: Path = capacity_model.DEFAULT_CAPACITY_SCHEMA,
    tool_root: Path | None = None,
    fail_after: str | None = None,
) -> dict[str, Any]:
    if fail_after is not None and fail_after not in PHASES:
        reject("unknown runtime-pair migration interruption checkpoint")
    root = activation.exact_root(game_root, "game root")
    state = root / ".zeldadoi-speedhack"
    schema = load_schema(authority_schema_path)
    prior_authority = load_authority(
        prior_authority_path,
        authority_schema_path,
        expected_sha256=expected_prior_authority_sha256,
    )
    new_authority = load_authority(
        new_authority_path,
        authority_schema_path,
        expected_sha256=expected_new_authority_sha256,
    )
    if prior_authority["release_id"] == new_authority["release_id"]:
        reject("runtime-pair migration requires distinct release IDs")
    filesystem = os.statvfs(root)
    prior_capacity = capacity_model.calculate(
        prior_authority_path,
        expected_prior_authority_sha256,
        prior_cache_contract_path,
        expected_prior_cache_contract_sha256,
        authority_schema_path=authority_schema_path,
        capacity_schema_path=capacity_schema_path,
        allocation_unit_bytes=filesystem.f_frsize,
    )
    new_capacity = capacity_model.calculate(
        new_authority_path,
        expected_new_authority_sha256,
        new_cache_contract_path,
        expected_new_cache_contract_sha256,
        authority_schema_path=authority_schema_path,
        capacity_schema_path=capacity_schema_path,
        allocation_unit_bytes=filesystem.f_frsize,
    )
    migration_capacity = capacity_model.restore_first_migration(
        prior_capacity, new_capacity
    )

    def install_new_pair(
        lock_lease: RuntimeLockLease | None = None,
    ) -> dict[str, Any]:
        return pair_install.install_pair(
            root,
            new_authority_path,
            expected_new_authority_sha256,
            default_patch,
            expected_default_patch_sha256,
            seeded_patch,
            expected_seeded_patch_sha256,
            seeded_config,
            new_cache_contract_path,
            expected_new_cache_contract_sha256,
            generation_timestamp,
            default_override_template_path=default_override_template_path,
            expected_default_override_template_sha256=(
                expected_default_override_template_sha256
            ),
            authority_schema_path=authority_schema_path,
            capacity_schema_path=capacity_schema_path,
            tool_root=tool_root,
            lock_lease=lock_lease,
        )

    state_exists = exists(state)
    if not state_exists:
        official_path = root / schema["official_source"]["archive"]["path"]
        if exists(official_path):
            reject("preserved official source exists without owned installer state")
        installed = install_new_pair()
        checkpoint("new-pair-installed", fail_after)
        return migration_result(
            prior_authority,
            new_authority,
            expected_prior_authority_sha256,
            expected_new_authority_sha256,
            "runtime_pair_migration_not_required_first_install",
            installed,
            migration_capacity,
            None,
            first_install=True,
        )

    activation.require_state_owner(state)

    with runtime_lock(state) as operation_lease:
        installed_authority = root / schema["authority_manifest_path"]
        restore_active = any(
            exists(state / name)
            for name in (
                pair_restore.RESTORE_JOURNAL,
                pair_restore.RESTORE_JOURNAL_NEXT,
            )
        )
        activation_unfinished = any(
            exists(state / name)
            for name in (
                activation.PAIR_JOURNAL,
                activation.PAIR_JOURNAL_NEXT,
                activation.PAIR_CURRENT_NEXT,
            )
        )
        activation_current = exists(state / activation.PAIR_CURRENT)
        installed_digest: str | None = None
        if exists(installed_authority):
            _, installed_digest = activation.file_identity(
                installed_authority, "installed runtime authority"
            )

        prior_restore_status: str | None
        migration_floor: dict[str, int] | None = None
        if installed_digest == expected_new_authority_sha256 or (
            installed_digest is None
            and activation_unfinished
            and not restore_active
        ):
            prior_restore_status = None
        elif restore_active:
            restored = pair_restore.restore_pair(
                root,
                expected_prior_authority_sha256,
                cache_contract_path=prior_cache_contract_path,
                expected_cache_contract_sha256=expected_prior_cache_contract_sha256,
                schema_path=authority_schema_path,
                capacity_schema_path=capacity_schema_path,
                lock_lease=operation_lease,
            )
            prior_restore_status = restored["status"]
            checkpoint("prior-pair-restored", fail_after)
        elif installed_digest == expected_prior_authority_sha256:
            if activation_unfinished or not activation_current:
                reject(
                    "runtime-pair migration requires a completely committed prior pair"
                )
            pair_verify.verify_installed_pair(
                root,
                expected_prior_authority_sha256,
                schema_path=authority_schema_path,
                lock_lease=operation_lease,
            )
            migration_floor = enforce_migration_floor(root, migration_capacity)
            restored = pair_restore.restore_pair(
                root,
                expected_prior_authority_sha256,
                cache_contract_path=prior_cache_contract_path,
                expected_cache_contract_sha256=expected_prior_cache_contract_sha256,
                schema_path=authority_schema_path,
                capacity_schema_path=capacity_schema_path,
                lock_lease=operation_lease,
            )
            prior_restore_status = restored["status"]
            checkpoint("prior-pair-restored", fail_after)
        elif installed_digest is not None:
            reject("installed runtime authority is neither the prior nor new release")
        else:
            official = schema["official_source"]["archive"]
            activation.verify_file(
                root / official["path"],
                official["size"],
                official["sha256"],
                "preserved official source between pair releases",
            )
            activation.verify_file(
                root / new_authority["runtimes"]["default"]["archive_path"],
                official["size"],
                official["sha256"],
                "restored active official source",
            )
            prior_restore_status = "runtime_pair_restore_already_official"

        installed = install_new_pair(operation_lease)
        checkpoint("new-pair-installed", fail_after)

    return migration_result(
        prior_authority,
        new_authority,
        expected_prior_authority_sha256,
        expected_new_authority_sha256,
        prior_restore_status,
        installed,
        migration_capacity,
        migration_floor,
        first_install=False,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-root", type=Path, required=True)
    parser.add_argument("--new-authority", type=Path, required=True)
    parser.add_argument("--new-authority-sha256", required=True)
    parser.add_argument("--default-patch", type=Path, required=True)
    parser.add_argument("--default-patch-sha256", required=True)
    parser.add_argument("--seeded-patch", type=Path, required=True)
    parser.add_argument("--seeded-patch-sha256", required=True)
    parser.add_argument("--seeded-config", type=Path, required=True)
    parser.add_argument("--new-cache-contract", type=Path, required=True)
    parser.add_argument("--new-cache-contract-sha256", required=True)
    parser.add_argument("--prior-authority", type=Path, required=True)
    parser.add_argument("--prior-authority-sha256", required=True)
    parser.add_argument("--prior-cache-contract", type=Path, required=True)
    parser.add_argument("--prior-cache-contract-sha256", required=True)
    parser.add_argument("--generation-timestamp", required=True)
    parser.add_argument("--default-override-template", type=Path, required=True)
    parser.add_argument("--default-override-template-sha256", required=True)
    parser.add_argument("--authority-schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument(
        "--capacity-schema",
        type=Path,
        default=capacity_model.DEFAULT_CAPACITY_SCHEMA,
    )
    parser.add_argument("--tool-root", type=Path)
    args = parser.parse_args()
    try:
        result = migrate_pair(
            args.game_root,
            args.new_authority,
            args.new_authority_sha256,
            args.default_patch,
            args.default_patch_sha256,
            args.seeded_patch,
            args.seeded_patch_sha256,
            args.seeded_config,
            args.new_cache_contract,
            args.new_cache_contract_sha256,
            args.prior_authority,
            args.prior_authority_sha256,
            args.prior_cache_contract,
            args.prior_cache_contract_sha256,
            args.generation_timestamp,
            default_override_template_path=args.default_override_template,
            expected_default_override_template_sha256=(
                args.default_override_template_sha256
            ),
            authority_schema_path=args.authority_schema,
            capacity_schema_path=args.capacity_schema,
            tool_root=args.tool_root,
        )
    except (
        OSError,
        RuntimeError,
        ValueError,
        TypeError,
        KeyError,
        json.JSONDecodeError,
        zipfile.BadZipFile,
    ) as exc:
        print(json.dumps({"status": "invalid", "error": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
