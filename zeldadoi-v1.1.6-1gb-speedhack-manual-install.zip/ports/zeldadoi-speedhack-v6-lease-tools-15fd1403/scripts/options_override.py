#!/usr/bin/env python3
"""Parse the external ZeldaDOI options overlay without touching the game archive."""

from __future__ import annotations

import argparse
import configparser
import hashlib
import json
import os
import stat
import sys
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SCHEMA = ROOT / "config/options-override-schema.json"
OVERRIDE_BASENAME = "options_override.ini"


@dataclass(frozen=True)
class ParsedOverride:
    source_status: str
    source_sha256: str | None
    enable_override: bool
    enable_override_error: str | None
    configuration_source: str
    config_version: int
    profile: str
    telemetry: str
    lighting_mode: str
    difficulty: str
    difficulty_error: str | None
    use_dungeon_seed: bool
    dungeon_seed: int | None
    dungeon_seed_request: str
    dungeon_seed_error: str | None
    use_run_seed: bool
    run_seed: int | None
    run_seed_request: str
    run_seed_error: str | None
    official_values: dict[str, int | float]
    applied_overrides: dict[str, int | float]
    environment: dict[str, str]
    diagnostics: tuple[str, ...]
    effective_sha256: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "source_status": self.source_status,
            "source_sha256": self.source_sha256,
            "enable_override": self.enable_override,
            "enable_override_error": self.enable_override_error,
            "configuration_source": self.configuration_source,
            "config_version": self.config_version,
            "profile": self.profile,
            "telemetry": self.telemetry,
            "lighting_mode": self.lighting_mode,
            "difficulty": self.difficulty,
            "difficulty_error": self.difficulty_error,
            "use_dungeon_seed": self.use_dungeon_seed,
            "dungeon_seed": self.dungeon_seed,
            "dungeon_seed_request": self.dungeon_seed_request,
            "dungeon_seed_error": self.dungeon_seed_error,
            "use_run_seed": self.use_run_seed,
            "run_seed": self.run_seed,
            "run_seed_request": self.run_seed_request,
            "run_seed_error": self.run_seed_error,
            "official_values": self.official_values,
            "applied_overrides": self.applied_overrides,
            "environment": self.environment,
            "diagnostics": list(self.diagnostics),
            "effective_sha256": self.effective_sha256,
            "official_archive_modified": False,
        }


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_schema(path: Path = DEFAULT_SCHEMA) -> dict[str, Any]:
    document = json.loads(path.read_text(encoding="utf-8"))
    if document.get("schema_version") != 1:
        raise ValueError("unsupported options override schema")
    if document.get("file", {}).get("basename") != OVERRIDE_BASENAME:
        raise ValueError("options override basename contract changed")
    return document


def canonical_number(value: Decimal) -> str:
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def parse_value(raw: str, rule: dict[str, Any]) -> tuple[int | float, str]:
    value_type = rule["type"]
    stripped = raw.strip()
    if value_type == "integer":
        if stripped not in {str(value) for value in rule["accepted_values"]}:
            raise ValueError("not an accepted integer")
        value = int(stripped)
        return value, str(value)
    if value_type == "number":
        try:
            decimal = Decimal(stripped)
        except InvalidOperation as exc:
            raise ValueError("not a number") from exc
        if not decimal.is_finite():
            raise ValueError("number must be finite")
        minimum = Decimal(str(rule["minimum"]))
        maximum = Decimal(str(rule["maximum"]))
        if decimal < minimum or decimal > maximum:
            raise ValueError("number is outside the accepted range")
        normalized = canonical_number(decimal)
        return float(decimal), normalized
    raise ValueError(f"unsupported option type: {value_type}")


def default_result(
    schema: dict[str, Any],
    source_status: str,
    source_sha256: str | None,
    diagnostics: list[str],
    *,
    enable_override: bool = False,
    enable_override_error: str | None = None,
    use_run_seed: bool = False,
    run_seed_request: str = "disabled",
    run_seed_error: str | None = None,
) -> ParsedOverride:
    values = {
        f'{rule["section"]}.{rule["name"]}': rule["official_archive_value"]
        for rule in schema["official_options"]
    }
    return finish_result(
        source_status=source_status,
        source_sha256=source_sha256,
        enable_override=enable_override,
        enable_override_error=enable_override_error,
        config_version=schema["speedhack"]["ConfigVersion"]["default"],
        profile=schema["speedhack"]["Profile"]["default"],
        telemetry=schema["speedhack"]["Telemetry"]["default"],
        lighting_mode=schema["speedhack"]["LightingMode"]["default"],
        difficulty=schema["speedhack"].get(
            "Difficulty", {"default": "Original"}
        )["default"],
        difficulty_error=None,
        use_dungeon_seed=False,
        dungeon_seed=None,
        dungeon_seed_request="disabled",
        dungeon_seed_error=None,
        use_run_seed=use_run_seed,
        run_seed=None,
        run_seed_request=run_seed_request,
        run_seed_error=run_seed_error,
        official_values=values,
        applied_overrides={},
        environment={},
        diagnostics=diagnostics,
    )


def finish_result(
    *,
    source_status: str,
    source_sha256: str | None,
    enable_override: bool,
    enable_override_error: str | None,
    config_version: int,
    profile: str,
    telemetry: str,
    lighting_mode: str,
    difficulty: str,
    difficulty_error: str | None,
    use_dungeon_seed: bool,
    dungeon_seed: int | None,
    dungeon_seed_request: str,
    dungeon_seed_error: str | None,
    use_run_seed: bool,
    run_seed: int | None,
    run_seed_request: str,
    run_seed_error: str | None,
    official_values: dict[str, int | float],
    applied_overrides: dict[str, int | float],
    environment: dict[str, str],
    diagnostics: list[str],
) -> ParsedOverride:
    environment = dict(environment)
    configuration_source = (
        "external_override" if enable_override else "in_game"
    )
    canonical = {
        "enable_override": enable_override,
        "configuration_source": configuration_source,
        "config_version": config_version,
        "profile": profile,
        "telemetry": telemetry,
        "lighting_mode": lighting_mode,
        "difficulty": difficulty,
        "use_dungeon_seed": use_dungeon_seed,
        "dungeon_seed": dungeon_seed,
        "dungeon_seed_request": dungeon_seed_request,
        "use_run_seed": use_run_seed,
        "run_seed": run_seed,
        "run_seed_request": run_seed_request,
        "official_values": official_values,
        "applied_overrides": applied_overrides,
    }
    effective_sha256 = sha256_bytes(
        json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")
    )
    environment.update(
        {
            "ZELDADOI_SPEEDHACK_PROFILE": profile,
            "ZELDADOI_SPEEDHACK_CONFIG_VERSION": str(config_version),
            "ZELDADOI_SPEEDHACK_TELEMETRY": telemetry,
            "ZELDADOI_SPEEDHACK_ENABLE_OVERRIDE": "1" if enable_override else "0",
            "ZELDADOI_SPEEDHACK_CONFIG_SOURCE": configuration_source,
            "ZELDADOI_SPEEDHACK_CONFIG_SHA256": effective_sha256,
        }
    )
    if enable_override:
        environment.update(
            {
                "ZELDADOI_SPEEDHACK_LIGHTING_MODE": lighting_mode,
                "ZELDADOI_SPEEDHACK_DIFFICULTY": difficulty,
            }
        )
    return ParsedOverride(
        source_status=source_status,
        source_sha256=source_sha256,
        enable_override=enable_override,
        enable_override_error=enable_override_error,
        configuration_source=configuration_source,
        config_version=config_version,
        profile=profile,
        telemetry=telemetry,
        lighting_mode=lighting_mode,
        difficulty=difficulty,
        difficulty_error=difficulty_error,
        use_dungeon_seed=use_dungeon_seed,
        dungeon_seed=dungeon_seed,
        dungeon_seed_request=dungeon_seed_request,
        dungeon_seed_error=dungeon_seed_error,
        use_run_seed=use_run_seed,
        run_seed=run_seed,
        run_seed_request=run_seed_request,
        run_seed_error=run_seed_error,
        official_values=official_values,
        applied_overrides=applied_overrides,
        environment=environment,
        diagnostics=tuple(diagnostics),
        effective_sha256=effective_sha256,
    )


def read_override(path: Path, maximum_bytes: int) -> tuple[bytes | None, str, list[str]]:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None, "missing", []
    except OSError as exc:
        return None, "unreadable", [f"could not inspect override: {exc.strerror or exc}"]
    if stat.S_ISLNK(info.st_mode):
        return None, "rejected_symlink", ["override file must not be a symlink"]
    if not stat.S_ISREG(info.st_mode):
        return None, "rejected_type", ["override path must be a regular file"]
    if info.st_size > maximum_bytes:
        return None, "rejected_size", ["override file exceeds the size limit"]
    try:
        with path.open("rb") as handle:
            data = handle.read(maximum_bytes + 1)
    except OSError as exc:
        return None, "unreadable", [f"could not read override: {exc.strerror or exc}"]
    if len(data) > maximum_bytes:
        return None, "rejected_size", ["override file exceeds the size limit"]
    return data, "loaded", []


def raw_ini_option_values(text: str, section_name: str, option_name: str) -> list[str]:
    """Return the unnormalised scalar value for one already-validated INI option.

    ``ConfigParser`` intentionally trims value whitespace.  That is fine for
    ordinary presentation options, but it is not acceptable for RunSeed: the
    external selection token has one canonical decimal spelling.  This helper
    is deliberately narrow; strict ``ConfigParser`` validation still owns
    duplicate/malformed INI rejection before it is used.
    """
    current_section: str | None = None
    values: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";")):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            current_section = stripped[1:-1]
            continue
        if current_section != section_name:
            continue
        for separator in ("=", ":"):
            if separator not in line:
                continue
            raw_name, raw_value = line.split(separator, 1)
            if raw_name.strip() == option_name:
                values.append(raw_value)
            break
    return values


def raw_ini_option_value(text: str, section_name: str, option_name: str) -> str | None:
    values = raw_ini_option_values(text, section_name, option_name)
    return values[0] if values else None


def malformed_run_seed_requested(text: str, schema: dict[str, Any]) -> bool:
    """Detect an explicit RunSeed request before malformed-INI fallback.

    The normal parser owns INI syntax and duplicate rejection.  If it rejects a
    file, a separately raw-scanned *enabled* RunSeed request stays fatal rather
    than being erased into an ordinary unseeded fallback.  An absent/disabled
    RunSeed remains inert even if an unrelated ordinary overlay key is malformed.
    """
    rule = schema["speedhack"].get("UseRunSeed")
    if rule is None:
        return False
    enabled = rule["accepted_true_values"]
    return any(
        value.strip().lower() in enabled
        for value in raw_ini_option_values(text, "Speedhack", "UseRunSeed")
    )


def malformed_difficulty_present(text: str) -> bool:
    """Keep an explicit Difficulty fail-closed when strict INI parsing fails."""
    return bool(raw_ini_option_values(text, "Speedhack", "Difficulty"))


def raw_enable_override_state(text: str) -> tuple[bool, str | None]:
    """Recover the authority request without trusting the rest of the INI.

    Missing is deliberately normal-player/in-game authority.  Any explicitly
    present non-canonical or duplicated value is a fail-closed configuration
    error.  A malformed file can therefore never partially activate external
    gameplay authority.
    """
    values = raw_ini_option_values(text, "Speedhack", "EnableOverride")
    if not values:
        return False, None
    if len(values) != 1:
        return any(value == "1" for value in values), "EnableOverride must occur exactly once"
    if values[0] == "0":
        return False, None
    if values[0] == "1":
        return True, None
    escaped = values[0].encode("unicode_escape").decode("ascii")
    return False, f"Invalid EnableOverride: {escaped}"


def parse_override(path: Path, schema: dict[str, Any] | None = None) -> ParsedOverride:
    schema = schema or load_schema()
    data, source_status, diagnostics = read_override(
        path, int(schema["file"]["maximum_bytes"])
    )
    if data is None:
        return default_result(schema, source_status, None, diagnostics)
    source_sha256 = sha256_bytes(data)
    text = ""
    try:
        text = data.decode(schema["file"]["encoding"])
        parser = configparser.ConfigParser(
            interpolation=None,
            strict=True,
            empty_lines_in_values=False,
        )
        parser.optionxform = str
        parser.read_string(text)
    except (UnicodeDecodeError, configparser.Error) as exc:
        enable_override, enable_override_error = raw_enable_override_state(text)
        fatal_run_seed = (
            isinstance(exc, configparser.Error)
            and enable_override
            and malformed_run_seed_requested(text, schema)
        )
        result = default_result(
            schema,
            "malformed",
            source_sha256,
            [f"override rejected as malformed: {type(exc).__name__}"],
            enable_override=enable_override,
            enable_override_error=enable_override_error,
            use_run_seed=fatal_run_seed,
            run_seed_request="invalid" if fatal_run_seed else "disabled",
            run_seed_error=(
                "RunSeed request occurred in malformed override"
                if fatal_run_seed
                else None
            ),
        )
        if (
            enable_override
            and isinstance(exc, configparser.Error)
            and malformed_difficulty_present(text)
        ):
            return ParsedOverride(
                **{
                    **result.__dict__,
                    "difficulty_error": "Difficulty occurred in malformed override",
                }
            )
        return result

    enable_override_rule = schema["speedhack"].get(
        "EnableOverride",
        {
            "accepted_true_values": ["1"],
            "accepted_false_values": ["0"],
            "default": False,
        },
    )
    enable_override = bool(enable_override_rule["default"])
    enable_override_error: str | None = None
    if parser.has_option("Speedhack", "EnableOverride"):
        raw_enable_override = raw_ini_option_value(
            text, "Speedhack", "EnableOverride"
        )
        if raw_enable_override in enable_override_rule["accepted_true_values"]:
            enable_override = True
        elif raw_enable_override in enable_override_rule["accepted_false_values"]:
            enable_override = False
        else:
            escaped = (raw_enable_override or "").encode(
                "unicode_escape"
            ).decode("ascii")
            enable_override_error = f"Invalid EnableOverride: {escaped}"

    known: dict[tuple[str, str], dict[str, Any]] = {}
    for name, rule in schema["speedhack"].items():
        known[("Speedhack", name)] = rule
    for rule in schema["official_options"]:
        known[(rule["section"], rule["name"])] = rule
    for section in parser.sections():
        for name in parser[section]:
            if (section, name) not in known:
                diagnostics.append(f"ignored unknown entry [{section}] {name}")

    config_version_rule = schema["speedhack"]["ConfigVersion"]
    config_version = config_version_rule["default"]
    if parser.has_option("Speedhack", "ConfigVersion"):
        candidate = parser.get("Speedhack", "ConfigVersion").strip()
        if candidate != str(config_version):
            return default_result(
                schema,
                "unsupported_config_version",
                source_sha256,
                diagnostics
                + [
                    "unsupported [Speedhack] ConfigVersion; overlay rejected"
                ],
            )

    profile_rule = schema["speedhack"]["Profile"]
    telemetry_rule = schema["speedhack"]["Telemetry"]
    lighting_mode_rule = schema["speedhack"]["LightingMode"]
    # Archived private kits carry the schema that existed when they were
    # frozen.  A pre-Difficulty schema must remain parseable as the product's
    # backward-compatible missing-key case instead of raising KeyError.
    difficulty_rule = schema["speedhack"].get(
        "Difficulty",
        {"default": "Original", "accepted_values": ["Original"]},
    )
    profile = profile_rule["default"]
    telemetry = telemetry_rule["default"]
    lighting_mode = lighting_mode_rule["default"]
    difficulty = difficulty_rule["default"]
    difficulty_error: str | None = None
    if parser.has_option("Speedhack", "Profile"):
        candidate = parser.get("Speedhack", "Profile").strip().lower()
        if candidate in profile_rule["accepted_values"]:
            profile = candidate
        else:
            diagnostics.append("invalid [Speedhack] Profile; using safe")
    if parser.has_option("Speedhack", "Telemetry"):
        candidate = parser.get("Speedhack", "Telemetry").strip().lower()
        if candidate in telemetry_rule["accepted_values"]:
            telemetry = candidate
        else:
            diagnostics.append("invalid [Speedhack] Telemetry; using off")
    if enable_override and parser.has_option("Speedhack", "LightingMode"):
        candidate = parser.get("Speedhack", "LightingMode").strip().lower()
        if candidate in lighting_mode_rule["accepted_values"]:
            lighting_mode = candidate
        else:
            diagnostics.append(
                "invalid [Speedhack] LightingMode; using standard"
            )
    if (
        profile == "safe"
        and lighting_mode not in lighting_mode_rule["safe_profile_values"]
    ):
        diagnostics.append(
            "rejected [Speedhack] LightingMode=fast in safe profile; using standard"
        )
        lighting_mode = lighting_mode_rule["default"]

    if enable_override and parser.has_option("Speedhack", "Difficulty"):
        # Difficulty values are deliberately case-sensitive, canonical product
        # tokens. Missing is backward-compatible Original; explicit bad input
        # is fatal rather than silently changing combat behavior.
        raw_difficulty = raw_ini_option_value(text, "Speedhack", "Difficulty")
        if raw_difficulty in difficulty_rule["accepted_values"]:
            difficulty = raw_difficulty
        else:
            escaped = (raw_difficulty or "").encode("unicode_escape").decode("ascii")
            difficulty_error = f"Invalid Difficulty: {escaped}"

    use_seed_rule = schema["speedhack"]["UseDungeonSeed"]
    seed_rule = schema["speedhack"]["DungeonSeed"]
    use_dungeon_seed = False
    dungeon_seed: int | None = None
    dungeon_seed_request = "disabled"
    dungeon_seed_error: str | None = None
    if enable_override and parser.has_option("Speedhack", "UseDungeonSeed"):
        candidate = parser.get("Speedhack", "UseDungeonSeed").strip().lower()
        if candidate in use_seed_rule["accepted_true_values"]:
            use_dungeon_seed = True
        elif candidate not in use_seed_rule["accepted_false_values"]:
            diagnostics.append(
                "invalid [Speedhack] UseDungeonSeed; seeded mode disabled"
            )
    if use_dungeon_seed:
        dungeon_seed_request = "generate"
        if parser.has_option("Speedhack", "DungeonSeed"):
            raw_seed = parser.get("Speedhack", "DungeonSeed").strip()
            if raw_seed:
                canonical_seed = (
                    raw_seed.isascii()
                    and raw_seed.isdecimal()
                    and (raw_seed == "0" or not raw_seed.startswith("0"))
                )
                if not canonical_seed:
                    dungeon_seed_request = "invalid"
                    escaped = raw_seed.encode("unicode_escape").decode("ascii")
                    dungeon_seed_error = f"Invalid DungeonSeed: {escaped}"
                else:
                    candidate_seed = int(raw_seed, 10)
                    if not seed_rule["minimum"] <= candidate_seed <= seed_rule["maximum"]:
                        dungeon_seed_request = "invalid"
                        dungeon_seed_error = f"Invalid DungeonSeed: {raw_seed}"
                    else:
                        dungeon_seed = candidate_seed
                        dungeon_seed_request = "configured"

    use_run_seed_rule = schema["speedhack"].get(
        "UseRunSeed",
        {
            "accepted_true_values": ["1", "true", "yes", "on"],
            "accepted_false_values": ["0", "false", "no", "off"],
        },
    )
    run_seed_rule = schema["speedhack"].get(
        "RunSeed", {"minimum": 1, "maximum": 2147483646}
    )
    use_run_seed = False
    run_seed: int | None = None
    run_seed_request = "disabled"
    run_seed_error: str | None = None
    if enable_override and parser.has_option("Speedhack", "UseRunSeed"):
        candidate = parser.get("Speedhack", "UseRunSeed").strip().lower()
        if candidate in use_run_seed_rule["accepted_true_values"]:
            use_run_seed = True
        elif candidate not in use_run_seed_rule["accepted_false_values"]:
            diagnostics.append("invalid [Speedhack] UseRunSeed; seeded mode disabled")
    if use_run_seed:
        # RunSeed is an external persistence/selection identity.  Do not
        # normalize it: accepting surrounding whitespace would create more
        # than one textual representation for the same selected runtime.
        raw_seed = raw_ini_option_value(text, "Speedhack", "RunSeed")
        if raw_seed is None:
            raw_seed = ""
        canonical_seed = (
            raw_seed.isascii()
            and raw_seed.isdecimal()
            and not raw_seed.startswith("0")
        )
        if not canonical_seed:
            run_seed_request = "invalid"
            escaped = raw_seed.encode("unicode_escape").decode("ascii")
            run_seed_error = f"Invalid RunSeed: {escaped}"
        else:
            candidate_seed = int(raw_seed, 10)
            if not run_seed_rule["minimum"] <= candidate_seed <= run_seed_rule["maximum"]:
                run_seed_request = "invalid"
                run_seed_error = f"Invalid RunSeed: {raw_seed}"
            else:
                run_seed = candidate_seed
                run_seed_request = "configured"
    if use_dungeon_seed and use_run_seed:
        dungeon_seed_request = "invalid"
        dungeon_seed_error = "DungeonSeed and RunSeed cannot both be enabled"
        run_seed_request = "invalid"
        run_seed_error = "DungeonSeed and RunSeed cannot both be enabled"

    values: dict[str, int | float] = {}
    applied: dict[str, int | float] = {}
    environment: dict[str, str] = {}
    for rule in schema["official_options"]:
        identity = f'{rule["section"]}.{rule["name"]}'
        base = rule["official_archive_value"]
        values[identity] = base
        if (
            not enable_override
            and identity == "Preferences.Lighting"
        ):
            continue
        if not parser.has_option(rule["section"], rule["name"]):
            continue
        raw = parser.get(rule["section"], rule["name"])
        try:
            value, normalized = parse_value(raw, rule)
        except ValueError as exc:
            diagnostics.append(f"invalid [{rule['section']}] {rule['name']}: {exc}")
            continue
        if profile == "safe" and value not in rule["safe_profile_values"]:
            diagnostics.append(
                f"rejected [{rule['section']}] {rule['name']} in safe profile"
            )
            continue
        values[identity] = value
        applied[identity] = value
        environment[rule["environment"]] = normalized

    return finish_result(
        source_status="loaded",
        source_sha256=source_sha256,
        enable_override=enable_override,
        enable_override_error=enable_override_error,
        config_version=config_version,
        profile=profile,
        telemetry=telemetry,
        lighting_mode=lighting_mode,
        difficulty=difficulty,
        difficulty_error=difficulty_error,
        use_dungeon_seed=use_dungeon_seed,
        dungeon_seed=dungeon_seed,
        dungeon_seed_request=dungeon_seed_request,
        dungeon_seed_error=dungeon_seed_error,
        use_run_seed=use_run_seed,
        run_seed=run_seed,
        run_seed_request=run_seed_request,
        run_seed_error=run_seed_error,
        official_values=values,
        applied_overrides=applied,
        environment=environment,
        diagnostics=diagnostics,
    )


def resolve_override(game_directory: Path) -> Path:
    if game_directory.is_symlink() or not game_directory.is_dir():
        raise ValueError("game directory must be a real directory")
    return game_directory.resolve() / OVERRIDE_BASENAME


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--game-dir", type=Path, required=True)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument("--environment-json", action="store_true")
    args = parser.parse_args()
    try:
        schema = load_schema(args.schema)
        result = parse_override(resolve_override(args.game_dir), schema)
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        print(f"options override validation failed: {exc}", file=sys.stderr)
        return 2
    if result.telemetry != "off":
        for diagnostic in result.diagnostics:
            print(f"options_override.ini: {diagnostic}", file=sys.stderr)
    document: Any = result.environment if args.environment_json else result.as_dict()
    print(json.dumps(document, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
