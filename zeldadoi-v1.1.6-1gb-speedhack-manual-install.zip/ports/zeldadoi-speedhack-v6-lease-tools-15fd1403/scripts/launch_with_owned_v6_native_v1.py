"""Explicit inactive V6 qualification hook over the unchanged shared launcher.

Only the explicit private qualification CLI selects this module. Archive/config verification,
installer locking, profiles, signals, telemetry and raw status remain owned by
the existing launcher. Only its GameMaker child's final native/env binding is
changed, after canonical options are resolved. No process result is wrapped.
"""
from contextlib import contextmanager
from pathlib import Path
import json
import sys

import launch_with_shared_runtime_authority_v6 as previous
import owned_v6_native_authority_v1 as native
from bounded_runtime_lock import runtime_lock, verify_runtime_lock_lease

PREVIOUS_SHA = '64a0ce611ac5a4146e9592e7f94b8e9e5b171805a71d491192cc90c1bedb8ac6'


def _verify_previous():
    path = Path(previous.__file__).resolve()
    native.require(path == native.ROOT / 'scripts/launch_with_shared_runtime_authority_v6.py',
                   'shared launcher origin differs')
    native.checked_file(path, maximum=2 * 1024**2, digest=PREVIOUS_SHA)
    previous.verify_sources()


class _CandidateSubprocess:
    def __init__(self, underlying, root, base_authority, before_game=None):
        self.underlying = underlying
        self.root = Path(root).absolute()
        self.base_authority = base_authority
        self.game_launches = 0
        self.game_process = None
        self.before_game = before_game
        self.lock_lease = None

    def __getattr__(self, name):
        return getattr(self.underlying, name)

    def Popen(self, *pos, **kwargs):
        stock = str(self.root / 'gmloadernext.aarch64')
        if not pos or not isinstance(pos[0], (list, tuple)) or not pos[0] or pos[0][0] != stock:
            return self.underlying.Popen(*pos, **kwargs)
        command = list(pos[0])
        configs = {str(self.root / row['runtime_config_path'])
                   for row in self.base_authority['runtimes'].values()}
        native.require(len(command) == 3 and command[1] == '-c' and command[2] in configs and
                       len(pos) == 1 and Path(kwargs.get('cwd', '')).absolute() == self.root,
                       'unexpected game command/cwd')
        native.require(self.game_launches == 0, 'duplicate game launch refused')
        binary, library = native.verify_native_and_providers(self.root)
        environment = native.child_environment(kwargs.get('env'), library)
        self.game_launches += 1
        verify_runtime_lock_lease(self.root / '.zeldadoi-speedhack', self.lock_lease)
        if self.before_game is not None:
            self.before_game()
        inherited = (*kwargs.get('pass_fds', ()), self.lock_lease.guard_fd)
        self.game_process = self.underlying.Popen([str(binary), *command[1:]],
                                                 **dict(kwargs, env=environment, pass_fds=inherited))
        return self.game_process


def run_game(args, enrollment_path, expected_enrollment_sha256, *, lock_lease=None, before_game=None):
    """A qualification caller must explicitly supply the exact enrollment hash."""
    native.legacy._sha256(expected_enrollment_sha256, 'expected_enrollment_sha256')
    native.require(before_game is None or callable(before_game), 'game prelaunch callback is invalid')
    _verify_previous()
    root = Path(args.game_dir).absolute()
    native.require(root.is_dir() and not root.is_symlink(), 'real game directory required')
    schema = native.shared.load_schema()
    enrollment = native.owned_path(root, native.ENROLLMENT_PATH)
    native.require(Path(enrollment_path).resolve(strict=True) == enrollment, 'enrollment path differs')
    document = native.legacy._read_regular_utf8_json(enrollment, 65536, expected_enrollment_sha256)
    native.require(getattr(args, 'runtime_authority', None) is not None and
                   getattr(args, 'runtime_authority_sha256', None) is not None,
                   'release-bound shared authority required')
    base_path = native.owned_path(root, schema['authority_manifest_path'])
    native.require(Path(args.runtime_authority).resolve(strict=True) == base_path and
                   args.runtime_authority_sha256 == document['shared_authority_sha256'],
                   'shared authority enrollment differs')
    base = native.shared.load_authority(base_path, expected_sha256=document['shared_authority_sha256'])
    native.validate_binding(document, base)
    native.require(args.command == [str(root / 'gmloadernext.aarch64'), '-c', str(root / 'gmloader.json')],
                   'original shared launcher command required')
    launcher = previous.bindings()
    # Existing bindings already create this invocation-local dictionary. Mutate
    # just its subprocess dependency; do not reconstruct functions or closures.
    scope = launcher.main.__globals__
    native.require(scope.get('parse_override') is previous._parse_for_launcher and
                   scope is not vars(previous), 'invocation-local launcher scope differs')
    native.require(scope.get('runtime_lock') is runtime_lock, 'shared runtime lock binding differs')
    observed = _CandidateSubprocess(scope['subprocess'], root, base, before_game)

    @contextmanager
    def hold_lock(state):
        with runtime_lock(state, lease=lock_lease) as acquired:
            observed.lock_lease = acquired
            yield acquired

    scope['runtime_lock'] = hold_lock
    scope['subprocess'] = observed
    try:
        return launcher.run_game(args)
    finally:
        child = observed.game_process
        if child is not None:
            print(json.dumps({'owned_v6_game_child_v1': {
                'pid': child.pid, 'raw_exit': child.returncode,
                'exit_observed': child.returncode is not None}}, sort_keys=True), flush=True)


if __name__ == '__main__':
    print('Inactive qualification hook: no launcher entrypoint has been enrolled.', file=sys.stderr)
    raise SystemExit(2)
