"""Aspect extension over the immutable configuration parser.

The predecessor parses the exact same single-read bytes and owns all existing
schema/authority/seed/profile errors. Aspect is separately identified presentation
state, deliberately excluded from the existing seed/runtime configuration digest.
This module is staged: do not wire a launcher until its runtime renders the mode.
"""
from copy import deepcopy
import configparser
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from types import FunctionType

import options_override as previous

MODES = ('16:9', '4:3', '1:1')
DEFAULT = '16:9'
ENVIRONMENT_KEY = 'ZELDADOI_SPEEDHACK_ASPECT_RATIO'
PRESENTATION_HASH_KEY = 'ZELDADOI_SPEEDHACK_PRESENTATION_SHA256'
PREVIOUS_SHA256 = 'ab1f69c2db340d1f5403c0c9923c930b927300ef027ac526cdae95ef9842ea20'


@dataclass(frozen=True)
class AspectOverride(previous.ParsedOverride):
    aspect_ratio: str
    presentation_sha256: str

    def as_dict(self):
        return dict(super().as_dict(), aspect_ratio=self.aspect_ratio,
                    presentation_sha256=self.presentation_sha256,
                    aspect_ratio_is_effective=self.enable_override,
                    normal_preference_resolution='GameMaker selected profile')


def parse_override(path, schema=None):
    if previous.sha256_bytes(Path(previous.__file__).read_bytes()) != PREVIOUS_SHA256:
        raise ValueError('aspect predecessor parser identity changed')
    schema = deepcopy(previous.load_schema() if schema is None else schema)
    rule = dict(default=DEFAULT, accepted_values=list(MODES))
    if 'AspectRatio' in schema['speedhack'] and schema['speedhack']['AspectRatio'] != rule:
        raise ValueError('AspectRatio schema differs from the canonical contract')
    schema['speedhack']['AspectRatio'] = rule
    snapshot = previous.read_override(path, int(schema['file']['maximum_bytes']))
    # Invocation-local reuse, never a global I/O monkeypatch. Both parsers see
    # one immutable read; file replacement cannot join two configurations.
    namespace = dict(vars(previous), read_override=lambda *_: snapshot)
    inherited = FunctionType(previous.parse_override.__code__, namespace,
                             previous.parse_override.__name__, previous.parse_override.__defaults__)
    result = inherited(path, schema)
    mode = DEFAULT
    if result.enable_override and snapshot[0] is not None:
        text = snapshot[0].decode(schema['file']['encoding'])
        values = previous.raw_ini_option_values(text, 'Speedhack', 'AspectRatio')
        if values:
            if result.source_status == 'malformed' or len(values) != 1 or values[0] not in MODES:
                raise ValueError('Invalid AspectRatio: expected one canonical 16:9, 4:3 or 1:1 value')
            parser = configparser.ConfigParser(interpolation=None, strict=True,
                                                empty_lines_in_values=False)
            parser.optionxform = str
            parser.read_string(text)
            if parser.get('Speedhack', 'AspectRatio') != values[0]:
                raise ValueError('Invalid AspectRatio: multiline value refused')
            mode = values[0]
    environment = dict(result.environment)
    environment.pop(ENVIRONMENT_KEY, None)
    if result.enable_override:
        environment[ENVIRONMENT_KEY] = mode
    presentation = dict(schema_version=1, configuration_source=result.configuration_source,
                        external_aspect_ratio=mode if result.enable_override else None)
    digest = hashlib.sha256(json.dumps(presentation, sort_keys=True,
                            separators=(',', ':')).encode()).hexdigest()
    environment[PRESENTATION_HASH_KEY] = digest
    return AspectOverride(**dict(result.__dict__, environment=environment),
                          aspect_ratio=mode, presentation_sha256=digest)


def effective_aspect(result, saved_preference):
    """Resolve the exclusive authority without mutating/synchronizing a carrier.

    This small reference is also the contract for the pending GameMaker wiring;
    its host tests are not proof of menu persistence or actual renderer behavior.
    """
    if result.enable_override_error is not None:
        raise ValueError(result.enable_override_error)
    if result.enable_override:
        if result.aspect_ratio not in MODES:
            raise ValueError('invalid effective external AspectRatio')
        return result.aspect_ratio
    return saved_preference if type(saved_preference) is str and saved_preference in MODES else DEFAULT
