"""Inactive fixed native component using the existing ownership/removal protocol.

The six-file directory (enrollment, loader, three libraries, install marker)
publishes with one no-replace rename under the existing shared runtime lock.
No archive, original native/library, save, default launcher or device setting is
written. This is a library for private qualification, not a public installer.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
from types import FunctionType, SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'device/tools'))
import speedhack_beta_device_v1 as ordinary
import owned_v6_native_authority_v1 as native
import verify_shared_runtime_pair_v2 as pair
from bounded_runtime_lock import runtime_lock, verify_runtime_lock_lease
from zeldadoi_temporary_workspace_v1 import make_workspace

STAGE_PREFIX = 'zeldadoi.owned-native-install.'
REMOVE_JOURNAL = '.native-remove.json'
# Exact intended CRT/Dungeon Seed package template, not current user INI bytes.
# Authority: config/options_override.release-crt-v1.default.ini / shared V9 contract.
DEFAULT_OVERRIDE_TEMPLATE_SHA256 = 'f4a7824c82551eb5d61208b3cedd5d80d7615faa8776029954b3a34d1821cfa6'
PINS = {
    ROOT / 'device/tools/speedhack_beta_device_v1.py': 'e0b266b30e7e690bb9444ebb4dbe071e84a0cca33794eb3038940b0944510389',
    ROOT / 'device/tools/materialize_current371_private_payload_v1.py': '50ef5e968842329eba47d0cacb45f27e49f2e12260f554f5fe8d50939e3ad59f',
    ROOT / 'scripts/bounded_runtime_lock.py': '26ff4ea4fe7752a5a7a0df642ecfa86a3196e2bb8d2fcfed47374152610533a3',
    ROOT / 'scripts/verify_shared_runtime_pair_v2.py': 'e0e0cc890975b0da3afe45d49ecfcb14c23837ee567da22f96d3d621af07629c',
    ROOT / 'scripts/zeldadoi_temporary_workspace_v1.py': 'd0f9ca2f25a449956b6124dcd1e3504806bb74ff68d6d608fbd1126c4f89d0d5',
    ROOT / 'scripts/owned_v6_native_authority_v1.py': '1d5cee85bb7337e4ace469ad60b437c4e8a256d6ce07be2a8af5cdee13e42820',
}


def _sources():
    for path, digest in PINS.items():
        native.checked_file(path, maximum=2 * 1024**2, digest=digest)
    native.require(Path(ordinary.__file__).resolve() == ROOT / 'device/tools/speedhack_beta_device_v1.py' and
                   Path(native.__file__).resolve() == ROOT / 'scripts/owned_v6_native_authority_v1.py',
                   'native component helper origin differs')
    native.require(native.ENROLLMENT_PATH == '.zeldadoi-speedhack/native/authority.json',
                   'enrollment must publish inside native component')


def _context(artifact_directory, expected_enrollment_sha256):
    _sources()
    native.legacy._sha256(expected_enrollment_sha256, 'expected_enrollment_sha256')
    artifacts = ordinary.safe(Path(artifact_directory).absolute(), directory=True)
    enrollment = artifacts / 'authority.json'
    document = native.legacy._read_regular_utf8_json(enrollment, 65536, expected_enrollment_sha256)
    raw = enrollment.read_bytes()
    native.require(0 < len(raw) <= 65536 and hashlib.sha256(raw).hexdigest() == expected_enrollment_sha256,
                   'enrollment changed after read')
    base = native.shared.load_authority(artifacts / 'runtime-authority.json',
                                       expected_sha256=document['shared_authority_sha256'])
    native.validate_binding(document, base)
    selected = native.contract()
    native.require(selected['native']['path'] == '.zeldadoi-speedhack/native/gmloadernext.aarch64' and
                   selected['library_directory'] == '.zeldadoi-speedhack/native/libs.aarch64',
                   'fixed component layout differs')
    files = [('authority.json', len(raw), expected_enrollment_sha256),
             ('gmloadernext.aarch64', selected['native']['bytes'], selected['native']['sha256'])]
    files += [('libs.aarch64/' + row['path'], row['bytes'], row['sha256'])
              for row in selected['library_files']]
    native.require(len(files) == 5, 'fixed native component file count')
    data = dict(build_id='owned-v6-native-' + expected_enrollment_sha256[:12], files=files,
                native=selected['native'])
    return artifacts, document, raw, selected, data


def _tools(lease):
    """Reuse verification verbatim; removal changes two fixed path literals."""
    scope = dict(vars(ordinary), runtime_files=lambda data: data['files'],
                 lock=lambda state: runtime_lock(state, lease=lease))
    old = ordinary.verify_tree
    scope['verify_tree'] = FunctionType(old.__code__, scope, old.__name__, old.__defaults__, old.__closure__)

    def verify_installed(state, data, digest):
        target = scope['verify_tree'](state / 'native', data, digest)
        row = data['native']
        native.checked_file(target / 'gmloadernext.aarch64', maximum=row['bytes'], size=row['bytes'],
                            digest=row['sha256'], executable=True)
        return target
    scope['verify_installed'] = verify_installed
    old = ordinary.remove
    replacements = {'.beta-remove.json': '.native-remove.json', 'installed': 'native'}
    for before in replacements:
        native.require(old.__code__.co_consts.count(before) == 1,
                       'existing removal constant seam differs')
    constants = tuple(replacements.get(value, value) if isinstance(value, str) else value
                      for value in old.__code__.co_consts)
    scope['remove'] = FunctionType(old.__code__.replace(co_consts=constants), scope,
                                   old.__name__, old.__defaults__, old.__closure__)
    return SimpleNamespace(verify_tree=scope['verify_tree'], verify_installed=verify_installed,
                           remove=scope['remove'], scope=scope)


def _root(game_root):
    root = ordinary.safe(Path(game_root).absolute(), directory=True)
    state = ordinary.safe(root / '.zeldadoi-speedhack', directory=True)
    return root, state


def _verify_base(root, document, lease):
    return pair.verify_installed_pair(root, document['shared_authority_sha256'],
                                      lock_lease=lease, require_complete_install=True,
                                      expected_default_override_template_sha256=DEFAULT_OVERRIDE_TEMPLATE_SHA256)


def _verify_component(tools, target, data, digest):
    tools.verify_tree(target, data, digest)
    row = data['native']
    native.checked_file(target / 'gmloadernext.aarch64', maximum=row['bytes'], size=row['bytes'],
                        digest=row['sha256'], executable=True)


def _copy(source, destination, size, digest, *, executable=False):
    ordinary.checked(source, size, digest)
    destination.parent.mkdir(parents=True, exist_ok=True)
    ordinary.safe(destination.parent, directory=True)
    with source.open('rb') as src, destination.open('xb') as out:
        shutil.copyfileobj(src, out, 65536)
        mode = 0o755 if executable or os.fstat(src.fileno()).st_mode & 0o111 else 0o644
        os.fchmod(out.fileno(), mode)
        out.flush()
        os.fsync(out.fileno())
    ordinary.checked(source, size, digest)
    ordinary.checked(destination, size, digest)
    ordinary.fsync_dir(destination.parent)


def install(game_root, artifact_directory, expected_enrollment_sha256, *, lease=None):
    artifacts, document, raw, selected, data = _context(artifact_directory, expected_enrollment_sha256)
    root, state = _root(game_root)
    with runtime_lock(state, lease=lease) as held:
        _verify_base(root, document, held)
        native.require(not os.path.lexists(state / REMOVE_JOURNAL), 'resume native removal first')
        tools = _tools(held)
        stages = [p for p in state.iterdir() if p.name.startswith(STAGE_PREFIX)]
        native.require(len(stages) <= 1, 'multiple native stages; preserve for inspection')
        target = state / 'native'
        if os.path.lexists(target):
            native.require(not stages, 'installed native and stale stage both present')
            tools.verify_installed(state, data, expected_enrollment_sha256)
            return dict(result='already_installed', component='owned-v6-native', native_executed=False)
        if stages:
            stage = stages[0]
            before = stage.stat()
            _verify_component(tools, stage, data, expected_enrollment_sha256)
            after = stage.stat()
            native.require((before.st_dev, before.st_ino, before.st_mtime_ns, before.st_ctime_ns) ==
                           (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_ctime_ns),
                           'completed native stage changed')
            verify_runtime_lock_lease(state, held)
            ordinary.fsync_dir(stage)
            ordinary.publish_new(stage, target)
            ordinary.fsync_dir(state)
            tools.verify_installed(state, data, expected_enrollment_sha256)
            return dict(result='recovered_completed_install', component='owned-v6-native', native_executed=False)
        sources = [(artifacts / 'gmloadernext.aarch64', 'gmloadernext.aarch64',
                    selected['native']['bytes'], selected['native']['sha256'])]
        sources += [(root / 'libs.aarch64' / row['path'], 'libs.aarch64/' + row['path'],
                     row['bytes'], row['sha256']) for row in selected['library_files']]
        for path, _, size, digest in sources:
            ordinary.checked(path, size, digest)
        stage = make_workspace('owned-native-install', parent=state,
                               required_bytes=sum(size for _, _, size, _ in sources) + len(raw) + 65536)
        ordinary.fsync_dir(state)
        with (stage / 'install.json').open('x') as out:
            json.dump(dict(build_id=data['build_id'], manifest_sha256=expected_enrollment_sha256), out, sort_keys=True)
            out.flush(); os.fsync(out.fileno())
        with (stage / 'authority.json').open('xb') as out:
            out.write(raw); out.flush(); os.fsync(out.fileno())
        for source, name, size, digest in sources:
            _copy(source, stage / name, size, digest, executable=name == 'gmloadernext.aarch64')
        _verify_component(tools, stage, data, expected_enrollment_sha256)
        verify_runtime_lock_lease(state, held)
        ordinary.fsync_dir(stage / 'libs.aarch64')
        ordinary.fsync_dir(stage)
        ordinary.publish_new(stage, target)
        ordinary.fsync_dir(state)
        tools.verify_installed(state, data, expected_enrollment_sha256)
        return dict(result='installed', component='owned-v6-native', native_executed=False)


def verify(game_root, artifact_directory, expected_enrollment_sha256, *, lease=None):
    _, document, _, _, data = _context(artifact_directory, expected_enrollment_sha256)
    root, state = _root(game_root)
    with runtime_lock(state, lease=lease) as held:
        _verify_base(root, document, held)
        native.require(not os.path.lexists(state / REMOVE_JOURNAL) and not any(
            p.name.startswith(STAGE_PREFIX) for p in state.iterdir()), 'unfinished native component state')
        _tools(held).verify_installed(state, data, expected_enrollment_sha256)
        return dict(result='verified', component='owned-v6-native', native_executed=False)


def remove(game_root, artifact_directory, expected_enrollment_sha256, *, lease=None):
    # The packaged snapshot remains the authority even after the ordinary pair
    # has been restored or the first owned file was removed before a crash.
    _, _, _, _, data = _context(artifact_directory, expected_enrollment_sha256)
    _, state = _root(game_root)
    with runtime_lock(state, lease=lease) as held:
        native.require(not any(p.name.startswith(STAGE_PREFIX) for p in state.iterdir()),
                       'native install stage preserved; do not remove it by prefix')
        if not os.path.lexists(state / 'native') and not os.path.lexists(state / REMOVE_JOURNAL):
            return dict(result='already_removed', component='owned-v6-native', native_executed=False)
        result = _tools(held).remove(state, data, expected_enrollment_sha256)
        return dict(result, component='owned-v6-native', native_executed=False)


if __name__ == '__main__':
    print('Inactive native component: no installer entrypoint has been enrolled.', file=sys.stderr)
    raise SystemExit(2)
