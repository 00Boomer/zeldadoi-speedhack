"""Project-owned deterministic lossless development codec for JSON value trees.

This is a correctness oracle, not yet a bounded-memory installer codec. It
preserves Python JSON scalar types, float bits, object insertion order, strings,
empty containers, nulls, booleans, and the source member's trailing-NUL count.
"""

from __future__ import annotations

import io
import struct
from dataclasses import dataclass
from typing import Any

MAGIC = b"ZDLF"
VERSION = 1
FLAG_INTERNED_STRINGS = 1

TAG_NULL = 0
TAG_FALSE = 1
TAG_TRUE = 2
TAG_INT64 = 3
TAG_FLOAT64 = 4
TAG_STRING = 5
TAG_ARRAY = 6
TAG_OBJECT = 7

I64_MIN = -(1 << 63)
I64_MAX = (1 << 63) - 1


def collect_strings(root: Any) -> list[str]:
    """Collect keys and string values in deterministic first-use order."""
    result: list[str] = []
    seen: set[str] = set()

    def add(value: str) -> None:
        if value not in seen:
            seen.add(value)
            result.append(value)

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                add(key)
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
        elif isinstance(value, str):
            add(value)

    walk(root)
    return result


class Encoder:
    def __init__(self, *, intern_strings: bool, trailing_nuls: int):
        if not 0 <= trailing_nuls <= 0xFFFFFFFF:
            raise ValueError("trailing-NUL count is outside u32")
        self.intern_strings = intern_strings
        self.trailing_nuls = trailing_nuls
        self.strings: list[str] = []
        self.string_index: dict[str, int] = {}
        self.buffer = io.BytesIO()

    def _write_bytes(self, value: bytes) -> None:
        if len(value) > 0xFFFFFFFF:
            raise ValueError("encoded string exceeds u32 length")
        self.buffer.write(struct.pack("<I", len(value)))
        self.buffer.write(value)
        self.buffer.write(b"\x00")

    def _write_string(self, value: str) -> None:
        if self.intern_strings:
            self.buffer.write(struct.pack("<I", self.string_index[value]))
        else:
            self._write_bytes(value.encode("utf-8"))

    def _write_value(self, value: Any) -> None:
        if value is None:
            self.buffer.write(bytes((TAG_NULL,)))
        elif value is False:
            self.buffer.write(bytes((TAG_FALSE,)))
        elif value is True:
            self.buffer.write(bytes((TAG_TRUE,)))
        elif type(value) is int:
            if not I64_MIN <= value <= I64_MAX:
                raise ValueError(f"integer is outside signed 64-bit range: {value}")
            self.buffer.write(struct.pack("<Bq", TAG_INT64, value))
        elif type(value) is float:
            self.buffer.write(struct.pack("<Bd", TAG_FLOAT64, value))
        elif isinstance(value, str):
            self.buffer.write(bytes((TAG_STRING,)))
            self._write_string(value)
        elif isinstance(value, list):
            if len(value) > 0xFFFFFFFF:
                raise ValueError("array exceeds u32 count")
            self.buffer.write(struct.pack("<BI", TAG_ARRAY, len(value)))
            for child in value:
                self._write_value(child)
        elif isinstance(value, dict):
            if len(value) > 0xFFFFFFFF:
                raise ValueError("object exceeds u32 count")
            self.buffer.write(struct.pack("<BI", TAG_OBJECT, len(value)))
            for key, child in value.items():
                if not isinstance(key, str):
                    raise TypeError("JSON object key is not a string")
                self._write_string(key)
                self._write_value(child)
        else:
            raise TypeError(f"unsupported value type: {type(value).__name__}")

    def encode(self, root: Any) -> bytes:
        if self.buffer.tell() != 0:
            raise RuntimeError("encoder instances are single-use")
        flags = FLAG_INTERNED_STRINGS if self.intern_strings else 0
        self.buffer.write(MAGIC)
        self.buffer.write(struct.pack("<BBI", VERSION, flags, self.trailing_nuls))
        if self.intern_strings:
            self.strings = collect_strings(root)
            self.string_index = {value: index for index, value in enumerate(self.strings)}
            self.buffer.write(struct.pack("<I", len(self.strings)))
            for value in self.strings:
                self._write_bytes(value.encode("utf-8"))
        self._write_value(root)
        return self.buffer.getvalue()


@dataclass(frozen=True)
class DecodedDocument:
    root: Any
    trailing_nuls: int
    interned_strings: bool


class Decoder:
    def __init__(self, payload: bytes):
        self.payload = payload
        self.position = 0
        self.interned_strings = False
        self.strings: list[str] = []

    def _read(self, size: int) -> bytes:
        value = self.payload[self.position : self.position + size]
        if len(value) != size:
            raise EOFError(
                f"wanted {size} bytes at {self.position}, got {len(value)}"
            )
        self.position += size
        return value

    def _unpack(self, fmt: str) -> tuple[Any, ...]:
        return struct.unpack(fmt, self._read(struct.calcsize(fmt)))

    def _read_bytes(self) -> bytes:
        length, = self._unpack("<I")
        value = self._read(length)
        if self._read(1) != b"\x00":
            raise ValueError("encoded string is missing its NUL terminator")
        return value

    def _read_string(self) -> str:
        if self.interned_strings:
            index, = self._unpack("<I")
            if index >= len(self.strings):
                raise ValueError(f"string index {index} is out of range")
            return self.strings[index]
        return self._read_bytes().decode("utf-8")

    def _read_value(self) -> Any:
        tag = self._read(1)[0]
        if tag == TAG_NULL:
            return None
        if tag == TAG_FALSE:
            return False
        if tag == TAG_TRUE:
            return True
        if tag == TAG_INT64:
            return self._unpack("<q")[0]
        if tag == TAG_FLOAT64:
            return self._unpack("<d")[0]
        if tag == TAG_STRING:
            return self._read_string()
        if tag == TAG_ARRAY:
            count, = self._unpack("<I")
            return [self._read_value() for _ in range(count)]
        if tag == TAG_OBJECT:
            count, = self._unpack("<I")
            result: dict[str, Any] = {}
            for _ in range(count):
                key = self._read_string()
                if key in result:
                    raise ValueError(f"duplicate object key in encoded payload: {key!r}")
                result[key] = self._read_value()
            return result
        raise ValueError(f"unknown tag {tag} at offset {self.position - 1}")

    def decode(self) -> DecodedDocument:
        if self._read(4) != MAGIC:
            raise ValueError("bad lossless data magic")
        version, flags, trailing_nuls = self._unpack("<BBI")
        if version != VERSION:
            raise ValueError(f"unsupported lossless data version {version}")
        if flags & ~FLAG_INTERNED_STRINGS:
            raise ValueError(f"unsupported lossless data flags {flags:#x}")
        self.interned_strings = bool(flags & FLAG_INTERNED_STRINGS)
        if self.interned_strings:
            count, = self._unpack("<I")
            for _ in range(count):
                self.strings.append(self._read_bytes().decode("utf-8"))
            if len(set(self.strings)) != len(self.strings):
                raise ValueError("duplicate strings in intern table")
        root = self._read_value()
        if self.position != len(self.payload):
            raise ValueError(f"trailing encoded bytes: {len(self.payload) - self.position}")
        return DecodedDocument(root, trailing_nuls, self.interned_strings)


def encode(root: Any, *, intern_strings: bool, trailing_nuls: int) -> bytes:
    return Encoder(
        intern_strings=intern_strings, trailing_nuls=trailing_nuls
    ).encode(root)


def decode(payload: bytes) -> DecodedDocument:
    return Decoder(payload).decode()


def exact_equal(left: Any, right: Any) -> bool:
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return list(left) == list(right) and all(
            exact_equal(left[key], right[key]) for key in left
        )
    if isinstance(left, list):
        return len(left) == len(right) and all(
            exact_equal(a, b) for a, b in zip(left, right)
        )
    if type(left) is float:
        return struct.pack("<d", left) == struct.pack("<d", right)
    return left == right
