"""Staged Filter/Aspect child handoff over the unchanged profile transport.

Separately versioned development successor, not installed or release-approved.
Preserves V3 and its evidence; never changes the parent process environment.
"""
import hashlib
from pathlib import Path
import sys
from types import FunctionType

import launch_with_options_override_v3 as previous
import launch_with_options_override_v2 as transport
import options_override_filter_v1 as filters

PINS = {
    Path(previous.__file__): '7d51795f3f7f9129cb59556464eb04aac70d224c946f3ea5b8470fe8521f5f21',
    Path(transport.__file__): 'dfc74f237d1cd6222527a96ff15eaaf8140664a9d693084328d144f61ad4d272',
    Path(filters.__file__): 'efee3e2103b1ca27e4bd71ba5c477aaa1eba7b140befca8bd015902c444134e8',
}


class _FilterConfigurationRefusal(ValueError):
    pass


def _parse_for_launcher(*args, **kwargs):
    try:
        if any(hashlib.sha256(path.read_bytes()).hexdigest() != pin for path, pin in PINS.items()):
            raise ValueError('Filter launcher predecessor identity changed')
        return filters.parse_override(*args, **kwargs)
    except ValueError as error:
        raise _FilterConfigurationRefusal(str(error)) from error


# V3 adds only its Aspect parse seam/error wrapper to this same transport.
# Rebind the transport directly, avoiding a V3 wrapper whose globals would
# still call the older parser. No mutation of either predecessor namespace.
_namespace = dict(transport._namespace)
_namespace['parse_override'] = _parse_for_launcher
_namespace['CONFIG_ENVIRONMENT_KEYS'] = set(_namespace['CONFIG_ENVIRONMENT_KEYS']) | {
    filters.ENVIRONMENT_KEY, filters.previous.ENVIRONMENT_KEY,
    filters.previous.PRESENTATION_HASH_KEY}
for _name, _value in tuple(_namespace.items()):
    if isinstance(_value, FunctionType) and _value.__globals__ is transport._namespace:
        _invoke = FunctionType(_value.__code__, _namespace, _value.__name__,
                               _value.__defaults__, _value.__closure__)
        _invoke.__kwdefaults__ = _value.__kwdefaults__
        _namespace[_name] = _invoke
for _name, _value in _namespace.items():
    if not _name.startswith('__'):
        globals()[_name] = _value

_inherited_run_game = run_game


def run_game(args):
    try:
        return _inherited_run_game(args)
    except _FilterConfigurationRefusal as error:
        print('ERROR: '+str(error), file=sys.stderr)
        return 2


_namespace['run_game'] = run_game


if __name__ == '__main__':
    raise SystemExit(main())
