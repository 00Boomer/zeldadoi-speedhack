"""Staged single-Dungeon-Seed child transport, preserving the shared runtime.

This changes the parser seam only. It is not a production/package adoption or
save-compatibility qualification; current VM/carrier integration is still open.
The pinned predecessor owns installer locking, final pair verification,
ephemeral profile identities, child environment, signals and telemetry.
"""
import inspect
from pathlib import Path
import sys
from types import FunctionType, SimpleNamespace

import launch_with_shared_runtime_authority_v4 as previous
import options_override_dungeon_seed_v1 as seeds

PINS = {
    Path(previous.__file__): '824ccfdc5bbcd2db1e88f97dcbe1f9a393ce01255a33d5278e9a90f41368d74d',
    Path(previous.previous.transport.prior.__file__): '9874819fcb15bbaf16b54559ac459e5e4a897b03e2e1779de0e7bb5cbe1e8cee',
    Path(seeds.__file__): '0cab10365a9a53e00603f4a6f8eefcb1082ae43e7ed6425aa63b2eeaf88c65a2',
    Path(seeds.previous.previous.previous.DEFAULT_SCHEMA): '613ee717877c82b462740e7c617768aab51ce9a0cf9d3aac4faacdd6555c52f7',
}


class _DungeonSeedConfigurationRefusal(ValueError):
    pass


def verify_sources():
    for path, pin in PINS.items():
        if previous._checked_sha256(path) != pin:
            raise ValueError('Dungeon Seed shared launcher predecessor identity changed')
    previous._verify_predecessors()
    seeds.verify_sources()


def _parse_for_launcher(path, schema=None):
    try:
        verify_sources()
        canonical = seeds.previous.previous.previous.load_schema()
        if schema is not None and schema != canonical:
            raise ValueError('Dungeon Seed launcher options schema differs from pinned authority')
        return seeds.parse_override(path, canonical)
    except ValueError as error:
        raise _DungeonSeedConfigurationRefusal(str(error)) from error


def bindings(authority_schema_path=previous.authority.DEFAULT_SCHEMA):
    verify_sources()
    old = previous.bindings(authority_schema_path)
    original_scope = old.main.__globals__
    scope = dict(vars(old), parse_override=_parse_for_launcher, __file__=__file__)
    for name, value in tuple(scope.items()):
        if isinstance(value, FunctionType) and value.__globals__ is original_scope:
            clone = FunctionType(value.__code__, scope, value.__name__,
                                 value.__defaults__, value.__closure__)
            clone.__kwdefaults__ = value.__kwdefaults__; scope[name] = clone
    # V4's run_game is an exception wrapper around a closure holding its old
    # namespace. Reconstruct its exact pinned inherited body, not that closure.
    legacy = previous.previous.transport.prior
    body = inspect.getsource(legacy.run_game)
    old_import = 'import bounded_runtime_pair_verify as runtime_pair_verify'
    if body.count(old_import) != 1:
        raise ValueError('Dungeon Seed shared launcher final verification seam changed')
    body = body.replace(old_import, 'runtime_pair_verify = shared_runtime_pair_verifier', 1)
    exec(compile(body, '<pinned shared launch; single Dungeon Seed parser>', 'exec'), scope)
    inherited = scope['run_game']
    def run_game(args):
        try:
            return inherited(args)
        except _DungeonSeedConfigurationRefusal as error:
            print('ERROR: '+str(error), file=sys.stderr)
            return 2
    scope['run_game'] = run_game
    return SimpleNamespace(**scope)


def run_game(args): return bindings().run_game(args)
def main(): return bindings().main()


if __name__ == '__main__': raise SystemExit(main())
