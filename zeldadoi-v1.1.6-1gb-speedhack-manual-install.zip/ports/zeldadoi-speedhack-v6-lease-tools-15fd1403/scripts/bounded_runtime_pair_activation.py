#!/usr/bin/env python3
"""Crash-recoverable activation of the fixed ZeldaDOI dual-runtime pair.

This module consumes a fully generated, hash-authorized staging mirror.  It
does not build either GameMaker runtime and it does not grant production,
determinism, parity, or physical-device authority.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from pathlib import Path
from typing import Any, NoReturn

from bounded_runtime_lock import (
    OWNER,
    RuntimeLockLease,
    fsync_directory,
    runtime_lock,
)
from convert_official_cache_bounded import atomic_activate_no_replace
from runtime_authority import DEFAULT_SCHEMA, load_authority, load_schema
import runtime_pair_capacity as capacity_model


PAIR_JOURNAL = "runtime-pair-transaction.json"
PAIR_JOURNAL_NEXT = "runtime-pair-transaction.next"
PAIR_CURRENT = "runtime-pair-current.json"
PAIR_CURRENT_NEXT = "runtime-pair-current.next"
STAGE_PREFIX = ".zeldadoi-runtime-pair-stage-"
PHASES = (
    "validated",
    "seeded-archive-activated",
    "seeded-config-activated",
    "authority-activated",
    "default-archive-activated",
    "state-committed",
)
JOURNAL_KEYS = {
    "schema_version",
    "owner",
    "release_id",
    "authority_sha256",
    "official_archive_sha256",
    "default_archive_sha256",
    "seeded_archive_sha256",
    "default_config_sha256",
    "seeded_config_sha256",
    "stage_basename",
    "phase",
}
CURRENT_KEYS = {
    "schema_version",
    "owner",
    "release_id",
    "authority_sha256",
    "default_archive_sha256",
    "seeded_archive_sha256",
    "seeded_config_sha256",
}
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
RELEASE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
MAX_JSON_BYTES = 65536


class PairActivationError(ValueError):
    """The fixed pair transaction is unsafe, foreign, or inconsistent."""


def reject(message: str) -> NoReturn:
    raise PairActivationError(message)


def file_identity(path: Path, label: str) -> tuple[int, str]:
    """Hash one regular single-link file through a stable descriptor."""
    try:
        initial = path.lstat()
    except OSError as exc:
        reject(f"cannot stat {label}: {exc}")
    if (
        stat.S_ISLNK(initial.st_mode)
        or not stat.S_ISREG(initial.st_mode)
        or initial.st_nlink != 1
        or initial.st_size <= 0
    ):
        reject(f"{label} must be a nonempty regular single-link file")
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or (opened.st_dev, opened.st_ino) != (initial.st_dev, initial.st_ino)
            or opened.st_size != initial.st_size
        ):
            reject(f"{label} changed while opening")
        digest = hashlib.sha256()
        size = 0
        while block := os.read(descriptor, 1024 * 1024):
            digest.update(block)
            size += len(block)
        final = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    if (
        size != opened.st_size
        or final.st_size != opened.st_size
        or final.st_mtime_ns != opened.st_mtime_ns
        or final.st_ctime_ns != opened.st_ctime_ns
    ):
        reject(f"{label} changed while reading")
    return size, digest.hexdigest()


def sha256_file(path: Path) -> str:
    return file_identity(path, "runtime-pair file")[1]


def canonical_bytes(document: dict[str, Any]) -> bytes:
    return (
        json.dumps(document, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")


def duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            reject(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_nonfinite(value: str) -> NoReturn:
    reject(f"non-finite JSON value is forbidden: {value}")


def read_json(path: Path, label: str) -> dict[str, Any]:
    try:
        metadata = path.lstat()
    except OSError as exc:
        reject(f"cannot stat {label}: {exc}")
    if (
        stat.S_ISLNK(metadata.st_mode)
        or not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
        or metadata.st_size < 2
        or metadata.st_size > MAX_JSON_BYTES
    ):
        reject(f"{label} must be a bounded regular single-link file")
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags)
    try:
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or (opened.st_dev, opened.st_ino) != (metadata.st_dev, metadata.st_ino)
            or opened.st_size != metadata.st_size
        ):
            reject(f"{label} changed while opening")
        chunks: list[bytes] = []
        remaining = MAX_JSON_BYTES + 1
        while remaining:
            block = os.read(descriptor, min(65536, remaining))
            if not block:
                break
            chunks.append(block)
            remaining -= len(block)
        raw = b"".join(chunks)
        final = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    if (
        len(raw) != opened.st_size
        or final.st_size != opened.st_size
        or final.st_mtime_ns != opened.st_mtime_ns
        or final.st_ctime_ns != opened.st_ctime_ns
    ):
        reject(f"{label} changed while reading")
    if raw.startswith(b"\xef\xbb\xbf"):
        reject(f"{label} must not contain a UTF-8 BOM")
    try:
        value = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=duplicate_keys,
            parse_constant=reject_nonfinite,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        reject(f"{label} is not strict UTF-8 JSON: {exc}")
    if not isinstance(value, dict):
        reject(f"{label} must be a JSON object")
    return value


def verify_file(path: Path, size: int, digest: str, label: str) -> None:
    if (
        type(size) is not int
        or size <= 0
        or HEX64.fullmatch(digest) is None
    ):
        reject(f"{label} identity mismatch")
    observed_size, observed_digest = file_identity(path, label)
    if observed_size != size or observed_digest != digest:
        reject(f"{label} identity mismatch")


def classify_file(
    path: Path,
    identities: tuple[tuple[str, int, str], ...],
    label: str,
) -> str:
    """Classify one regular file against a small exact identity set."""
    size, digest = file_identity(path, label)
    matches = [
        name for name, expected_size, expected in identities
        if size == expected_size and digest == expected
    ]
    if len(matches) != 1:
        reject(f"{label} has no unique authorized identity")
    return matches[0]


def path_state(path: Path, size: int, digest: str, label: str) -> str:
    if not path.exists() and not path.is_symlink():
        return "absent"
    verify_file(path, size, digest, label)
    return "exact"


def exact_root(path: Path, label: str) -> Path:
    absolute = Path(os.path.abspath(path))
    try:
        metadata = absolute.lstat()
    except OSError as exc:
        reject(f"cannot stat {label}: {exc}")
    if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
        reject(f"{label} must be a real directory")
    if absolute.resolve() != absolute:
        reject(f"{label} must not traverse symbolic path components")
    return absolute


def validate_document_keys(
    document: dict[str, Any], expected: set[str], label: str
) -> None:
    if set(document) != expected:
        reject(
            f"{label} key coverage mismatch: "
            f"missing={sorted(expected - set(document))} "
            f"unknown={sorted(set(document) - expected)}"
        )


def validate_journal(document: dict[str, Any]) -> dict[str, Any]:
    validate_document_keys(document, JOURNAL_KEYS, "runtime-pair journal")
    if document["schema_version"] != 1 or document["owner"] != OWNER:
        reject("runtime-pair journal schema or owner mismatch")
    if type(document["release_id"]) is not str or RELEASE_ID.fullmatch(
        document["release_id"]
    ) is None:
        reject("runtime-pair journal release ID is invalid")
    for key in JOURNAL_KEYS:
        if key.endswith("_sha256") and (
            type(document[key]) is not str or HEX64.fullmatch(document[key]) is None
        ):
            reject(f"runtime-pair journal digest is invalid: {key}")
    expected_stage = STAGE_PREFIX + document["release_id"]
    if document["stage_basename"] != expected_stage:
        reject("runtime-pair journal stage basename mismatch")
    if document["phase"] not in PHASES:
        reject("runtime-pair journal phase is invalid")
    return dict(document)


def validate_current(document: dict[str, Any]) -> dict[str, Any]:
    validate_document_keys(document, CURRENT_KEYS, "runtime-pair current state")
    if document["schema_version"] != 1 or document["owner"] != OWNER:
        reject("runtime-pair current state schema or owner mismatch")
    if type(document["release_id"]) is not str or RELEASE_ID.fullmatch(
        document["release_id"]
    ) is None:
        reject("runtime-pair current release ID is invalid")
    for key in CURRENT_KEYS:
        if key.endswith("_sha256") and (
            type(document[key]) is not str or HEX64.fullmatch(document[key]) is None
        ):
            reject(f"runtime-pair current digest is invalid: {key}")
    return dict(document)


def write_atomic(state: Path, name: str, next_name: str, payload: bytes) -> None:
    target = state / name
    pending = state / next_name
    if target.is_symlink() or (target.exists() and not target.is_file()):
        reject(f"unsafe owned state path: {name}")
    if pending.exists() or pending.is_symlink():
        reject(f"pending owned state path already exists: {next_name}")
    descriptor = os.open(
        pending,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
        0o600,
    )
    with os.fdopen(descriptor, "wb", closefd=True) as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(pending, target)
    fsync_directory(state)


def write_journal(state: Path, document: dict[str, Any]) -> None:
    write_atomic(
        state,
        PAIR_JOURNAL,
        PAIR_JOURNAL_NEXT,
        canonical_bytes(validate_journal(document)),
    )


def reconcile_pending_journal(
    state: Path, expected: dict[str, Any]
) -> dict[str, Any] | None:
    transaction = state / PAIR_JOURNAL
    pending = state / PAIR_JOURNAL_NEXT
    if not pending.exists() and not pending.is_symlink():
        return None
    pending_document = validate_journal(
        read_json(pending, "pending runtime-pair journal")
    )
    verify_release_journal(pending_document, expected)
    if transaction.exists() or transaction.is_symlink():
        current = validate_journal(read_json(transaction, "runtime-pair journal"))
        verify_release_journal(current, expected)
        current_index = PHASES.index(current["phase"])
        if (
            current_index + 1 >= len(PHASES)
            or pending_document["phase"] != PHASES[current_index + 1]
        ):
            reject("pending runtime-pair journal is not the exact next phase")
    elif pending_document["phase"] != "validated":
        reject("orphan pending runtime-pair journal is not the initial phase")
    os.replace(pending, transaction)
    fsync_directory(state)
    return pending_document


def reconcile_pending_current(state: Path, expected: dict[str, Any]) -> None:
    target = state / PAIR_CURRENT
    pending = state / PAIR_CURRENT_NEXT
    if not pending.exists() and not pending.is_symlink():
        return
    observed = validate_current(
        read_json(pending, "pending runtime-pair current state")
    )
    if observed != expected:
        reject("pending runtime-pair current state is foreign or mismatched")
    if target.exists() or target.is_symlink():
        reject("pending and installed runtime-pair current state both exist")
    os.replace(pending, target)
    fsync_directory(state)


def advance_journal(state: Path, document: dict[str, Any], phase: str) -> dict[str, Any]:
    checked = validate_journal(document)
    current_index = PHASES.index(checked["phase"])
    if current_index + 1 >= len(PHASES) or PHASES[current_index + 1] != phase:
        reject("runtime-pair phase advance must be exactly monotonic")
    checked["phase"] = phase
    write_journal(state, checked)
    return checked


def current_document(journal: dict[str, Any]) -> dict[str, Any]:
    return validate_current({
        "schema_version": 1,
        "owner": OWNER,
        "release_id": journal["release_id"],
        "authority_sha256": journal["authority_sha256"],
        "default_archive_sha256": journal["default_archive_sha256"],
        "seeded_archive_sha256": journal["seeded_archive_sha256"],
        "seeded_config_sha256": journal["seeded_config_sha256"],
    })


def require_state_owner(state: Path) -> None:
    owner = state / "owner"
    if state.is_symlink() or not state.is_dir():
        reject("runtime-pair state directory is missing or unsafe")
    if owner.is_symlink() or not owner.is_file() or owner.stat().st_nlink != 1:
        reject("runtime-pair state owner is missing or unsafe")
    if owner.read_text(encoding="utf-8") != OWNER + "\n":
        reject("runtime-pair state owner mismatch")


def stage_inventory(stage: Path, allowed_files: set[str]) -> None:
    allowed_directories = {".zeldadoi-speedhack"}
    for path in stage.rglob("*"):
        relative = path.relative_to(stage).as_posix()
        if path.is_symlink():
            reject(f"runtime-pair stage contains a symlink: {relative}")
        if path.is_dir() and relative not in allowed_directories:
            reject(f"runtime-pair stage contains an unknown directory: {relative}")
        if path.is_file() and relative not in allowed_files:
            reject(f"runtime-pair stage contains an unknown file: {relative}")


def build_context(
    game_root: Path,
    stage: Path,
    expected_authority_sha256: str,
    schema_path: Path,
) -> dict[str, Any]:
    if HEX64.fullmatch(expected_authority_sha256) is None:
        reject("expected runtime authority must be a lowercase SHA-256")
    game_root = exact_root(game_root, "game root")
    state = game_root / ".zeldadoi-speedhack"
    require_state_owner(state)
    stage = exact_root(stage, "runtime-pair stage")
    if stage.parent != state or not stage.name.startswith(STAGE_PREFIX):
        reject("runtime-pair stage is outside the fixed owned namespace")

    schema = load_schema(schema_path)
    staged_authority = stage / schema["authority_manifest_path"]
    installed_authority = game_root / schema["authority_manifest_path"]
    staged_authority_exists = staged_authority.exists() or staged_authority.is_symlink()
    installed_authority_exists = (
        installed_authority.exists() or installed_authority.is_symlink()
    )
    if staged_authority_exists == installed_authority_exists:
        reject("runtime authority must exist in exactly one staged or installed location")
    authority_path = staged_authority if staged_authority_exists else installed_authority
    authority = load_authority(
        authority_path, schema_path, expected_sha256=expected_authority_sha256
    )
    authority_size, observed_authority_sha256 = file_identity(
        authority_path, "runtime authority"
    )
    if observed_authority_sha256 != expected_authority_sha256:
        reject("runtime authority identity changed after validation")
    if stage.name != STAGE_PREFIX + authority["release_id"]:
        reject("runtime-pair stage does not match the authority release ID")

    official_rule = schema["official_source"]["archive"]
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    paths = {
        "active_default": game_root / default["archive_path"],
        "preserved_official": game_root / official_rule["path"],
        "default_config": game_root / default["runtime_config_path"],
        "seeded_archive": game_root / seeded["archive_path"],
        "seeded_config": game_root / seeded["runtime_config_path"],
        "authority": installed_authority,
        "staged_official": stage / official_rule["path"],
        "staged_default": stage / default["archive_path"],
        "staged_default_config": stage / default["runtime_config_path"],
        "staged_seeded": stage / seeded["archive_path"],
        "staged_seeded_config": stage / seeded["runtime_config_path"],
        "staged_authority": staged_authority,
    }
    allowed = {
        official_rule["path"],
        default["archive_path"],
        default["runtime_config_path"],
        seeded["archive_path"],
        seeded["runtime_config_path"],
        schema["authority_manifest_path"],
    }
    stage_inventory(stage, allowed)
    verify_file(
        paths["preserved_official"],
        official_rule["size"],
        official_rule["sha256"],
        "preserved official archive",
    )
    verify_file(
        paths["default_config"],
        default["runtime_config_size"],
        default["runtime_config_sha256"],
        "installed default runtime config",
    )
    verify_file(
        paths["staged_official"],
        official_rule["size"],
        official_rule["sha256"],
        "staged official archive",
    )
    verify_file(
        paths["staged_default_config"],
        default["runtime_config_size"],
        default["runtime_config_sha256"],
        "staged default runtime config",
    )
    journal = validate_journal({
        "schema_version": 1,
        "owner": OWNER,
        "release_id": authority["release_id"],
        "authority_sha256": expected_authority_sha256,
        "official_archive_sha256": official_rule["sha256"],
        "default_archive_sha256": default["archive_sha256"],
        "seeded_archive_sha256": seeded["archive_sha256"],
        "default_config_sha256": default["runtime_config_sha256"],
        "seeded_config_sha256": seeded["runtime_config_sha256"],
        "stage_basename": stage.name,
        "phase": "validated",
    })
    return {
        "root": game_root,
        "state": state,
        "stage": stage,
        "schema": schema,
        "authority": authority,
        "paths": paths,
        "journal": journal,
        "official": official_rule,
        "default": default,
        "seeded": seeded,
        "authority_size": authority_size,
    }


def installed_pair_context(
    game_root: Path,
    expected_authority_sha256: str,
    schema_path: Path,
) -> dict[str, Any]:
    """Validate a complete installed pair when no staging directory remains."""
    if HEX64.fullmatch(expected_authority_sha256) is None:
        reject("expected runtime authority must be a lowercase SHA-256")
    game_root = exact_root(game_root, "game root")
    state = game_root / ".zeldadoi-speedhack"
    require_state_owner(state)
    schema = load_schema(schema_path)
    authority_path = game_root / schema["authority_manifest_path"]
    authority = load_authority(
        authority_path, schema_path, expected_sha256=expected_authority_sha256
    )
    official = schema["official_source"]["archive"]
    default = authority["runtimes"]["default"]
    seeded = authority["runtimes"]["seeded"]
    for path, size, digest, label in (
        (
            game_root / official["path"],
            official["size"],
            official["sha256"],
            "preserved official archive",
        ),
        (
            game_root / default["archive_path"],
            default["archive_size"],
            default["archive_sha256"],
            "installed default runtime archive",
        ),
        (
            game_root / default["runtime_config_path"],
            default["runtime_config_size"],
            default["runtime_config_sha256"],
            "installed default runtime config",
        ),
        (
            game_root / seeded["archive_path"],
            seeded["archive_size"],
            seeded["archive_sha256"],
            "installed seeded runtime archive",
        ),
        (
            game_root / seeded["runtime_config_path"],
            seeded["runtime_config_size"],
            seeded["runtime_config_sha256"],
            "installed seeded runtime config",
        ),
        (
            authority_path,
            file_identity(authority_path, "installed runtime authority")[0],
            expected_authority_sha256,
            "installed runtime authority",
        ),
    ):
        verify_file(path, size, digest, label)
    journal = validate_journal({
        "schema_version": 1,
        "owner": OWNER,
        "release_id": authority["release_id"],
        "authority_sha256": expected_authority_sha256,
        "official_archive_sha256": official["sha256"],
        "default_archive_sha256": default["archive_sha256"],
        "seeded_archive_sha256": seeded["archive_sha256"],
        "default_config_sha256": default["runtime_config_sha256"],
        "seeded_config_sha256": seeded["runtime_config_sha256"],
        "stage_basename": STAGE_PREFIX + authority["release_id"],
        "phase": "state-committed",
    })
    expected_current = current_document(journal)
    reconcile_pending_current(state, expected_current)
    observed_current = validate_current(
        read_json(state / PAIR_CURRENT, "runtime-pair current state")
    )
    if observed_current != expected_current:
        reject("installed runtime-pair current state is mismatched")
    transaction = state / PAIR_JOURNAL
    pending = state / PAIR_JOURNAL_NEXT
    if pending.exists() or pending.is_symlink():
        reconcile_pending_journal(state, journal)
    if transaction.exists() or transaction.is_symlink():
        observed_journal = validate_journal(
            read_json(transaction, "runtime-pair journal")
        )
        verify_release_journal(observed_journal, journal)
        if observed_journal["phase"] == "default-archive-activated":
            observed_journal = advance_journal(
                state, observed_journal, "state-committed"
            )
        if observed_journal["phase"] != "state-committed":
            reject("complete installed pair has a noncommitted journal")
        transaction.unlink()
        fsync_directory(state)
    return {
        "journal": journal,
        "authority": authority,
        "state": state,
        "root": game_root,
    }


def enforce_activation_capacity(
    game_root: Path,
    stage: Path,
    expected_authority_sha256: str,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    schema_path: Path,
    capacity_schema_path: Path,
) -> dict[str, Any]:
    """Bind the pair/cache model and enforce its activation byte/inode floor."""
    schema = load_schema(schema_path)
    relative = schema["authority_manifest_path"]
    staged_authority = stage / relative
    installed_authority = game_root / relative
    staged_exists = staged_authority.exists() or staged_authority.is_symlink()
    installed_exists = (
        installed_authority.exists() or installed_authority.is_symlink()
    )
    if staged_exists == installed_exists:
        reject(
            "capacity preflight requires exactly one staged or installed runtime authority"
        )
    authority_path = staged_authority if staged_exists else installed_authority
    stats = os.statvfs(game_root)
    model = capacity_model.calculate(
        authority_path,
        expected_authority_sha256,
        cache_contract_path,
        expected_cache_contract_sha256,
        authority_schema_path=schema_path,
        capacity_schema_path=capacity_schema_path,
        allocation_unit_bytes=stats.f_frsize,
    )
    floor = model["floors"]["activation_after_complete_stage"]
    available_bytes = stats.f_bavail * stats.f_frsize
    available_inodes = stats.f_favail
    required_bytes = floor["required_free_capacity_bytes"]
    required_inodes = floor["required_free_inodes"]
    capacity_model.enforce_filesystem_capacity(
        game_root, stats, required_bytes, required_inodes, "runtime-pair activation", reject,
    )
    return {
        "capacity_model_status": model["status"],
        "cache_contract_sha256": model["inputs"]["cache_contract_sha256"],
        "required_free_logical_bytes": floor["required_free_logical_bytes"],
        "required_free_capacity_bytes": required_bytes,
        "allocation_unit_bytes": stats.f_frsize,
        "required_free_inodes": required_inodes,
        "available_logical_bytes": available_bytes,
        "available_inodes": available_inodes,
        "logical_floor_only": model["claims"]["logical_byte_floor_only"],
        "regular_file_allocation_unit_ceiling_calculated": model["claims"][
            "regular_file_allocation_unit_ceiling_calculated"
        ],
    }


def cleanup_committed_stage(
    stage: Path,
    installed: dict[str, Any],
    schema_path: Path,
) -> None:
    """Remove only the two exact generator-mirror inputs after pair commit."""
    if not stage.exists() and not stage.is_symlink():
        return
    stage = exact_root(stage, "committed runtime-pair stage")
    authority = installed["authority"]
    if stage.parent != installed["state"] or stage.name != (
        STAGE_PREFIX + authority["release_id"]
    ):
        reject("committed runtime-pair stage is outside the fixed owned namespace")
    schema = load_schema(schema_path)
    official = schema["official_source"]["archive"]
    default = authority["runtimes"]["default"]
    allowed_files = {official["path"], default["runtime_config_path"]}
    stage_inventory(stage, allowed_files)
    for path, size, digest, label in (
        (
            stage / official["path"],
            official["size"],
            official["sha256"],
            "committed staged official mirror",
        ),
        (
            stage / default["runtime_config_path"],
            default["runtime_config_size"],
            default["runtime_config_sha256"],
            "committed staged default config mirror",
        ),
    ):
        if path.exists() or path.is_symlink():
            verify_file(path, size, digest, label)
            path.unlink()
            fsync_directory(path.parent)
    nested = stage / ".zeldadoi-speedhack"
    if nested.exists() or nested.is_symlink():
        if nested.is_symlink() or not nested.is_dir() or any(nested.iterdir()):
            reject("committed nested runtime-pair stage is not empty")
        nested.rmdir()
        fsync_directory(stage)
    if stage.is_symlink() or not stage.is_dir() or any(stage.iterdir()):
        reject("committed runtime-pair stage is not empty")
    stage.rmdir()
    fsync_directory(installed["state"])


def verify_release_journal(observed: dict[str, Any], expected: dict[str, Any]) -> None:
    for key in JOURNAL_KEYS - {"phase"}:
        if observed[key] != expected[key]:
            reject(f"runtime-pair journal release mismatch: {key}")


def ensure_location(
    context: dict[str, Any],
    staged_key: str,
    final_key: str,
    size: int,
    digest: str,
    label: str,
) -> str:
    staged = path_state(context["paths"][staged_key], size, digest, f"staged {label}")
    final = path_state(context["paths"][final_key], size, digest, f"installed {label}")
    if staged == final:
        reject(f"{label} must exist in exactly one staged or installed location")
    return final


def checkpoint(name: str, fail_after: str | None) -> None:
    if fail_after == name:
        raise RuntimeError(f"injected runtime-pair interruption after {name}")


def activate_pair(
    game_root: Path,
    stage: Path,
    expected_authority_sha256: str,
    *,
    cache_contract_path: Path,
    expected_cache_contract_sha256: str,
    schema_path: Path = DEFAULT_SCHEMA,
    capacity_schema_path: Path = capacity_model.DEFAULT_CAPACITY_SCHEMA,
    fail_after: str | None = None,
    lock_lease: RuntimeLockLease | None = None,
) -> dict[str, Any]:
    if fail_after is not None and fail_after not in PHASES:
        reject("unknown runtime-pair interruption checkpoint")
    game_root = exact_root(game_root, "game root")
    state = game_root / ".zeldadoi-speedhack"
    require_state_owner(state)
    with runtime_lock(state, lock_lease):
        for name in (
            "runtime-pair-restore.json",
            "runtime-pair-restore.next",
            "runtime-pair-preserve.json",
            "runtime-pair-preserve.next",
        ):
            path = state / name
            if path.exists() or path.is_symlink():
                reject(f"runtime-pair activation overlaps another transaction: {name}")
        capacity = enforce_activation_capacity(
            game_root,
            stage,
            expected_authority_sha256,
            cache_contract_path,
            expected_cache_contract_sha256,
            schema_path,
            capacity_schema_path,
        )
        current_path = state / PAIR_CURRENT
        current_pending = state / PAIR_CURRENT_NEXT
        if (
            current_path.exists()
            or current_path.is_symlink()
            or current_pending.exists()
            or current_pending.is_symlink()
        ):
            installed = installed_pair_context(
                game_root, expected_authority_sha256, schema_path
            )
            cleanup_committed_stage(stage, installed, schema_path)
            committed = installed["journal"]
            return {
                "schema_version": 1,
                "status": "runtime_pair_already_current",
                "release_id": committed["release_id"],
                "authority_sha256": committed["authority_sha256"],
                "default_archive_sha256": committed["default_archive_sha256"],
                "seeded_archive_sha256": committed["seeded_archive_sha256"],
                "activation_capacity": capacity,
                "activation_capacity_enforced": True,
                "crash_recovery_supported": True,
                "physical_target_executed": False,
                "production_approved": False,
            }
        if not stage.exists() and not stage.is_symlink():
            reject("runtime-pair stage is missing before pair commitment")
        context = build_context(
            game_root, stage, expected_authority_sha256, schema_path
        )
        paths = context["paths"]
        expected = context["journal"]
        transaction_path = state / PAIR_JOURNAL
        pending_path = state / PAIR_JOURNAL_NEXT
        if pending_path.exists() or pending_path.is_symlink():
            reconcile_pending_journal(state, expected)
        if transaction_path.exists() or transaction_path.is_symlink():
            observed = validate_journal(read_json(transaction_path, "runtime-pair journal"))
            verify_release_journal(observed, expected)
            journal = observed
        else:
            active_state = classify_file(
                paths["active_default"],
                ((
                    "official",
                    context["official"]["size"],
                    context["official"]["sha256"],
                ),),
                "active archive",
            )
            if active_state != "official":
                reject("new runtime-pair activation requires the exact official active archive")
            for path in (paths["seeded_archive"], paths["seeded_config"], paths["authority"]):
                if path.exists() or path.is_symlink():
                    reject("new runtime-pair activation collides with an installed path")
            journal = expected
            write_journal(state, journal)
            checkpoint("validated", fail_after)

        phase_index = PHASES.index(journal["phase"])

        steps = (
            (
                "seeded-archive-activated",
                "staged_seeded",
                "seeded_archive",
                context["seeded"]["archive_size"],
                context["seeded"]["archive_sha256"],
                "seeded runtime archive",
                context["root"],
            ),
            (
                "seeded-config-activated",
                "staged_seeded_config",
                "seeded_config",
                context["seeded"]["runtime_config_size"],
                context["seeded"]["runtime_config_sha256"],
                "seeded runtime config",
                state,
            ),
            (
                "authority-activated",
                "staged_authority",
                "authority",
                context["authority_size"],
                expected_authority_sha256,
                "runtime authority",
                state,
            ),
        )
        for phase, staged_key, final_key, size, digest, label, parent in steps:
            final_state = ensure_location(
                context, staged_key, final_key, size, digest, label
            )
            step_index = PHASES.index(phase)
            if step_index <= phase_index and final_state != "exact":
                reject(f"runtime-pair journal is ahead of {label}")
            if final_state == "absent":
                atomic_activate_no_replace(paths[staged_key], paths[final_key])
                fsync_directory(parent)
            if step_index > phase_index:
                journal = advance_journal(state, journal, phase)
                phase_index = step_index
            checkpoint(phase, fail_after)

        active = paths["active_default"]
        staged_default = paths["staged_default"]
        active_identity = classify_file(
            active,
            (
                (
                    "official",
                    context["official"]["size"],
                    context["official"]["sha256"],
                ),
                (
                    "default",
                    context["default"]["archive_size"],
                    context["default"]["archive_sha256"],
                ),
            ),
            "active archive",
        )
        staged_default_state = (
            path_state(
                staged_default,
                context["default"]["archive_size"],
                context["default"]["archive_sha256"],
                "staged default runtime archive",
            )
            if staged_default.exists() or staged_default.is_symlink()
            else "absent"
        )
        default_phase = PHASES.index("default-archive-activated")
        if phase_index >= default_phase:
            if staged_default_state != "absent":
                reject("runtime-pair journal is ahead of default archive activation")
            if active_identity != "default":
                reject("runtime-pair journal is ahead of installed default archive")
        else:
            if active_identity == "official" and staged_default_state == "exact":
                os.replace(staged_default, active)
                fsync_directory(context["root"])
            elif active_identity != "default" or staged_default_state != "absent":
                reject("default runtime activation boundary is inconsistent")
            journal = advance_journal(
                state, journal, "default-archive-activated"
            )
            phase_index = default_phase
        checkpoint("default-archive-activated", fail_after)

        current = current_document(journal)
        current_path = state / PAIR_CURRENT
        reconcile_pending_current(state, current)
        if current_path.exists() or current_path.is_symlink():
            observed_current = validate_current(
                read_json(current_path, "runtime-pair current state")
            )
            if observed_current != current:
                reject("runtime-pair current state is foreign or mismatched")
        else:
            write_atomic(
                state,
                PAIR_CURRENT,
                PAIR_CURRENT_NEXT,
                canonical_bytes(current),
            )
        if phase_index < PHASES.index("state-committed"):
            journal = advance_journal(state, journal, "state-committed")
        checkpoint("state-committed", fail_after)

        installed = {
            "authority": context["authority"],
            "state": state,
            "root": context["root"],
        }
        transaction_path.unlink()
        fsync_directory(state)
        cleanup_committed_stage(stage, installed, schema_path)

    return {
        "schema_version": 1,
        "status": "runtime_pair_activated_host_contract",
        "release_id": journal["release_id"],
        "authority_sha256": journal["authority_sha256"],
        "default_archive_sha256": journal["default_archive_sha256"],
        "seeded_archive_sha256": journal["seeded_archive_sha256"],
        "activation_capacity": capacity,
        "activation_capacity_enforced": True,
        "crash_recovery_supported": True,
        "physical_target_executed": False,
        "production_approved": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game-root", type=Path, required=True)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--authority-sha256", required=True)
    parser.add_argument("--cache-contract", type=Path, required=True)
    parser.add_argument("--cache-contract-sha256", required=True)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument(
        "--capacity-schema",
        type=Path,
        default=capacity_model.DEFAULT_CAPACITY_SCHEMA,
    )
    args = parser.parse_args()
    try:
        result = activate_pair(
            args.game_root,
            args.stage,
            args.authority_sha256,
            cache_contract_path=args.cache_contract,
            expected_cache_contract_sha256=args.cache_contract_sha256,
            schema_path=args.schema,
            capacity_schema_path=args.capacity_schema,
        )
    except (OSError, RuntimeError, PairActivationError, ValueError) as exc:
        print(json.dumps({"status": "invalid", "error": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
