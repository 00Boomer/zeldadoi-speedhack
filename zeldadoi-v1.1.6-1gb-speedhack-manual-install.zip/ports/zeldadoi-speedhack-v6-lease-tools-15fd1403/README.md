# ZeldaDOI Speedhack Edition

This patch requires a separately installed, supported Zelda: Dungeons of
Infinity v1.1.6 PortMaster game. Setup creates a separate installation for
the patch without copying existing player saves. Run opens that installation.
Restore rolls back the patch in that installation and preserves its saves.

Run ZeldaDOI Speedhack Installer, then ZeldaDOI Speedhack Launcher.
ZeldaDOI Speedhack Remover rolls back the patch and keeps its saves. The
GMLoader-Next license and corresponding source archives are included.
