"""Inactive bounded head/tail drain for a future private beta transport.

Keep complete short streams byte-for-byte. An overflowing stream retains its
first half and its latest tail, with an explicit gap marker inside the same
file-size cap. The caller's truncation and error flags remain authoritative.
This helper does not launch processes, change status codes, or touch saves.
"""
GAP = b'\n[ZDLF_BOUNDED_LOG_GAP_V1] middle bytes omitted; log is incomplete\n'
BLOCK_BYTES = 65536
MAX_LOG_BYTES = 8 * 1024**2


def drain_head_tail(stream, output, limit, truncated, errors):
    """Drain one binary pipe; caller owns output and handles errors after join.

    Tail retention uses at most half the cap plus one input block and small
    fixed allocation overhead. EOF after a game-child crash publishes the tail.
    Abrupt termination of this collecting process or the device is not covered.
    """
    tail = None
    tail_position = 0
    kept = 0
    overflow = False
    head_limit = 0

    def write(data):
        if output.write(data) != len(data):
            raise OSError('short bounded log write')

    try:
        if type(limit) is not int or not 2 * len(GAP) + 2 <= limit <= MAX_LOG_BYTES:
            raise ValueError('bounded head/tail log limit refused')
        head_limit = limit // 2
        tail_limit = limit - head_limit - len(GAP)
        tail = bytearray(tail_limit)
        while True:
            block = stream.read(BLOCK_BYTES)
            if not isinstance(block, bytes) or len(block) > BLOCK_BYTES:
                raise ValueError('bounded binary log block refused')
            if not block:
                break
            if len(block) >= tail_limit:
                tail[:] = block[-tail_limit:]
                tail_position = 0
            else:
                first = min(len(block), tail_limit - tail_position)
                tail[tail_position:tail_position + first] = block[:first]
                if first < len(block):
                    tail[:len(block) - first] = block[first:]
                tail_position = (tail_position + len(block)) % tail_limit
            keep = min(len(block), max(0, limit - kept))
            if keep:
                write(block[:keep])
                kept += keep
            if keep < len(block):
                overflow = True
                truncated[0] = True
    except (OSError, ValueError, TypeError) as error:
        errors.append(str(error))
    finally:
        try:
            if overflow:
                output.seek(head_limit)
                write(GAP)
                # Overflow means the fixed ring is full. Memoryviews avoid a
                # second tail-sized allocation while publishing its two parts.
                view = memoryview(tail)
                write(view[tail_position:])
                if tail_position:
                    write(view[:tail_position])
                output.truncate()
            output.flush()
        except (OSError, ValueError, TypeError) as error:
            errors.append(str(error))
        finally:
            try:
                stream.close()
            except (OSError, ValueError, TypeError) as error:
                errors.append(str(error))
