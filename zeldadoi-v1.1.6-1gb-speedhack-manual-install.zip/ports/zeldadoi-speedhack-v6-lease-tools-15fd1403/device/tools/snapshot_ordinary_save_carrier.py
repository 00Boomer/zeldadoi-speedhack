#!/usr/bin/env python3
"""Create a payload-free snapshot of one disposable ordinary save carrier.

The tool is intentionally read-only with respect to the save sandbox.  It
records hashes and structural facts only; it never copies ``Users`` or the
``UserData`` member into telemetry.  A project-owned sandbox marker is required
so an operator cannot accidentally point evidence collection at normal saves.
"""

from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import json
import os
import re
import stat
import sys
import zlib
from pathlib import Path
from typing import Any, BinaryIO


SCHEMA = "zeldadoi-ordinary-save-carrier-snapshot-v1"
MARKER = ".zeldadoi-disposable-save.json"
SENTINEL = ".zeldadoi-foreign-sentinel"
ACTIVE = "Users"
TEMPORARY = "Users_Temp"
MEMBER = "UserData"
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_MEMBER_BYTES = 32 * 1024 * 1024
SAFE_TOKEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
POST_CHILD_PHASES = frozenset({"post-save", "continue-prelaunch", "post-continue"})
PHASES = frozenset({"initial-prelaunch", *POST_CHILD_PHASES})
PARENT_PHASE = {
    "initial-prelaunch": None,
    "post-save": "initial-prelaunch",
    "continue-prelaunch": "post-save",
    "post-continue": "continue-prelaunch",
}


class SnapshotError(RuntimeError):
    pass


def _sha256_file(handle: BinaryIO, *, maximum: int) -> tuple[str, int]:
    digest = hashlib.sha256()
    total = 0
    while True:
        chunk = handle.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > maximum:
            raise SnapshotError(f"input exceeds {maximum} bytes")
        digest.update(chunk)
    return digest.hexdigest(), total


def _safe_token(label: str, value: str) -> str:
    if not SAFE_TOKEN.fullmatch(value):
        raise SnapshotError(f"unsafe {label}: {value!r}")
    return value


def _open_regular_single_link(path: Path, *, maximum: int) -> tuple[int, os.stat_result]:
    flags = os.O_RDONLY
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise SnapshotError(f"cannot safely open {path.name}: {exc}") from exc
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise SnapshotError(f"{path.name} is not a regular file")
        if before.st_nlink != 1:
            raise SnapshotError(f"{path.name} must have exactly one hard link")
        if before.st_size < 1 or before.st_size > maximum:
            raise SnapshotError(f"{path.name} size is outside 1..{maximum}")
        return descriptor, before
    except Exception:
        os.close(descriptor)
        raise


def _verify_unchanged(descriptor: int, before: os.stat_result, label: str) -> None:
    after = os.fstat(descriptor)
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns", "st_nlink")
    if any(getattr(before, field) != getattr(after, field) for field in fields):
        raise SnapshotError(f"{label} changed while being read")


def _read_small_json(path: Path, *, maximum: int = 16 * 1024) -> tuple[dict[str, Any], str]:
    descriptor, before = _open_regular_single_link(path, maximum=maximum)
    try:
        with os.fdopen(os.dup(descriptor), "rb") as handle:
            digest, size = _sha256_file(handle, maximum=maximum)
            handle.seek(0)
            raw = handle.read()
        _verify_unchanged(descriptor, before, path.name)
    finally:
        os.close(descriptor)
    if size != len(raw):
        raise SnapshotError(f"short read from {path.name}")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SnapshotError(f"invalid JSON in {path.name}: {exc}") from exc
    if not isinstance(value, dict):
        raise SnapshotError(f"{path.name} must contain one JSON object")
    return value, digest


def _require_safe_directory(path: Path) -> Path:
    absolute = path.absolute()
    try:
        info = os.lstat(absolute)
    except OSError as exc:
        raise SnapshotError(f"save directory is unavailable: {exc}") from exc
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
        raise SnapshotError("save directory must be a real directory")
    try:
        if absolute.resolve(strict=True) != absolute:
            raise SnapshotError("save directory must not traverse a symlink")
    except OSError as exc:
        raise SnapshotError(f"save directory cannot be resolved safely: {exc}") from exc
    return absolute


def _read_status(path: Path) -> tuple[int, str]:
    descriptor, before = _open_regular_single_link(path, maximum=128)
    try:
        with os.fdopen(os.dup(descriptor), "rb") as handle:
            raw = handle.read(129)
        _verify_unchanged(descriptor, before, path.name)
    finally:
        os.close(descriptor)
    if len(raw) > 128:
        raise SnapshotError("child status file is too large")
    try:
        text = raw.decode("ascii").strip()
    except UnicodeDecodeError as exc:
        raise SnapshotError("child status must be ASCII") from exc
    if not re.fullmatch(r"-?[0-9]+", text):
        raise SnapshotError("child status must contain exactly one decimal integer")
    return int(text), hashlib.sha256(raw).hexdigest()


def _read_parent(path: Path, run_id: str, role: str) -> tuple[dict[str, Any], str]:
    value, digest = _read_small_json(path, maximum=256 * 1024)
    if value.get("schema") != SCHEMA or value.get("run_id") != run_id or value.get("role") != role:
        raise SnapshotError("parent snapshot does not belong to this run and role")
    if value.get("capture_complete") is not True:
        raise SnapshotError("parent snapshot is incomplete")
    active = value.get("active_archive")
    member = value.get("user_data_member")
    if value.get("phase") == "initial-prelaunch" and active is None and member is None:
        return value, digest
    if not isinstance(active, dict) or not re.fullmatch(r"[0-9a-f]{64}", str(active.get("sha256", ""))):
        raise SnapshotError("parent snapshot has no valid active archive digest")
    if not isinstance(member, dict) or not re.fullmatch(r"[0-9a-f]{64}", str(member.get("sha256", ""))):
        raise SnapshotError("parent snapshot has no valid UserData digest")
    return value, digest


def _quoted_value(raw: str, *, label: str) -> str:
    value = raw.strip()
    if len(value) < 2 or value[0] != '"' or value[-1] != '"':
        raise SnapshotError(f"Xzip {label} must be one quoted value")
    value = value[1:-1]
    if '"' in value or "\r" in value or "\n" in value:
        raise SnapshotError(f"Xzip {label} contains unsupported quoting")
    return value


def _parse_xzip(raw: bytes) -> tuple[int, bytes, int]:
    """Return member count, decompressed UserData, and compressed byte count.

    ZeldaDOI's source-owned ``xzip_*`` helpers use GameMaker INI sections, not
    the PKZIP format.  The ``[?]`` section maps consecutive decimal indexes to
    member section names; each member stores a base64-encoded zlib stream in
    its ``data`` key.  This parser intentionally accepts only that bounded
    source-derived shape and never materializes the payload outside memory.
    """
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise SnapshotError(f"active save carrier is not UTF-8 Xzip: {exc}") from exc
    sections: dict[str, dict[str, str]] = {}
    current: dict[str, str] | None = None
    for line_number, source_line in enumerate(text.splitlines(), 1):
        line = source_line.strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            name = line[1:-1]
            if not name or name in sections:
                raise SnapshotError(f"duplicate or empty Xzip section at line {line_number}")
            current = sections[name] = {}
            continue
        if current is None or "=" not in line:
            raise SnapshotError(f"malformed Xzip entry at line {line_number}")
        key, value = line.split("=", 1)
        key = key.strip()
        if not key or key in current:
            raise SnapshotError(f"duplicate or empty Xzip key at line {line_number}")
        current[key] = _quoted_value(value, label=f"value at line {line_number}")

    index = sections.get("?")
    if index is None or index.get("?") != "Xzip by XGASOFT":
        raise SnapshotError("active save carrier has no authoritative Xzip header")
    numbered: dict[int, str] = {}
    for key, name in index.items():
        if key == "?":
            continue
        if re.fullmatch(r"0|[1-9][0-9]*", key) is None:
            raise SnapshotError("Xzip index contains a non-decimal member key")
        ordinal = int(key)
        if ordinal >= 4096:
            raise SnapshotError("Xzip member index exceeds the 4096-member bound")
        numbered[ordinal] = name
    if not numbered or set(numbered) != set(range(len(numbered))):
        raise SnapshotError("Xzip member indexes must be consecutive from zero")
    names = [numbered[index] for index in range(len(numbered))]
    if len(set(names)) != len(names):
        raise SnapshotError("Xzip index contains a duplicate member name")
    if names.count(MEMBER) != 1:
        raise SnapshotError(f"expected exactly one {MEMBER} member, found {names.count(MEMBER)}")
    if set(sections) != {"?", *names}:
        raise SnapshotError("Xzip member index and sections do not match exactly")

    member = sections[MEMBER]
    if set(member) != {"index", "data", "path", "readonly"}:
        raise SnapshotError(f"{MEMBER} Xzip section has unexpected keys")
    expected_index = str(names.index(MEMBER))
    if member["index"] != expected_index or member["path"] != "" or member["readonly"] not in {"true", "false"}:
        raise SnapshotError(f"{MEMBER} Xzip metadata is inconsistent")
    try:
        compressed = base64.b64decode(member["data"], validate=True)
    except (binascii.Error, ValueError) as exc:
        raise SnapshotError(f"cannot decode {MEMBER} Xzip data: {exc}") from exc
    if not compressed or len(compressed) > MAX_ARCHIVE_BYTES:
        raise SnapshotError(f"compressed {MEMBER} size is outside 1..{MAX_ARCHIVE_BYTES}")
    try:
        inflater = zlib.decompressobj()
        payload = inflater.decompress(compressed, MAX_MEMBER_BYTES + 1)
        if len(payload) > MAX_MEMBER_BYTES or inflater.unconsumed_tail:
            raise SnapshotError(f"{MEMBER} exceeds {MAX_MEMBER_BYTES} bytes")
        payload += inflater.flush(MAX_MEMBER_BYTES + 1 - len(payload))
    except zlib.error as exc:
        raise SnapshotError(f"cannot decompress {MEMBER} Xzip data: {exc}") from exc
    if not inflater.eof or inflater.unused_data or not payload:
        raise SnapshotError(f"{MEMBER} Xzip stream is truncated, concatenated, or empty")
    return len(names), payload, len(compressed)


def build_snapshot(
    *,
    save_dir: Path,
    run_id: str,
    role: str,
    phase: str,
    sentinel_sha256: str,
    child_status_file: Path | None = None,
    parent_snapshot: Path | None = None,
) -> dict[str, Any]:
    run_id = _safe_token("run ID", run_id)
    role = _safe_token("role", role)
    if phase not in PHASES:
        raise SnapshotError(f"unsupported phase: {phase}")
    if not re.fullmatch(r"[0-9a-f]{64}", sentinel_sha256):
        raise SnapshotError("sentinel SHA-256 must be 64 lowercase hexadecimal characters")

    save_dir = _require_safe_directory(save_dir)
    marker, marker_sha256 = _read_small_json(save_dir / MARKER)
    if set(marker) != {"schema", "run_id", "role"}:
        raise SnapshotError("disposable-save marker has unexpected keys")
    if marker != {"schema": "zeldadoi-disposable-save-v1", "run_id": run_id, "role": role}:
        raise SnapshotError("disposable-save marker does not match this run and role")

    temporary = save_dir / TEMPORARY
    if os.path.lexists(temporary):
        raise SnapshotError(f"temporary save carrier remains present: {TEMPORARY}")

    sentinel_fd, sentinel_before = _open_regular_single_link(save_dir / SENTINEL, maximum=4096)
    try:
        with os.fdopen(os.dup(sentinel_fd), "rb") as handle:
            actual_sentinel_sha256, sentinel_bytes = _sha256_file(handle, maximum=4096)
        _verify_unchanged(sentinel_fd, sentinel_before, SENTINEL)
    finally:
        os.close(sentinel_fd)
    if actual_sentinel_sha256 != sentinel_sha256:
        raise SnapshotError("foreign sentinel digest mismatch")

    active_path = save_dir / ACTIVE
    active_record: dict[str, Any] | None = None
    member_record: dict[str, Any] | None = None
    archive_sha256: str | None = None
    member_sha256: str | None = None
    if not os.path.lexists(active_path):
        if phase != "initial-prelaunch":
            raise SnapshotError(f"active save carrier is absent after child execution: {ACTIVE}")
    else:
        active_fd, active_before = _open_regular_single_link(active_path, maximum=MAX_ARCHIVE_BYTES)
        try:
            with os.fdopen(os.dup(active_fd), "rb") as handle:
                archive_sha256, archive_bytes = _sha256_file(handle, maximum=MAX_ARCHIVE_BYTES)
            os.lseek(active_fd, 0, os.SEEK_SET)
            with os.fdopen(os.dup(active_fd), "rb") as handle:
                raw_archive = handle.read(MAX_ARCHIVE_BYTES + 1)
            if len(raw_archive) != archive_bytes:
                raise SnapshotError("short read from active Xzip save carrier")
            archive_member_count, member_payload, compressed_bytes = _parse_xzip(raw_archive)
            member_sha256 = hashlib.sha256(member_payload).hexdigest()
            member_record = {
                "name": MEMBER,
                "bytes": len(member_payload),
                "compressed_bytes": compressed_bytes,
                "crc32": f"{zlib.crc32(member_payload) & 0xffffffff:08x}",
                "sha256": member_sha256,
            }
            _verify_unchanged(active_fd, active_before, ACTIVE)
        finally:
            os.close(active_fd)
        active_record = {
            "name": ACTIVE,
            "bytes": archive_bytes,
            "sha256": archive_sha256,
            "member_count": archive_member_count,
            "regular_file": True,
            "hard_link_count": 1,
        }

    child: dict[str, Any] | None = None
    if phase in POST_CHILD_PHASES:
        if child_status_file is None:
            raise SnapshotError(f"{phase} requires a reaped child status file")
        child_status, child_status_sha256 = _read_status(child_status_file)
        child = {
            "reaped": True,
            "raw_status": child_status,
            "clean_exit": child_status == 0,
            "status_file_sha256": child_status_sha256,
        }
    elif child_status_file is not None:
        raise SnapshotError("initial-prelaunch must not claim a child status")

    expected_parent_phase = PARENT_PHASE[phase]
    parent: dict[str, Any] | None = None
    if parent_snapshot is not None:
        parent_value, parent_sha256 = _read_parent(parent_snapshot, run_id, role)
        if parent_value.get("phase") != expected_parent_phase:
            raise SnapshotError(
                f"{phase} requires a {expected_parent_phase} parent, got {parent_value.get('phase')!r}"
            )
        parent = {
            "snapshot_sha256": parent_sha256,
            "phase": parent_value["phase"],
            "archive_sha256": None if parent_value["active_archive"] is None else parent_value["active_archive"]["sha256"],
            "member_sha256": None if parent_value["user_data_member"] is None else parent_value["user_data_member"]["sha256"],
        }
    if expected_parent_phase is not None and parent is None:
        raise SnapshotError(f"{phase} requires its own-run {expected_parent_phase} parent snapshot")
    if expected_parent_phase is None and parent is not None:
        raise SnapshotError("initial-prelaunch must not have a parent snapshot")
    if phase == "continue-prelaunch" and (
        parent["archive_sha256"] != archive_sha256 or parent["member_sha256"] != member_sha256
    ):
        raise SnapshotError("Continue launch carrier differs from the persisted post-save carrier")

    return {
        "schema": SCHEMA,
        "capture_complete": True,
        "run_id": run_id,
        "role": role,
        "phase": phase,
        "save_sandbox_marker_sha256": marker_sha256,
        "active_archive": active_record,
        "user_data_member": member_record,
        "temporary_archive_absent": True,
        "foreign_sentinel": {
            "name": SENTINEL,
            "bytes": sentinel_bytes,
            "sha256": actual_sentinel_sha256,
            "unchanged": True,
        },
        "child_process": child,
        "parent_snapshot": parent,
        "payload_bytes_collected": 0,
        "claims": {
            "ordinary_save_semantics_verified": False,
            "continue_semantics_verified": False,
            "clean_loaded_runner_exit_verified": False,
            "physical_target_executed": False,
        },
    }


def write_exclusive(path: Path, record: dict[str, Any]) -> None:
    parent = _require_safe_directory(path.parent)
    target = parent / path.name
    if target.name in {"", ".", ".."}:
        raise SnapshotError("unsafe output name")
    data = (json.dumps(record, indent=2, sort_keys=True) + "\n").encode("utf-8")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(target, flags, 0o600)
    except OSError as exc:
        raise SnapshotError(f"refusing to overwrite output: {exc}") from exc
    try:
        with os.fdopen(descriptor, "wb", closefd=False) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        try:
            os.unlink(target)
        except OSError:
            pass
        raise
    finally:
        os.close(descriptor)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--save-dir", required=True, type=Path)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--role", required=True)
    parser.add_argument("--phase", required=True, choices=sorted(PHASES))
    parser.add_argument("--sentinel-sha256", required=True)
    parser.add_argument("--child-status-file", type=Path)
    parser.add_argument("--parent-snapshot", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        record = build_snapshot(
            save_dir=args.save_dir,
            run_id=args.run_id,
            role=args.role,
            phase=args.phase,
            sentinel_sha256=args.sentinel_sha256,
            child_status_file=args.child_status_file,
            parent_snapshot=args.parent_snapshot,
        )
        write_exclusive(args.output, record)
    except SnapshotError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(f"ordinary save carrier snapshot: PASS ({args.phase})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
