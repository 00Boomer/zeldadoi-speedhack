#!/usr/bin/env python3
"""Verify and materialize one private diagnostic payload, never an installation.

The official archive is read-only. Publication is destination-local, atomic and
no-clobber; a changed existing payload is an error, not something to replace.
No game execution, downloads, save access or cleanup of historical stages.
"""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import resource
import stat
import subprocess
import tempfile

MANIFEST = 'current371_private_device_kit_v1.json'
OFFICIAL_SHA = 'df37214a5b1dd7e91050a4df686103ade56b53c935792ada0f96766c4413cade'
OFFICIAL_BYTES = 104829399
ARCHIVE_SHA = '921afe0fc4b6575f5fbdf0836bbaccdbfae06a77f703753aec50f36e97ffabaf'
ARCHIVE_BYTES = 177456638
DELTA_SHA = '11007ffd237250d0b7f9e335484ad42fe5bceb888d404b4dac56ef229cdc88de'
DELTA_BYTES = 2566022
HOST_XDELTA_SHA='dc6bdc6ee86b2b3e389c937610c0b2508e31ca53c197de6f9c176909c546a846'


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''): value.update(block)
    return value.hexdigest()


def safe(path, *, directory=False):
    path = Path(path).absolute()
    if path.resolve(strict=True) != path: raise ValueError('symlink/path alias refused')
    info = path.lstat()
    if directory:
        if not stat.S_ISDIR(info.st_mode): raise ValueError('real directory required')
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('single-link regular file required')
    return path


def checked(path, size, sha):
    path = safe(path)
    before = path.stat()
    if before.st_size != size or digest(path) != sha: raise ValueError('content identity mismatch: '+str(path))
    after = path.stat()
    if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns) != (
            after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
        raise ValueError('input changed while verified')
    return path


def pairs(rows):
    result={}
    for key,value in rows:
        if key in result: raise ValueError('duplicate JSON key')
        result[key]=value
    return result


def load_contract(kit):
    kit=safe(kit,directory=True)
    path=safe(kit/MANIFEST)
    if path.stat().st_size>1024**2: raise ValueError('oversize kit contract')
    note=json.loads(path.read_bytes(),object_pairs_hook=pairs)
    if (note.get('schema')!='current371_private_device_kit_v1' or
        note.get('archive')!={'relative_path':'stage/game.apk','sha256':ARCHIVE_SHA,'bytes':ARCHIVE_BYTES} or
        note.get('official')!={'sha256':OFFICIAL_SHA,'bytes':OFFICIAL_BYTES} or
        note.get('delta')!={'relative_path':'patches/current371.xdelta','sha256':DELTA_SHA,'bytes':DELTA_BYTES}):
        raise ValueError('exact current371 diagnostic authority required')
    files=note.get('files')
    if not isinstance(files,dict) or not files: raise ValueError('kit file authority missing')
    for name,sha in files.items():
        relative=PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or str(relative)!=name:
            raise ValueError('unsafe kit member')
        target=safe(kit/name)
        if digest(target)!=sha: raise ValueError('kit member identity mismatch: '+name)
    return note


def publish_new(source,destination):
    # Same no-replace primitive as scripts/runseed_exact_runner_v1.py. Linux
    # support is mandatory: no overwrite-prone rename fallback or new hard link.
    libc=ctypes.CDLL(None,use_errno=True)
    rename=libc.renameat2
    rename.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint]
    rename.restype=ctypes.c_int
    if rename(-100,os.fsencode(source),-100,os.fsencode(destination),1):
        error=ctypes.get_errno();raise OSError(error,os.strerror(error),str(destination))


@contextmanager
def decoder(path):
    """Snapshot a trusted local decoder into a sealed, executable descriptor.

    Host identity is pinned. Device policy accepts ONLY a root-owned, non-group/
    world-writable xdelta3 in the existing system/PortMaster locations. Unknown
    user/card binaries require separate identity qualification, not a fallback.
    """
    path=safe(path)
    parents=('/usr/bin','/opt/system/Tools/PortMaster','/opt/tools/PortMaster')
    if str(path.parent) not in parents or path.name!='xdelta3':
        raise ValueError('unqualified decoder location')
    fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    sealed=None
    try:
        before=os.fstat(fd)
        if before.st_uid!=0 or before.st_mode&0o022 or not os.access(path,os.X_OK):
            raise ValueError('untrusted decoder owner/mode')
        if before.st_size<1 or before.st_size>16*1024**2:raise ValueError('decoder size bound')
        raw=b''
        while len(raw)<before.st_size:
            block=os.read(fd,before.st_size-len(raw))
            if not block:raise ValueError('short decoder read')
            raw+=block
        after=os.fstat(fd)
        fields=('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')
        if any(getattr(before,k)!=getattr(after,k) for k in fields):raise ValueError('decoder source drift')
        sha=hashlib.sha256(raw).hexdigest()
        if str(path)=='/usr/bin/xdelta3' and sha!=HOST_XDELTA_SHA:
            raise ValueError('unqualified host decoder identity')
        sealed=os.memfd_create('current371-xdelta3',os.MFD_ALLOW_SEALING)
        with os.fdopen(os.dup(sealed),'wb') as stream:stream.write(raw);stream.flush()
        os.fchmod(sealed,0o500)
        fcntl.fcntl(sealed,fcntl.F_ADD_SEALS,
            fcntl.F_SEAL_SEAL|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_GROW|fcntl.F_SEAL_WRITE)
        yield sealed,dict(path=str(path),sha256=sha,bytes=len(raw),
            policy='pinned-host-or-root-owned-system-PortMaster',sealed_snapshot=True)
    finally:
        os.close(fd)
        if sealed is not None:os.close(sealed)


def materialize(kit,official,xdelta):
    kit=safe(kit,directory=True)
    note=load_contract(kit)
    official=checked(official,OFFICIAL_BYTES,OFFICIAL_SHA)
    delta=checked(kit/note['delta']['relative_path'],DELTA_BYTES,DELTA_SHA)
    xdelta=safe(xdelta)
    if not os.access(xdelta,os.X_OK): raise ValueError('xdelta executable unavailable')
    # The declared tool boundary applies to reuse too; missing/unknown tools
    # must not become acceptable just because a payload already happens to fit.
    with decoder(xdelta) as (_,decoder_authority):pass
    stage=kit/'stage'
    if not stage.exists(): stage.mkdir(mode=0o700)
    safe(stage,directory=True)
    lock=stage/'.materialization.lock'
    descriptor=os.open(lock,os.O_CREAT|os.O_RDWR|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        info=os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_uid!=os.getuid():
            raise ValueError('unsafe materialization lock')
        fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
        destination=stage/'game.apk'
        if os.path.lexists(destination):
            checked(destination,ARCHIVE_BYTES,ARCHIVE_SHA)
            return dict(reused=True,archive_sha256=ARCHIVE_SHA,decoder=decoder_authority,game_executed=False)
        capacity=os.statvfs(stage)
        if capacity.f_bavail*capacity.f_frsize < ARCHIVE_BYTES+1024**3:
            raise ValueError('insufficient destination capacity including 1GiB reserve')
        fd,raw=tempfile.mkstemp(prefix='.current371-',suffix='.partial',dir=stage)
        temporary=Path(raw)
        try:
            def limits():
                resource.setrlimit(resource.RLIMIT_FSIZE,(ARCHIVE_BYTES,ARCHIVE_BYTES))
                resource.setrlimit(resource.RLIMIT_CORE,(0,0))
            with os.fdopen(fd,'wb') as output,decoder(xdelta) as (executable,tool):
                command=['/proc/self/fd/'+str(executable),'-d','-c','-D','-R','-s',str(official),str(delta)]
                # Execute the sealed, verified bytes, never the mutable pathname.
                completed=subprocess.run(command,stdout=output,stderr=subprocess.PIPE,
                    timeout=300,check=False,preexec_fn=limits,pass_fds=(executable,),
                    env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TMPDIR':str(stage)})
                output.flush();os.fsync(output.fileno())
            if completed.returncode: raise ValueError('xdelta failed: '+str(completed.returncode))
            checked(temporary,ARCHIVE_BYTES,ARCHIVE_SHA)
            checked(official,OFFICIAL_BYTES,OFFICIAL_SHA)
            checked(delta,DELTA_BYTES,DELTA_SHA)
            load_contract(kit)
            publish_new(temporary,destination)
            parent=os.open(stage,os.O_RDONLY|os.O_DIRECTORY)
            try:os.fsync(parent)
            finally:os.close(parent)
            return dict(reused=False,archive_sha256=ARCHIVE_SHA,command=command,
                        decoder=tool,game_executed=False)
        finally:
            if temporary.exists(): temporary.unlink()
    finally:os.close(descriptor)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kit',required=True,type=Path)
    parser.add_argument('--official',required=True,type=Path)
    parser.add_argument('--xdelta',required=True,type=Path)
    args=parser.parse_args()
    try:result=materialize(args.kit,args.official,args.xdelta)
    except (OSError,ValueError,subprocess.SubprocessError) as error:
        print('REFUSED: '+str(error));return 2
    print(json.dumps(result,sort_keys=True));return 0


if __name__=='__main__':raise SystemExit(main())
