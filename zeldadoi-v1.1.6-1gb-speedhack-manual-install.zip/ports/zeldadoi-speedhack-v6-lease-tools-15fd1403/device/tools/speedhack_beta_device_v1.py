#!/usr/bin/env python3
"""Fail-closed, side-by-side beta materialization; never writes original files."""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import resource
import selectors
import shutil
import stat
import subprocess
import tarfile
import tempfile
import time
import zipfile

# This existing, pinned project tool is included beside this module in the kit.
from materialize_current371_private_payload_v1 import checked, pairs, publish_new, safe

SOURCE_SHA = 'df37214a5b1dd7e91050a4df686103ade56b53c935792ada0f96766c4413cade'
SOURCE_BYTES = 104829399
RESERVE = 1024**3
SHA = re.compile(r'^[0-9a-f]{64}$')
ID = re.compile(r'^[a-z0-9][a-z0-9-]{0,39}$')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def relative(value):
    require(isinstance(value, str) and value and '\\' not in value, 'invalid relative path')
    path = PurePosixPath(value)
    require(not path.is_absolute() and all(p not in ('', '.', '..') for p in path.parts)
            and str(path) == value, 'unsafe relative path')
    return value


def entry(row, field='path'):
    require(isinstance(row, dict), 'invalid file entry')
    relative(row[field])
    require(type(row.get('bytes')) is int and 0 < row['bytes'] <= 4 * 1024**3,
            'invalid file length')
    require(isinstance(row.get('sha256'), str) and SHA.fullmatch(row['sha256']),
            'invalid SHA-256')
    return row


def contract(root, manifest_sha):
    root = safe(root, directory=True)
    require(SHA.fullmatch(manifest_sha) is not None, 'invalid manifest identity')
    manifest = safe(root / 'beta-manifest.json')
    require(manifest.stat().st_size <= 1024**2, 'oversized manifest')
    raw = manifest.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == manifest_sha, 'manifest identity mismatch')
    data = json.loads(raw, object_pairs_hook=pairs)
    require(data.get('schema') == 'zeldadoi_speedhack_beta_v1' and
            data.get('experimental') is True and data.get('release_approved') is False,
            'unsupported beta contract')
    build = data.get('build_id')
    require(isinstance(build, str) and ID.fullmatch(build), 'invalid build id')
    require(root.name == 'zeldadoi-speedhack-beta-' + build and root.parent.name == 'ports',
            'beta root must have the declared name beneath ports')
    official = entry(data['official'], 'relative_path')
    require(official['sha256'] == SOURCE_SHA and official['bytes'] == SOURCE_BYTES,
            'unsupported original archive authority')
    require(official['relative_path'] == 'zeldadoi.port', 'unsupported original archive location')
    for key in ('patch', 'decoder'):
        entry(data[key])
    archive = entry(dict(data['archive'], path='game.apk'))
    require(type(archive.get('game_droid_bytes')) is int and archive['game_droid_bytes'] > 0 and
            SHA.fullmatch(archive.get('game_droid_sha256', '')), 'missing game.droid authority')
    bundle = data.get('bundle_files')
    require(isinstance(bundle, list) and bundle, 'bundle inventory missing')
    seen = set()
    for row in bundle:
        entry(row)
        require(row['path'] not in seen, 'duplicate bundle member')
        seen.add(row['path'])
        checked(root / row['path'], row['bytes'], row['sha256'])
    for key in ('patch', 'decoder'):
        require(any(row == data[key] for row in bundle), key + ' missing from inventory')
    donors = data.get('donor_files')
    require(isinstance(donors, list) and donors, 'missing runtime inventory')
    destinations = {'game.apk', 'install.json'}
    for row in donors:
        entry(row, 'source')
        target = relative(row['destination'])
        require(target.startswith(('runtime/', 'lib/arm64-v8a/')) and target not in destinations,
                'unsafe/duplicate runtime target')
        destinations.add(target)
    return data


def environment():
    require(platform.machine().lower() == 'aarch64', 'unsupported architecture; AArch64 required')
    require(Path('/mnt/mmc/MUOS/PortMaster').is_dir() or
            Path('/mnt/sdcard/MUOS/PortMaster').is_dir(), 'muOS PortMaster environment not found')
    require(os.path.exists('/usr/bin/python3'), '/usr/bin/python3 unavailable')
    require(tuple(__import__('sys').version_info[:2]) >= (3, 10), 'Python 3.10 or newer required')
    model = ''
    try:
        model = Path('/proc/device-tree/model').read_bytes()[:160].replace(b'\x00', b'').decode('ascii', 'replace')
    except OSError:
        pass
    return {'architecture': 'aarch64', 'platform': 'muOS', 'model': model}


def original(root, data):
    donor = safe(root.parent / 'zeldadoi', directory=True)
    official = data['official']
    checked(donor / official['relative_path'], official['bytes'], official['sha256'])
    for row in data['donor_files']:
        checked(donor / row['source'], row['bytes'], row['sha256'])
    return donor


def fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


@contextlib.contextmanager
def lock(root):
    path = root / '.beta.lock'
    fd = os.open(path, os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'unsafe lock')
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(fd)


def check_elf(path):
    with path.open('rb') as src:
        header = src.read(20)
    require(len(header) == 20 and header[:6] == b'\x7fELF\x02\x01' and
            int.from_bytes(header[18:20], 'little') == 183,
            'decoder is not a little-endian AArch64 ELF')
    require(os.access(path, os.X_OK), 'decoder not executable')


def probe_decoder(root, data):
    """Execute only the authenticated decoder snapshot, without touching files."""
    row = data['decoder']
    path = checked(root / row['path'], row['bytes'], row['sha256'])
    check_elf(path)
    raw = path.read_bytes()
    require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'],
            'decoder changed during snapshot')
    fd = os.memfd_create('beta-xdelta3-probe', os.MFD_ALLOW_SEALING)
    try:
        with os.fdopen(os.dup(fd), 'wb') as output:
            output.write(raw); output.flush()
        os.fchmod(fd, 0o500)
        fcntl.fcntl(fd, fcntl.F_ADD_SEALS, fcntl.F_SEAL_SEAL | fcntl.F_SEAL_SHRINK |
                    fcntl.F_SEAL_GROW | fcntl.F_SEAL_WRITE)
        result = subprocess.run(['/proc/self/fd/' + str(fd), '-V'],
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, timeout=10, pass_fds=(fd,),
                                env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'})
        require(result.returncode == 0, 'decoder execution or runtime dependencies unavailable')
    finally:
        os.close(fd)


def runtime_files(data):
    return [('game.apk', data['archive']['bytes'], data['archive']['sha256'])] + [
        (row['destination'], row['bytes'], row['sha256']) for row in data['donor_files']]


def verify_tree(installed, data, manifest_sha):
    installed = safe(installed, directory=True)
    marker = safe(installed / 'install.json')
    require(marker.stat().st_size <= 4096, 'invalid installation marker')
    require(json.loads(marker.read_text(), object_pairs_hook=pairs) ==
            {'build_id': data['build_id'], 'manifest_sha256': manifest_sha},
            'installation marker mismatch')
    expected = {'install.json'}
    for name, size, sha in runtime_files(data):
        checked(installed / name, size, sha)
        expected.add(name)
    actual = set()
    expected_dirs = set()
    for name in expected:
        parent = PurePosixPath(name).parent
        while str(parent) != '.':
            expected_dirs.add(str(parent))
            parent = parent.parent
    actual_dirs = set()
    for base, dirs, files in os.walk(installed, followlinks=False):
        for name in dirs:
            safe(Path(base) / name, directory=True)
            actual_dirs.add((Path(base) / name).relative_to(installed).as_posix())
        for name in files:
            actual.add((Path(base) / name).relative_to(installed).as_posix())
    require(actual == expected and actual_dirs == expected_dirs,
            'installed files changed or foreign files present')
    return installed


def verify_installed(root, data, manifest_sha):
    return verify_tree(root / 'installed', data, manifest_sha)


def verify_apk(path, archive):
    with zipfile.ZipFile(path) as zf:
        members = [i for i in zf.infolist() if i.filename == 'assets/game.droid']
        require(len(members) == 1, 'game.droid is missing or duplicated')
        item = members[0]
        require(item.file_size == archive['game_droid_bytes'], 'game.droid size mismatch')
        h = hashlib.sha256()
        with zf.open(item) as stream:
            for chunk in iter(lambda: stream.read(1024**2), b''):
                h.update(chunk)
        require(h.hexdigest() == archive['game_droid_sha256'], 'game.droid identity mismatch')


def preflight(root, data):
    facts = environment()
    original(root, data)
    probe_decoder(root, data)
    capacity = os.statvfs(root)
    free = capacity.f_bavail * capacity.f_frsize
    required = RESERVE
    if not os.path.lexists(root / 'installed') and not list(root.glob('.beta-install-*')):
        required += data['archive']['bytes'] + sum(row['bytes'] for row in data['donor_files'])
    require(free >= required, 'insufficient beta filesystem capacity including 1 GiB reserve')
    facts.update({'free_bytes': free, 'required_bytes': required,
                  'runtime_dependency_probe': 'pending_installed_runtime_probe'})
    return facts


def probe_runtime(root, data, manifest_sha):
    """Probe the pinned loader under the caller-held lock, without launching game.

    This checks direct ELF dependencies only; dlopen'd game libraries and a
    successful gameplay launch still need separate validation.
    """
    installed = verify_installed(root, data, manifest_sha)
    runtime = installed / 'runtime/gmloadernext.aarch64'
    require(any(name == 'runtime/gmloadernext.aarch64' for name, _, _ in runtime_files(data)),
            'pinned GMLoader missing from donor inventory')
    check_elf(runtime)
    linker = Path('/lib/ld-linux-aarch64.so.1')
    require(linker.is_file() and os.access(linker, os.X_OK), 'muOS AArch64 dynamic linker unavailable')
    library_dirs = []
    for relative_path in ('runtime/libs.aarch64', 'runtime/lib'):
        directory = installed / relative_path
        if directory.exists():
            safe(directory, directory=True)
            library_dirs.append(str(directory))
    require(library_dirs, 'pinned runtime library directories unavailable')
    environment = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C',
                   'LD_LIBRARY_PATH': ':'.join(library_dirs)}
    with subprocess.Popen([str(linker), '--list', str(runtime)], cwd=installed,
                          env=environment, stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT) as child:
        output = bytearray()
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ)
                deadline = time.monotonic() + 15
                while selector.get_map():
                    remaining = deadline - time.monotonic()
                    require(remaining > 0, 'runtime dependency probe timed out')
                    for key, _ in selector.select(min(remaining, 1)):
                        block = os.read(key.fd, 8192)
                        if not block:
                            selector.unregister(key.fileobj)
                        output.extend(block)
                        require(len(output) <= 65536, 'runtime dependency output exceeded limit')
                status = child.wait(timeout=max(0.1, deadline - time.monotonic()))
        except BaseException:
            child.kill()
            child.wait()
            raise
    require(status == 0 and b'not found' not in output.lower(),
            'runtime dependency probe failed or reports missing libraries')
    verify_installed(root, data, manifest_sha)
    return {'result': 'direct_runtime_dependencies_present',
            'limitation': 'dynamic game libraries and gameplay not validated'}


def install(root, data, manifest_sha):
    with lock(root):
        require(not os.path.lexists(root / '.beta-remove.json'),
                'interrupted removal must be resumed before installation')
        facts = preflight(root, data)
        if os.path.lexists(root / 'installed'):
            verify_installed(root, data, manifest_sha)
            return {'result': 'already_installed', 'environment': facts}
        stages = list(root.glob('.beta-install-*'))
        require(len(stages) <= 1, 'multiple interrupted beta stages; inspect before recovery')
        if stages:
            stage = safe(stages[0], directory=True)
            before = stage.stat()
            try:
                verify_tree(stage, data, manifest_sha)
            except (OSError, ValueError, KeyError, TypeError) as error:
                raise ValueError('interrupted beta stage is incomplete or contains unknown content; '
                                 'preserved for inspection: ' + str(error)) from error
            after = stage.stat()
            require((before.st_dev, before.st_ino, before.st_mtime_ns, before.st_ctime_ns) ==
                    (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_ctime_ns),
                    'interrupted stage changed during recovery verification')
            contract(root, manifest_sha)
            fsync_dir(stage)
            publish_new(stage, root / 'installed')
            fsync_dir(root)
            verify_installed(root, data, manifest_sha)
            return {'result': 'recovered_completed_install', 'environment': facts}
        donor = original(root, data)
        stage = Path(tempfile.mkdtemp(prefix='.beta-install-', dir=root))
        fsync_dir(root)
        # Never delete an incomplete stage: it remains inspectable after failure/interruption.
        marker = stage / 'install.json'
        with marker.open('x') as out:
            json.dump({'build_id': data['build_id'], 'manifest_sha256': manifest_sha}, out, sort_keys=True)
            out.flush(); os.fsync(out.fileno())
        for row in data['donor_files']:
            dst = stage / row['destination']
            dst.parent.mkdir(parents=True, exist_ok=True)
            with (donor / row['source']).open('rb') as src, dst.open('xb') as out:
                shutil.copyfileobj(src, out, 1024**2)
                if os.fstat(src.fileno()).st_mode & 0o111:
                    os.fchmod(out.fileno(), 0o755)
                out.flush(); os.fsync(out.fileno())
            checked(dst, row['bytes'], row['sha256'])
            fsync_dir(dst.parent)
        decoder = root / data['decoder']['path']
        raw = decoder.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == data['decoder']['sha256'], 'decoder changed')
        fd = os.memfd_create('beta-xdelta3', os.MFD_ALLOW_SEALING)
        try:
            with os.fdopen(os.dup(fd), 'wb') as output:
                output.write(raw); output.flush()
            os.fchmod(fd, 0o500)
            fcntl.fcntl(fd, fcntl.F_ADD_SEALS, fcntl.F_SEAL_SEAL | fcntl.F_SEAL_SHRINK |
                        fcntl.F_SEAL_GROW | fcntl.F_SEAL_WRITE)
            def limits():
                resource.setrlimit(resource.RLIMIT_FSIZE, (data['archive']['bytes'],) * 2)
                resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            with (stage / 'game.apk').open('xb') as out:
                result = subprocess.run(['/proc/self/fd/' + str(fd), '-d', '-c', '-D', '-R', '-s',
                                         str(donor / data['official']['relative_path']),
                                         str(root / data['patch']['path'])], stdout=out,
                                        stderr=subprocess.DEVNULL, timeout=600, pass_fds=(fd,),
                                        preexec_fn=limits, env={'PATH':'/usr/bin:/bin','LC_ALL':'C',
                                                               'TMPDIR':str(stage)})
                out.flush(); os.fsync(out.fileno())
            require(result.returncode == 0, 'xdelta failed: ' + str(result.returncode))
        finally:
            os.close(fd)
        checked(stage / 'game.apk', data['archive']['bytes'], data['archive']['sha256'])
        verify_apk(stage / 'game.apk', data['archive'])
        original(root, data)
        contract(root, manifest_sha)
        fsync_dir(stage)
        verify_tree(stage, data, manifest_sha)
        publish_new(stage, root / 'installed')
        fsync_dir(root)
        verify_installed(root, data, manifest_sha)
        return {'result': 'installed', 'environment': facts}


def remove(root, data, manifest_sha):
    with lock(root):
        journal = root / '.beta-remove.json'
        authority = {'build_id': data['build_id'], 'manifest_sha256': manifest_sha,
                     'files': [list(item) for item in runtime_files(data)]}
        if os.path.lexists(journal):
            safe(journal)
            require(journal.stat().st_size <= 65536 and
                    json.loads(journal.read_text(), object_pairs_hook=pairs) == authority,
                    'invalid removal journal; preserved for inspection')
        else:
            verify_installed(root, data, manifest_sha)
            with journal.open('x') as output:
                json.dump(authority, output, sort_keys=True)
                output.flush(); os.fsync(output.fileno())
            fsync_dir(root)
        installed = root / 'installed'
        if os.path.lexists(installed):
            safe(installed, directory=True)
            expected = {name: (size, sha) for name, size, sha in runtime_files(data)}
            expected_dirs = set()
            for name in expected:
                parent = PurePosixPath(name).parent
                while str(parent) != '.':
                    expected_dirs.add(str(parent)); parent = parent.parent
            for base, dirs, files in os.walk(installed, followlinks=False):
                for name in dirs:
                    path = Path(base) / name
                    safe(path, directory=True)
                    require(path.relative_to(installed).as_posix() in expected_dirs,
                            'foreign directory in interrupted removal')
                for name in files:
                    path = Path(base) / name
                    rel = path.relative_to(installed).as_posix()
                    if rel == 'install.json':
                        safe(path)
                        require(path.stat().st_size <= 4096 and
                                json.loads(path.read_text(), object_pairs_hook=pairs) ==
                                {'build_id': data['build_id'], 'manifest_sha256': manifest_sha},
                                'changed install marker during removal')
                    else:
                        require(rel in expected, 'foreign file in interrupted removal')
                        checked(path, *expected[rel])
            for name in expected:
                path = installed / name
                if os.path.lexists(path):
                    checked(path, *expected[name])
                    path.unlink(); fsync_dir(path.parent)
            marker = installed / 'install.json'
            if os.path.lexists(marker):
                marker.unlink(); fsync_dir(installed)
            for relative_dir in sorted(expected_dirs, key=lambda value: value.count('/'), reverse=True):
                directory = installed / relative_dir
                if os.path.lexists(directory):
                    safe(directory, directory=True)
                    directory.rmdir(); fsync_dir(directory.parent)
            installed.rmdir()
            fsync_dir(root)
        journal.unlink()
        fsync_dir(root)
        return {'result': 'removed', 'preserved': ['saves', 'logs', 'reports', 'package files']}


def report(root, data):
    # Only explicitly structured, allowlisted summaries; never copy saves or raw logs.
    allowed = {'build_id', 'run_id', 'device_model', 'os_version', 'architecture',
               'aspect', 'crt', 'lighting', 'difficulty', 'mode', 'exit_code',
               'signal', 'launch_result', 'cleanup_result', 'peak_rss_kib', 'min_memavailable_kib'}
    records = []
    directory = root / 'logs'
    if directory.exists():
        safe(directory, directory=True)
        files = sorted(directory.glob('run-*.json'))[-20:]
        for path in files:
            safe(path)
            require(path.stat().st_size <= 16384, 'oversized run summary')
            data_in = json.loads(path.read_text(), object_pairs_hook=pairs)
            require(isinstance(data_in, dict), 'invalid run summary')
            row = {k: v for k, v in data_in.items() if k in allowed and
                   (v is None or type(v) in (int, bool) or
                    (isinstance(v, str) and len(v) <= 120 and re.fullmatch(r'[A-Za-z0-9 ._:+-]*', v)))}
            records.append(row)
    reports = root / 'reports'
    reports.mkdir(exist_ok=True)
    safe(reports, directory=True)
    fd, raw = tempfile.mkstemp(prefix='.beta-report-', suffix='.tar.gz', dir=reports)
    name = f'ZeldaDOI-Beta-Report-{data["build_id"]}-{time.time_ns()}.tar.gz'
    try:
        with os.fdopen(fd, 'wb') as out:
            with tarfile.open(fileobj=out, mode='w:gz') as tar:
                payload = (json.dumps({'build_id': data['build_id'], 'runs': records}, indent=2) + '\n').encode()
                info = tarfile.TarInfo('summary.json'); info.size = len(payload); info.mode = 0o600
                tar.addfile(info, io.BytesIO(payload))
                body = b'Device model:\nWhat were you doing?\nExpected behavior:\nActual behavior:\nDoes it repeat?\nScreenshot or photo (optional):\n'
                info = tarfile.TarInfo('ISSUE_TEMPLATE.txt'); info.size = len(body); info.mode = 0o600
                tar.addfile(info, io.BytesIO(body))
            out.flush(); os.fsync(out.fileno())
        publish_new(raw, reports / name)
        fsync_dir(reports)
    finally:
        if os.path.exists(raw): os.unlink(raw)
    return {'result': 'report_created', 'path': str(reports / name), 'run_count': len(records)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('preflight', 'install', 'verify-runtime', 'remove', 'report'))
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    try:
        root = safe(args.root, directory=True)
        data = contract(root, args.manifest_sha256)
        if args.action == 'preflight': result = preflight(root, data)
        elif args.action == 'install': result = install(root, data, args.manifest_sha256)
        elif args.action == 'verify-runtime':
            with lock(root): result = probe_runtime(root, data, args.manifest_sha256)
        elif args.action == 'remove': result = remove(root, data, args.manifest_sha256)
        else: result = report(root, data)
        print(json.dumps(result, sort_keys=True))
        return 0
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, zipfile.BadZipFile) as error:
        print(json.dumps({'result': 'refused', 'reason': str(error)}, sort_keys=True))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
