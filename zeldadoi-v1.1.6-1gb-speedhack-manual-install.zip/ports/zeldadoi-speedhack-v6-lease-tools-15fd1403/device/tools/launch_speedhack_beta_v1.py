#!/usr/bin/env python3
"""Launch an installed ordinary-Random beta with a private save directory.

The caller supplies PortMaster's GPTOKEYB command.  This module holds the same
lock as installation for the complete session; it does not modify installed/.
"""
from __future__ import annotations
import argparse
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import threading
import time
import shlex
import stat
import subprocess
import sys
import tempfile
from types import FunctionType, SimpleNamespace

import speedhack_beta_device_v1 as device

LOG_LIMIT = 8 * 1024 * 1024
MAPPER_SHA256 = '38b4787b8870c5ff38f3d46c804cf239cf6a5a0717cc521d013700ce3eeb7d1d'
MAPPER_BYTES = 68136
MAPPER_PATHS = frozenset(('/mnt/mmc/MUOS/PortMaster/gptokeyb',
                          '/mnt/sdcard/MUOS/PortMaster/gptokeyb',
                          '/opt/system/Tools/PortMaster/gptokeyb',
                          '/opt/tools/PortMaster/gptokeyb'))


def mapper_command(value):
    words = shlex.split(value or '')
    if not words or words[0] not in MAPPER_PATHS or words[1:] not in ([], ['-1']):
        raise ValueError('a qualified PortMaster gptokeyb command is required')
    return words + ['gmloadernext.aarch64']


@contextlib.contextmanager
def mapper_snapshot(command):
    path = Path(command[0])
    if path.resolve(strict=True) != path:
        raise ValueError('mapper path alias refused')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    sealed = None
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size != MAPPER_BYTES:
            raise ValueError('mapper type or size is unqualified')
        raw = bytearray()
        while len(raw) < before.st_size:
            part = os.read(fd, min(65536, before.st_size - len(raw)))
            if not part:
                raise ValueError('short mapper snapshot')
            raw.extend(part)
        after = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if any(getattr(before, k) != getattr(after, k) for k in fields):
            raise ValueError('mapper changed during snapshot')
        digest = hashlib.sha256(raw).hexdigest()
        if digest != MAPPER_SHA256:
            raise ValueError('mapper identity mismatch')
        sealed = os.memfd_create('speedhack-beta-mapper', os.MFD_ALLOW_SEALING)
        with os.fdopen(os.dup(sealed), 'wb') as out:
            out.write(raw); out.flush()
        os.fchmod(sealed, 0o500)
        fcntl.fcntl(sealed, fcntl.F_ADD_SEALS, fcntl.F_SEAL_SEAL | fcntl.F_SEAL_SHRINK |
                    fcntl.F_SEAL_GROW | fcntl.F_SEAL_WRITE)
        yield sealed, digest
    finally:
        os.close(fd)
        if sealed is not None:
            os.close(sealed)


# Source-owned carrier keys rejected by the current whole-Users validator.
_SEEDED_KEYS = frozenset(('__ZDLF_DungeonGenerationSave_v1', '__ZDLF_RunSeedTemplateContext_v1',
    '__ZDLF_RunSeedCheckpoint_v2', '__ZDLF_RunSeedCheckpoint_v3',
    '__ZDLF_DungeonSeedCheckpoint_v1', '__ZDLF_DeterministicSaveMode_v1',
    '__ZDLF_RunSeedConsumedState_v1', '__ZDLF_RunSeedConsumedState_v2'))
_TRANSACTIONS = ('Users_Temp', 'Users_ZDLF_RunSeed_New_v2', 'Users_ZDLF_RunSeed_Previous_v2',
                 'Users_ZDLF_RunSeed_New_v3', 'Users_ZDLF_RunSeed_Previous_v3')


def guard_saves(saves, reader):
    """Refuse seeded or ambiguous Users before any loader or mapper runs."""
    for name in _TRANSACTIONS:
        if os.path.lexists(saves / name):
            raise ValueError('pending Users transaction requires separate review')
    path = saves / 'Users'
    if not os.path.lexists(path):
        return
    try:
        fd, before = reader._open_regular_single_link(path, maximum=reader.MAX_ARCHIVE_BYTES)
    except reader.SnapshotError as error:
        raise ValueError('Users archive refused: ' + str(error)) from error
    try:
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(reader.MAX_ARCHIVE_BYTES + 1)
        if len(raw) != before.st_size:
            raise ValueError('Users archive changed or was truncated')
        try:
            _, payload, _ = reader._parse_xzip(raw)
            reader._verify_unchanged(fd, before, 'Users')
        except reader.SnapshotError as error:
            raise ValueError('Users archive refused: ' + str(error)) from error
    finally:
        os.close(fd)
    def invalid_constant(_):
        raise ValueError('non-finite Users JSON number')
    # xzip stores buffer_string data, including its single NUL terminator.
    # Accept the existing unterminated host/reference form as well, but never
    # strip arbitrary padding or interior NULs from malformed input.
    if payload.endswith(b'\0'):
        payload=payload[:-1]
    if b'\0' in payload:
        raise ValueError('invalid Users string terminator')
    profiles = json.loads(payload.decode('utf-8'), object_pairs_hook=device.pairs,
                          parse_constant=invalid_constant)
    if not isinstance(profiles, list) or len(profiles) != 5:
        raise ValueError('Users profile shape is not supported')
    for profile in profiles:
        if not isinstance(profile, dict) or 'SaveData' not in profile:
            raise ValueError('Users profile shape is not supported')
        saved = profile['SaveData']
        if 'SpeedhackSeedMode' in profile and profile['SpeedhackSeedMode']!='Random':
            raise ValueError('seeded profile is unavailable in this beta')
        if _SEEDED_KEYS.intersection(profile) or (isinstance(saved, dict) and _SEEDED_KEYS.intersection(saved)):
            raise ValueError('seeded save carrier is unavailable in this beta')


def _run_transport(launcher, args, schema, override, cwd, environment, stdout, stderr):
    """Reuse V5 signal and environment transport with capped parent-side drains."""
    if override.use_dungeon_seed or override.use_run_seed:
        raise ValueError('beta accepts ordinary Random only')
    dungeon = launcher.resolve_dungeon_seed(override, schema)
    run_seed = launcher.resolve_run_seed(override, schema)
    if dungeon.enabled or run_seed.enabled:
        raise ValueError('beta accepts ordinary Random only')
    if override.telemetry != 'off':
        raise ValueError('beta launcher requires Telemetry=off')
    underlying = launcher._namespace['subprocess']
    children, threads = [], []
    truncated = [False]
    errors = []
    def drain(stream, output):
        total = 0
        try:
            while True:
                block = stream.read(65536)
                if not block: break
                keep = min(len(block), max(0, LOG_LIMIT - total))
                if keep: output.write(block[:keep]); total += keep
                if keep < len(block): truncated[0] = True
        except (OSError, ValueError) as error:
            errors.append(str(error))
        finally:
            stream.close()
    class ProcessProxy:
        def __getattr__(self, name):
            return getattr(underlying, name)
        def Popen(self, *pos, **kw):
            if kw.get('env') is None:
                return underlying.Popen(*pos, **kw)
            kw = dict(kw, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            child = underlying.Popen(*pos, **kw)
            children.append(child)
            for stream, output in ((child.stdout, stdout), (child.stderr, stderr)):
                thread = threading.Thread(target=drain, args=(stream, output), daemon=True)
                thread.start(); threads.append(thread)
            return child
    class OSProxy:
        environ = environment
        def __getattr__(self, name):
            return getattr(os, name)
    namespace = dict(launcher._namespace, subprocess=ProcessProxy(), os=OSProxy())
    original = launcher._namespace['_run_game']
    invoke = FunctionType(original.__code__, namespace, original.__name__,
                          original.__defaults__, original.__closure__)
    invoke.__kwdefaults__ = original.__kwdefaults__
    try:
        status = invoke(args, schema, override, dungeon, run_seed, None, None)
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
                try: child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait(timeout=10)
        for thread in threads: thread.join(timeout=10)
    if any(thread.is_alive() for thread in threads) or errors:
        raise ValueError('bounded game log capture failed')
    return status, (children[0].returncode if children else None), truncated[0]

def launch(root, manifest_sha, mapper):
    root = device.safe(Path(root), directory=True)
    with device.lock(root):
        data = device.contract(root, manifest_sha)
        installed = device.verify_installed(root, data, manifest_sha)
        probe = device.probe_runtime(root, data, manifest_sha)
        for directory in (root / 'saves', root / 'logs'):
            directory.mkdir(mode=0o700, exist_ok=True)
            device.safe(directory, directory=True)
        schema_path = root / 'config/options-override-schema.json'
        if not any(row['path'] == 'config/options-override-schema.json' for row in data['bundle_files']):
            raise ValueError('options schema absent from authenticated bundle')
        # Import only authenticated packaged launcher files, after contract verification.
        scripts = root / 'scripts'
        device.safe(scripts, directory=True)
        authenticated = {row['path'] for row in data['bundle_files']}
        if 'scripts/launch_with_options_override_v5.py' not in authenticated:
            raise ValueError('canonical launcher absent from authenticated bundle')
        for member in scripts.iterdir():
            if member.is_file() and member.suffix == '.py':
                if member.is_symlink() or 'scripts/' + member.name not in authenticated:
                    raise ValueError('unlisted Python file in launcher directory')
        for name, module in tuple(sys.modules.items()):
            if name.startswith(('launch_with_options_override', 'options_override',
                                'runseed_profile_', 'runtime_authority', 'bounded_runtime_lock')):
                origin = getattr(module, '__file__', None)
                if origin and Path(origin).resolve().parent != scripts.resolve():
                    raise ValueError('cached launcher module is outside authenticated package')
        sys.path.insert(0, str(scripts))
        import launch_with_options_override_v5 as launcher
        schema = launcher.load_schema(schema_path)
        override = launcher._parse_for_launcher(launcher.resolve_override(root), schema)
        if override.use_dungeon_seed or override.use_run_seed:
            raise ValueError('beta accepts ordinary Random only')
        if override.telemetry != 'off':
            raise ValueError('beta launcher requires Telemetry=off')
        if 'device/tools/snapshot_ordinary_save_carrier.py' not in authenticated:
            raise ValueError('source-derived save reader absent from authenticated bundle')
        import snapshot_ordinary_save_carrier as reader
        if Path(reader.__file__).resolve() != (root / 'device/tools/snapshot_ordinary_save_carrier.py').resolve():
            raise ValueError('save reader is outside authenticated package')
        guard_saves(root / 'saves', reader)
        command = mapper_command(mapper)
        env = dict(os.environ)
        env['LD_LIBRARY_PATH'] = str(installed / 'runtime/libs.aarch64')
        env['SDL_GAMECONTROLLERCONFIG'] = env.get('sdl_controllerconfig', env.get('SDL_GAMECONTROLLERCONFIG', ''))
        config_fd, config_name = tempfile.mkstemp(prefix='.beta-gmloader-', suffix='.json', dir=root)
        config = Path(config_name)
        stdout_fd = stderr_fd = None
        try:
            with os.fdopen(config_fd, 'wb') as output:
                output.write((json.dumps({'apk_path': str(installed / 'game.apk'), 'save_dir': str(root / 'saves'),
                                         'force_platform': 'os_android'}, sort_keys=True) + '\n').encode())
                output.flush(); os.fsync(output.fileno())
            stdout_fd, stdout_name = tempfile.mkstemp(prefix='beta-stdout-', suffix='.log', dir=root / 'logs')
            stderr_fd, stderr_name = tempfile.mkstemp(prefix='beta-stderr-', suffix='.log', dir=root / 'logs')
            args = SimpleNamespace(game_dir=root, command=[str(installed / 'runtime/gmloadernext.aarch64'), '-c', str(config)],
                                   scenario='beta-random', role='candidate', run_number=1,
                                   sampler=None, strict_validation=False)
            with mapper_snapshot(command) as (fd, mapper_sha), os.fdopen(stdout_fd, 'wb') as out, os.fdopen(stderr_fd, 'wb') as err:
                stdout_fd = stderr_fd = None
                process = subprocess.Popen(['/proc/self/fd/' + str(fd), *command[1:]],
                                           pass_fds=(fd,), cwd=installed, stdout=subprocess.DEVNULL,
                                           stderr=subprocess.DEVNULL)
                try:
                    try:
                        process.wait(timeout=0.25)
                    except subprocess.TimeoutExpired:
                        pass
                    else:
                        raise ValueError('PortMaster mapper exited before game launch')
                    status, raw_status, truncated = _run_transport(launcher, args, schema, override, installed, env, out, err)
                finally:
                    if process.poll() is None:
                        process.terminate()
                    try:
                        mapper_status = process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill(); mapper_status = process.wait(timeout=10)
                    out.flush(); os.fsync(out.fileno()); err.flush(); os.fsync(err.fileno())
            device.verify_installed(root, data, manifest_sha)
            run_id = str(time.time_ns())
            summary = {'build_id': data['build_id'], 'run_id': run_id, 'mode': 'Random',
                       'exit_code': raw_status if raw_status is not None and raw_status >= 0 else None,
                       'signal': -raw_status if raw_status is not None and raw_status < 0 else None,
                       'launch_result': 'finished', 'cleanup_result': 'mapper_stopped'}
            summary_path = root / 'logs' / ('run-' + run_id + '.json')
            with summary_path.open('xb') as output:
                output.write((json.dumps(summary, sort_keys=True, allow_nan=False) + '\n').encode())
                output.flush(); os.fsync(output.fileno())
            device.fsync_dir(root / 'logs')
            return {'schema': 'speedhack_beta_launch_v1', 'result': 'finished',
                    'launcher_status': status, 'raw_child_status': raw_status,
                    'logs_truncated': truncated, 'run_id': run_id, 'mapper_status': mapper_status,
                    'mapper_sha256': mapper_sha, 'runtime_probe': probe['result'],
                    'stdout_log': Path(stdout_name).name, 'stderr_log': Path(stderr_name).name,
                    'log_limit_bytes': LOG_LIMIT, 'physical_reviewed': False,
                    'release_approved': False}
        finally:
            if stdout_fd is not None: os.close(stdout_fd)
            if stderr_fd is not None: os.close(stderr_fd)
            config.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--mapper', default=os.environ.get('GPTOKEYB', ''))
    args = parser.parse_args(argv)
    try:
        result = launch(args.root, args.manifest_sha256, args.mapper)
    except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
        print(json.dumps({'schema': 'speedhack_beta_launch_v1', 'result': 'refused',
                          'error': str(error), 'physical_reviewed': False,
                          'release_approved': False}, allow_nan=False), file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True, allow_nan=False))
    return result['launcher_status']


if __name__ == '__main__':
    raise SystemExit(main())
