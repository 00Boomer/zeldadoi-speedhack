# ZeldaDOI Speedhack Edition

This patch requires a separately installed, supported Zelda: Dungeons of
Infinity v1.1.6 PortMaster game. Setup creates a separate installation for
the patch without copying existing player saves. Run opens that installation.
Restore rolls back the patch in that installation and preserves its saves.

Run ZeldaDOI Speedhack Installer, then ZeldaDOI Speedhack Launcher.
ZeldaDOI Speedhack Remover rolls back the patch and keeps its saves. The
GMLoader-Next license and corresponding source archives are included.

## Playing on the RG35XX SP

This patch targets the 1 GB RG35XX SP on muOS. It needs the supported
Zelda: Dungeons of Infinity v1.1.6 PortMaster installation and the system
Python supplied by muOS. Keep the original game installed. Setup creates a
separate game directory with its own profiles and saves. Run uses that
directory. Restore puts the original archive back in the separate directory
and keeps its profiles and saves. Use the untouched original port to play
with your original profiles.

Start with **Fast Lighting** and **CRT Off**. Standard lighting retains more
of the original effects and can slow down in dim rooms. Profile **Options**
offers 16:9, 3:2, 4:3 and 1:1 before gameplay. **Back** applies changes and
the visible **Cancel** row discards a preview. Set Lighting and CRT
independently. Fast CRT adds lightweight scanlines.

The separate installation ships with `EnableOverride=0` in
`options_override.ini`, so it uses profile preferences. With
`EnableOverride=1`, specified overrides take effect on the next launch and
leave the stored preferences intact. If an external setting forces a game
mode, disable the override and relaunch to select a mode in the menu.

## Dungeon Seed and Continue

Choose **Dungeon Seed** in the New Game menu and record your V6 seed if you
want to revisit the dungeon. To start another seeded game, use **Quit to
Desktop**, then relaunch. **Random** is also available from New Game.

The same seed and saved generation rules reproduce the tested dungeon setup.
Initial Shop stock, quantities and base prices also depend on the shop and
the inventory and progression inputs at generation time. Coupons can change
the price you see. Combat, drops and treasure rewards use gameplay RNG.
Some generation retries and fallback paths were outside the tested scope.

Save at a SaveTent and select **Continue** on the same profile after starting
a fresh game process. Continue restores the saved generation context and
consumes the checkpoint once. Reach a SaveTent again to create the next
checkpoint. Use the game's **Quit to Desktop** for a normal exit.

The **Loading…** cue can flash briefly during a fast Continue. Wait for
gameplay or the game's error message before pressing Continue again.

### If launch reports an interrupted save

Close the game and installer. Preserve a verified copy of the entire
save/profile folder, including any `Users` transaction siblings and unknown
files. Keep the original files in place. Restore rolls back the game patch.
A readable backup may contain a checkpoint already used, so retain it for
review and keep it out of the active `Users` slot.

The supported manual recovery case requires authenticated evidence that the
active `Users` already consumed the checkpoint and that
`Users_ZDLF_RunSeed_Previous_v2` is exactly the older checkpoint. Verify in
a disposable copy that there is no conflicting `New` file or transaction,
that preserving Previous outside the active save directory leaves all five
profiles and foreign files intact, and that Continue remains unavailable.
Keep the game stopped for case-specific recovery if chronology is uncertain,
another transaction file exists, or active `Users` is missing or invalid.

## Using a custom character sheet

Use a compatible v1.1.6 character sprite sheet that you have permission to
use. With the game closed, copy the PNG into the patched game's
`saves/data/Characters/1/` directory. Create missing folders with that
capitalization and keep the original copy of your sheet. If the first slot
already has a sheet, preserve it before making any change. Choose the first
character in the character picker when creating a new profile. The character
choice and the player profile number are separate, so an unused player
profile is suitable for trying the first character.

The handheld check used one 128 × 448 pixel RGBA PNG laid out as a v1.1.6
character sheet. It covered visible movement, saving and reloading the
character on fresh Continue. Use a sheet with the matching frame layout.
Other sizes, layouts and palette files were outside that check.

## When launcher logs are full

Use this procedure after the message `private log capacity reached; retain logs before another session`.
The guarded launcher stores up to 64 session logs. For a private test, wait
until any pending diagnostic logs have been read back.

1. Power off the handheld and mount the SD card. Show hidden files. In
   `ports/zeldadoi-speedhack-v6-lease-tools-15fd1403/`, find
   `.zeldadoi-speedhack-launcher-logs/`. Its `OWNER` must be a regular file
   containing `org.zeldadoi.speedhack.portmaster-launcher-log` on one line.
2. Create a fresh empty folder at the root of that same card, outside
   `ports/` and `ROMS/`. Move only the hidden log directory into it as one
   folder. Cancel any prompt to copy, merge or replace. Leave the tools
   directory, game directories and saves in place. Keep the archived logs
   private.
3. Safely eject the card and use the normal launcher. It will create a fresh
   log directory. If a different error appears, retain the archive and error
   for review.
